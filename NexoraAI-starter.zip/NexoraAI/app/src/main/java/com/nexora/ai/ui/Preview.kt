package com.nexora.ai.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.viewinterop.AndroidView

private const val POLICY =
    "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'unsafe-inline'; " +
    "style-src 'unsafe-inline'; img-src data: blob:; font-src data:; media-src data: blob:\">"

private fun page(code: String, language: String): String {
    val body = when (language) {
        "css" -> "<style>$code</style><h1>Heading</h1><p>Sample <a href='#'>link</a></p><button>Button</button>"
        "javascript" -> "<pre id='out'></pre><script>const o=document.getElementById('out');" +
            "console.log=(...a)=>o.textContent+=a.join(' ')+'\\n';window.onerror=m=>console.log('Error:',m);</script>" +
            "<script>$code</script>"
        else -> code
    }
    return "<!DOCTYPE html>$POLICY<meta name='viewport' content='width=device-width,initial-scale=1'>$body"
}

/** Runs generated web code with no app bridge, no file access and network loading restricted. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Preview(code: String, language: String, modifier: Modifier) {
    val html = page(code, language)
    AndroidView(
        modifier = modifier.clipToBounds(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.blockNetworkLoads = true
                webViewClient = object : WebViewClient() {
                    // Block all navigation away from the preview.
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
                }
            }
        },
        update = {
            if (it.tag != html) {
                it.tag = html
                it.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
            }
        },
        onRelease = { it.destroy() }
    )
}
