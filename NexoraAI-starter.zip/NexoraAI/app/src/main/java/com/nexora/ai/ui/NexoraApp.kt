package com.nexora.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun NexoraApp(vm: MainViewModel = viewModel()) {
    BackHandler(enabled = vm.screen != Screen.HOME) { vm.screen = Screen.HOME }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp)) {
            if (vm.screen != Screen.HOME) TextButton(onClick = { vm.screen = Screen.HOME }) { Text("‹ Home") }
            when (vm.screen) {
                Screen.HOME -> Dashboard(vm)
                Screen.CHAT -> ChatScreen(vm)
                Screen.EDITOR -> EditorScreen(vm)
                Screen.HISTORY -> HistoryScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
private fun Dashboard(vm: MainViewModel) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(40.dp))
        Text("Nexora", fontFamily = FontFamily.Serif, fontSize = 40.sp, color = MaterialTheme.colorScheme.primary)
        Text("What shall we build today?", color = Muted)
        Spacer(Modifier.height(12.dp))
        HomeCard("New chat", "Write, plan and generate code") { vm.newChat() }
        HomeCard("Coding Studio", "Edit, preview and save code") { vm.screen = Screen.EDITOR }
        HomeCard("Chat history", "Continue or delete past chats") { vm.screen = Screen.HISTORY }
        HomeCard("Settings", "Gemini API key and model") { vm.screen = Screen.SETTINGS }
    }
}

@Composable
private fun HomeCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = OffWhite)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Muted)
        }
    }
}

@Composable
private fun HistoryScreen(vm: MainViewModel) {
    val list by vm.conversations.collectAsStateWithLifecycle()
    var pending by remember { mutableStateOf<Long?>(null) }
    if (list.isEmpty()) Text("No chats yet.", color = Muted)
    LazyColumn {
        items(list, key = { it.id }) { c ->
            Row(Modifier.fillMaxWidth().clickable { vm.open(c.id) }.padding(vertical = 8.dp)) {
                Text(c.title, Modifier.weight(1f).padding(top = 12.dp))
                TextButton(onClick = { pending = c.id }) { Text("Delete") }
            }
            HorizontalDivider()
        }
    }
    pending?.let { id ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Delete this chat?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.delete(id); pending = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel) {
    val saved by vm.settings.collectAsStateWithLifecycle()
    var key by remember(saved) { mutableStateOf(saved.apiKey) }
    var model by remember(saved) { mutableStateOf(saved.model) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation()
        )
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model ID") })
        Button(onClick = { vm.saveSettings(key, model); vm.screen = Screen.HOME }) { Text("Save") }
        Text("Your messages are sent to Google's Gemini API. The key is stored encrypted on this device.", color = Muted)
    }
}
