package com.nexora.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private const val SYSTEM_PROMPT = """You are Nexora, a careful coding partner and writing assistant.
- Reply in the user's language (Bengali or English).
- For complex requests, state a short numbered plan, then carry it out.
- When debugging, name the root cause before giving the fix.
- Put every piece of code in a fenced block with a language tag.
- For web pages, return one self-contained HTML file with inline CSS and JavaScript, using no external resources.
- Say when you are unsure. You cannot control the phone, run code or save files yourself, so never claim that you did."""

class GeminiClient {
    private val http = OkHttpClient.Builder()
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    /** Emits text chunks as they arrive (server-sent events). */
    fun stream(settings: Settings, history: List<Message>): Flow<String> = flow {
        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject().put("role", it.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", contents)

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${settings.model}:streamGenerateContent?alt=sse")
            .header("x-goog-api-key", settings.apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val call = http.newCall(request)
        // Cancelling the coroutine also aborts a blocked network read.
        @OptIn(kotlinx.coroutines.InternalCoroutinesApi::class)
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion(onCancelling = true) { call.cancel() }
        try {
            call.execute().use { response ->
                val source = response.body?.source() ?: throw IOException("Empty response")
                if (!response.isSuccessful) {
                    val raw = source.readUtf8()
                    val message = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }
                        .getOrDefault(raw.take(300))
                    throw IOException("Gemini error ${response.code}: $message")
                }
                var finish = ""
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val candidate = JSONObject(line.removePrefix("data:").trim())
                        .optJSONArray("candidates")?.optJSONObject(0) ?: continue
                    val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val text = part.optString("text")
                        if (text.isNotEmpty() && !part.optBoolean("thought")) emit(text)
                    }
                    finish = candidate.optString("finishReason", finish)
                }
                if (finish != "STOP") throw IOException("Reply is incomplete (${finish.ifEmpty { "connection ended" }})")
            }
        } finally {
            handle?.dispose()
        }
    }.flowOn(Dispatchers.IO)
}
