package com.nexora.ai.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.dataStore by preferencesDataStore("settings")

data class Settings(val apiKey: String = "", val model: String = DEFAULT_MODEL)

const val DEFAULT_MODEL = "gemini-3.8-flash"

/** DataStore settings. The API key is encrypted with an Android Keystore key. */
class SettingsStore(private val context: Context) {
    private val keyPref = stringPreferencesKey("api_key_enc")
    private val modelPref = stringPreferencesKey("model")

    val settings = context.dataStore.data.map { p ->
        Settings(
            apiKey = p[keyPref]?.let { runCatching { decrypt(it) }.getOrNull() }.orEmpty(),
            model = p[modelPref] ?: DEFAULT_MODEL
        )
    }

    suspend fun save(apiKey: String, model: String) {
        context.dataStore.edit {
            it[keyPref] = encrypt(apiKey.trim())
            it[modelPref] = model.trim().ifEmpty { DEFAULT_MODEL }
        }
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build()
            )
            generateKey()
        }
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, secretKey()) }
        return Base64.encodeToString(c.iv + c.doFinal(plain.toByteArray()), Base64.NO_WRAP)
    }

    private fun decrypt(data: String): String {
        val bytes = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes, 0, 12))
        return String(c.doFinal(bytes, 12, bytes.size - 12))
    }

    private companion object { const val ALIAS = "nexora_api_key" }
}
