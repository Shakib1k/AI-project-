package com.nexora.ai.core

enum class TokenType { COMMENT, STRING, KEYWORD, NUMBER, TAG }

data class Token(val start: Int, val end: Int, val type: TokenType)

/** Lightweight regex highlighter. It colours common syntax; it is not a full parser. */
object Highlighter {
    private val keywords = mapOf(
        "python" to "False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield",
        "javascript" to "async await break case catch class const continue default delete do else export extends false finally for from function if import in instanceof let new null of return static super switch this throw true try typeof undefined var void while yield",
        "java" to "abstract boolean break byte case catch char class continue default do double else enum extends false final finally float for if implements import instanceof int interface long new null package private protected public record return short static super switch this throw throws true try var void volatile while",
        "kotlin" to "as break by class companion continue data do else false for fun if import in interface is null object override package private protected public return sealed super suspend this throw true try typealias val var when while"
    ).mapValues { it.value.split(" ").toSet() }

    fun normalize(language: String) = when (val l = language.lowercase()) {
        "py" -> "python"
        "js" -> "javascript"
        "kt" -> "kotlin"
        else -> l
    }

    private const val DQ = "\"(?:\\\\.|[^\"\\\\\\n])*\""
    private const val SQ = "'(?:\\\\.|[^'\\\\\\n])*'"

    fun tokenize(code: String, language: String): List<Token> {
        val lang = normalize(language)
        val markup = lang == "html" || lang == "xml"
        val comment = when {
            markup -> "<!--[\\s\\S]*?-->"
            lang == "python" -> "#[^\\n]*"
            lang == "css" -> "/\\*[\\s\\S]*?\\*/"
            else -> "/\\*[\\s\\S]*?\\*/|//[^\\n]*"
        }
        val string = when {
            lang == "python" -> "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|$DQ|$SQ"
            lang == "javascript" -> "`(?:\\\\.|[^`\\\\])*`|$DQ|$SQ"
            else -> "$DQ|$SQ"
        }
        val tag = if (markup) "</?[A-Za-z][\\w.:-]*|/?>" else "(?!)"
        val regex = Regex("($comment)|($string)|($tag)|(\\b\\d+(?:\\.\\d+)?\\b)|([A-Za-z_]\\w*)")
        val words = keywords[lang].orEmpty()

        return regex.findAll(code).mapNotNull { m ->
            val g = m.groups
            val type = when {
                g[1] != null -> TokenType.COMMENT
                g[2] != null -> TokenType.STRING
                g[3] != null -> TokenType.TAG
                g[4] != null -> TokenType.NUMBER
                m.value in words -> TokenType.KEYWORD
                else -> null
            }
            type?.let { Token(m.range.first, m.range.last + 1, it) }
        }.toList()
    }
}
