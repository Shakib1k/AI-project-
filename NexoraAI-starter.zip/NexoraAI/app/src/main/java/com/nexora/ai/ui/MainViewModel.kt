package com.nexora.ai.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatState(val streaming: String = "", val busy: Boolean = false, val error: String? = null)

data class Draft(val language: String, val code: String)

enum class Screen { HOME, CHAT, EDITOR, HISTORY, SETTINGS }

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).chat()
    private val store = SettingsStore(app)
    private val gemini = GeminiClient()
    private var job: Job? = null

    var screen by mutableStateOf(Screen.HOME)
    var draft by mutableStateOf(Draft("html", ""))
    var input by mutableStateOf("")

    private val conversationId = MutableStateFlow<Long?>(null)
    private val _chat = MutableStateFlow(ChatState())
    val chat = _chat.asStateFlow()

    val settings = store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val conversations = dao.conversations().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val messages = conversationId
        .flatMapLatest { if (it == null) flowOf(emptyList()) else dao.messages(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun saveSettings(key: String, model: String) = viewModelScope.launch { store.save(key, model) }

    fun openEditor(language: String, code: String) {
        draft = Draft(language, code)
        screen = Screen.EDITOR
    }

    fun newChat() { stop(); conversationId.value = null; _chat.value = ChatState(); screen = Screen.CHAT }

    fun open(id: Long) { stop(); conversationId.value = id; _chat.value = ChatState(); screen = Screen.CHAT }

    fun delete(id: Long) = viewModelScope.launch {
        if (conversationId.value == id) { stop(); conversationId.value = null; _chat.value = ChatState() }
        dao.delete(id)
    }

    fun stop() { job?.cancel() }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || _chat.value.busy) return
        val current = settings.value
        if (current.apiKey.isBlank()) {
            _chat.value = ChatState(error = "Add your Gemini API key in Settings first.")
            return
        }
        input = ""
        _chat.value = ChatState(busy = true)
        job = viewModelScope.launch {
            val thisJob = coroutineContext[Job]
            val reply = StringBuilder()
            var id: Long? = null
            var error: String? = null
            try {
                val chatId = conversationId.value
                    ?: dao.insertConversation(Conversation(title = text.take(60))).also { conversationId.value = it }
                id = chatId
                dao.insertMessage(Message(conversationId = chatId, role = "user", text = text))
                gemini.stream(current, dao.messagesOnce(chatId)).collect {
                    reply.append(it)
                    _chat.value = ChatState(streaming = reply.toString(), busy = true)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Request failed"
            } finally {
                withContext(NonCancellable) {
                    // Keep partial replies, unless the conversation was deleted meanwhile.
                    val chatId = id
                    if (chatId != null && reply.isNotEmpty()) runCatching {
                        dao.insertMessage(Message(conversationId = chatId, role = "model", text = reply.toString()))
                    }
                    // A cancelled job must not overwrite the state of a newer one.
                    if (job === thisJob) _chat.value = ChatState(error = error)
                }
            }
        }
    }
}
