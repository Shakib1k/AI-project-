package com.nexora.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Charcoal = Color(0xFF1C1B19)
val Panel = Color(0xFF282724)
val OffWhite = Color(0xFFF2EFE8)
val Terracotta = Color(0xFFD9825F)
val Amber = Color(0xFFE5B567)
val Muted = Color(0xFFA8A398)

private val colors = darkColorScheme(
    primary = Terracotta, onPrimary = Charcoal,
    secondary = Amber, onSecondary = Charcoal,
    background = Charcoal, onBackground = OffWhite,
    surface = Charcoal, onSurface = OffWhite,
    surfaceVariant = Panel, onSurfaceVariant = Muted,
    surfaceContainer = Panel, surfaceContainerHighest = Panel,
    outline = Color(0xFF4A4741)
)

@Composable
fun NexoraTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = colors, content = content)
