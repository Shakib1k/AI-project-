package com.nexora.ai.core

sealed interface Segment {
    data class Text(val text: String) : Segment
    data class Code(val language: String, val code: String, val complete: Boolean) : Segment
}

/** Splits a Markdown reply into prose and fenced code blocks. Safe on half-streamed input. */
object CodeBlocks {
    private val fence = Regex("^\\s{0,3}(`{3,})\\s*([^`]*)$")

    fun parse(markdown: String): List<Segment> {
        val out = mutableListOf<Segment>()
        val buf = mutableListOf<String>()
        var open: String? = null
        var lang = ""

        fun flushText() {
            val t = buf.joinToString("\n").trim()
            if (t.isNotEmpty()) out += Segment.Text(t)
            buf.clear()
        }

        for (line in markdown.replace("\r\n", "\n").split("\n")) {
            val ticks = open
            if (ticks == null) {
                val m = fence.find(line)
                if (m != null) {
                    flushText()
                    open = m.groupValues[1]
                    lang = m.groupValues[2].trim().substringBefore(' ').lowercase()
                } else buf += line
            } else {
                val t = line.trim()
                if (t.length >= ticks.length && t.all { it == '`' }) {
                    out += Segment.Code(lang, buf.joinToString("\n"), true)
                    buf.clear()
                    open = null
                } else buf += line
            }
        }
        if (open != null) out += Segment.Code(lang, buf.joinToString("\n"), false) else flushText()
        return out
    }

    fun fileName(language: String): String = when (language.lowercase()) {
        "python", "py" -> "script.py"
        "html" -> "index.html"
        "css" -> "style.css"
        "javascript", "js" -> "script.js"
        "java" -> "Main.java"
        "kotlin", "kt" -> "Main.kt"
        "xml" -> "layout.xml"
        else -> "snippet.txt"
    }

    fun isPreviewable(language: String) = language.lowercase() in setOf("html", "css", "javascript", "js")
}
