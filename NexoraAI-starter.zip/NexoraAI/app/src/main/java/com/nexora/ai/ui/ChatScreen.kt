package com.nexora.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.ai.core.CodeBlocks
import com.nexora.ai.core.Segment

@Composable
fun ColumnScope.ChatScreen(vm: MainViewModel) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val state by vm.chat.collectAsStateWithLifecycle()
    val list = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) list.animateScrollToItem(messages.lastIndex)
    }

    LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(messages, key = { it.id }) { MessageView(it.role, it.text, vm) }
        if (state.streaming.isNotEmpty()) item { MessageView("model", state.streaming, vm) }
    }
    if (state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            vm.input, { vm.input = it }, Modifier.weight(1f), maxLines = 5,
            placeholder = { Text("Ask Nexora…") }, shape = RoundedCornerShape(20.dp)
        )
        Spacer(Modifier.width(8.dp))
        Button(onClick = { if (state.busy) vm.stop() else vm.send() }) { Text(if (state.busy) "Stop" else "Send") }
    }
}

@Composable
private fun MessageView(role: String, text: String, vm: MainViewModel) {
    val user = role == "user"
    Column(
        Modifier.fillMaxWidth()
            .then(if (user) Modifier.background(Panel, RoundedCornerShape(16.dp)).padding(12.dp) else Modifier),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        CodeBlocks.parse(text).forEach { segment ->
            when (segment) {
                is Segment.Text -> SelectionContainer { Text(segment.text) }
                is Segment.Code -> ArtifactCard(segment) { vm.openEditor(segment.language, segment.code) }
            }
        }
    }
}

@Composable
private fun ArtifactCard(block: Segment.Code, onOpen: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(CodeBlocks.fileName(block.language), Modifier.weight(1f), color = Amber)
                TextButton(onClick = onOpen, enabled = block.complete) {
                    Text(if (block.complete) "Open" else "Incomplete")
                }
            }
            Text(
                block.code.lineSequence().take(8).joinToString("\n"),
                Modifier.horizontalScroll(rememberScrollState()),
                fontFamily = FontFamily.Monospace, fontSize = 12.sp, softWrap = false
            )
        }
    }
}
