package com.nexora.ai.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.ai.core.*

private val languages = listOf("html", "css", "javascript", "python", "java", "kotlin", "xml")

private class CodeColors(private val language: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val builder = AnnotatedString.Builder(text.text)
        // Skip colouring very large files to keep typing responsive.
        if (text.length <= 30_000) Highlighter.tokenize(text.text, language).forEach {
            val color = when (it.type) {
                TokenType.COMMENT -> Muted
                TokenType.STRING -> Color(0xFFA9C98B)
                TokenType.KEYWORD -> Terracotta
                TokenType.NUMBER -> Amber
                TokenType.TAG -> Color(0xFF8FB8D8)
            }
            builder.addStyle(SpanStyle(color = color), it.start, it.end)
        }
        return TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
    }
}

@Composable
fun ColumnScope.EditorScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val language = Highlighter.normalize(vm.draft.language)
    var field by remember { mutableStateOf(TextFieldValue(vm.draft.code)) }
    var preview by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    fun update(value: TextFieldValue) {
        field = value
        vm.draft = vm.draft.copy(code = value.text)
    }

    // The system file picker grants access to the chosen file, so no storage permission is needed.
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(vm.draft.code.toByteArray()) }
            }.isSuccess
            Toast.makeText(context, if (ok) "ফাইল সেভ হয়েছে" else "Save failed", Toast.LENGTH_SHORT).show()
        }
    }

    Row(Modifier.horizontalScroll(rememberScrollState())) {
        Box {
            TextButton(onClick = { menu = true }) { Text("$language ▾") }
            DropdownMenu(menu, { menu = false }) {
                languages.forEach { l ->
                    DropdownMenuItem(text = { Text(l) }, onClick = { vm.draft = vm.draft.copy(language = l); menu = false })
                }
            }
        }
        if (Indenter.canFormat(language)) TextButton(onClick = {
            val formatted = Indenter.format(field.text, language)
            update(TextFieldValue(formatted, TextRange(formatted.length)))
        }) { Text("Re-indent") }
        if (CodeBlocks.isPreviewable(language)) {
            TextButton(onClick = { preview = !preview }) { Text(if (preview) "Code" else "Run preview") }
        }
        TextButton(onClick = { save.launch(CodeBlocks.fileName(language)) }) { Text("Save") }
    }

    val area = Modifier.weight(1f).fillMaxWidth()
    if (preview && CodeBlocks.isPreviewable(language)) {
        Preview(vm.draft.code, language, area)
    } else {
        Box(area.background(Panel).verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())) {
            BasicTextField(
                value = field,
                onValueChange = { next ->
                    val cursor = next.selection.start
                    val typedNewline = next.text.length == field.text.length + 1 &&
                        next.selection.collapsed && cursor > 0 && next.text[cursor - 1] == '\n'
                    update(
                        if (typedNewline) Indenter.autoIndent(next.text, cursor, language)
                            .let { TextFieldValue(it.text, TextRange(it.cursor)) }
                        else next
                    )
                },
                modifier = Modifier.padding(12.dp).widthIn(min = 320.dp),
                textStyle = TextStyle(color = OffWhite, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                cursorBrush = SolidColor(Terracotta),
                keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, capitalization = KeyboardCapitalization.None),
                visualTransformation = CodeColors(language)
            )
        }
    }
}
