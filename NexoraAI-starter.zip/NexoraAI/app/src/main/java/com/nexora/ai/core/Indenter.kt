package com.nexora.ai.core

data class EditResult(val text: String, val cursor: Int)

object Indenter {
    private const val UNIT = "    "

    /** Call after the user typed a newline; cursor is just after it. */
    fun autoIndent(text: String, cursor: Int, language: String): EditResult {
        if (cursor <= 0 || cursor > text.length || text[cursor - 1] != '\n') return EditResult(text, cursor)
        val lineStart = text.lastIndexOf('\n', cursor - 2) + 1
        val previous = text.substring(lineStart, cursor - 1)
        val base = previous.takeWhile { it == ' ' || it == '\t' }
        val last = previous.trimEnd().lastOrNull()
        val python = Highlighter.normalize(language) in setOf("python")
        val opens = last == '{' || last == '(' || last == '[' || (python && last == ':')
        val indent = if (opens) base + UNIT else base
        // Enter between an opening and closing bracket puts the closer on its own line.
        val closer = mapOf('{' to '}', '(' to ')', '[' to ']')[last]
        val tail = if (closer != null && text.getOrNull(cursor) == closer) "\n$base" else ""
        return EditResult(text.substring(0, cursor) + indent + tail + text.substring(cursor), cursor + indent.length)
    }

    private val reindentable = setOf("javascript", "java", "kotlin", "css")

    fun canFormat(language: String) = Highlighter.normalize(language) in reindentable

    /**
     * Re-indents brace languages by bracket depth. Lines inside multi-line strings
     * and comments are left exactly as they were.
     */
    fun format(code: String, language: String): String {
        if (!canFormat(language)) return code
        val tokens = Highlighter.tokenize(code, language)
            .filter { it.type == TokenType.STRING || it.type == TokenType.COMMENT }
        // Multi-line template/raw strings and unusual literals (e.g. JS regex) are risky to rewrite.
        if (code.contains("\"\"\"") ||
            tokens.any { it.type == TokenType.STRING && '\n' in code.substring(it.start, it.end) }
        ) return code

        val masked = StringBuilder(code)
        for (t in tokens) for (i in t.start until t.end) if (masked[i] != '\n') masked.setCharAt(i, '_')

        val original = code.split("\n")
        val shape = masked.toString().split("\n")
        var depth = 0
        var offset = 0
        return original.indices.joinToString("\n") { i ->
            val line = original[i]
            val inside = tokens.any { it.start < offset && offset < it.end }
            offset += line.length + 1
            val m = shape[i].trim()
            val closers = m.takeWhile { it in "})]" }.length
            val level = (depth - closers).coerceAtLeast(0)
            depth = (depth + m.count { it in "{([" } - m.count { it in "})]" }).coerceAtLeast(0)
            when {
                inside -> line
                line.isBlank() -> ""
                else -> UNIT.repeat(level) + line.trim()
            }
        }
    }
}
