# Nexora AI (starter, phase 1)

**Build status: not compiled or run on Android.** No Android SDK was available when this was written.
Expect to fix possible build errors on the first sync.

## Build
1. Open this folder in Android Studio (JDK 17 or newer) and let Gradle sync.
2. If the Gradle wrapper is missing, set Gradle 8.14.3 in Android Studio.
3. Run on a device with Android 8.0 (API 26) or newer.
4. In Settings, paste your Gemini API key. Default model: `gemini-3.8-flash` (editable).

## Included
- Dark charcoal / terracotta dashboard
- Streaming Gemini chat that sends the conversation history, with Stop
- Code blocks shown as cards that open in the editor
- Editor: basic syntax colouring, auto-indent, re-indent (JS, Java, Kotlin, CSS)
- Preview for HTML, CSS and JavaScript only. Python, Java, Kotlin and XML can be edited and saved, not run
- Save through the Android file picker (no storage permission)
- Room chat history, DataStore settings, API key encrypted with Android Keystore

## Not built yet
Live voice and barge-in, floating orb, screen vision, phone and MT Manager automation, task progress UI.

## Security notes
- A key typed into an app on your own phone suits personal use. For a public app, call Gemini
  through your own backend or a managed service instead of shipping or collecting raw keys.
- The preview restricts network loading and navigation. It is not a guaranteed sandbox,
  so read unfamiliar code before running it.

## Before building automation
Google Play's AccessibilityService policy prohibits using the API to autonomously initiate,
plan and execute actions or decisions, while allowing deterministic rule-based automation.
Verified accessibility tools have an exemption tied to helping people with disabilities.
Read the current policy: https://support.google.com/googleplay/android-developer/answer/10964491
