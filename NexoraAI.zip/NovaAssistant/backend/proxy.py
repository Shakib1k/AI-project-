"""Small Gemini proxy: the Google key stays on your server.

  pip install aiohttp
  export GEMINI_API_KEY=...  PROXY_TOKEN=$(openssl rand -hex 32)
  python proxy.py            # serve it behind an HTTPS reverse proxy

A single shared token suits personal use. For public distribution add per-user
authentication, revocation, rate limits and spending limits.
"""
import asyncio, hmac, os, re
from aiohttp import ClientSession, WSMsgType, web

KEY = os.environ["GEMINI_API_KEY"]
TOKEN = os.environ["PROXY_TOKEN"]
if len(TOKEN) < 24:
    raise SystemExit("PROXY_TOKEN must be at least 24 characters")
HOST = "generativelanguage.googleapis.com"
WS_PATH = "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
ALLOWED = re.compile(r"^/v1beta/models(/[A-Za-z0-9._-]+(:generateContent)?)?$")


def authorize(request):
    if not hmac.compare_digest(request.headers.get("x-proxy-token", "").encode(), TOKEN.encode()):
        raise web.HTTPUnauthorized()


async def rest(request):
    authorize(request)
    if not ALLOWED.match(request.path) or request.method not in ("GET", "POST"):
        raise web.HTTPNotFound()
    async with request.app["http"].request(
        request.method, f"https://{HOST}{request.path}", params=request.query,
        data=await request.read(), allow_redirects=False,
        headers={"x-goog-api-key": KEY, "content-type": "application/json"},
    ) as upstream:
        return web.Response(status=upstream.status, body=await upstream.read(), content_type="application/json")


async def live(request):
    authorize(request)
    client = web.WebSocketResponse(max_msg_size=8_000_000, heartbeat=20)
    await client.prepare(request)
    async with request.app["http"].ws_connect(
        f"wss://{HOST}{WS_PATH}", headers={"x-goog-api-key": KEY}, max_msg_size=8_000_000
    ) as google:
        async def pipe(source, target):
            async for message in source:
                if message.type == WSMsgType.TEXT:
                    await target.send_str(message.data)
                elif message.type == WSMsgType.BINARY:
                    await target.send_bytes(message.data)
        tasks = [asyncio.create_task(pipe(client, google)), asyncio.create_task(pipe(google, client))]
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in tasks:
            task.cancel()
    await client.close()
    return client


async def session(app):
    app["http"] = ClientSession()
    yield
    await app["http"].close()


app = web.Application(client_max_size=8 * 1024 * 1024)
app.cleanup_ctx.append(session)
app.router.add_get(WS_PATH, live)
app.router.add_route("*", "/{tail:.*}", rest)
if __name__ == "__main__":
    web.run_app(app, host="127.0.0.1", port=int(os.environ.get("PORT", 8080)), access_log=None)
