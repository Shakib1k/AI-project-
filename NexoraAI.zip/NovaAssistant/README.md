# Nova Assistant (Android, Kotlin, Jetpack Compose)

A voice-first personal assistant on Google Gemini. Default name: **Maya**.

## Verification status (read first)
| Check | Result |
|---|---|
| 12 unit tests for the platform-independent logic (`core/`) | Passed, using Kotlin 2.0.21 and a minimal JUnit stand-in |
| Kotlin syntax, all files | No syntax errors |
| XML resources, proxy script, CI YAML | Parse |
| **Android compile / APK** | **Not done.** No Android SDK or Google Maven access where this was written |
| **Run on a device or against the live Gemini API** | **Not done** |

Expect that the first real build may report some compile errors. API formats follow Google's docs as read on 27 Nov 2026.

## Build
**Android Studio:** open this folder (a recent version supporting Android Gradle Plugin 8.11), let it sync, install SDK 35, then Run on an Android 10+ phone.
Command line (JDK 17, SDK installed): `./gradlew testDebugUnitTest assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

**Without a computer:** upload the *contents* of this folder to a private GitHub repository, including the hidden `.github` folder.
Open Actions → Build APK → Run workflow, then download the artifact and unzip it.
If it fails, copy the first `e:` lines from the log to get them fixed.

**Install:** open the APK and allow installs from that source, or use `adb install app-debug.apk`.
A release build needs your own signing key (Build → Generate Signed App Bundle / APK). Never commit the keystore.

## First-run setup
1. Settings → Gemini API: paste your key (from Google AI Studio), Save, Test connection. Usage may be billed or quota limited.
2. Models: load the list, pick a model, **Validate and save**, then "Use for voice" or "Use for text".
   Defaults are `gemini-3.8-live` and `gemini-3.8-flash`; they work only if your key has access.
3. Permissions: microphone and notifications.
4. For phone control: Accessibility. On Android 13+ a sideloaded app may be greyed out:
   App info → ⋮ → **Allow restricted settings**, then try again.
5. For files: choose a workspace folder, e.g. `Documents/NovaProjects`.
6. Optional: Display over other apps (sharing bubble, background app launch), battery Unrestricted.

## Using it with MT Manager
The assistant writes files into the workspace through Android's Storage Access Framework, reads them back and compares
the content. Open the same folder in MT Manager to view or edit them. This does not depend on MT Manager's UI.
It can also try to operate MT Manager through Accessibility ("open MT Manager", then tap and type). That works only for
controls MT Manager exposes to Accessibility, and has not been tested.

## Safety model (enforced in code, not only in the prompt)
- Taps whose label suggests send, post, install, share and similar, unlabeled buttons, and sideways swipes need approval.
- Delete, payment, erase and overwrite need a physical tap. Spoken approval is rejected.
- Spoken approval requires the whole phrase ("হ্যাঁ, পাঠাও", "yes"). It cannot identify the speaker; it can be switched off.
- An approved tap is cancelled if the app, header text or typed draft changes. A changing header (e.g. "typing…") can also cancel it.
- No automation on this app, system UI, Settings, installer or permission screens. Password fields are not read or filled.
- Label matching is a heuristic and cannot know what every button does. Turn on **Confirm every action** for sensitive apps.
- STOP AI ends the conversation, pending actions, wake word and screen sharing. It cannot undo a completed action.
  A coding request is stopped by the STOP AI button inside the app.

## Android limits and the chosen alternatives
| Wish | Reality |
|---|---|
| Always-on custom wake word | A speech-recognition loop in a visible microphone service. Uses battery, may beep, has gaps, may use the provider's servers, and some phones kill it. Must be restarted from the app after reboot. A dedicated engine can replace `WakeWordEngine`. |
| Interrupt by voice | Works through Live API voice detection (default mode). Echo cancellation varies by phone; headphones help. Classic mode uses the Interrupt button. |
| Female voice, speed, pitch | Live: choose a Gemini voice (default Leda); pace is only a prompt request; no pitch control. Classic: Android voices with speed and pitch; Android does not report gender. |
| See the screen | Needs consent every session. Protected screens are black. The lock screen or system may end capture. Up to one changed frame per interval (minimum 1 s). |
| Control any app | Only what Accessibility exposes. No coordinate tapping, so unlabeled canvas UIs and games may not work. |
| Access all files | Only the chosen folder. Android blocks the storage root and Download in the folder picker. |
| Model capabilities | The model list reports API methods and token limits only. Image and tool support are probed on save. Live support comes from `bidiGenerateContent`; voice and tools are proven only by a real session. Image-only or TTS models may pass the method filter but fail the probes. |
| Temperature | Deprecated by Google. Off by default, for older models. Not applied to Live. |
| Google Play | Accessibility-driven automation faces strict policy review and may be rejected. Check current policy first. This build is meant for personal sideloading. |

## Not included
Non-Gemini providers (custom endpoints must speak the Gemini protocol), Room (history is a small local JSON file),
a custom keyboard (InputMethodService), streaming text in the coding screen, multi-file import into coding chat,
and saved conversation transcripts.

## Privacy
The API key and proxy token are AES-GCM encrypted with an Android Keystore key and excluded from backup. This protects
storage; it cannot protect against a compromised or rooted phone. There is no analytics and no HTTP logging.
Audio, shared frames, screen text and files the AI reads are sent to Gemini or your proxy. Requests to
`generateContent` set `store=false`; Google's own data terms still apply. Local history keeps short action results and
coding prompts (up to 500 characters each).

## Backend proxy (for distribution)
See `backend/proxy.py`. Run it behind HTTPS, enter its URL and token in the app, and leave the API key empty.
The shared token is suitable for personal use only.

## Device test checklist
- [ ] Connection test; wrong key shows a clear error; airplane mode shows a network error
- [ ] Live conversation in Bengali; talk over the reply and confirm it stops at once, with no double audio
- [ ] Wake word with the app open, in the background, and with the screen off
- [ ] Screen sharing: ask what is visible; stop it; ask again (it must say it cannot see)
- [ ] "Open Telegram"; send "Hi" to a **test** chat: check the card, say না once, then approve
- [ ] While approval is pending, change the draft: the send must be refused
- [ ] Create, read, overwrite and delete a test file
- [ ] STOP AI during speech, an action, and screen sharing

## Structure
```
core/        pure Kotlin: protocol, safety policy, wake match, paths, code parsing, prompts, tools
data/        Keystore storage, settings, history
gemini/      REST client, Live WebSocket
voice/       mic, playback, audio focus, speech, wake word
screen/      MediaProjection service, frame change detection
automation/  Accessibility service, gated tool executor
assistant/   conversation controller, confirmations, microphone service
files/       workspace file operations
coding/      coding assistant
ui/          theme, orb, overlays, view model, screens (MVVM)
backend/     optional proxy
```

## Full file list
```
.github/workflows/build.yml
.gitignore
README.md
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/nova/assistant/MainActivity.kt
app/src/main/java/com/nova/assistant/NovaApp.kt
app/src/main/java/com/nova/assistant/assistant/AssistantController.kt
app/src/main/java/com/nova/assistant/assistant/AssistantService.kt
app/src/main/java/com/nova/assistant/assistant/ConfirmationManager.kt
app/src/main/java/com/nova/assistant/automation/AccessibilityBridge.kt
app/src/main/java/com/nova/assistant/automation/ToolExecutor.kt
app/src/main/java/com/nova/assistant/coding/CodingAssistant.kt
app/src/main/java/com/nova/assistant/core/ActionPolicy.kt
app/src/main/java/com/nova/assistant/core/CodeBlocks.kt
app/src/main/java/com/nova/assistant/core/GeminiProtocol.kt
app/src/main/java/com/nova/assistant/core/Json.kt
app/src/main/java/com/nova/assistant/core/Models.kt
app/src/main/java/com/nova/assistant/core/Prompts.kt
app/src/main/java/com/nova/assistant/core/SafePath.kt
app/src/main/java/com/nova/assistant/core/SettingsCodec.kt
app/src/main/java/com/nova/assistant/core/ToolSchema.kt
app/src/main/java/com/nova/assistant/core/WakeWord.kt
app/src/main/java/com/nova/assistant/data/Repositories.kt
app/src/main/java/com/nova/assistant/data/SecureStore.kt
app/src/main/java/com/nova/assistant/files/WorkspaceFiles.kt
app/src/main/java/com/nova/assistant/gemini/GeminiClient.kt
app/src/main/java/com/nova/assistant/gemini/LiveSession.kt
app/src/main/java/com/nova/assistant/screen/ScreenCaptureService.kt
app/src/main/java/com/nova/assistant/screen/ScreenState.kt
app/src/main/java/com/nova/assistant/ui/MainViewModel.kt
app/src/main/java/com/nova/assistant/ui/Orb.kt
app/src/main/java/com/nova/assistant/ui/Overlays.kt
app/src/main/java/com/nova/assistant/ui/Theme.kt
app/src/main/java/com/nova/assistant/ui/screens/Common.kt
app/src/main/java/com/nova/assistant/ui/screens/HomeAndLive.kt
app/src/main/java/com/nova/assistant/ui/screens/ModelsScreen.kt
app/src/main/java/com/nova/assistant/ui/screens/PermissionsScreen.kt
app/src/main/java/com/nova/assistant/ui/screens/SettingsScreens.kt
app/src/main/java/com/nova/assistant/ui/screens/ToolScreens.kt
app/src/main/java/com/nova/assistant/voice/AudioIO.kt
app/src/main/java/com/nova/assistant/voice/Speech.kt
app/src/main/java/com/nova/assistant/voice/WakeWordEngine.kt
app/src/main/res/drawable/ic_orb.xml
app/src/main/res/values/strings.xml
app/src/main/res/values/themes.xml
app/src/main/res/xml/accessibility_config.xml
app/src/main/res/xml/data_extraction_rules.xml
app/src/test/java/com/nova/assistant/CoreTest.kt
backend/proxy.py
build.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.jar
gradle/wrapper/gradle-wrapper.properties
gradlew
gradlew.bat
settings.gradle.kts
```
