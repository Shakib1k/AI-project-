package com.nova.assistant

import com.nova.assistant.core.*
import com.nova.assistant.core.ActionPolicy.Risk
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test fun wakeWordMatchesWholeWordsOnly() {
        val names = WakeWord.names(AssistantSettings())
        assertEquals("", WakeWord.match("Maya", names))
        assertEquals("open telegram", WakeWord.match("hey Maya, open Telegram", names))
        assertEquals("", WakeWord.match("মায়া", names))
        assertNull(WakeWord.match("Amaya is here", names))
        assertNull(WakeWord.match("yesterday I was talking to maya", names))
        assertEquals("hello", WakeWord.match("nova prime hello", listOf("nova prime")))
    }

    @Test fun sensitiveTapsNeedApproval() {
        assertEquals(Risk.CONFIRM, ActionPolicy.tapRisk("Send"))
        assertEquals(Risk.CONFIRM, ActionPolicy.tapRisk("Send message"))
        assertEquals(Risk.CONFIRM, ActionPolicy.tapRisk(""))
        assertEquals(Risk.CONFIRM, ActionPolicy.tapRisk("পাঠান"))
        assertEquals(Risk.TAP_ONLY, ActionPolicy.tapRisk("Delete chat"))
        assertEquals(Risk.TAP_ONLY, ActionPolicy.tapRisk("Pay now"))
        assertEquals(Risk.TAP_ONLY, ActionPolicy.tapRisk("মুছুন"))
        assertEquals(Risk.SAFE, ActionPolicy.tapRisk("Bookmarks"))
        assertEquals(Risk.SAFE, ActionPolicy.tapRisk("Search"))
    }

    @Test fun voiceApprovalIsStrict() {
        assertEquals(true, ActionPolicy.voiceAnswer("হ্যাঁ, পাঠাও।"))
        assertEquals(true, ActionPolicy.voiceAnswer("Yes."))
        assertEquals(false, ActionPolicy.voiceAnswer("না"))
        assertEquals(false, ActionPolicy.voiceAnswer("no don't send"))
        assertNull(ActionPolicy.voiceAnswer("yes but change the text"))
        assertNull(ActionPolicy.voiceAnswer("should I say yes"))
    }

    @Test fun protectedScreensAreBlocked() {
        listOf("me.app", "com.android.systemui", "com.android.settings", "com.google.android.permissioncontroller")
            .forEach { assertTrue(it, ActionPolicy.isBlockedPackage(it, "me.app")) }
        assertFalse(ActionPolicy.isBlockedPackage("org.telegram.messenger", "me.app"))
    }

    @Test fun pathTraversalRejected() {
        listOf("../a", "/etc/passwd", "a/../../b", "a//b", "a\\b", "", "content:x").forEach { assertNull(it, SafePath.split(it)) }
        assertEquals(listOf("bot", "bot.py"), SafePath.split("bot/bot.py"))
    }

    @Test fun codeBlocksNeverSaveTruncatedOrUnsafeFiles() {
        val r = CodeBlocks.parse("```python path=a.py\nprint(1)\n```\n````markdown path=README.md\n```sh\nls\n```\n````\n" +
            "```js path=../x.js\n1\n```\n```html path=cut.html\n<html>")
        assertEquals(listOf("a.py", "README.md"), r.files.map { it.path })
        assertEquals("```sh\nls\n```\n", r.files[1].content)
        assertEquals(listOf("../x.js", "cut.html"), r.unterminated)
    }

    @Test fun settingsRoundTripAndBadInput() {
        val s = AssistantSettings(aiName = "রিয়া", pitch = 1.3f, confirmEveryAction = true,
            savedModels = listOf(SavedModel("Voice", "gemini-3.8-live", capabilities = setOf(Capability.LIVE))))
        assertEquals(s, SettingsCodec.decode(SettingsCodec.encode(s)))
        assertEquals(AssistantSettings(), SettingsCodec.decode("not json"))
        assertEquals(1000, SettingsCodec.decode("""{"frameIntervalMs":1}""").frameIntervalMs)
    }

    @Test fun capabilitiesComeFromApiMethods() {
        val m = GeminiProtocol.parseModel(parseObject(
            """{"name":"models/x-live","inputTokenLimit":131072,"supportedGenerationMethods":["bidiGenerateContent"]}""")!!)
        assertEquals("x-live", m.id)
        assertEquals(setOf(Capability.LIVE), m.capabilities)
        assertEquals(131072L, m.inputTokenLimit)
        assertFalse(GeminiProtocol.isValidModelId("a/../b?key=1"))
    }

    @Test fun thoughtSignatureIsPreserved() {
        val response = parseObject("""{"candidates":[{"content":{"parts":[{"functionCall":{"id":"1","name":"go_home","args":{}},"thoughtSignature":"abc"}]}}]}""")!!
        val parts = GeminiProtocol.responseParts(response)
        assertTrue(GeminiProtocol.content("model", parts).toString().contains("\"thoughtSignature\":\"abc\""))
        assertEquals("go_home", GeminiProtocol.functionCalls(parts).single().name)
    }

    @Test fun temperatureOnlyWhenChosen() {
        assertFalse(GeminiProtocol.generateRequest(emptyList(), null, null, 100, null).toString().contains("temperature"))
        assertTrue(GeminiProtocol.generateRequest(emptyList(), null, null, 100, 0.5f).toString().contains("temperature"))
    }

    @Test fun liveSetupShape() {
        val setup = parseObject(GeminiProtocol.liveSetup("gemini-3.8-live", "sys", "Leda", ToolSchema.all, null))!!["setup"]!!.jsonObject
        assertEquals("models/gemini-3.8-live", setup.string("model"))
        assertTrue(setup["generationConfig"]!!.jsonObject.containsKey("speechConfig"))
        assertTrue(setup.toString().contains("\"behavior\":\"BLOCKING\""))
        val extended = GeminiProtocol.liveSetup("gemini-3.8-live-extended-thinking", "s", "Leda", ToolSchema.all, "h")
        assertFalse(extended.contains("BLOCKING"))
    }

    @Test fun liveInterruptComesBeforeNewAudio() {
        val events = GeminiProtocol.parseLive("""{"serverContent":{"modelTurn":{"parts":[{"inlineData":{"data":"AA"}}]},"interrupted":true}}""")
        assertEquals(LiveEvent.Interrupted, events.first())
        assertTrue(GeminiProtocol.parseLive("""{"toolCallCancellation":{"ids":["7"]}}""").single() is LiveEvent.ToolCancel)
        assertTrue(GeminiProtocol.parseLive("garbage").isEmpty())
    }
}
