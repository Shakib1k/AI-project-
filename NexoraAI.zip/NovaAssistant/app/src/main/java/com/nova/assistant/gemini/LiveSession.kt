package com.nova.assistant.gemini

import com.nova.assistant.core.GeminiProtocol
import com.nova.assistant.core.LiveEvent
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString

/** One WebSocket connection. Callbacks arrive on OkHttp threads, in order. */
class LiveSession(
    client: GeminiClient, base: String, private val setup: String,
    private val onEvent: (LiveSession, LiveEvent) -> Unit,
    private val onClosed: (LiveSession, String) -> Unit
) : WebSocketListener() {
    @Volatile var ready = false
        private set
    @Volatile private var closedByUs = false
    private val socket = client.openSocket(base, this)

    override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setup) }
    override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
    override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

    private fun handle(text: String) {
        if (closedByUs) return
        GeminiProtocol.parseLive(text).forEach {
            if (it is LiveEvent.Ready) ready = true
            onEvent(this, it)
        }
    }

    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
        webSocket.close(1000, null)
        report(reason.ifBlank { "Session closed ($code)" })
    }

    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) =
        report(response?.let { GeminiProtocol.errorMessage(it.code, "") } ?: "Live connection lost.")

    private var reported = false
    @Synchronized private fun report(reason: String) {
        if (!closedByUs && !reported) { reported = true; ready = false; onClosed(this, reason) }
    }

    fun send(message: String) { if (ready && socket.queueSize() < 4_000_000) socket.send(message) }

    fun close() { closedByUs = true; ready = false; socket.close(1000, null); }
}
