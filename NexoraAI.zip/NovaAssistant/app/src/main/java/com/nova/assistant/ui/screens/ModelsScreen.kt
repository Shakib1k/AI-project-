package com.nova.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.assistant.core.Capability
import com.nova.assistant.ui.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModelsScreen(vm: MainViewModel, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }
    var id by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var form by remember { mutableIntStateOf(0) }
    fun edit(newName: String, newId: String, newEndpoint: String) { name = newName; id = newId; endpoint = newEndpoint; form++ }

    Page("AI models", back) {
        Note("Voice (Live): ${s.liveModel}\nText, vision, tools and coding: ${s.textModel}")
        if (vm.apiStatus.isNotBlank()) Text(vm.apiStatus)

        Heading("Saved models")
        if (s.savedModels.isEmpty()) Note("None yet. Validate one below.")
        s.savedModels.forEach { m ->
            GlassCard {
                Heading(m.displayName)
                Note("${m.modelId} · ${m.provider}${if (m.endpoint.isNotBlank()) "\n" + m.endpoint else ""}\n" +
                    m.capabilities.joinToString { it.label })
                if (m.modelId == s.liveModel) Text("✓ Default voice model")
                if (m.modelId == s.textModel) Text("✓ Default text model")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (Capability.LIVE in m.capabilities) Button({ vm.setDefault(m, true) }) { Text("Use for voice") }
                    if (Capability.TEXT in m.capabilities) Button({ vm.setDefault(m, false) }) { Text("Use for text") }
                    TextButton({ edit(m.displayName, m.modelId, m.endpoint) }) { Text("Edit") }
                    TextButton({ vm.deleteModel(m) }) { Text("Delete") }
                }
            }
        }

        GlassCard {
            Heading("Add or edit a model")
            key(form) {
                Field("Display name", name) { name = it }
                Field("Model ID", id) { id = it }
                Field("Gemini-compatible HTTPS proxy (optional)", endpoint) { endpoint = it }
            }
            Note("Only the Gemini protocol is supported. A custom endpoint receives your proxy token, not your Google key.")
            Button({ vm.validateAndSave(name, id, endpoint) }, enabled = !vm.busy && id.isNotBlank()) { Text("Validate and save") }
        }

        Heading("Discover from your API key")
        Button(vm::loadModels, enabled = !vm.busy) { Text("Load model list") }
        if (vm.models.isNotEmpty()) Field("Search", filter) { filter = it }
        vm.models.filter { filter.isBlank() || it.id.contains(filter, true) }.forEach { m ->
            GlassCard {
                Heading(m.displayName)
                Note("ID: ${m.id}\nContext: ${m.inputTokenLimit ?: "not reported"} in / ${m.outputTokenLimit ?: "not reported"} out\n" +
                    "API methods: ${m.methods.joinToString()}\nInput/output types and tools: not reported by the list; tested on save.\n" +
                    "Status: listed for this key\n${m.description.take(200)}")
                OutlinedButton({ edit(m.displayName, m.id, "") }, Modifier.fillMaxWidth()) { Text("Fill form above") }
            }
        }
    }
}
