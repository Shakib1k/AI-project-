package com.nova.assistant.core

import kotlinx.serialization.json.*

object SettingsCodec {
    fun encode(s: AssistantSettings): String = buildJsonObject {
        put("aiName", s.aiName); put("wakeAliases", s.wakeAliases); put("wakeEnabled", s.wakeEnabled)
        put("textModel", s.textModel); put("liveModel", s.liveModel); put("useLiveApi", s.useLiveApi)
        put("proxyUrl", s.proxyUrl); put("sendTemperature", s.sendTemperature); put("temperature", s.temperature)
        put("maxOutputTokens", s.maxOutputTokens); put("liveVoice", s.liveVoice); put("ttsVoice", s.ttsVoice)
        put("speechRate", s.speechRate); put("pitch", s.pitch); put("volume", s.volume)
        put("languageTag", s.languageTag); put("voiceResponses", s.voiceResponses)
        put("personality", s.personality); put("replyLanguage", s.replyLanguage)
        put("detailedReplies", s.detailedReplies); put("confirmEveryAction", s.confirmEveryAction)
        put("voiceConfirmation", s.voiceConfirmation); put("frameIntervalMs", s.frameIntervalMs)
        put("frameMaxSize", s.frameMaxSize); put("jpegQuality", s.jpegQuality)
        put("floatingIndicator", s.floatingIndicator)
        putJsonArray("savedModels") {
            s.savedModels.forEach { m ->
                addJsonObject {
                    put("displayName", m.displayName); put("modelId", m.modelId)
                    put("provider", m.provider); put("endpoint", m.endpoint)
                    putJsonArray("capabilities") { m.capabilities.forEach { add(it.name) } }
                }
            }
        }
    }.toString()

    fun decode(text: String?): AssistantSettings {
        val d = AssistantSettings()
        val o = text?.let(::parseObject) ?: return d
        return AssistantSettings(
            aiName = o.string("aiName", d.aiName),
            wakeAliases = o.string("wakeAliases", d.wakeAliases),
            wakeEnabled = o.bool("wakeEnabled", d.wakeEnabled),
            textModel = o.string("textModel", d.textModel),
            liveModel = o.string("liveModel", d.liveModel),
            useLiveApi = o.bool("useLiveApi", d.useLiveApi),
            proxyUrl = o.string("proxyUrl", d.proxyUrl),
            sendTemperature = o.bool("sendTemperature", d.sendTemperature),
            temperature = o.float("temperature", d.temperature),
            maxOutputTokens = o.int("maxOutputTokens") ?: d.maxOutputTokens,
            liveVoice = o.string("liveVoice", d.liveVoice),
            ttsVoice = o.string("ttsVoice", d.ttsVoice),
            speechRate = o.float("speechRate", d.speechRate),
            pitch = o.float("pitch", d.pitch),
            volume = o.float("volume", d.volume),
            languageTag = o.string("languageTag", d.languageTag),
            voiceResponses = o.bool("voiceResponses", d.voiceResponses),
            personality = o.string("personality", d.personality),
            replyLanguage = o.string("replyLanguage", d.replyLanguage),
            detailedReplies = o.bool("detailedReplies", d.detailedReplies),
            confirmEveryAction = o.bool("confirmEveryAction", d.confirmEveryAction),
            voiceConfirmation = o.bool("voiceConfirmation", d.voiceConfirmation),
            frameIntervalMs = (o.int("frameIntervalMs") ?: d.frameIntervalMs).coerceIn(1000, 10000),
            frameMaxSize = (o.int("frameMaxSize") ?: d.frameMaxSize).coerceIn(512, 1536),
            jpegQuality = (o.int("jpegQuality") ?: d.jpegQuality).coerceIn(40, 90),
            floatingIndicator = o.bool("floatingIndicator", d.floatingIndicator),
            savedModels = o["savedModels"].arr().mapNotNull { e ->
                val m = e.obj() ?: return@mapNotNull null
                SavedModel(
                    m.string("displayName"), m.string("modelId"), m.string("provider", "Google Gemini"),
                    m.string("endpoint"),
                    m["capabilities"].arr().mapNotNull { c -> Capability.entries.find { it.name == c.str() } }.toSet()
                )
            }
        )
    }
}
