package com.nova.assistant.core

import kotlinx.serialization.json.*

object ToolSchema {
    private fun tool(name: String, description: String, vararg params: Pair<String, String>) = buildJsonObject {
        put("name", name); put("description", description)
        if (params.isNotEmpty()) putJsonObject("parameters") {
            put("type", "OBJECT")
            putJsonObject("properties") {
                params.forEach { (key, desc) -> putJsonObject(key) { put("type", "STRING"); put("description", desc) } }
            }
            putJsonArray("required") { params.forEach { add(it.first) } }
        }
    }

    val all = JsonArray(listOf(
        tool("open_app", "Open an installed app by its visible name.", "name" to "App name, e.g. Telegram or MT Manager"),
        tool("read_screen", "List visible UI elements with ids, using Accessibility."),
        tool("tap", "Tap an element from the latest read_screen.", "id" to "Element id", "purpose" to "What this tap will do, including destination"),
        tool("long_press", "Long press an element from the latest read_screen.", "id" to "Element id"),
        tool("type_text", "Replace the text of an editable element. Does not send.", "id" to "Element id", "text" to "Exact text"),
        tool("swipe", "Swipe the screen. Use up to scroll down the page and down to scroll up.", "direction" to "up, down, left or right (finger direction)"),
        tool("press_back", "Press Android Back."),
        tool("go_home", "Go to the home screen."),
        tool("list_files", "List a folder in the user's workspace.", "path" to "Relative folder, or . for the root"),
        tool("read_file", "Read a text file from the workspace.", "path" to "Relative path"),
        tool("write_file", "Create or overwrite a workspace text file, then verify it.", "path" to "Relative path", "content" to "Complete file content"),
        tool("delete_file", "Delete one workspace file. Always needs the user's tap.", "path" to "Relative path"),
        tool("generate_code_file", "Generate one complete source file with the coding model, save and verify it.", "path" to "Relative path with extension", "instructions" to "Full requirements")
    ))
}
