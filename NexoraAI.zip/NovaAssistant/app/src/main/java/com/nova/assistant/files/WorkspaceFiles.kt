package com.nova.assistant.files

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.nova.assistant.core.SafePath
import com.nova.assistant.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** File access limited to the one folder the user picked with the Storage Access Framework. */
class WorkspaceFiles(private val context: Context, private val settings: SettingsRepository) {
    private fun root(): DocumentFile {
        val uri = settings.workspace.value ?: error("No workspace folder. Choose one in Permissions.")
        val dir = DocumentFile.fromTreeUri(context, Uri.parse(uri))
        if (dir == null || !dir.canWrite()) error("Workspace access was lost. Choose the folder again.")
        return dir
    }

    private fun parts(path: String) = SafePath.split(path) ?: error("Unsafe or invalid path: $path")

    private fun find(path: String): DocumentFile? =
        parts(path).fold(root() as DocumentFile?) { dir, name -> dir?.findFile(name) }

    suspend fun exists(path: String) = withContext(Dispatchers.IO) { find(path) != null }

    suspend fun list(path: String): List<String> = withContext(Dispatchers.IO) {
        val dir = if (path == "." || path.isBlank()) root() else find(path) ?: error("Folder not found.")
        if (!dir.isDirectory) error("Not a folder.")
        dir.listFiles().map { (it.name ?: "?") + if (it.isDirectory) "/" else "" }.sorted()
    }

    suspend fun read(path: String): String = withContext(Dispatchers.IO) {
        val file = find(path)?.takeIf { it.isFile } ?: error("File not found: $path")
        if (file.length() > 400_000) error("File is too large to read (limit 400 KB).")
        context.contentResolver.openInputStream(file.uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: error("Could not open file.")
    }

    /** Writes, reads back, and succeeds only if the content matches exactly. */
    suspend fun write(path: String, content: String) = withContext(Dispatchers.IO) {
        val names = parts(path)
        var dir = root()
        for (name in names.dropLast(1)) {
            val next = dir.findFile(name) ?: dir.createDirectory(name) ?: error("Cannot create folder $name")
            if (!next.isDirectory) error("$name is not a folder.")
            dir = next
        }
        val name = names.last()
        val existing = dir.findFile(name)
        if (existing?.isDirectory == true) error("A folder has that name.")
        // octet-stream stops most providers from appending an extra extension.
        val file = existing ?: dir.createFile("application/octet-stream", name) ?: error("Cannot create $name")
        if (file.name != name) { file.delete(); error("Storage provider changed the file name; not saved.") }
        context.contentResolver.openOutputStream(file.uri, "wt")?.use { it.write(content.toByteArray()) }
            ?: error("Cannot write file.")
        if (read(path) != content) error("Verification failed: saved content does not match.")
    }

    suspend fun delete(path: String) = withContext(Dispatchers.IO) {
        val file = find(path)?.takeIf { it.isFile } ?: error("Only existing files can be deleted.")
        if (!file.delete() || find(path) != null) error("Delete could not be verified.")
    }
}
