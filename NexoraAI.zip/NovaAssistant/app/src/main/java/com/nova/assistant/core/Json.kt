package com.nova.assistant.core

import kotlinx.serialization.json.*

fun JsonElement?.obj(): JsonObject? = this as? JsonObject
fun JsonElement?.arr(): List<JsonElement> = (this as? JsonArray) ?: emptyList()
fun JsonElement?.str(): String? = (this as? JsonPrimitive)?.takeIf { it !is JsonNull }?.content
fun JsonObject.string(key: String, default: String = "") = this[key].str() ?: default
fun JsonObject.int(key: String): Int? = this[key].str()?.toIntOrNull()
fun JsonObject.bool(key: String, default: Boolean) = this[key].str()?.toBooleanStrictOrNull() ?: default
fun JsonObject.float(key: String, default: Float) = this[key].str()?.toFloatOrNull() ?: default
fun parseObject(text: String): JsonObject? = runCatching { Json.parseToJsonElement(text).obj() }.getOrNull()
