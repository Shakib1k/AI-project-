package com.nova.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nova.assistant.screen.ScreenCaptureService
import com.nova.assistant.ui.*
import com.nova.assistant.ui.screens.*

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NovaTheme { Surface { App(vm) } } }
    }
}

@Composable
private fun App(vm: MainViewModel) {
    val context = LocalContext.current
    val nav = rememberNavController()
    val controller = vm.graph.controller
    var afterMic by remember { mutableStateOf("") }

    fun enableWake() { vm.update { it.copy(wakeEnabled = true) }; controller.startWakeWord() }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (afterMic == "wake") enableWake() else controller.startSession()
        } else controller.report("Microphone permission was denied. Enable it in Permissions.")
        afterMic = ""
    }
    fun withMic(purpose: String) {
        afterMic = purpose
        val wanted = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        // Launching with already granted permissions returns immediately.
        micLauncher.launch(wanted.toTypedArray())
    }

    val capture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == android.app.Activity.RESULT_OK && data != null)
            ScreenCaptureService.start(context, result.resultCode, data)
        else controller.report("Screen sharing was not allowed.")
    }
    fun toggleShare() {
        if (vm.graph.screen.active.value) ScreenCaptureService.stop(context)
        else capture.launch(context.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    fun startLive() {
        nav.navigate("live") { launchSingleTop = true }
        if (!controller.inSession.value) withMic("live")
    }
    fun go(route: String) = nav.navigate(route) { launchSingleTop = true }
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(nav, "home") {
        composable("home") { HomeScreen(vm, ::go, ::startLive, ::toggleShare) }
        composable("live") { LiveScreen(vm, back, { withMic("live") }, ::toggleShare) }
        composable("settings") {
            SettingsScreen(vm, back, ::go) { on ->
                if (on) withMic("wake") else { vm.update { it.copy(wakeEnabled = false) }; controller.stopWakeWord() }
            }
        }
        composable("api") { ApiScreen(vm, back, ::go) }
        composable("models") { ModelsScreen(vm, back) }
        composable("voice") { VoiceScreen(vm, back) }
        composable("permissions") { PermissionsScreen(vm, back) }
        composable("screen") { ScreenShareScreen(vm, back, ::toggleShare, ::startLive) }
        composable("coding") { CodingScreen(vm, back) }
        composable("history") { HistoryScreen(vm, back) }
    }

    // Resume the wake word when the user reopens the app (Android forbids doing it from the background).
    val settings by vm.settings.collectAsStateWithLifecycle()
    androidx.lifecycle.compose.LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
        if (settings.wakeEnabled && !controller.inSession.value && !controller.wakeListening.value &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) controller.startWakeWord()
    }

    val error by controller.error.collectAsStateWithLifecycle()
    error?.let {
        AlertDialog(onDismissRequest = controller::clearError, title = { Text("Assistant") }, text = { Text(it) },
            confirmButton = { TextButton(controller::clearError) { Text("OK") } })
    }
    val pending by vm.graph.confirmations.pending.collectAsStateWithLifecycle()
    pending?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.graph.confirmations.resolve(false) },
            title = { Text(c.title) },
            text = { Text(c.details.take(1500)) },
            confirmButton = { Button({ vm.graph.confirmations.resolve(true) }) { Text("Allow") } },
            dismissButton = { TextButton({ vm.graph.confirmations.resolve(false) }) { Text("Cancel") } }
        )
    }
}
