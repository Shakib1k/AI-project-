package com.nova.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.nova.assistant.assistant.AssistantController
import com.nova.assistant.assistant.ConfirmationManager
import com.nova.assistant.automation.ToolExecutor
import com.nova.assistant.coding.CodingAssistant
import com.nova.assistant.data.*
import com.nova.assistant.files.WorkspaceFiles
import com.nova.assistant.gemini.GeminiClient
import com.nova.assistant.screen.ScreenState
import kotlinx.coroutines.*

/** Hand-wired dependency graph, shared by the UI and services. */
class AppGraph(app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val secrets = SecureStore(app)
    val settings = SettingsRepository(app, scope)
    val history = HistoryRepository(app, scope)
    val client = GeminiClient(secrets)
    val files = WorkspaceFiles(app, settings)
    val coder = CodingAssistant(client, settings)
    val screen = ScreenState()
    val confirmations = ConfirmationManager()
    val tools = ToolExecutor(app, settings, files, coder, confirmations, history)
    val controller = AssistantController(app, this)
}

class NovaApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Assistant activity", NotificationManager.IMPORTANCE_LOW))
        graph = AppGraph(this)
    }

    companion object { const val CHANNEL = "assistant" }
}
