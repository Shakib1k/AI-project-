package com.nova.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.assistant.core.AssistantState
import com.nova.assistant.ui.*

@Composable
fun StopButton(vm: MainViewModel) = Button(
    { vm.graph.controller.stopAll(); vm.stopCode() },
    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF7A0016))
) { Icon(Icons.Default.Dangerous, null); Spacer(Modifier.width(6.dp)); Text("STOP AI") }

@Composable
fun statusLine(vm: MainViewModel): String {
    val state by vm.graph.controller.state.collectAsStateWithLifecycle()
    val sharing by vm.graph.screen.active.collectAsStateWithLifecycle()
    val wake by vm.graph.controller.wakeListening.collectAsStateWithLifecycle()
    val base = when {
        state != AssistantState.IDLE -> state.name.lowercase().replaceFirstChar { it.uppercase() }
        wake -> "Waiting for wake word (mic on)"
        else -> "Idle · microphone off"
    }
    return if (sharing) "$base · screen shared" else base
}

@Composable
fun HomeScreen(vm: MainViewModel, go: (String) -> Unit, startLive: () -> Unit, toggleShare: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val state by vm.graph.controller.state.collectAsStateWithLifecycle()
    val sharing by vm.graph.screen.active.collectAsStateWithLifecycle()
    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        val orb = minOf(maxWidth * .82f, maxHeight * .42f)
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.aiName, Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.Light)
                IconButton({ go("settings") }) { Icon(Icons.Default.Settings, "Settings") }
            }
            Spacer(Modifier.weight(1f))
            AiOrb(state, sharing, Modifier.size(orb))
            Text(statusLine(vm), color = Muted, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            Button(startLive, Modifier.fillMaxWidth().height(56.dp)) { Text("Live Chat", fontSize = 18.sp) }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(toggleShare, Modifier.weight(1f)) { Text(if (sharing) "Stop sharing" else "Share screen") }
                FilledIconButton(startLive, Modifier.size(60.dp)) { Icon(Icons.Default.Mic, "Talk") }
                OutlinedButton({ go("coding") }, Modifier.weight(1f)) { Text("Code") }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ go("history") }) { Text("Activity") }
                StopButton(vm)
            }
        }
    }
}

@Composable
fun LiveScreen(vm: MainViewModel, back: () -> Unit, start: () -> Unit, toggleShare: () -> Unit) {
    val c = vm.graph.controller
    val state by c.state.collectAsStateWithLifecycle()
    val active by c.inSession.collectAsStateWithLifecycle()
    val muted by c.muted.collectAsStateWithLifecycle()
    val captions by c.captions.collectAsStateWithLifecycle()
    val sharing by vm.graph.screen.active.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val list = rememberLazyListState()
    LaunchedEffect(captions) { if (captions.isNotEmpty()) list.animateScrollToItem(captions.lastIndex) }

    FixedPage(s.aiName, back) {
        AiOrb(state, sharing, Modifier.size(220.dp))
        Text(statusLine(vm), color = Muted)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(captions) { Text((if (it.fromUser) "You: " else "${s.aiName}: ") + it.text,
                color = if (it.fromUser) Muted else MaterialTheme.colorScheme.onBackground) }
        }
        Note(if (s.useLiveApi) "Just speak to interrupt. Headphones reduce echo."
        else "Classic mode: tap Interrupt while the assistant is thinking or speaking.")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (active) {
                FilledTonalIconButton(c::toggleMute) { Icon(if (muted) Icons.Default.MicOff else Icons.Default.Mic, "Mute") }
                OutlinedButton(c::interrupt) { Text("Interrupt") }
                Button(c::stopSession) { Text("End") }
            } else Button(start) { Text("Start conversation") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(toggleShare) { Text(if (sharing) "Stop sharing" else "Share screen") }
            StopButton(vm)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FixedPage(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) = Scaffold(
    topBar = { TopAppBar({ Text(title) }, navigationIcon = { TextButton(back) { Text("Back") } }) }
) { padding ->
    Column(Modifier.padding(padding).fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}
