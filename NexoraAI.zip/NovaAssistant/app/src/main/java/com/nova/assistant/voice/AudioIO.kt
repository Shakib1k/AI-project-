package com.nova.assistant.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.util.Base64
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

/** 16 kHz mono PCM microphone stream with echo cancellation, so the user can talk over the AI. */
class MicStreamer {
    @Volatile private var running = false
    @Volatile var muted = false
    private var worker: Thread? = null

    @SuppressLint("MissingPermission") // checked by AssistantController before starting
    fun start(onChunk: (String) -> Unit, onError: (String) -> Unit) {
        stop()
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val record = runCatching {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400)
            )
        }.getOrNull()
        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            record?.release(); onError("Microphone is unavailable."); return
        }
        val echo = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(record.audioSessionId) else null
        val noise = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(record.audioSessionId) else null
        echo?.enabled = true; noise?.enabled = true
        running = true
        worker = thread(name = "nova-mic") {
            try {
                record.startRecording()
                val buffer = ByteArray(1280) // 40 ms
                while (running) {
                    val n = record.read(buffer, 0, buffer.size)
                    if (n < 0) { if (running) onError("Microphone stopped."); break }
                    if (n > 0 && !muted) onChunk(Base64.encodeToString(buffer, 0, n, Base64.NO_WRAP))
                }
            } catch (e: IllegalStateException) {
                onError("Microphone is in use by another app.")
            } finally {
                runCatching { record.stop() }
                echo?.release(); noise?.release(); record.release()
            }
        }
    }

    fun stop() { running = false; worker?.join(500); worker = null }
}

/** Single playback queue for 24 kHz PCM. flush() is the barge-in: it drops queued and buffered audio. */
class PcmPlayer(private val onPlaying: (Boolean) -> Unit) {
    private val queue = LinkedBlockingQueue<Pair<Int, ByteArray>>()
    @Volatile private var generation = 0
    @Volatile private var running = true
    private val lock = Any()
    private val track = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT), 9600))
        .setTransferMode(AudioTrack.MODE_STREAM).build()

    private val worker = thread(name = "nova-speaker") {
        var playing = false
        track.play()
        while (running) {
            val item = queue.poll(150, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (item == null) { if (playing) { playing = false; onPlaying(false) }; continue }
            val (gen, data) = item
            var offset = 0
            // Small non-blocking writes keep interruption latency low.
            while (running && gen == generation && offset < data.size) {
                val written = synchronized(lock) {
                    if (gen != generation) 0
                    else track.write(data, offset, minOf(960, data.size - offset), AudioTrack.WRITE_NON_BLOCKING)
                }
                if (written < 0) break
                if (written == 0) Thread.sleep(5) else offset += written
                if (!playing && written > 0) { playing = true; onPlaying(true) }
            }
        }
        track.release()
    }

    fun setVolume(v: Float) { track.setVolume(v.coerceIn(0f, 1f)) }
    fun play(base64: String) { queue.offer(generation to Base64.decode(base64, Base64.DEFAULT)) }
    fun flush() {
        synchronized(lock) { generation++; queue.clear(); track.pause(); track.flush(); track.play() }
        onPlaying(false)
    }
    fun release() { running = false; generation++; queue.clear(); worker.join(500) }
}

class AudioRoute(context: Context, private val onFocusLost: () -> Unit) {
    private val manager = context.getSystemService(AudioManager::class.java)
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setOnAudioFocusChangeListener { if (it == AudioManager.AUDIOFOCUS_LOSS) onFocusLost() }
        .build()

    @Suppress("DEPRECATION")
    fun acquire(): Boolean {
        if (manager.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) return false
        manager.mode = AudioManager.MODE_IN_COMMUNICATION
        val headsets = setOf(AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_USB_HEADSET)
        if (Build.VERSION.SDK_INT >= 31) {
            val devices = manager.availableCommunicationDevices
            val target = devices.firstOrNull { it.type in headsets }
                ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            target?.let { manager.setCommunicationDevice(it) }
        } else if (manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).none { it.type in headsets }) {
            manager.isSpeakerphoneOn = true
        }
        return true
    }

    @Suppress("DEPRECATION")
    fun release() {
        if (Build.VERSION.SDK_INT >= 31) manager.clearCommunicationDevice() else manager.isSpeakerphoneOn = false
        manager.mode = AudioManager.MODE_NORMAL
        manager.abandonAudioFocusRequest(focus)
    }
}
