package com.nova.assistant.core

object SafePath {
    /** Splits a workspace-relative path, rejecting traversal and absolute paths. */
    fun split(path: String): List<String>? {
        val p = path.trim()
        if (p.isEmpty() || p.startsWith("/") || p.contains('\\') || p.length > 300) return null
        val parts = p.split('/')
        if (parts.any { it.isBlank() || it == "." || it == ".." || it.any { c -> c.code < 32 || c == ':' } }) return null
        return parts
    }
}
