package com.nova.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.nova.assistant.ui.Muted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Page(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) = Scaffold(
    topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = {
            IconButton(onClick = back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        })
    }
) { padding ->
    Column(
        Modifier.padding(padding).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable fun Heading(text: String) = Text(text, style = MaterialTheme.typography.titleMedium)
@Composable fun Note(text: String) = Text(text, color = Muted, style = MaterialTheme.typography.bodySmall)

/** Keeps local text while typing so asynchronous saving never moves the cursor. */
@Composable
fun Field(label: String, value: String, secret: Boolean = false, lines: Int = 1, onChange: (String) -> Unit) {
    var text by remember { mutableStateOf(value) }
    OutlinedTextField(
        text, { text = it; onChange(it) }, Modifier.fillMaxWidth(), label = { Text(label) },
        singleLine = lines == 1, minLines = lines,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
    )
}

@Composable
fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Row(
    Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically
) {
    Text(label, Modifier.weight(1f).padding(end = 12.dp))
    Switch(checked, onChange)
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onDone: (Float) -> Unit) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Text("$label: ${"%.2f".format(local)}")
        Slider(local, { local = it }, valueRange = range, onValueChangeFinished = { onDone(local) })
    }
}

@Composable
fun Picker(label: String, selected: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text("$label: ${selected.ifBlank { "Default" }}") }
        DropdownMenu(open, { open = false }) {
            options.forEach { DropdownMenuItem({ Text(it.ifBlank { "Default" }) }, { onPick(it); open = false }) }
        }
    }
}
