package com.nova.assistant.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.assistant.core.CodeBlocks
import com.nova.assistant.ui.*
import java.text.DateFormat
import java.util.Date

@Composable
fun ScreenShareScreen(vm: MainViewModel, back: () -> Unit, toggleShare: () -> Unit, openLive: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val sharing by vm.graph.screen.active.collectAsStateWithLifecycle()
    val frames by vm.graph.screen.framesPrepared.collectAsStateWithLifecycle()
    val state by vm.graph.controller.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    Page("AI Vision", back) {
        GlassCard {
            AiOrb(state, sharing, Modifier.size(140.dp))
            Heading(if (sharing) "Screen vision ACTIVE" else "Screen vision OFF")
            Note(if (sharing) "$frames changed frames prepared. Frames leave the phone only during a conversation."
                else "The assistant cannot see your screen.")
            Button(toggleShare) { Text(if (sharing) "Stop screen sharing" else "Start screen sharing") }
            OutlinedButton(openLive) { Text("Talk about my screen") }
            if (sharing) {
                var preview by remember { mutableStateOf<String?>(null) }
                TextButton({ preview = vm.graph.screen.latest?.jpegBase64 }) { Text("Show latest captured frame") }
                preview?.let { data ->
                    val image = remember(data) {
                        val bytes = Base64.decode(data, Base64.NO_WRAP)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                    }
                    image?.let { Image(it, "Latest frame", Modifier.height(260.dp)) }
                }
            }
        }
        GlassCard {
            Toggle("Floating AI indicator (needs overlay permission)", s.floatingIndicator) { v -> vm.update { it.copy(floatingIndicator = v) } }
            if (!Settings.canDrawOverlays(context)) OutlinedButton({
                context.openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
            }) { Text("Allow display over other apps") }
            SliderRow("Seconds between samples", s.frameIntervalMs / 1000f, 1f..10f) { v -> vm.update { it.copy(frameIntervalMs = (v * 1000).toInt()) } }
            SliderRow("Max image edge (pixels)", s.frameMaxSize.toFloat(), 512f..1536f) { v -> vm.update { it.copy(frameMaxSize = v.toInt()) } }
            SliderRow("JPEG quality", s.jpegQuality.toFloat(), 40f..90f) { v -> vm.update { it.copy(jpegQuality = v.toInt()) } }
            Note("Restart sharing after changing size or the indicator. Apps that block capture appear black. " +
                "Close banking apps and private chats before sharing. Tap the bubble twice to stop.")
        }
        StopButton(vm)
    }
}

@Composable
fun CodingScreen(vm: MainViewModel, back: () -> Unit) {
    var prompt by remember { mutableStateOf("") }
    var overwrite by remember { mutableStateOf(false) }
    var form by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val parsed = remember(vm.codeReply) { CodeBlocks.parse(vm.codeReply) }
    Page("Coding assistant", back) {
        key(form) { Field("Describe a project, paste an error, or ask for changes", "", lines = 4) { prompt = it } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.askCode(prompt); prompt = ""; form++ }, enabled = prompt.isNotBlank() && !vm.codeBusy) { Text("Generate") }
            if (vm.codeBusy) OutlinedButton(vm::stopCode) { Text("Stop") }
            TextButton({ vm.newProject() }) { Text("New project") }
        }
        if (vm.codeBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.codeStatus.isNotBlank()) Text(vm.codeStatus)
        if (parsed.unterminated.isNotEmpty()) Text("Incomplete or unsafe files, not saveable: ${parsed.unterminated.joinToString()}")
        if (parsed.files.isNotEmpty()) GlassCard {
            Heading("${parsed.files.size} file(s)")
            Note(parsed.files.joinToString("\n") { it.path })
            Toggle("Overwrite existing files", overwrite) { overwrite = it }
            Button({ vm.saveFiles(parsed.files, overwrite); overwrite = false }) { Text("Save all to workspace and verify") }
        }
        if (vm.codeReply.isNotBlank()) {
            TextButton({
                context.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", vm.codeReply))
            }) { Text("Copy answer") }
            GlassCard {
                SelectionContainer {
                    Text(vm.codeReply, Modifier.horizontalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: MainViewModel, back: () -> Unit) {
    val entries by vm.graph.history.entries.collectAsStateWithLifecycle()
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Page("Activity and tasks", back) {
        Note("Stored only on this phone (latest 300). Conversation audio, transcripts and screen frames are not stored.")
        TextButton({ vm.graph.history.clear() }) { Text("Clear history") }
        if (entries.isEmpty()) Note("No activity yet.")
        entries.take(100).forEach { GlassCard { Note("${it.kind} · ${format.format(Date(it.time))}"); Text(it.text) } }
    }
}
