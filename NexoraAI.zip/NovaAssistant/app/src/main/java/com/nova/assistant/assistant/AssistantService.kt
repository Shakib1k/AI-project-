package com.nova.assistant.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.NovaApp
import com.nova.assistant.R

/** Keeps the microphone legitimately alive in the background, with a visible notification. */
class AssistantService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val controller = (application as NovaApp).graph.controller
        if (intent?.action == ACTION_STOP) { controller.stopAll(); return START_NOT_STICKY }
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val flagsImmutable = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(this, 0, Intent(this, javaClass).setAction(ACTION_STOP), flagsImmutable)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flagsImmutable)
        val notification = NotificationCompat.Builder(this, NovaApp.CHANNEL)
            .setSmallIcon(R.drawable.ic_orb).setContentTitle("Assistant microphone service")
            .setContentText(intent.getStringExtra(EXTRA_TEXT) ?: "Active").setContentIntent(open)
            .setOngoing(true).addAction(0, "STOP AI", stop).build()
        try {
            startForeground(1, notification,
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
            running = true
            controller.onServiceReady()
        } catch (e: Exception) {
            controller.report("Android did not allow the microphone service. Open the app and try again.")
            controller.stopAll()
            stopSelf()
        }
        return START_NOT_STICKY  // Android 14+ forbids restarting a microphone service from the background
    }

    override fun onDestroy() {
        running = false
        (application as NovaApp).graph.controller.onServiceDestroyed()
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "com.nova.assistant.STOP_ALL"
        private const val EXTRA_TEXT = "text"
        @Volatile var running = false
            private set
        fun start(context: Context, text: String) = ContextCompat.startForegroundService(
            context, Intent(context, AssistantService::class.java).putExtra(EXTRA_TEXT, text))
        fun stop(context: Context) { context.stopService(Intent(context, AssistantService::class.java)) }
    }
}
