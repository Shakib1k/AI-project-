package com.nova.assistant.screen

import kotlinx.coroutines.flow.*

data class Frame(val jpegBase64: String, val time: Long)

/** Shared capture status. When inactive there is no frame, so nothing can claim to see the screen. */
class ScreenState {
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active
    private val _changed = MutableSharedFlow<Frame>(extraBufferCapacity = 1,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)
    /** Emits only when the picture changed. */
    val changed: SharedFlow<Frame> = _changed
    @Volatile var latest: Frame? = null
        private set
    private val _framesPrepared = MutableStateFlow(0)
    val framesPrepared: StateFlow<Int> = _framesPrepared

    fun started() { latest = null; _framesPrepared.value = 0; _active.value = true }
    fun publish(frame: Frame) {
        if (!_active.value) return
        latest = frame; _framesPrepared.value++; _changed.tryEmit(frame)
    }
    fun stopped() { _active.value = false; latest = null }
}
