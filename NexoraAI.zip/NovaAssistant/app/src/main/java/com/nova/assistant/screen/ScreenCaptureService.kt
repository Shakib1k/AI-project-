package com.nova.assistant.screen

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.nova.assistant.NovaApp
import com.nova.assistant.R
import com.nova.assistant.core.AssistantState
import com.nova.assistant.ui.FloatingIndicator
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import kotlin.math.abs

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var indicator: FloatingIndicator? = null
    private var uiScope: CoroutineScope? = null
    private var signature: IntArray? = null
    private var lastSent = 0L
    private val graph get() = (application as NovaApp).graph

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null || projection != null) { if (projection == null) stopSelf(); return START_NOT_STICKY }

        val stop = PendingIntent.getService(this, 1, Intent(this, javaClass).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, NovaApp.CHANNEL)
            .setSmallIcon(R.drawable.ic_orb).setContentTitle("Screen sharing is active")
            .setContentText("Frames may be sent to your AI model.").setOngoing(true)
            .addAction(0, "Stop sharing", stop).build()
        try {
            // Must be foreground with this type before getMediaProjection on Android 14+.
            startForeground(2, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            val manager = getSystemService(MediaProjectionManager::class.java)
            val mp = manager.getMediaProjection(intent!!.getIntExtra(EXTRA_CODE, 0), data) ?: error("denied")
            projection = mp
            val worker = HandlerThread("nova-capture").also { it.start() }
            thread = worker
            handler = Handler(worker.looper)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }  // system chip, lock screen or another app ended it
                override fun onCapturedContentResize(width: Int, height: Int) { resize(width, height) }
            }, handler)
            val (w, h) = screenSize()
            val r = newReader(w, h)
            reader = r
            display = mp.createVirtualDisplay("nova", r.width, r.height, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
            graph.screen.started()
            graph.history.add("Screen", "Screen sharing started")
            handler?.post(tick)
            showIndicator()
        } catch (e: Exception) {
            graph.controller.report("Screen capture could not start. Please try again.")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else resources.displayMetrics.let { it.widthPixels to it.heightPixels }
    }

    private fun newReader(width: Int, height: Int): ImageReader {
        val scale = minOf(1f, graph.settings.settings.value.frameMaxSize.toFloat() / maxOf(width, height))
        return ImageReader.newInstance(maxOf(2, (width * scale).toInt()), maxOf(2, (height * scale).toInt()), PixelFormat.RGBA_8888, 2)
    }

    private fun resize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        handler?.post {
            val old = reader ?: return@post
            val next = newReader(width, height)
            if (next.width == old.width && next.height == old.height) { next.close(); return@post }
            // The projection token allows one VirtualDisplay, so resize it in place.
            display?.resize(next.width, next.height, resources.displayMetrics.densityDpi)
            display?.surface = next.surface
            reader = next; old.close(); signature = null
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (Build.VERSION.SDK_INT < 34) screenSize().let { resize(it.first, it.second) }
    }

    /** Samples at the user's interval and publishes only changed frames. */
    private val tick = object : Runnable {
        override fun run() {
            runCatching { capture() }
            handler?.postDelayed(this, graph.settings.settings.value.frameIntervalMs.toLong())
        }
    }

    private fun capture() {
        val image = reader?.acquireLatestImage() ?: return  // no new image means nothing moved
        val bitmap = image.use {
            val plane = it.planes[0]
            val padded = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(plane.buffer)
            Bitmap.createBitmap(padded, 0, 0, it.width, it.height).also { cropped -> if (cropped !== padded) padded.recycle() }
        }
        val small = Bitmap.createScaledBitmap(bitmap, 32, 32, true)
        val now = IntArray(32 * 32).also { small.getPixels(it, 0, 32, 0, 0, 32, 32) }
        if (small !== bitmap) small.recycle()
        val old = signature
        val changedCells = if (old == null) now.size else now.indices.count {
            abs((now[it] shr 8 and 0xff) - (old[it] shr 8 and 0xff)) > 12
        }
        // Refresh periodically even when static so a new session has a recent frame.
        if (changedCells >= 6 || System.currentTimeMillis() - lastSent > 30_000) {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, graph.settings.settings.value.jpegQuality, out)
            signature = now; lastSent = System.currentTimeMillis()
            graph.screen.publish(Frame(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), lastSent))
        }
        bitmap.recycle()
    }

    private fun showIndicator() {
        if (!graph.settings.settings.value.floatingIndicator || !android.provider.Settings.canDrawOverlays(this)) return
        val view = FloatingIndicator(this) { stopSelf() }
        if (!view.attach()) return
        indicator = view
        uiScope = CoroutineScope(Dispatchers.Main.immediate).also { s ->
            s.launch { graph.controller.state.collect { view.setState(it) } }
        }
    }

    override fun onDestroy() {
        val wasActive = graph.screen.active.value
        graph.screen.stopped()
        uiScope?.cancel(); indicator?.detach(); indicator = null
        handler?.removeCallbacksAndMessages(null)
        // Release on the capture thread so no frame is being processed meanwhile.
        val d = display; val r = reader; val t = thread
        handler?.post { d?.release(); r?.close() }
        t?.quitSafely()
        handler = null; display = null; reader = null
        projection?.stop(); projection = null
        if (wasActive) graph.history.add("Screen", "Screen sharing stopped")
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "com.nova.assistant.STOP_SCREEN"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        /** Call only with the result of the system consent dialog. */
        fun start(context: Context, resultCode: Int, data: Intent) = context.startForegroundService(
            Intent(context, ScreenCaptureService::class.java).putExtra(EXTRA_CODE, resultCode).putExtra(EXTRA_DATA, data))
        fun stop(context: Context) { context.stopService(Intent(context, ScreenCaptureService::class.java)) }
    }
}
