package com.nova.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.nova.assistant.core.AssistantSettings
import java.util.Locale

/** One-utterance Android speech recognition. All methods must be called on the main thread. */
class Recognizer(private val context: Context) {
    private var engine: SpeechRecognizer? = null

    fun listen(languageTag: String, preferOffline: Boolean, onResult: (String) -> Unit, onFail: (Int) -> Unit) {
        stop()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { onFail(UNAVAILABLE); return }
        val onDevice = preferOffline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        val r = if (onDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        else SpeechRecognizer.createSpeechRecognizer(context)
        engine = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                if (engine !== r) return
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onFail(SpeechRecognizer.ERROR_NO_MATCH) else onResult(text)
            }
            override fun onError(error: Int) { if (engine === r) onFail(error) }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
        })
    }

    fun stop() { engine?.let { engine = null; it.cancel(); it.destroy() } }

    companion object { const val UNAVAILABLE = -100 }
}

/** Android TextToSpeech, used by classic mode. QUEUE_FLUSH prevents overlapping speech. */
class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var done: (() -> Unit)? = null
    private var current = 0
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        main.post {
            ready = status == TextToSpeech.SUCCESS
            pending?.invoke(); pending = null
        }
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = finish(id)
            @Deprecated("Deprecated in Java") override fun onError(id: String?) = finish(id)
        })
    }

    private fun finish(id: String?) { main.post { if (id == current.toString()) { done?.invoke(); done = null } } }

    /** Installed voices for a language. Android does not report voice gender, so the user picks by ear. */
    fun voices(languageTag: String): List<Voice> = runCatching {
        val language = Locale.forLanguageTag(languageTag).language
        tts.voices.orEmpty().filter { it.locale.language == language }.sortedBy { it.name }
    }.getOrDefault(emptyList())

    fun speak(text: String, s: AssistantSettings, onDone: () -> Unit) {
        val run = {
            if (!ready) onDone() else {
                tts.language = Locale.forLanguageTag(s.languageTag)
                voices(s.languageTag).firstOrNull { it.name == s.ttsVoice }?.let { tts.voice = it }
                tts.setSpeechRate(s.speechRate); tts.setPitch(s.pitch)
                done = onDone
                current++
                val clean = text.replace(Regex("```[\\s\\S]*?```"), " code ").replace(Regex("[*#`_]"), "")
                    .take(TextToSpeech.getMaxSpeechInputLength() - 1)
                val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, s.volume) }
                if (tts.speak(clean, TextToSpeech.QUEUE_FLUSH, params, current.toString()) != TextToSpeech.SUCCESS) onDone()
            }
        }
        if (ready) run() else pending = run
    }

    fun stop() { pending = null; done = null; current++; tts.stop() }
}
