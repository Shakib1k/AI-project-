package com.nova.assistant.ui.screens

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.nova.assistant.assistant.AssistantService
import com.nova.assistant.automation.AssistantAccessibilityService
import com.nova.assistant.ui.*
import kotlinx.coroutines.launch

private fun accessibilityEnabled(context: Context): Boolean {
    val mine = ComponentName(context, AssistantAccessibilityService::class.java)
    return Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        .orEmpty().split(':').any { ComponentName.unflattenFromString(it) == mine }
}

fun Context.openSettings(intent: Intent) {
    runCatching { startActivity(intent) }.onFailure { runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
}

@Composable
private fun PermissionCard(title: String, status: String, about: String, revoke: String, button: String, action: () -> Unit) =
    GlassCard {
        Heading(title)
        Text(status)
        Note(about)
        Note("To revoke: $revoke")
        OutlinedButton(action) { Text(button) }
    }

@Composable
fun PermissionsScreen(vm: MainViewModel, back: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var disclose by remember { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    val sharing by vm.graph.screen.active.collectAsStateWithLifecycle()
    val workspace by vm.graph.settings.workspace.collectAsStateWithLifecycle()
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            vm.viewModelScope.launch { vm.graph.settings.setWorkspace(uri.toString()) }
        }
    }
    val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
    fun status(on: Boolean) = if (on) "● Granted" else "○ Not granted"

    Page("Permissions", back) {
        key(refresh) {
            val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            PermissionCard("Microphone", status(mic), "Voice conversation and wake word.",
                "App info → Permissions → Microphone.", if (mic) "Open app settings" else "Enable") {
                if (mic) context.openSettings(appDetails) else request.launch(Manifest.permission.RECORD_AUDIO)
            }
            if (!mic) TextButton({ context.openSettings(appDetails) }) { Text("Dialog not appearing? Open app settings") }
            PermissionCard("Accessibility", status(accessibilityEnabled(context)),
                "Reads visible text and taps, types and swipes when you ask. If greyed out for a sideloaded app: App info → ⋮ → Allow restricted settings.",
                "Accessibility settings → Nova Assistant → Off.", "Open settings") { disclose = true }
            PermissionCard("Screen capture", if (sharing) "● Sharing now" else "○ Off",
                "Android asks for consent each time. It cannot be granted in advance.",
                "Stop sharing in the app, notification or system chip.", "Stop sharing") {
                com.nova.assistant.screen.ScreenCaptureService.stop(context)
            }
            val notes = NotificationManagerCompat.from(context).areNotificationsEnabled()
            PermissionCard("Notifications", status(notes), "Shows when the microphone or capture service is running, with Stop buttons.",
                "App info → Notifications.", "Enable / open settings") {
                if (!notes && Build.VERSION.SDK_INT >= 33) request.launch(Manifest.permission.POST_NOTIFICATIONS)
                else context.openSettings(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            }
            if (!notes) TextButton({ context.openSettings(appDetails) }) { Text("Dialog not appearing? Open app settings") }
            PermissionCard("Display over other apps", status(Settings.canDrawOverlays(context)),
                "Floating screen-sharing indicator, and opening apps by wake word.",
                "Same settings page, switch off.", "Open settings") {
                context.openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
            }
            PermissionCard("Workspace folder", workspace?.let { "● ${Uri.decode(it.substringAfterLast('/'))}" } ?: "○ Not chosen",
                "The only folder the AI can read or write. Create e.g. Documents/NovaProjects. Android blocks the storage root and Download.",
                "Choose another folder, or clear the app's storage.", "Choose folder") { folder.launch(null) }
            PermissionCard("Background service", if (AssistantService.running) "● Running" else "○ Stopped",
                "Microphone foreground service for conversations and wake word.", "Press STOP AI.", "Stop") {
                vm.graph.controller.stopAll(); refresh++
            }
            val free = context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)
            PermissionCard("Battery optimization", if (free) "Unrestricted" else "Optimized (may stop background listening)",
                "Some phones need Unrestricted for a reliable wake word.", "Set the app back to Optimized.", "Open settings") {
                context.openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }
    if (disclose) AlertDialog(
        onDismissRequest = { disclose = false },
        title = { Text("Accessibility disclosure") },
        text = { Text("When you give a command, the assistant reads the visible text of the current app and sends it to your configured " +
            "Gemini model (or proxy). It can tap, type, swipe and navigate. Password fields are excluded; other private text on screen is not. " +
            "Sensitive taps need your approval. You can turn this off at any time.") },
        confirmButton = { Button({ disclose = false; context.openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("I agree, open settings") } },
        dismissButton = { TextButton({ disclose = false }) { Text("Cancel") } }
    )
}
