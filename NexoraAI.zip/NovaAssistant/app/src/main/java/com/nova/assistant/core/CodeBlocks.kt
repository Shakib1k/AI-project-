package com.nova.assistant.core

data class GeneratedFile(val path: String, val content: String)

/** Parses fences written as ```lang path=dir/file.ext. A longer outer fence may contain ``` blocks. */
object CodeBlocks {
    private val open = Regex("^(`{3,})[^`]*?\\bpath=(\\S+)\\s*$")

    data class Result(val files: List<GeneratedFile>, val unterminated: List<String>)

    fun parse(text: String): Result {
        val files = LinkedHashMap<String, String>()
        val broken = mutableListOf<String>()
        val lines = text.replace("\r\n", "\n").split('\n')
        var i = 0
        while (i < lines.size) {
            val m = open.find(lines[i].trimStart())
            i++
            if (m == null) continue
            val fence = m.groupValues[1]
            val path = m.groupValues[2]
            val body = mutableListOf<String>()
            while (i < lines.size && lines[i].trim() != fence) body.add(lines[i++])
            when {
                i >= lines.size -> broken.add(path)      // truncated: never save half a file
                SafePath.split(path) != null -> files[path] = body.joinToString("\n") + "\n"
                else -> broken.add(path)
            }
            i++
        }
        return Result(files.map { GeneratedFile(it.key, it.value) }, broken)
    }
}
