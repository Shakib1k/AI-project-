package com.nova.assistant.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.nova.assistant.AppGraph
import com.nova.assistant.coding.endpointFor
import com.nova.assistant.core.*
import com.nova.assistant.gemini.GeminiException
import com.nova.assistant.gemini.LiveSession
import com.nova.assistant.screen.ScreenCaptureService
import com.nova.assistant.voice.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

data class Caption(val fromUser: Boolean, val text: String)

/**
 * Single owner of the conversation. All state changes happen on the main thread.
 * Live mode: server-side voice activity detection gives true barge-in.
 * Classic mode: SpeechRecognizer, generateContent and TTS; interruption is by tapping the mic.
 */
class AssistantController(private val context: Context, private val graph: AppGraph) {
    private val main = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(AssistantState.IDLE)
    val state: StateFlow<AssistantState> = _state
    private val _inSession = MutableStateFlow(false)
    val inSession: StateFlow<Boolean> = _inSession
    private val _captions = MutableStateFlow<List<Caption>>(emptyList())
    val captions: StateFlow<List<Caption>> = _captions
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted
    private val _wakeListening = MutableStateFlow(false)
    val wakeListening: StateFlow<Boolean> = _wakeListening

    private val mic = MicStreamer()
    private var player: PcmPlayer? = null
    private var live: LiveSession? = null
    private val route = AudioRoute(context) { main.post { stopSession(); report("Audio was taken by another app.") } }
    private val wake = WakeWordEngine(context)
    private val recognizer by lazy { Recognizer(context) }
    private val speaker by lazy { Speaker(context) }
    private var sessionJob: Job? = null
    private var turnJob: Job? = null
    private val toolJobs = mutableMapOf<String, Job>()
    private var resumeHandle: String? = null
    private var reconnects = 0
    private var greeting: String? = null
    private var pendingStart: (() -> Unit)? = null
    private val classicHistory = mutableListOf<JsonObject>()
    private var turnOpen = false

    private val settings get() = graph.settings.settings.value

    fun voices() = speaker.voices(settings.languageTag).map { it.name }
    fun previewVoice() = speaker.speak("জি বস, বলুন। How can I help you?", settings) {}

    fun report(message: String) { main.post { _error.value = message } }
    fun clearError() { _error.value = null }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Runs the action once the microphone foreground service is up. Must start while the app is visible. */
    private fun withService(text: String, action: () -> Unit) {
        if (AssistantService.running) { action(); return }
        pendingStart = action
        runCatching { AssistantService.start(context, text) }
            .onFailure { pendingStart = null; report("Open the app to start the microphone service.") }
    }

    fun onServiceReady() { pendingStart?.also { pendingStart = null }?.invoke() }

    fun onServiceDestroyed() {
        pendingStart = null
        wake.stop(); _wakeListening.value = false
        if (_inSession.value) endConversation()
    }

    fun startWakeWord() {
        if (!hasMic()) { report("Microphone permission is required."); return }
        if (_inSession.value) return
        withService("Listening for “${settings.aiName}”") { listenForWake() }
    }

    private fun listenForWake() {
        _wakeListening.value = true
        wake.start(settings, { rest ->
            _wakeListening.value = false
            startSession(if (rest.isBlank())
                "[App event: the user called your name. Reply only with: জি বস, বলুন।]" else rest)
        }, { reason -> _wakeListening.value = false; report(reason); AssistantService.stop(context) })
    }

    fun stopWakeWord() {
        wake.stop(); _wakeListening.value = false
        if (!_inSession.value) AssistantService.stop(context)
    }

    fun startSession(firstText: String? = null) {
        if (_inSession.value) return
        if (!hasMic()) { report("Microphone permission is required."); return }
        withService("Live conversation: microphone in use") {
            wake.stop(); _wakeListening.value = false
            _error.value = null; _captions.value = emptyList(); _muted.value = false
            _inSession.value = true; resumeHandle = null; reconnects = 0; greeting = firstText
            graph.history.add("Conversation", "Session started")
            sessionJob = graph.scope.launch {
                launch {
                    graph.screen.active.drop(1).collect { on ->
                        live?.send(GeminiProtocol.liveText(if (on)
                            "[App event: screen sharing is now ACTIVE. Do not reply unless asked.]"
                        else "[App event: screen sharing STOPPED. You can no longer see the screen. Do not reply.]"))
                    }
                }
                launch { graph.screen.changed.collect { live?.send(GeminiProtocol.liveFrame(it.jpegBase64)) } }
            }
            if (settings.useLiveApi) startLive() else startClassic()
        }
    }

    // ---------- Live API ----------

    private fun startLive() {
        if (!route.acquire()) { fail("Could not get audio focus."); return }
        player = PcmPlayer { playing ->
            main.post {
                if (_inSession.value) _state.value = if (playing) AssistantState.SPEAKING
                else if (_state.value == AssistantState.SPEAKING) AssistantState.LISTENING else _state.value
            }
        }.also { it.setVolume(settings.volume) }
        connect()
    }

    private fun connect() {
        _state.value = AssistantState.CONNECTING
        val s = settings
        try {
            val setup = GeminiProtocol.liveSetup(s.liveModel, Prompts.assistant(s, graph.screen.active.value),
                s.liveVoice, ToolSchema.all, resumeHandle)
            live = LiveSession(graph.client, endpointFor(s, s.liveModel), setup,
                { session, event -> main.post { if (session === live) onLive(session, event) } },
                { session, reason -> main.post { if (session === live) onDropped(reason) } })
        } catch (e: GeminiException) { fail(e.message!!) }
    }

    private fun onLive(session: LiveSession, event: LiveEvent) {
        when (event) {
            LiveEvent.Ready -> {
                _state.value = AssistantState.LISTENING
                mic.muted = _muted.value
                mic.start({ session.send(GeminiProtocol.liveAudio(it)) }, { main.post { fail(it) } })
                greeting?.let { session.send(GeminiProtocol.liveText(it)); greeting = null }
                graph.screen.latest?.let { session.send(GeminiProtocol.liveFrame(it.jpegBase64)) }
            }
            is LiveEvent.Audio -> {
                if (settings.voiceResponses) player?.play(event.base64)
                _state.value = AssistantState.SPEAKING
            }
            is LiveEvent.UserText -> { graph.confirmations.onUserSpeech(event.text); caption(true, event.text) }
            is LiveEvent.ModelText -> caption(false, event.text)
            LiveEvent.Interrupted -> {
                player?.flush()
                turnOpen = false
                _state.value = AssistantState.LISTENING
            }
            LiveEvent.TurnComplete -> {
                turnOpen = false; reconnects = 0
                graph.confirmations.onTurnBoundary()
                if (_state.value != AssistantState.SPEAKING) _state.value = AssistantState.LISTENING
            }
            is LiveEvent.ToolCalls -> {
                _state.value = AssistantState.THINKING
                graph.confirmations.onTurnBoundary()
                event.calls.forEach { call ->
                    if (graph.confirmations.pending.value != null) {
                        session.send(GeminiProtocol.liveToolResponse(call,
                            status("Another action is waiting for the user's approval. Wait for its result.")))
                        return@forEach
                    }
                    val job = graph.scope.launch(start = CoroutineStart.LAZY) { runLiveTool(call) }
                    toolJobs[call.id] = job
                    job.invokeOnCompletion { main.post { if (toolJobs[call.id] === job) toolJobs.remove(call.id) } }
                    job.start()
                }
            }
            is LiveEvent.ToolCancel -> event.ids.forEach { toolJobs.remove(it)?.cancel() }
            is LiveEvent.ResumeHandle -> resumeHandle = event.handle
            LiveEvent.GoAway -> if (resumeHandle != null) reconnect()
        }
    }

    private fun status(message: String) = buildJsonObject {
        put("ok", false); put("verified", false); put("message", message)
    }

    /**
     * User speech can make the server cancel a call that is still open. So when approval is needed,
     * the call is answered at once with "waiting", and the real outcome follows as an app event.
     */
    private suspend fun runLiveTool(call: FunctionCall) = coroutineScope {
        var answered = false
        val watcher = launch {
            graph.confirmations.pending.first { it != null }
            answered = true
            live?.send(GeminiProtocol.liveToolResponse(call, status(
                "NOT DONE YET. Waiting for the user's approval. Ask briefly, state the exact action, " +
                    "then wait for the app event with the result.")))
        }
        val result = graph.tools.execute(call)
        watcher.cancel()
        live?.send(if (answered) GeminiProtocol.liveText("[App event: final result of ${call.name}: $result]")
            else GeminiProtocol.liveToolResponse(call, result))
    }

    private fun reconnect() {
        mic.stop(); player?.flush(); cancelTools()
        live?.close(); live = null
        connect()
    }

    private fun onDropped(reason: String) {
        if (resumeHandle != null && reconnects < 3) {
            reconnects++
            mic.stop(); player?.flush(); cancelTools(); live = null
            _state.value = AssistantState.CONNECTING
            sessionJob?.let { parent -> graph.scope.launch(parent) { delay(1000L * reconnects); if (live == null) connect() } }
        } else fail(reason)
    }

    // ---------- Classic mode ----------

    private fun startClassic() {
        classicHistory.clear()
        val first = greeting.also { greeting = null }
        if (first != null) classicTurn(first) else listenClassic()
    }

    private fun listenClassic() {
        if (!_inSession.value || _muted.value) { _state.value = AssistantState.IDLE; return }
        _state.value = AssistantState.LISTENING
        recognizer.listen(settings.languageTag, false, { heard ->
            graph.confirmations.onTurnBoundary()
            if (graph.confirmations.pending.value != null) { graph.confirmations.onUserSpeech(heard); listenClassic() }
            else { caption(true, heard); turnOpen = false; classicTurn(heard) }
        }, { code ->
            if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                main.postDelayed({ if (_inSession.value && _state.value == AssistantState.LISTENING) listenClassic() }, 400)
            else fail("Speech recognition failed (error $code).")
        })
    }

    private fun classicTurn(text: String) {
        turnJob?.cancel()
        _state.value = AssistantState.THINKING
        turnJob = graph.scope.launch {
            val s = settings
            val checkpoint = classicHistory.size
            try {
                val parts = mutableListOf(GeminiProtocol.textPart(text))
                val frame = if (graph.screen.active.value) graph.screen.latest else null
                frame?.let { parts.add(0, GeminiProtocol.imagePart(it.jpegBase64)) }
                classicHistory += GeminiProtocol.content("user", parts)
                var reply = ""
                for (round in 0 until 12) {
                    val response = graph.client.generate(endpointFor(s, s.textModel), s.textModel,
                        GeminiProtocol.generateRequest(classicHistory, Prompts.assistant(s, graph.screen.active.value),
                            ToolSchema.all, s.maxOutputTokens, if (s.sendTemperature) s.temperature else null))
                    val modelParts = GeminiProtocol.responseParts(response)
                    if (modelParts.isEmpty()) throw GeminiException("Empty or blocked response.")
                    classicHistory += GeminiProtocol.content("model", modelParts)
                    val calls = GeminiProtocol.functionCalls(modelParts)
                    if (calls.isEmpty()) { reply = GeminiProtocol.visibleText(modelParts); break }
                    classicHistory += GeminiProtocol.content("user",
                        calls.map { GeminiProtocol.functionResponsePart(it, graph.tools.execute(it)) })
                }
                if (reply.isBlank()) reply = "বস, কাজটা শেষ করতে পারিনি। অনেক ধাপ লাগছে।"
                // Keep context short: drop whole old turns, and old screenshots.
                while (classicHistory.size > 30) {
                    classicHistory.removeAt(0)
                    while (classicHistory.isNotEmpty() && !isUserText(classicHistory.first())) classicHistory.removeAt(0)
                }
                frame?.let {
                    val index = classicHistory.indexOfLast(::isUserText)
                    if (index >= 0) classicHistory[index] = GeminiProtocol.content("user", listOf(GeminiProtocol.textPart(text)))
                }
                turnOpen = false
                caption(false, reply)
                if (s.voiceResponses) {
                    _state.value = AssistantState.SPEAKING
                    speaker.speak(reply, s) { listenClassic() }
                } else listenClassic()
            } catch (e: CancellationException) {
                while (classicHistory.size > checkpoint) classicHistory.removeAt(classicHistory.lastIndex)
                throw e
            } catch (e: GeminiException) { fail(e.message!!) }
        }
    }

    private fun isUserText(content: JsonObject) = content["role"].str() == "user" &&
        content["parts"].arr().any { it.obj()?.containsKey("text") == true }

    // ---------- Controls ----------

    /** Stop talking now. In live mode, speaking over the assistant does the same automatically. */
    fun interrupt() {
        if (!_inSession.value) return
        if (settings.useLiveApi) {
            player?.flush()
            live?.send(GeminiProtocol.liveText("[App event: the user pressed interrupt. Stop and wait.]"))
            _state.value = AssistantState.LISTENING
        } else {
            turnJob?.cancel(); speaker.stop(); graph.confirmations.resolve(false)
            _muted.value = false; listenClassic()
        }
    }

    fun toggleMute() {
        _muted.value = !_muted.value
        mic.muted = _muted.value
        if (!settings.useLiveApi) {
            if (_muted.value) { recognizer.stop(); if (_state.value == AssistantState.LISTENING) _state.value = AssistantState.IDLE }
            else if (_state.value == AssistantState.IDLE) listenClassic()
        }
    }

    private fun caption(fromUser: Boolean, chunk: String) {
        val list = _captions.value.toMutableList()
        val last = list.lastOrNull()
        if (turnOpen && last != null && last.fromUser == fromUser) list[list.lastIndex] = last.copy(text = last.text + chunk)
        else list += Caption(fromUser, chunk)
        turnOpen = true
        _captions.value = list.takeLast(40)  // in memory only
    }

    private fun cancelTools() {
        toolJobs.values.toList().forEach { it.cancel() }
        toolJobs.clear()
        graph.confirmations.resolve(false)
        graph.tools.forget()
    }

    private fun endConversation() {
        if (!_inSession.value) return
        _inSession.value = false
        sessionJob?.cancel(); turnJob?.cancel(); cancelTools()
        live?.close(); live = null
        mic.stop()
        player?.release()
        if (player != null) route.release()
        player = null
        if (!settings.useLiveApi) { recognizer.stop(); speaker.stop() }
        _state.value = AssistantState.IDLE
        graph.history.add("Conversation", "Session ended")
    }

    private fun fail(message: String) {
        graph.history.add("Error", message)
        _error.value = message
        stopSession()
    }

    fun stopSession() {
        endConversation()
        if (settings.wakeEnabled && AssistantService.running) listenForWake() else AssistantService.stop(context)
    }

    /** Emergency stop: conversation, actions, wake word and screen capture. */
    fun stopAll() {
        pendingStart = null
        endConversation()
        cancelTools()
        wake.stop(); _wakeListening.value = false
        graph.scope.launch { graph.settings.update { it.copy(wakeEnabled = false) } }
        runCatching { speaker.stop() }
        ScreenCaptureService.stop(context)
        AssistantService.stop(context)
        _state.value = AssistantState.IDLE
        graph.history.add("Safety", "STOP AI used")
    }
}
