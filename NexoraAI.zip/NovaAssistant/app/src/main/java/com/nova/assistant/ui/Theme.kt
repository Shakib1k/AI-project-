package com.nova.assistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Red = Color(0xFFFF2442)
val Muted = Color(0xFFA8A0A3)
private val Glass = Color(0x14FFFFFF)

@Composable
fun NovaTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Red, onPrimary = Color.White, secondary = Color.White, onSecondary = Color.Black,
        secondaryContainer = Color(0xFF3A0C15), background = Color.Black, onBackground = Color.White,
        surface = Color.Black, onSurface = Color.White, surfaceVariant = Color(0xFF151113),
        onSurfaceVariant = Muted, outline = Color(0xFF55454A), error = Color(0xFFFF8A80),
        surfaceContainerHigh = Color(0xFF181214)
    ), content = content
)

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Surface(
    modifier = modifier.fillMaxWidth(), color = Glass, shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, Color(0x26FFFFFF))
) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }
