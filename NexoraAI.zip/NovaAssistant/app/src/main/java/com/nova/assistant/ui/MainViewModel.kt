package com.nova.assistant.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.assistant.NovaApp
import com.nova.assistant.coding.endpointFor
import com.nova.assistant.core.*
import com.nova.assistant.data.SecureStore
import com.nova.assistant.gemini.GeminiException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val graph = (app as NovaApp).graph
    val settings = graph.settings.settings

    fun update(change: (AssistantSettings) -> AssistantSettings) {
        viewModelScope.launch { graph.settings.update(change) }
    }

    // API configuration
    var apiStatus by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    var models by mutableStateOf<List<ModelInfo>>(emptyList())
        private set
    var hasKey by mutableStateOf(graph.secrets.has(SecureStore.API_KEY))
        private set

    fun saveSecrets(key: String, token: String) {
        runCatching {
            if (key.isNotBlank()) graph.secrets.put(SecureStore.API_KEY, key)
            if (token.isNotBlank()) graph.secrets.put(SecureStore.PROXY_TOKEN, token)
        }.onSuccess { apiStatus = "Saved with Android Keystore encryption." }
            .onFailure { apiStatus = "Secure storage failed on this device. Nothing was saved." }
        hasKey = graph.secrets.has(SecureStore.API_KEY)
    }

    fun removeSecrets() {
        graph.secrets.put(SecureStore.API_KEY, ""); graph.secrets.put(SecureStore.PROXY_TOKEN, "")
        hasKey = false; apiStatus = "Key and token removed."
    }

    private fun api(block: suspend () -> Unit) {
        if (busy) return
        busy = true; apiStatus = "Working…"
        viewModelScope.launch {
            try { block() }
            catch (e: GeminiException) { apiStatus = e.message.orEmpty() }
            finally { busy = false }
        }
    }

    fun loadModels() = api {
        val all = graph.client.listModels(settings.value.proxyUrl)
        models = all.filter { it.usable }.sortedBy { it.id }
        apiStatus = "Connected. ${models.size} usable of ${all.size} models returned."
    }

    /** Looks the model up, probes real capabilities, then saves it. */
    fun validateAndSave(name: String, id: String, endpoint: String) = api {
        val base = endpoint.trim().ifEmpty { settings.value.proxyUrl }
        val info = graph.client.getModel(base, id)
        if (!info.usable) throw GeminiException("This model supports neither text generation nor Live audio.")
        apiStatus = "Model found. Testing image and tool support (uses a little quota)…"
        val (caps, notes) = graph.client.probe(base, info)
        val saved = SavedModel(name.ifBlank { info.displayName }, info.id, "Google Gemini", endpoint.trim(), caps)
        graph.settings.update { s -> s.copy(savedModels = s.savedModels.filter { it.modelId != info.id } + saved) }
        apiStatus = "Saved ${info.id}: ${caps.joinToString { it.label }}" +
            if (notes.isEmpty()) "" else "\n" + notes.joinToString("\n")
    }

    /** A role is assigned only if the model was verified for what that role needs. */
    fun setDefault(model: SavedModel, live: Boolean) {
        val needed = if (live) setOf(Capability.LIVE) else setOf(Capability.TEXT, Capability.IMAGE_INPUT, Capability.TOOLS)
        val missing = needed - model.capabilities
        if (missing.isNotEmpty()) { apiStatus = "Not selected. Unverified: ${missing.joinToString { it.label }}"; return }
        update { if (live) it.copy(liveModel = model.modelId) else it.copy(textModel = model.modelId) }
        apiStatus = "${model.modelId} is now the default ${if (live) "Live voice" else "text, vision and coding"} model."
    }

    fun deleteModel(model: SavedModel) = update { s -> s.copy(savedModels = s.savedModels - model) }

    fun testConnection() = api {
        val s = settings.value
        val info = graph.client.getModel(endpointFor(s, s.textModel), s.textModel)
        apiStatus = "Connection OK. ${info.id} is available. (Live voice is verified when a session starts.)"
    }

    // Coding assistant
    var codeReply by mutableStateOf("")
        private set
    var codeStatus by mutableStateOf("")
        private set
    var codeBusy by mutableStateOf(false)
        private set
    private var codeJob: Job? = null

    fun askCode(prompt: String) {
        codeJob?.cancel()
        codeBusy = true; codeStatus = "Generating…"
        codeJob = viewModelScope.launch {
            try {
                val reply = graph.coder.ask(prompt)
                codeReply = reply.text
                codeStatus = if (reply.truncated) "Output limit reached: the answer is INCOMPLETE. Ask for fewer files at a time." else ""
                graph.history.add("Coding", prompt)
            } catch (e: CancellationException) { throw e }
            catch (e: GeminiException) { codeStatus = e.message.orEmpty() }
            codeBusy = false
        }
    }

    fun stopCode() { codeJob?.cancel(); codeBusy = false; codeStatus = "Stopped." }
    fun newProject() { stopCode(); graph.coder.reset(); codeReply = ""; codeStatus = "" }

    /** The user presses Save after seeing the file list; existing files are not replaced unless asked. */
    fun saveFiles(files: List<GeneratedFile>, overwrite: Boolean) {
        viewModelScope.launch {
            codeStatus = try {
                val clash = if (overwrite) emptyList() else files.filter { graph.files.exists(it.path) }
                if (clash.isNotEmpty()) "These exist: ${clash.joinToString { it.path }}. Tick overwrite to replace them."
                else {
                    files.forEach { graph.files.write(it.path, it.content) }
                    graph.history.add("Files", "Saved and verified ${files.size} file(s)")
                    "Saved and verified ${files.size} file(s)."
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { "Save failed: ${e.message}" }
        }
    }
}
