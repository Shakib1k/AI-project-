package com.nova.assistant.gemini

import com.nova.assistant.core.*
import com.nova.assistant.data.SecureStore
import kotlinx.coroutines.*
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class GeminiException(message: String) : Exception(message)

class GeminiClient(private val secrets: SecureStore) {
    // No logging interceptor on purpose: requests carry credentials and user data.
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .followRedirects(false)   // never forward credentials to another host
        .build()

    private val google = "https://generativelanguage.googleapis.com"

    /** The Google key only ever goes to Google. Any other endpoint gets the proxy token instead. */
    private fun request(base: String, path: String): Request.Builder {
        val root = base.trim().trimEnd('/').ifEmpty { google }
        val url = (root + path).toHttpUrlOrNull()
        if (url == null || !url.isHttps) throw GeminiException("Endpoint must be a valid https:// URL.")
        val builder = Request.Builder().url(url)
        if (root == google) {
            val key = secrets.get(SecureStore.API_KEY) ?: throw GeminiException("Add your Gemini API key in API settings.")
            builder.header("x-goog-api-key", key)
        } else {
            val token = secrets.get(SecureStore.PROXY_TOKEN) ?: throw GeminiException("Add your proxy token in API settings.")
            builder.header("x-proxy-token", token)
        }
        return builder
    }

    /** Cancelling the coroutine cancels the HTTP call, which is how barge-in stops generation. */
    private suspend fun execute(req: Request): JsonObject = suspendCancellableCoroutine { cont ->
        val call = http.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(GeminiException("Network error. Check your connection."))
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val result = runCatching {
                        val body = it.body?.string().orEmpty()
                        if (!it.isSuccessful) throw GeminiException(GeminiProtocol.errorMessage(it.code, body))
                        parseObject(body) ?: throw GeminiException("Unreadable response from server.")
                    }
                    if (cont.isActive) result.fold({ v -> cont.resume(v) }, { e ->
                        cont.resumeWithException(e as? GeminiException ?: GeminiException("Connection lost while reading."))
                    })
                }
            }
        })
    }

    suspend fun listModels(base: String): List<ModelInfo> {
        val all = mutableListOf<ModelInfo>()
        var page = ""
        do {
            val suffix = if (page.isEmpty()) "" else "&pageToken=" + java.net.URLEncoder.encode(page, "UTF-8")
            val res = execute(request(base, "/v1beta/models?pageSize=1000$suffix").build())
            all += res["models"].arr().mapNotNull { it.obj()?.let(GeminiProtocol::parseModel) }
            page = res["nextPageToken"].str().orEmpty()
        } while (page.isNotEmpty())
        return all
    }

    suspend fun getModel(base: String, id: String): ModelInfo {
        if (!GeminiProtocol.isValidModelId(id)) throw GeminiException("That model ID has invalid characters.")
        return GeminiProtocol.parseModel(execute(request(base, "/v1beta/models/" + GeminiProtocol.cleanModelId(id)).build()))
    }

    suspend fun generate(base: String, model: String, body: JsonObject): JsonObject = execute(
        request(base, "/v1beta/models/${GeminiProtocol.cleanModelId(model)}:generateContent")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
    )

    /** The models endpoint does not report image or tool support, so send tiny real requests. */
    suspend fun probe(base: String, info: ModelInfo): Pair<Set<Capability>, List<String>> {
        val caps = info.capabilities.toMutableSet()
        val notes = mutableListOf<String>()
        if (Capability.TEXT in caps) {
            suspend fun attempt(cap: Capability, body: JsonObject, passed: (JsonObject) -> Boolean) {
                try {
                    if (passed(generate(base, info.id, body))) caps += cap else notes += "${cap.label}: not confirmed"
                } catch (e: GeminiException) { notes += "${cap.label}: ${e.message}" }
            }
            val pixel = "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA="
            attempt(Capability.IMAGE_INPUT, GeminiProtocol.generateRequest(
                listOf(GeminiProtocol.content("user", listOf(GeminiProtocol.imagePart(pixel), GeminiProtocol.textPart("Reply OK")))),
                null, null, 2048, null
            )) { GeminiProtocol.responseParts(it).isNotEmpty() }
            val ping = buildJsonArray { addJsonObject { put("name", "ping"); put("description", "Connectivity check") } }
            attempt(Capability.TOOLS, GeminiProtocol.generateRequest(
                listOf(GeminiProtocol.content("user", listOf(GeminiProtocol.textPart("Call the ping function now.")))),
                null, ping, 2048, null
            )) { GeminiProtocol.functionCalls(GeminiProtocol.responseParts(it)).isNotEmpty() }
        }
        return caps to notes
    }

    fun openSocket(base: String, listener: WebSocketListener): WebSocket {
        val path = "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        return http.newWebSocket(request(base, path).build(), listener)
    }
}
