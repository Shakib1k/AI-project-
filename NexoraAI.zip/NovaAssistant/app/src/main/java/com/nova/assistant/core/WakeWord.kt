package com.nova.assistant.core

import java.text.Normalizer

object WakeWord {
    fun normalize(text: String): String =
        Normalizer.normalize(text, Normalizer.Form.NFC).lowercase()
            // Keep letters, digits and combining marks (needed for Bengali/Hindi vowel signs).
            .replace(Regex("[^\\p{L}\\p{M}\\p{N}]+"), " ").trim()

    fun names(settings: AssistantSettings): List<String> =
        (listOf(settings.aiName) + settings.wakeAliases.split(','))
            .map(::normalize).filter { it.length >= 2 }.distinct()

    /**
     * Returns the text spoken after the wake word, or null when there is no match.
     * Whole words only, near the start, so "Amaya" does not wake "Maya".
     */
    fun match(heard: String, names: List<String>): String? {
        val words = normalize(heard).split(' ').filter { it.isNotEmpty() }
        for (name in names) {
            val parts = name.split(' ')
            for (start in 0..minOf(2, words.size - parts.size)) {
                if (words.subList(start, start + parts.size) == parts)
                    return words.drop(start + parts.size).joinToString(" ")
            }
        }
        return null
    }
}
