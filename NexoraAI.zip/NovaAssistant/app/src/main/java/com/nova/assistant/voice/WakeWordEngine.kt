package com.nova.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import com.nova.assistant.core.AssistantSettings
import com.nova.assistant.core.WakeWord

/**
 * Restarts Android speech recognition in a loop while the microphone foreground service runs.
 * This is not a low-power hotword chip: it costs battery, may beep on some phones and has short gaps.
 * To use a dedicated engine (e.g. Vosk or Porcupine), replace this class.
 */
class WakeWordEngine(context: Context) {
    private val recognizer = Recognizer(context)
    private val main = Handler(Looper.getMainLooper())
    private var token = 0

    fun start(settings: AssistantSettings, onWake: (String) -> Unit, onFatal: (String) -> Unit) {
        stop()
        val mine = ++token
        val names = WakeWord.names(settings)
        var failures = 0
        fun loop() {
            if (mine != token) return
            recognizer.listen(settings.languageTag, true, { heard ->
                if (mine != token) return@listen
                failures = 0
                val rest = WakeWord.match(heard, names)
                if (rest != null) { stop(); onWake(rest) } else main.postDelayed({ loop() }, 300)
            }, { error ->
                if (mine != token) return@listen
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                failures = if (quiet) 0 else failures + 1
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error == Recognizer.UNAVAILABLE || failures >= 8) {
                    stop(); onFatal("Wake word stopped (speech recognizer error $error). Check the language pack and microphone permission.")
                } else main.postDelayed({ loop() }, if (quiet) 300L else 1000L * failures)
            })
        }
        main.post { loop() }
    }

    fun stop() { token++; main.removeCallbacksAndMessages(null); recognizer.stop() }
}
