package com.nova.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.assistant.ui.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: MainViewModel, back: () -> Unit, go: (String) -> Unit, setWake: (Boolean) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    Page("Settings", back) {
        GlassCard {
            Heading("Identity and wake word")
            var preset by remember { mutableIntStateOf(0) }
            key(preset) {
                Field("AI name (this is the wake word)", s.aiName) { v -> if (v.isNotBlank()) vm.update { it.copy(aiName = v.trim()) } }
                Field("Other spellings, comma separated (e.g. মায়া)", s.wakeAliases) { v -> vm.update { it.copy(wakeAliases = v) } }
            }
            ChipRow(listOf("Maya" to "মায়া, माया", "Riya" to "রিয়া, रिया", "Nova" to "নোভা, नोवा", "Jarvis" to "জার্ভিস, जार्विस")) { (n, a) ->
                vm.update { it.copy(aiName = n, wakeAliases = a) }
                // Recreate the fields after the new values arrive.
                scope.launch { vm.settings.first { it.aiName == n }; preset++ }
            }
            Toggle("Background wake word", s.wakeEnabled, setWake)
            Note("Runs only while its notification is visible. It uses Android speech recognition: extra battery, possible beeps, short gaps, " +
                "and audio may go to your speech provider. After a reboot or app kill, open the app and switch it on again. " +
                "If you rename the assistant, switch this off and on.")
        }
        listOf(
            "Gemini API key and connection" to "api", "Models and custom models" to "models",
            "Voice and personality" to "voice", "Permissions" to "permissions",
            "Screen sharing and AI vision" to "screen", "Coding assistant" to "coding", "Activity history" to "history"
        ).forEach { (label, route) -> OutlinedButton({ go(route) }, Modifier.fillMaxWidth()) { Text(label) } }
        StopButton(vm)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipRow(values: List<Pair<String, String>>, pick: (Pair<String, String>) -> Unit) =
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { values.forEach { AssistChip({ pick(it) }, { Text(it.first) }) } }

@Composable
fun ApiScreen(vm: MainViewModel, back: () -> Unit, go: (String) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var apiKey by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var generation by remember { mutableIntStateOf(0) }
    Page("Gemini API", back) {
        GlassCard {
            Note(if (vm.hasKey) "An API key is saved. It is never displayed again." else "No API key saved.")
            key(generation) {
                Field("New Gemini API key", "", secret = true) { apiKey = it }
                Field("Proxy token (only for a backend proxy)", "", secret = true) { token = it }
            }
            Button({ vm.saveSecrets(apiKey, token); apiKey = ""; token = ""; generation++ }) { Text("Save securely") }
            TextButton(vm::removeSecrets) { Text("Remove key and token") }
        }
        GlassCard {
            Field("Backend proxy URL (empty = Google directly)", s.proxyUrl) { v -> vm.update { it.copy(proxyUrl = v.trim()) } }
            Note("For apps you distribute, use a proxy so no Google key is on users' phones. Your Google key is only ever sent to Google.")
            Button(vm::testConnection, enabled = !vm.busy) { Text("Test connection") }
            Button({ go("models") }) { Text("Choose model") }
            Text(vm.apiStatus)
        }
        GlassCard {
            Heading("Response settings")
            Toggle("Send temperature (older models only)", s.sendTemperature) { v -> vm.update { it.copy(sendTemperature = v) } }
            Note("Google has deprecated temperature; current models ignore it.")
            if (s.sendTemperature) SliderRow("Temperature", s.temperature, 0f..2f) { v -> vm.update { it.copy(temperature = v) } }
            Picker("Max output tokens", s.maxOutputTokens.toString(), listOf("8192", "16384", "32768", "65536")) { v ->
                vm.update { it.copy(maxOutputTokens = v.toInt()) }
            }
            Note("These apply to text, classic voice and coding requests.")
        }
    }
}

@Composable
fun VoiceScreen(vm: MainViewModel, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    Page("Voice and personality", back) {
        GlassCard {
            Toggle("Live API voice (natural, interruptible)", s.useLiveApi) { v -> vm.update { it.copy(useLiveApi = v) } }
            Toggle("Voice responses", s.voiceResponses) { v -> vm.update { it.copy(voiceResponses = v) } }
            SliderRow("Volume", s.volume, 0f..1f) { v -> vm.update { it.copy(volume = v) } }
        }
        if (s.useLiveApi) GlassCard {
            Heading("Gemini neural voice")
            Picker("Voice", s.liveVoice, listOf("Leda", "Aoede", "Kore", "Zephyr", "Autonoe", "Callirrhoe")) { v ->
                vm.update { it.copy(liveVoice = v) }
            }
            SliderRow("Speaking pace (a request to the model)", s.speechRate, .7f..1.4f) { v -> vm.update { it.copy(speechRate = v) } }
            Note("Leda sounds youthful and Aoede breezy. Live voices pick the language automatically and have no pitch control. Changes apply to the next session.")
        } else GlassCard {
            Heading("Android voice (classic mode)")
            Picker("Language", s.languageTag, listOf("bn-BD", "bn-IN", "en-IN", "en-US", "hi-IN")) { v ->
                vm.update { it.copy(languageTag = v, ttsVoice = "") }
            }
            var voices by remember { mutableStateOf(emptyList<String>()) }
            OutlinedButton({ voices = listOf("") + vm.graph.controller.voices() }) { Text("Load installed voices") }
            if (voices.isNotEmpty()) Picker("Voice", s.ttsVoice, voices) { v -> vm.update { it.copy(ttsVoice = v) } }
            Note("Android does not label voice gender. Preview voices and keep the one you like.")
            SliderRow("Speed", s.speechRate, .5f..2f) { v -> vm.update { it.copy(speechRate = v) } }
            SliderRow("Pitch", s.pitch, .5f..2f) { v -> vm.update { it.copy(pitch = v) } }
            Button(vm.graph.controller::previewVoice) { Text("Preview") }
        }
        if (s.useLiveApi) Picker("Wake word recognition language", s.languageTag, listOf("bn-BD", "bn-IN", "en-IN", "en-US", "hi-IN")) { v ->
            vm.update { it.copy(languageTag = v) }
        }
        GlassCard {
            Heading("Behavior")
            Field("Personality", s.personality, lines = 2) { v -> vm.update { it.copy(personality = v) } }
            Picker("Reply language", s.replyLanguage, listOf(
                "Natural Bengali / Hinglish mix, matching the user", "Bengali", "English", "Hinglish")) { v ->
                vm.update { it.copy(replyLanguage = v) }
            }
            Toggle("Detailed responses", s.detailedReplies) { v -> vm.update { it.copy(detailedReplies = v) } }
            Toggle("Confirm every action", s.confirmEveryAction) { v -> vm.update { it.copy(confirmEveryAction = v) } }
            Toggle("Allow spoken “হ্যাঁ” for send/post actions", s.voiceConfirmation) { v -> vm.update { it.copy(voiceConfirmation = v) } }
            Note("Sensitive actions always ask. Delete, payment and overwrite always need a tap. Turn spoken approval off in noisy or shared places: it cannot tell who is speaking.")
        }
    }
}
