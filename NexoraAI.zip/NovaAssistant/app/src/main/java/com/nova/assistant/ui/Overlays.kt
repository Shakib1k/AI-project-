package com.nova.assistant.ui

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.nova.assistant.assistant.Confirmation
import com.nova.assistant.assistant.ConfirmationManager
import com.nova.assistant.core.AssistantState
import kotlin.math.abs
import kotlin.math.sin

private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

/**
 * Draggable "screen is shared" bubble. Tap it twice within 3 s to stop sharing.
 * It supplements, and never covers or replaces, Android's own capture indicator.
 */
class FloatingIndicator(context: Context, private val onStop: () -> Unit) : View(context) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var state = AssistantState.IDLE
    private var armedAt = 0L
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private val params = WindowManager.LayoutParams(
        context.dp(68), context.dp(68), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = context.dp(12); y = context.dp(140) }

    init { contentDescription = "Screen sharing active. Double tap to stop." }

    fun setState(s: AssistantState) { state = s }
    fun attach(): Boolean = runCatching { wm.addView(this, params); animator.start() }.isSuccess
    fun detach() { animator.cancel(); runCatching { wm.removeView(this) } }

    override fun onDraw(canvas: Canvas) {
        val c = width / 2f
        val wave = abs(sin(Math.toRadians(phase * 3.0))).toFloat()
        val pulse = if (state == AssistantState.SPEAKING) wave * .12f else 0f
        paint.style = Paint.Style.FILL; paint.color = Color.BLACK
        canvas.drawCircle(c, c, c * (.82f + pulse), paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = c * .11f; paint.strokeCap = Paint.Cap.ROUND
        val ring = RectF(c * .24f, c * .24f, width - c * .24f, width - c * .24f)
        val speed = if (state == AssistantState.THINKING) 3 else 1
        paint.color = Color.rgb(255, 36, 66); canvas.drawArc(ring, phase * speed, 140f, false, paint)
        paint.color = Color.WHITE; canvas.drawArc(ring, phase * speed + 180, 70f, false, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(255, 36, 66)
        val armed = System.currentTimeMillis() - armedAt < 3000
        if (armed) canvas.drawRect(c * .75f, c * .75f, c * 1.25f, c * 1.25f, paint)
        else canvas.drawCircle(c, c, c * (.2f + pulse), paint)
    }

    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y }
            MotionEvent.ACTION_MOVE -> {
                params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt()
                wm.updateViewLayout(this, params)
            }
            MotionEvent.ACTION_UP -> if (abs(event.rawX - downX) + abs(event.rawY - downY) < context.dp(10)) performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        if (System.currentTimeMillis() - armedAt < 3000) onStop() else armedAt = System.currentTimeMillis()
        return true
    }
}

/**
 * Approval card shown above other apps, using the accessibility overlay window.
 * Automation can never tap it: our own package is blocked in ActionPolicy.
 */
class ConfirmationOverlay(
    private val service: AccessibilityService, private val manager: ConfirmationManager,
    private val emergencyStop: () -> Unit
) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private var view: View? = null

    fun show(c: Confirmation?) {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        if (c == null) return
        fun text(value: String, size: Float, color: Int) = TextView(service).apply {
            this.text = value; textSize = size; setTextColor(color); setPadding(0, 0, 0, service.dp(8))
        }
        fun button(label: String, color: Int, action: () -> Unit) = Button(service).apply {
            this.text = label; setTextColor(Color.WHITE); filterTouchesWhenObscured = true
            background = GradientDrawable().apply { setColor(color); cornerRadius = service.dp(20).toFloat() }
            setOnClickListener { action() }
        }
        val card = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(service.dp(20), service.dp(16), service.dp(20), service.dp(16))
            background = GradientDrawable().apply {
                setColor(Color.argb(248, 14, 10, 12)); cornerRadius = service.dp(24).toFloat()
                setStroke(service.dp(1), Color.rgb(255, 36, 66))
            }
            addView(text(c.title, 18f, Color.WHITE))
            val details = ScrollView(service).apply { addView(text(c.details, 14f, Color.LTGRAY)) }
            addView(details, LinearLayout.LayoutParams(-1, service.dp(150)))
            if (!c.allowVoice) addView(text("Tap to approve. Voice approval is off for this action.", 12f, Color.GRAY))
            val row = LinearLayout(service)
            val weight = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = service.dp(6) }
            row.addView(button("Allow", Color.rgb(200, 20, 50)) { manager.resolve(true) }, weight)
            row.addView(button("Cancel", Color.DKGRAY) { manager.resolve(false) }, weight)
            row.addView(button("STOP AI", Color.rgb(90, 0, 15)) { emergencyStop() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row)
        }
        // Bottom placement keeps the destination header visible.
        val params = WindowManager.LayoutParams(-1, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM }
        if (runCatching { wm.addView(card, params) }.isSuccess) view = card
    }
}
