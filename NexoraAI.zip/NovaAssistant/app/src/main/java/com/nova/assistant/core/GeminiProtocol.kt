package com.nova.assistant.core

import kotlinx.serialization.json.*

data class FunctionCall(val id: String, val name: String, val args: JsonObject)

sealed interface LiveEvent {
    data object Ready : LiveEvent
    data class Audio(val base64: String) : LiveEvent
    data class UserText(val text: String) : LiveEvent
    data class ModelText(val text: String) : LiveEvent
    data object Interrupted : LiveEvent
    data object TurnComplete : LiveEvent
    data class ToolCalls(val calls: List<FunctionCall>) : LiveEvent
    data class ToolCancel(val ids: List<String>) : LiveEvent
    data class ResumeHandle(val handle: String) : LiveEvent
    data object GoAway : LiveEvent
}

object GeminiProtocol {
    fun cleanModelId(id: String) = id.trim().removePrefix("models/")
    fun isValidModelId(id: String) = Regex("[A-Za-z0-9._-]{2,128}").matches(cleanModelId(id))

    fun parseModel(o: JsonObject) = ModelInfo(
        id = cleanModelId(o.string("name")),
        displayName = o.string("displayName", cleanModelId(o.string("name"))),
        description = o.string("description"),
        inputTokenLimit = o["inputTokenLimit"].str()?.toLongOrNull(),
        outputTokenLimit = o["outputTokenLimit"].str()?.toLongOrNull(),
        methods = o["supportedGenerationMethods"].arr().mapNotNull { it.str() }
    )

    fun textPart(text: String) = buildJsonObject { put("text", text) }
    fun imagePart(base64: String) = buildJsonObject {
        putJsonObject("inlineData") { put("mimeType", "image/jpeg"); put("data", base64) }
    }
    fun content(role: String, parts: List<JsonElement>) = buildJsonObject {
        put("role", role); put("parts", JsonArray(parts))
    }

    fun generateRequest(
        contents: List<JsonObject>, system: String?, tools: JsonArray?,
        maxTokens: Int, temperature: Float?
    ) = buildJsonObject {
        put("contents", JsonArray(contents))
        if (system != null) putJsonObject("systemInstruction") { put("parts", JsonArray(listOf(textPart(system)))) }
        if (tools != null) putJsonArray("tools") { addJsonObject { put("functionDeclarations", tools) } }
        putJsonObject("generationConfig") {
            put("maxOutputTokens", maxTokens)
            // Deprecated on current models; sent only when the user opts in.
            if (temperature != null) put("temperature", temperature)
        }
        put("store", false)
    }

    /** Raw parts are kept untouched so thoughtSignature is returned exactly as received. */
    fun responseParts(response: JsonObject): List<JsonElement> =
        response["candidates"].arr().firstOrNull().obj()?.get("content").obj()?.get("parts").arr()

    fun finishReason(response: JsonObject): String? =
        response["candidates"].arr().firstOrNull().obj()?.get("finishReason").str()

    fun visibleText(parts: List<JsonElement>) = parts.mapNotNull { it.obj() }
        .filter { it["thought"].str() != "true" }.mapNotNull { it["text"].str() }.joinToString("")

    private fun call(o: JsonObject) = FunctionCall(o.string("id"), o.string("name"), o["args"].obj() ?: JsonObject(emptyMap()))

    fun functionCalls(parts: List<JsonElement>) =
        parts.mapNotNull { it.obj()?.get("functionCall").obj()?.let(::call) }

    fun functionResponsePart(c: FunctionCall, result: JsonObject) = buildJsonObject {
        putJsonObject("functionResponse") {
            if (c.id.isNotEmpty()) put("id", c.id)
            put("name", c.name); put("response", result)
        }
    }

    fun liveSetup(model: String, system: String, voice: String, tools: JsonArray, resumeHandle: String?): String {
        // Blocking calls make the model wait for the real result. Extended Thinking does not support them.
        val declarations = if (model.contains("extended-thinking")) tools else JsonArray(
            tools.map { JsonObject(it.jsonObject + ("behavior" to JsonPrimitive("BLOCKING"))) }
        )
        return buildJsonObject {
            putJsonObject("setup") {
                put("model", "models/" + cleanModelId(model))
                putJsonObject("generationConfig") {
                    putJsonArray("responseModalities") { add("AUDIO") }
                    putJsonObject("speechConfig") {
                        putJsonObject("voiceConfig") { putJsonObject("prebuiltVoiceConfig") { put("voiceName", voice) } }
                    }
                }
                putJsonObject("systemInstruction") { put("parts", JsonArray(listOf(textPart(system)))) }
                putJsonArray("tools") { addJsonObject { put("functionDeclarations", declarations) } }
                putJsonObject("inputAudioTranscription") {}
                putJsonObject("outputAudioTranscription") {}
                putJsonObject("sessionResumption") { if (resumeHandle != null) put("handle", resumeHandle) }
                putJsonObject("contextWindowCompression") { putJsonObject("slidingWindow") {} }
            }
        }.toString()
    }

    private fun realtime(key: String, value: JsonElement) =
        buildJsonObject { put("realtimeInput", buildJsonObject { put(key, value) }) }.toString()

    fun liveAudio(base64: String) = realtime("audio", buildJsonObject { put("data", base64); put("mimeType", "audio/pcm;rate=16000") })
    fun liveFrame(base64: String) = realtime("video", buildJsonObject { put("data", base64); put("mimeType", "image/jpeg") })
    fun liveText(text: String) = realtime("text", JsonPrimitive(text))

    fun liveToolResponse(c: FunctionCall, result: JsonObject) = buildJsonObject {
        putJsonObject("toolResponse") {
            putJsonArray("functionResponses") { addJsonObject { put("id", c.id); put("name", c.name); put("response", result) } }
        }
    }.toString()

    fun parseLive(text: String): List<LiveEvent> {
        val o = parseObject(text) ?: return emptyList()
        val out = mutableListOf<LiveEvent>()
        if ("setupComplete" in o) out += LiveEvent.Ready
        o["serverContent"].obj()?.let { c ->
            // Interrupted goes first so stale audio is flushed before anything new is queued.
            if (c["interrupted"].str() == "true") out += LiveEvent.Interrupted
            c["inputTranscription"].obj()?.get("text").str()?.let { out += LiveEvent.UserText(it) }
            c["outputTranscription"].obj()?.get("text").str()?.let { out += LiveEvent.ModelText(it) }
            c["modelTurn"].obj()?.get("parts").arr().forEach { p ->
                p.obj()?.get("inlineData").obj()?.get("data").str()?.let { out += LiveEvent.Audio(it) }
            }
            if (c["turnComplete"].str() == "true") out += LiveEvent.TurnComplete
        }
        o["toolCall"].obj()?.let { t ->
            out += LiveEvent.ToolCalls(t["functionCalls"].arr().mapNotNull { it.obj()?.let(::call) })
        }
        o["toolCallCancellation"].obj()?.let { t -> out += LiveEvent.ToolCancel(t["ids"].arr().mapNotNull { it.str() }) }
        o["sessionResumptionUpdate"].obj()?.let { u -> u["newHandle"].str()?.takeIf { it.isNotEmpty() }?.let { out += LiveEvent.ResumeHandle(it) } }
        if ("goAway" in o) out += LiveEvent.GoAway
        return out
    }

    fun errorMessage(status: Int, body: String): String {
        val detail = parseObject(body)?.get("error").obj()?.get("message").str().orEmpty().take(300)
        return when {
            status == 401 || status == 403 || detail.contains("API key", true) -> "API key rejected or not permitted. $detail"
            status == 404 -> "Model or endpoint not found, or not available to this key. $detail"
            status == 429 -> "Quota or rate limit reached. Wait or check your plan. $detail"
            status == 400 -> "Request not supported by this model or invalid. $detail"
            status >= 500 -> "Gemini service error ($status). Try again. $detail"
            else -> "Request failed ($status). $detail"
        }
    }
}
