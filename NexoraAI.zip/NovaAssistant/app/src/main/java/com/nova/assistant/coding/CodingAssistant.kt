package com.nova.assistant.coding

import com.nova.assistant.core.*
import com.nova.assistant.data.SettingsRepository
import com.nova.assistant.gemini.GeminiClient
import com.nova.assistant.gemini.GeminiException
import kotlinx.serialization.json.JsonObject

data class CodeReply(val text: String, val truncated: Boolean)

class CodingAssistant(private val client: GeminiClient, private val settings: SettingsRepository) {
    private val history = mutableListOf<JsonObject>()

    private suspend fun run(contents: List<JsonObject>): Pair<List<kotlinx.serialization.json.JsonElement>, Boolean> {
        val s = settings.settings.value
        val body = GeminiProtocol.generateRequest(contents, Prompts.coding, null,
            maxOf(s.maxOutputTokens, 32768), if (s.sendTemperature) s.temperature else null)
        val response = client.generate(endpointFor(s, s.textModel), s.textModel, body)
        val parts = GeminiProtocol.responseParts(response)
        if (GeminiProtocol.visibleText(parts).isBlank())
            throw GeminiException("No answer (${GeminiProtocol.finishReason(response) ?: "blocked"}).")
        return parts to (GeminiProtocol.finishReason(response) == "MAX_TOKENS")
    }

    /** Multi-turn chat, so follow-up debugging keeps the project in context. */
    suspend fun ask(prompt: String): CodeReply {
        val turn = GeminiProtocol.content("user", listOf(GeminiProtocol.textPart(prompt)))
        val (parts, cut) = run(history + turn)
        history += turn
        history += GeminiProtocol.content("model", parts)
        while (history.size > 12) { history.removeAt(0); history.removeAt(0) }
        return CodeReply(GeminiProtocol.visibleText(parts), cut)
    }

    suspend fun singleFile(path: String, instructions: String): String {
        val turn = GeminiProtocol.content("user", listOf(GeminiProtocol.textPart(
            "Create exactly one complete file at path=$path. Requirements: $instructions")))
        val (parts, cut) = run(listOf(turn))
        if (cut) throw GeminiException("The file was cut off by the output limit, so it was not saved.")
        return CodeBlocks.parse(GeminiProtocol.visibleText(parts)).files.firstOrNull { it.path == path }?.content
            ?: throw GeminiException("The model did not return a complete $path.")
    }

    fun reset() = history.clear()
}

/** A saved model may point at its own Gemini-compatible proxy. */
fun endpointFor(s: AssistantSettings, model: String): String =
    s.savedModels.firstOrNull { it.modelId == model && it.endpoint.isNotBlank() }?.endpoint ?: s.proxyUrl
