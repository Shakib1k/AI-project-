package com.nova.assistant.core

enum class AssistantState { IDLE, CONNECTING, LISTENING, THINKING, SPEAKING }

/** Capabilities are only added when the API reports them or a real probe succeeds. */
enum class Capability(val label: String) {
    TEXT("generateContent (text)"),
    LIVE("Live audio (bidiGenerateContent)"),
    IMAGE_INPUT("Image input (tested)"),
    TOOLS("Tool calling (tested)")
}

data class ModelInfo(
    val id: String,
    val displayName: String,
    val description: String = "",
    val inputTokenLimit: Long? = null,
    val outputTokenLimit: Long? = null,
    val methods: List<String> = emptyList()
) {
    val capabilities: Set<Capability>
        get() = buildSet {
            if ("generateContent" in methods) add(Capability.TEXT)
            if ("bidiGenerateContent" in methods) add(Capability.LIVE)
        }
    val usable: Boolean get() = capabilities.isNotEmpty()
}

data class SavedModel(
    val displayName: String,
    val modelId: String,
    val provider: String = "Google Gemini",
    /** Empty = Google. Otherwise a Gemini-compatible HTTPS proxy base URL. */
    val endpoint: String = "",
    val capabilities: Set<Capability> = emptySet()
)

data class AssistantSettings(
    val aiName: String = "Maya",
    /** Extra spellings the speech recognizer may return, comma separated. */
    val wakeAliases: String = "মায়া, माया",
    val wakeEnabled: Boolean = false,
    val textModel: String = "gemini-3.8-flash",
    val liveModel: String = "gemini-3.8-live",
    val useLiveApi: Boolean = true,
    val proxyUrl: String = "",
    val sendTemperature: Boolean = false,
    val temperature: Float = 1.0f,
    val maxOutputTokens: Int = 32768,
    val liveVoice: String = "Leda",
    val ttsVoice: String = "",
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.1f,
    val volume: Float = 1.0f,
    val languageTag: String = "bn-BD",
    val voiceResponses: Boolean = true,
    val personality: String = "Friendly, warm and practical. Slightly cute, never childish.",
    val replyLanguage: String = "Natural Bengali / Hinglish mix, matching the user",
    val detailedReplies: Boolean = false,
    val confirmEveryAction: Boolean = false,
    val voiceConfirmation: Boolean = true,
    val frameIntervalMs: Int = 2000,
    val frameMaxSize: Int = 1024,
    val jpegQuality: Int = 70,
    val floatingIndicator: Boolean = true,
    val savedModels: List<SavedModel> = emptyList()
)
