package com.nova.assistant.core

/**
 * Decides what needs the user's approval. Enforced by app code, so the model
 * (or hostile text on screen) cannot switch it off.
 */
object ActionPolicy {
    enum class Risk { SAFE, CONFIRM, TAP_ONLY, BLOCKED }

    /** Irreversible or costly: needs a physical tap; spoken "yes" is not enough. */
    private val critical = listOf(
        "delete", "remove", "erase", "format", "wipe", "uninstall", "pay", "buy", "purchase", "transfer",
        "withdraw", "subscribe", "reset", "clear", "মুছ", "ডিলিট", "পেমেন্ট", "কিনুন", "हटा", "मिटा", "भुगतान", "खरीद"
    )
    private val sensitive = listOf(
        "send", "post", "publish", "share", "submit", "confirm", "install", "call", "reply", "forward",
        "upload", "save", "overwrite", "replace", "accept", "allow", "grant", "agree", "join", "leave",
        "block", "report", "sign", "log", "ok", "yes", "done", "continue", "move",
        "পাঠা", "পোস্ট", "শেয়ার", "নিশ্চিত", "भेज", "पोस्ट", "साझा"
    )

    /** Screens where automation must never act. Our own package protects the confirmation card. */
    fun isBlockedPackage(pkg: String, ownPackage: String): Boolean =
        pkg == ownPackage || pkg == "com.android.systemui" || pkg == "com.android.settings" ||
            pkg.contains("permissioncontroller") || pkg.contains("packageinstaller")

    private fun hit(label: String, terms: List<String>): Boolean {
        val words = WakeWord.normalize(label).split(' ')
        return terms.any { term ->
            // Short Latin words must match exactly ("ok" must not match "book").
            if (term.length <= 4 && term.all { it in 'a'..'z' }) term in words
            else words.any { it.startsWith(term) }
        }
    }

    fun tapRisk(label: String): Risk = when {
        label.isBlank() -> Risk.CONFIRM          // unlabeled icon: could be "send"
        hit(label, critical) -> Risk.TAP_ONLY
        hit(label, sensitive) -> Risk.CONFIRM
        else -> Risk.SAFE
    }

    private val yes = setOf(
        "yes", "yes send", "yes send it", "yes do it", "confirm", "ha", "haan", "haa pathao", "ha pathao",
        "haan bhejo", "হ্যাঁ", "হ্যা", "হ্যাঁ পাঠাও", "হ্যা পাঠাও", "হ্যাঁ করো", "ঠিক আছে পাঠাও", "हाँ", "हां", "हाँ भेजो", "हां भेजो"
    ).map(WakeWord::normalize).toSet()
    private val noWords = setOf("no", "cancel", "stop", "na", "nahi", "না", "থামো", "বাতিল", "नहीं", "रुको").map(WakeWord::normalize)

    /** true = approve, false = reject, null = unrelated. Approval requires the whole utterance to match. */
    fun voiceAnswer(utterance: String): Boolean? {
        val n = WakeWord.normalize(utterance)
        if (n.split(' ').any { it in noWords }) return false
        return if (n in yes) true else null
    }
}
