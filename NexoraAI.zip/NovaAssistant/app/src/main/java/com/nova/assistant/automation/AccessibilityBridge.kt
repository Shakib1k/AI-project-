package com.nova.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.nova.assistant.NovaApp
import com.nova.assistant.core.ActionPolicy
import com.nova.assistant.ui.ConfirmationOverlay
import kotlinx.coroutines.*

data class UiElement(
    val id: String, val node: AccessibilityNodeInfo, val label: String,
    val editable: Boolean, val clickable: Boolean, val text: String, val bounds: Rect
)

data class ScreenSnapshot(val pkg: String, val elements: List<UiElement>) {
    /** Header text (chat title and the like) plus every draft: if these change, approval is void. */
    fun context(screenHeight: Int): String =
        pkg + "|" + elements.filter { !it.editable && it.bounds.centerY() < screenHeight / 7 }
            .joinToString("/") { it.label }.replace(Regex("\\d"), "") +
            "|" + elements.filter { it.editable }.joinToString("/") { it.text }
}

class AssistantAccessibilityService : AccessibilityService() {
    private var overlay: ConfirmationOverlay? = null
    private var scope: CoroutineScope? = null

    override fun onServiceConnected() {
        instance = this
        val graph = (application as NovaApp).graph
        val view = ConfirmationOverlay(this, graph.confirmations) { graph.controller.stopAll() }
        overlay = view
        scope = CoroutineScope(Dispatchers.Main.immediate).also { s ->
            s.launch { graph.confirmations.pending.collect { view.show(it) } }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}  // screen is read only on request
    override fun onInterrupt() {}

    override fun onDestroy() {
        scope?.cancel(); overlay?.show(null)
        instance = null
        super.onDestroy()
    }

    fun snapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val found = mutableListOf<UiElement>()
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (found.size >= 150 || depth > 40) return
            if (n.isVisibleToUser) {
                val secret = n.isPassword
                val own = if (secret) "" else n.text?.toString().orEmpty()
                var label = if (secret) "[password field]" else
                    listOfNotNull(own.ifBlank { null }, n.contentDescription?.toString(), n.hintText?.toString())
                        .distinct().joinToString(" · ")
                if (label.isBlank() && n.isClickable) label = childText(n, 0)
                if (label.isNotBlank() || n.isClickable || n.isEditable) {
                    val bounds = Rect().also(n::getBoundsInScreen)
                    found += UiElement("e${found.size}", n, label.take(200), n.isEditable && !secret,
                        n.isClickable, own, bounds)
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return ScreenSnapshot(root.packageName?.toString().orEmpty(), found)
    }

    private fun childText(n: AccessibilityNodeInfo, depth: Int): String {
        if (depth > 4) return ""
        return (0 until n.childCount).mapNotNull { n.getChild(it) }.map { c ->
            if (c.isPassword) "" else c.text?.toString() ?: c.contentDescription?.toString() ?: childText(c, depth + 1)
        }.filter { it.isNotBlank() }.joinToString(" ").take(200)
    }

    fun click(element: UiElement, long: Boolean): Boolean {
        if (!element.node.refresh()) return false
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        var node: AccessibilityNodeInfo? = element.node
        repeat(4) {
            val n = node ?: return false
            if (if (long) n.isLongClickable else n.isClickable) return n.performAction(action)
            node = n.parent
        }
        return false
    }

    /** The label of what will really be clicked, which may be a parent of the listed text. */
    fun effectiveLabel(element: UiElement): String {
        var node: AccessibilityNodeInfo? = element.node
        repeat(4) {
            val n = node ?: return element.label
            if (n.isClickable) return listOf(element.label, n.contentDescription?.toString().orEmpty(),
                n.viewIdResourceName?.substringAfter('/')?.replace('_', ' ').orEmpty()).joinToString(" ").trim()
            node = n.parent
        }
        return element.label
    }

    fun setText(element: UiElement, text: String): Boolean {
        if (!element.node.refresh() || !element.node.isEditable || element.node.isPassword) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return element.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    suspend fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val line = when (direction) {
            "up" -> floatArrayOf(w / 2, h * .72f, w / 2, h * .28f)
            "down" -> floatArrayOf(w / 2, h * .28f, w / 2, h * .72f)
            "left" -> floatArrayOf(w * .82f, h / 2, w * .18f, h / 2)
            "right" -> floatArrayOf(w * .18f, h / 2, w * .82f, h / 2)
            else -> return false
        }
        val path = Path().apply { moveTo(line[0], line[1]); lineTo(line[2], line[3]) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 320)).build()
        val result = CompletableDeferred<Boolean>()
        val accepted = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { result.complete(true) }
            override fun onCancelled(g: GestureDescription?) { result.complete(false) }
        }, null)
        return accepted && (withTimeoutOrNull(3000) { result.await() } ?: false)
    }

    fun blocked(pkg: String) = ActionPolicy.isBlockedPackage(pkg, packageName)

    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null
            private set
    }
}
