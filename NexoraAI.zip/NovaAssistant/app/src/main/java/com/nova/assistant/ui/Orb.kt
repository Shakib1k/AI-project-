package com.nova.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.nova.assistant.core.AssistantState
import kotlin.math.*

@Composable
fun AiOrb(state: AssistantState, sharing: Boolean, modifier: Modifier = Modifier) {
    val loop = rememberInfiniteTransition(label = "orb")
    val slow by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "slow")
    val fast by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "fast")

    Canvas(modifier.semantics { contentDescription = "Assistant is ${state.name.lowercase()}" }) {
        val c = center
        val r = size.minDimension / 2
        val tau = (2 * PI).toFloat()
        val breathe = sin(fast * tau)
        val core = r * when (state) {
            AssistantState.SPEAKING -> .46f + .06f * breathe
            AssistantState.LISTENING -> .45f + .015f * breathe
            else -> .44f + .01f * sin(slow * tau)
        }
        drawCircle(Brush.radialGradient(listOf(Red.copy(alpha = .38f), Color.Transparent), c, r), r)
        drawCircle(Brush.radialGradient(listOf(Color.White, Red, Color(0xFF3B0010), Color.Black),
            c + Offset(-core * .3f, -core * .35f), core * 1.5f), core)

        fun arc(radius: Float, start: Float, sweep: Float, color: Color, width: Float) = drawArc(
            color, start, sweep, false, c - Offset(radius, radius), Size(radius * 2, radius * 2),
            style = Stroke(width, cap = StrokeCap.Round))

        arc(r * .64f, slow * 360, 110f, Color.White.copy(alpha = .8f), r * .012f)
        arc(r * .64f, slow * 360 + 180, 110f, Red, r * .012f)

        when (state) {
            AssistantState.LISTENING -> repeat(3) { i ->
                val p = (fast + i / 3f) % 1f
                drawCircle(Red.copy(alpha = 1 - p), core + (r * .5f) * p, style = Stroke(r * .022f))
            }
            AssistantState.THINKING, AssistantState.CONNECTING -> repeat(28) { i ->
                val angle = (i / 28f + slow * (2 + i % 3)) * tau
                val orbit = r * (.58f + (i % 4) * .08f)
                drawCircle(if (i % 3 == 0) Color.White else Red, r * (.012f + (i % 3) * .005f),
                    c + Offset(cos(angle) * orbit, sin(angle) * orbit))
            }
            AssistantState.SPEAKING -> repeat(72) { i ->
                val angle = i / 72f * tau
                val level = abs(sin(fast * tau * 2 + i * .55f) * sin(fast * tau + i * .21f))
                val dir = Offset(cos(angle), sin(angle))
                drawLine(if (i % 2 == 0) Red else Color.White, c + dir * (r * .70f),
                    c + dir * (r * (.73f + .23f * level)), r * .016f, StrokeCap.Round)
            }
            AssistantState.IDLE -> {}
        }
        if (sharing) repeat(4) { i -> arc(r * .96f, -slow * 720 + i * 90, 42f, if (i % 2 == 0) Color.White else Red, r * .026f) }
    }
}
