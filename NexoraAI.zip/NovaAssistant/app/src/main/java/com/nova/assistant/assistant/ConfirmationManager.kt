package com.nova.assistant.assistant

import com.nova.assistant.core.ActionPolicy
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

data class Confirmation(val title: String, val details: String, val allowVoice: Boolean)

/** One pending approval at a time. Timeout, stop and cancellation all mean "no". */
class ConfirmationManager {
    private val lock = Mutex()
    private var answer: CompletableDeferred<Boolean>? = null
    private var shownAt = 0L
    private var heard = ""
    private val _pending = MutableStateFlow<Confirmation?>(null)
    val pending: StateFlow<Confirmation?> = _pending

    suspend fun ask(title: String, details: String, allowVoice: Boolean): Boolean = lock.withLock {
        val deferred = CompletableDeferred<Boolean>()
        answer = deferred; heard = ""; shownAt = System.currentTimeMillis()
        _pending.value = Confirmation(title, details, allowVoice)
        try { withTimeoutOrNull(60_000) { deferred.await() } ?: false }
        finally { _pending.value = null; answer = null }
    }

    fun resolve(approved: Boolean) { answer?.complete(approved) }

    /** Fed only with the transcription of the user's microphone, never with model output. */
    fun onUserSpeech(chunk: String) {
        val p = _pending.value ?: return
        // Ignore speech still in flight from before the question appeared.
        if (System.currentTimeMillis() - shownAt < 1200) return
        heard += chunk
        when (ActionPolicy.voiceAnswer(heard)) {
            false -> resolve(false)
            true -> if (p.allowVoice) resolve(true)
            null -> {}
        }
    }

    /** A new spoken turn starts a new utterance. */
    fun onTurnBoundary() { heard = "" }
}
