package com.nova.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nova.assistant.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.*
import java.io.File

private val Context.dataStore by preferencesDataStore("nova")

class SettingsRepository(private val context: Context, scope: CoroutineScope) {
    private val key = stringPreferencesKey("settings_json")
    private val workspaceKey = stringPreferencesKey("workspace_uri")

    /** Loaded synchronously once so services never act on default settings by mistake. */
    private val initial = runBlocking { context.dataStore.data.first() }

    val settings: StateFlow<AssistantSettings> = context.dataStore.data
        .map { SettingsCodec.decode(it[key]) }
        .stateIn(scope, SharingStarted.Eagerly, SettingsCodec.decode(initial[key]))

    val workspace: StateFlow<String?> = context.dataStore.data.map { it[workspaceKey] }
        .stateIn(scope, SharingStarted.Eagerly, initial[workspaceKey])

    suspend fun update(change: (AssistantSettings) -> AssistantSettings) {
        context.dataStore.edit { it[key] = SettingsCodec.encode(change(SettingsCodec.decode(it[key]))) }
    }

    suspend fun setWorkspace(uri: String) { context.dataStore.edit { it[workspaceKey] = uri } }
}

data class HistoryEntry(val time: Long, val kind: String, val text: String)

/** Local-only activity log (newest first, capped). Never stores keys, frames or audio. */
class HistoryRepository(context: Context, private val scope: CoroutineScope) {
    private val file = File(context.filesDir, "history.jsonl")
    private val lock = Mutex()
    private val _entries = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val entries: StateFlow<List<HistoryEntry>> = _entries

    init {
        scope.launch(Dispatchers.IO) {
            lock.withLock {
                if (file.exists()) _entries.value = file.readLines().mapNotNull { line ->
                    parseObject(line)?.let { HistoryEntry(it.string("t").toLongOrNull() ?: 0, it.string("k"), it.string("x")) }
                }
            }
        }
    }

    fun add(kind: String, text: String) = write { listOf(HistoryEntry(System.currentTimeMillis(), kind, text.take(500))) + it }

    fun clear() = write { emptyList() }

    private fun write(change: (List<HistoryEntry>) -> List<HistoryEntry>) {
        scope.launch(Dispatchers.IO) {
            lock.withLock {
                val next = change(_entries.value).take(300)
                _entries.value = next
                runCatching {
                    file.writeText(next.joinToString("\n") {
                        buildJsonObject { put("t", it.time.toString()); put("k", it.kind); put("x", it.text) }.toString()
                    })
                }
            }
        }
    }
}
