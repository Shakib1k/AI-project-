package com.riya.assistant

import com.riya.assistant.data.VoicePersonality
import com.riya.assistant.voice.LanguageUnavailable
import com.riya.assistant.voice.SpeakConfig
import com.riya.assistant.voice.SpeakState
import com.riya.assistant.voice.SpeechController
import com.riya.assistant.voice.SpeechLang
import com.riya.assistant.voice.TtsProvider
import com.riya.assistant.voice.VoiceInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeTts(val failWith: Exception? = null) : TtsProvider {
    var active = 0; var maxActive = 0; var stops = 0
    val spoken = mutableListOf<String>()
    val langs = mutableListOf<SpeechLang>()
    override suspend fun initialize() = true
    override fun voices() = emptyList<VoiceInfo>()
    override suspend fun speak(text: String, lang: SpeechLang, config: SpeakConfig) {
        failWith?.let { throw it }
        spoken += text; langs += lang
        active++; maxActive = maxOf(maxActive, active)
        try { delay(1000) } finally { active-- }
    }
    override fun stop() { stops++ }
    override fun shutdown() {}
}

class SpeechControllerTest {
    private val cfg = SpeakConfig(VoicePersonality.Cute, 1f, 1f, null)

    @Test fun finishedSpeechReturnsToIdle() = runTest {
        val ctrl = SpeechController(FakeTts(), backgroundScope)
        ctrl.speak("Hello Boss", cfg); runCurrent()
        assertEquals(SpeakState.Speaking, ctrl.state.value)
        advanceUntilIdle()
        assertEquals(SpeakState.Idle, ctrl.state.value)
    }

    @Test fun newSpeechNeverOverlapsOldSpeech() = runTest {
        val tts = FakeTts()
        val ctrl = SpeechController(tts, backgroundScope)
        ctrl.speak("first.", cfg); runCurrent()
        ctrl.speak("second.", cfg); advanceUntilIdle()
        assertEquals(1, tts.maxActive)
        assertEquals(listOf("first.", "second."), tts.spoken)
    }

    @Test fun interruptStopsAudioImmediately() = runTest {
        val tts = FakeTts()
        val ctrl = SpeechController(tts, backgroundScope)
        ctrl.speak("a long answer", cfg); runCurrent()
        ctrl.interrupt()
        assertEquals(SpeakState.Idle, ctrl.state.value)
        assertTrue(tts.stops >= 1)
        runCurrent()
        assertEquals(0, tts.active)
    }

    @Test fun emojiOnlyTextSpeaksNothing() = runTest {
        val tts = FakeTts()
        val ctrl = SpeechController(tts, backgroundScope)
        ctrl.speak("😊❤️", cfg); advanceUntilIdle()
        assertTrue(tts.spoken.isEmpty())
        assertEquals(SpeakState.Idle, ctrl.state.value)
    }

    @Test fun picksLanguagePerText() = runTest {
        val tts = FakeTts()
        val ctrl = SpeechController(tts, backgroundScope)
        ctrl.speak("জি বস, আমি শুনছি।", cfg); advanceUntilIdle()
        assertEquals(listOf(SpeechLang.Bengali), tts.langs)
    }

    @Test fun missingLanguageDataIsReportedNotHidden() = runTest {
        val ctrl = SpeechController(FakeTts(LanguageUnavailable(SpeechLang.Bengali)), backgroundScope)
        ctrl.speak("জি বস", cfg); advanceUntilIdle()
        val st = ctrl.state.value
        assertTrue(st is SpeakState.Error && st.message.contains("Bengali"))
    }

    @Test fun engineFailureIsReported() = runTest {
        val ctrl = SpeechController(FakeTts(IllegalStateException("boom")), backgroundScope)
        ctrl.speak("Hello", cfg); advanceUntilIdle()
        assertEquals(SpeakState.Error("boom"), ctrl.state.value)
    }
}
