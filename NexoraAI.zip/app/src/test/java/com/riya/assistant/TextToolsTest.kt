package com.riya.assistant

import com.riya.assistant.voice.EchoFilter
import com.riya.assistant.voice.LanguageDetector
import com.riya.assistant.voice.SpeechLang
import com.riya.assistant.voice.TextChunker
import com.riya.assistant.voice.TextSanitizer
import com.riya.assistant.voice.VoiceHeuristics
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextToolsTest {
    @Test fun detectsBengaliHindiEnglish() {
        assertEquals(SpeechLang.Bengali, LanguageDetector.detect("জি বস, আমি শুনছি।"))
        assertEquals(SpeechLang.Hindi, LanguageDetector.detect("बॉस, मैं सुन रही हूँ।"))
        assertEquals(SpeechLang.English, LanguageDetector.detect("Boss, I'm right here."))
        assertEquals(SpeechLang.English, LanguageDetector.detect("12345 😊"))
    }

    @Test fun mixedTextUsesDominantScript() {
        assertEquals(SpeechLang.Bengali, LanguageDetector.detect("বস আপনার Telegram channel খুলছি এখনই"))
        assertEquals(SpeechLang.English, LanguageDetector.detect("Please open the Telegram app now বস"))
    }

    @Test fun emojisAndMarkdownAreNotSpoken() {
        assertEquals("Hello Boss", TextSanitizer.forSpeech("Hello ❤️ Boss 😊"))
        assertEquals("Title and bold", TextSanitizer.forSpeech("# Title and **bold**"))
    }

    @Test fun chunkerKeepsPiecesUnderLimit() {
        val text = (1..50).joinToString(" ") { "This is sentence number $it." }
        val parts = TextChunker.split(text, max = 200)
        assertTrue(parts.size > 1)
        assertTrue(parts.all { it.length <= 200 })
        assertEquals(50, parts.sumOf { p -> Regex("sentence number").findAll(p).count() })
    }

    @Test fun chunkerSplitsOneHugeSentence() {
        val parts = TextChunker.split("a".repeat(1000), max = 300)
        assertEquals(4, parts.size)
    }

    @Test fun chunkerSplitsAtBanglaDanda() {
        val parts = TextChunker.split("প্রথম বাক্য। দ্বিতীয় বাক্য। তৃতীয় বাক্য।", max = 20)
        assertTrue(parts.size >= 2)
    }

    @Test fun echoFilterIgnoresRivasOwnWords() {
        assertTrue(EchoFilter.isEcho("I'm right here", "Boss, I'm right here. Tell me what you need."))
        assertFalse(EchoFilter.isEcho("open telegram", "Boss, I'm right here. Tell me what you need."))
        assertFalse(EchoFilter.isEcho("", "anything"))
    }

    @Test fun femaleNameHeuristic() {
        assertTrue(VoiceHeuristics.looksFemale("en-in-x-female-local"))
        assertFalse(VoiceHeuristics.looksFemale("en-in-x-male-local"))
    }
}
