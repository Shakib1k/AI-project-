package com.riya.assistant

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.riya.assistant.ui.theme.OrbStyles
import com.riya.assistant.ui.theme.RiyaPalettes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PalettesTest {

    private fun contrast(a: Color, b: Color): Float {
        val l1 = maxOf(a.luminance(), b.luminance())
        val l2 = minOf(a.luminance(), b.luminance())
        return (l1 + 0.05f) / (l2 + 0.05f)
    }

    @Test fun tenNamedThemesExist() {
        val names = RiyaPalettes.all.map { it.name }
        assertEquals(10, names.size)
        assertEquals(
            listOf("Obsidian Red", "Midnight Blue", "Purple Galaxy", "Emerald Night", "Rose Quartz",
                "Arctic Silver", "Ocean Teal", "Sunset Ember", "Cyber Neon", "Pure Minimal"),
            names,
        )
    }

    @Test fun themesAreDistinct() {
        assertEquals(10, RiyaPalettes.all.map { it.id }.toSet().size)
        assertEquals(10, RiyaPalettes.all.map { it.primary to it.background }.toSet().size)
    }

    @Test fun textAndButtonsAreReadable() {
        RiyaPalettes.all.forEach {
            assertTrue("${it.name} text/background", contrast(it.text, it.background) >= 4.5f)
            assertTrue("${it.name} text/surface", contrast(it.text, it.surfaceHigh) >= 4.5f)
            assertTrue("${it.name} onPrimary/primary", contrast(it.onPrimary, it.primary) >= 4.5f)
        }
    }

    @Test fun colorSchemeAppliesPalette() {
        RiyaPalettes.all.forEach {
            val s = it.toColorScheme()
            assertEquals(it.primary, s.primary)
            assertEquals(it.background, s.background)
            assertEquals(it.surfaceHigh, s.surfaceContainerHigh)
        }
    }

    @Test fun systemDefaultFollowsDeviceMode() {
        assertEquals("obsidian_red", RiyaPalettes.resolve(RiyaPalettes.SYSTEM_ID, true).id)
        assertEquals("pure_minimal", RiyaPalettes.resolve(RiyaPalettes.SYSTEM_ID, false).id)
    }

    @Test fun orbStylesMatchTenThemesAndAreDistinct() {
        assertEquals(10, OrbStyles.all.size)
        assertEquals(10, OrbStyles.all.map { it.core }.toSet().size)
        assertNotEquals(OrbStyles.resolve("obsidian_red"), OrbStyles.resolve("cyber_neon"))
    }

    @Test fun unknownIdsFallBackToDefaults() {
        assertEquals("obsidian_red", RiyaPalettes.resolve("nope", true).id)
        assertEquals("obsidian_red", OrbStyles.resolve("nope").id)
    }
}
