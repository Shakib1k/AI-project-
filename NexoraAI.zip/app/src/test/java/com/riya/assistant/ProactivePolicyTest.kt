package com.riya.assistant

import com.riya.assistant.data.AppSettings
import com.riya.assistant.voice.ProactivePolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProactivePolicyTest {
    private val on = AppSettings(proactiveEnabled = true, silenceSeconds = 20, maxProactive = 2,
        quietEnabled = true, quietStartHour = 22, quietEndHour = 7, timeoutMinutes = 5)
    private val noon = 12

    @Test fun offByDefault() {
        assertFalse(ProactivePolicy.shouldSpeak(AppSettings(), 100_000, 0, 0, noon, false))
    }

    @Test fun waitsForSilenceThenSpeaks() {
        assertFalse(ProactivePolicy.shouldSpeak(on, 19_000, 0, 0, noon, false))
        assertTrue(ProactivePolicy.shouldSpeak(on, 20_000, 0, 0, noon, false))
    }

    @Test fun respectsMaximumCount() {
        assertFalse(ProactivePolicy.shouldSpeak(on, 60_000, 0, 2, noon, false))
        assertTrue(ProactivePolicy.shouldSpeak(on, 60_000, 0, 1, noon, false))
    }

    @Test fun quietHoursWrapMidnight() {
        assertTrue(ProactivePolicy.isQuietHour(23, 22, 7))
        assertTrue(ProactivePolicy.isQuietHour(3, 22, 7))
        assertFalse(ProactivePolicy.isQuietHour(7, 22, 7))
        assertFalse(ProactivePolicy.isQuietHour(12, 22, 7))
        assertFalse(ProactivePolicy.shouldSpeak(on, 60_000, 0, 0, 23, false))
        assertTrue(ProactivePolicy.shouldSpeak(on.copy(quietEnabled = false), 60_000, 0, 0, 23, false))
    }

    @Test fun doNotDisturbBlocksSpeech() {
        assertFalse(ProactivePolicy.shouldSpeak(on, 60_000, 0, 0, noon, dndActive = true))
    }

    @Test fun conversationTimeout() {
        assertFalse(ProactivePolicy.shouldTimeout(on, 299_000, 0))
        assertTrue(ProactivePolicy.shouldTimeout(on, 300_000, 0))
    }
}
