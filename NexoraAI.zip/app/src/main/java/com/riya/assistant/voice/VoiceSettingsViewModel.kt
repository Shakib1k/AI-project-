package com.riya.assistant.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class VoiceSettingsViewModel(private val tts: TtsProvider) : ViewModel() {
    private val speech = SpeechController(tts, viewModelScope)

    /** null = still starting, true = engine ready, false = engine unavailable. */
    private val _ready = MutableStateFlow<Boolean?>(null)
    val ready: StateFlow<Boolean?> = _ready
    private val _voices = MutableStateFlow<List<VoiceInfo>>(emptyList())
    val voices: StateFlow<List<VoiceInfo>> = _voices
    val state: StateFlow<SpeakState> = speech.state

    init {
        viewModelScope.launch {
            val ok = tts.initialize()
            _ready.value = ok
            if (ok) _voices.value = tts.voices()
        }
    }

    fun preview(lang: SpeechLang, config: SpeakConfig) = speech.speak(VoicePhrases.preview(lang), config)
    fun stop() = speech.interrupt()
    override fun onCleared() { speech.interrupt() }

    companion object {
        fun factory(tts: TtsProvider): ViewModelProvider.Factory = viewModelFactory {
            initializer { VoiceSettingsViewModel(tts) }
        }
    }
}
