package com.riya.assistant.voice

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Guarantees ONE voice at a time: starting new speech cancels the old speech first,
 * and interrupt() stops audio immediately.
 */
class SpeechController(private val tts: TtsProvider, private val scope: CoroutineScope) {

    private val _state = MutableStateFlow<SpeakState>(SpeakState.Idle)
    val state: StateFlow<SpeakState> = _state

    private var job: Job? = null

    val isSpeaking: Boolean get() = _state.value is SpeakState.Speaking

    fun speak(text: String, config: SpeakConfig) {
        interrupt()
        val clean = TextSanitizer.forSpeech(text)
        if (clean.isEmpty()) return
        _state.value = SpeakState.Speaking
        job = scope.launch {
            try {
                for (chunk in TextChunker.split(clean)) {
                    tts.speak(chunk, LanguageDetector.detect(chunk), config)
                }
                _state.value = SpeakState.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: LanguageUnavailable) {
                _state.value = SpeakState.Error(
                    "Voice data for ${e.lang.name} is not installed on this device. " +
                        "Install it in Android text-to-speech settings.",
                )
            } catch (e: Exception) {
                _state.value = SpeakState.Error(e.message ?: "Speech failed.")
            }
        }
    }

    /** Called when the user starts talking, taps Stop, or audio focus is lost. */
    fun interrupt() {
        job?.cancel()
        job = null
        tts.stop()
        _state.value = SpeakState.Idle
    }
}
