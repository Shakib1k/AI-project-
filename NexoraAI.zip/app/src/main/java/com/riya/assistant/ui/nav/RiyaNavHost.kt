package com.riya.assistant.ui.nav

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.riya.assistant.AppContainer
import com.riya.assistant.data.AppSettings
import com.riya.assistant.ui.home.HomeScreen
import com.riya.assistant.ui.live.LiveChatScreen
import com.riya.assistant.ui.settings.SettingsScreen
import com.riya.assistant.ui.settings.SettingsViewModel
import com.riya.assistant.ui.settings.ThemeGalleryScreen
import com.riya.assistant.ui.settings.ThemeKind
import com.riya.assistant.ui.settings.VoiceSettingsScreen
import com.riya.assistant.voice.LiveChatViewModel
import com.riya.assistant.voice.VoiceSettingsViewModel

object Routes {
    const val HOME = "home"
    const val LIVE = "live"
    const val SETTINGS = "settings"
    const val UI_THEMES = "settings/ui_theme"
    const val ORB_THEMES = "settings/orb_theme"
    const val VOICE = "settings/voice"
}

@Composable
fun RiyaNavHost(settings: AppSettings, vm: SettingsViewModel, container: AppContainer) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(settings,
                onLiveVoice = { nav.navigate(Routes.LIVE) },
                onSettings = { nav.navigate(Routes.SETTINGS) })
        }
        composable(Routes.LIVE) {
            val liveVm: LiveChatViewModel = viewModel(factory = LiveChatViewModel.factory(container))
            LiveChatScreen(liveVm, onEndChat = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(settings, vm,
                onBack = { nav.popBackStack() },
                onOpenUiThemes = { nav.navigate(Routes.UI_THEMES) },
                onOpenOrbThemes = { nav.navigate(Routes.ORB_THEMES) },
                onOpenVoice = { nav.navigate(Routes.VOICE) })
        }
        composable(Routes.VOICE) {
            val voiceVm: VoiceSettingsViewModel =
                viewModel(factory = VoiceSettingsViewModel.factory(container.ttsProvider))
            VoiceSettingsScreen(settings, vm, voiceVm, onBack = { nav.popBackStack() })
        }
        composable(Routes.UI_THEMES) {
            ThemeGalleryScreen(ThemeKind.Ui, settings.uiThemeId,
                onApply = { vm.setUiTheme(it) }, onBack = { nav.popBackStack() })
        }
        composable(Routes.ORB_THEMES) {
            ThemeGalleryScreen(ThemeKind.Orb, settings.orbThemeId,
                onApply = { vm.setOrbTheme(it) }, onBack = { nav.popBackStack() })
        }
    }
}
