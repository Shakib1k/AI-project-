package com.riya.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.riya.assistant.ui.nav.RiyaNavHost
import com.riya.assistant.ui.settings.SettingsViewModel
import com.riya.assistant.ui.theme.RiyaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val container = (application as RiyaApp).container
        setContent {
            val vm: SettingsViewModel =
                viewModel(factory = SettingsViewModel.factory(container.settingsRepository))
            val settings by vm.settings.collectAsStateWithLifecycle()
            RiyaTheme(settings) {
                RiyaNavHost(settings = settings, vm = vm)
            }
        }
    }
}
