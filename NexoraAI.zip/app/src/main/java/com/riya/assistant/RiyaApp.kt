package com.riya.assistant

import android.app.Application
import com.riya.assistant.data.SettingsRepository
import com.riya.assistant.voice.AndroidTtsProvider
import com.riya.assistant.voice.NotConnectedResponder
import com.riya.assistant.voice.Responder
import com.riya.assistant.voice.SpeechListener
import com.riya.assistant.voice.TtsProvider

/** Manual dependency container. Later phases add their engines here. */
class AppContainer(val app: Application) {
    val settingsRepository = SettingsRepository(app)
    val ttsProvider: TtsProvider = AndroidTtsProvider(app)
    val speechListener = SpeechListener(app)
    /** Replaced by the Gemini-backed responder in Phase 3. */
    val responder: Responder = NotConnectedResponder()
}

class RiyaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
