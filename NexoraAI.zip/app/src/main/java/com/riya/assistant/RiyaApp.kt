package com.riya.assistant

import android.app.Application
import com.riya.assistant.data.SettingsRepository

/** Manual dependency container. Later phases add their engines here. */
class AppContainer(app: Application) {
    val settingsRepository = SettingsRepository(app)
}

class RiyaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
