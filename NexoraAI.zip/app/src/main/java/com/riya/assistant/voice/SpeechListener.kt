package com.riya.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

sealed interface ListenEvent {
    data class Partial(val text: String) : ListenEvent
    data class Final(val text: String) : ListenEvent
    data class Error(val code: Int, val message: String) : ListenEvent
}

/**
 * One recognition turn per collected flow (call again for the next turn).
 * Must be collected on the main thread. Requires the Microphone Permission.
 * Android's recognizer works in ONE language per turn, so Nova uses the app language setting.
 */
class SpeechListener(private val context: Context) {

    fun isAvailable() = SpeechRecognizer.isRecognitionAvailable(context)

    fun listen(languageTag: String): Flow<ListenEvent> = callbackFlow {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                first(partialResults)?.let { trySend(ListenEvent.Partial(it)) }
            }
            override fun onResults(results: Bundle?) {
                trySend(ListenEvent.Final(first(results).orEmpty())); close()
            }
            override fun onError(error: Int) {
                trySend(ListenEvent.Error(error, describe(error))); close()
            }
            private fun first(b: Bundle?) =
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer.startListening(intent)
        awaitClose { recognizer.cancel(); recognizer.destroy() }
    }

    companion object {
        fun describe(code: Int) = when (code) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_CLIENT -> "Recognizer client error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone Permission is not granted."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Speech recognition needs a network connection for this language."
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech was recognized."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The recognizer is busy."
            SpeechRecognizer.ERROR_SERVER -> "The recognition service reported an error."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech was heard."
            else -> "Speech recognition error ($code)."
        }

        /** Normal silence outcomes. They restart listening and are not counted as failures. */
        fun isBenign(code: Int) =
            code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
    }
}
