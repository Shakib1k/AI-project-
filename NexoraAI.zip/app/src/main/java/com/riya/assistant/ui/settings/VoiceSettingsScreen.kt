package com.riya.assistant.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.riya.assistant.R
import com.riya.assistant.data.AppSettings
import com.riya.assistant.data.VoicePersonality
import com.riya.assistant.voice.SpeakState
import com.riya.assistant.voice.SpeechLang
import com.riya.assistant.voice.VoiceSettingsViewModel
import com.riya.assistant.voice.toSpeakConfig
import kotlin.math.roundToInt

@Composable
fun VoiceSettingsScreen(
    settings: AppSettings, vm: SettingsViewModel, voiceVm: VoiceSettingsViewModel, onBack: () -> Unit,
) {
    val ready by voiceVm.ready.collectAsState()
    val voices by voiceVm.voices.collectAsState()
    val speakState by voiceVm.state.collectAsState()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { voiceVm.stop(); onBack() }, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.ArrowBack, stringResource(R.string.back),
                    tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(stringResource(R.string.group_voice), style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground)
        }

        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ToggleRow(stringResource(R.string.spoken_responses), settings.voiceEnabled) {
                vm.update { setVoiceEnabled(it) }
            }

            Label(stringResource(R.string.voice_style))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(settings.voicePersonality == VoicePersonality.Cute,
                    { vm.update { setPersonality(VoicePersonality.Cute) } },
                    { Text(stringResource(R.string.personality_cute)) })
                FilterChip(settings.voicePersonality == VoicePersonality.Normal,
                    { vm.update { setPersonality(VoicePersonality.Normal) } },
                    { Text(stringResource(R.string.personality_normal)) })
            }

            SliderRow(stringResource(R.string.speech_speed), settings.speechRate, 0.5f..1.5f, "%.2fx") {
                vm.update { setSpeechRate(it) }
            }
            SliderRow(stringResource(R.string.pitch), settings.pitchAdjust, 0.5f..1.5f, "%.2f") {
                vm.update { setPitchAdjust(it) }
            }
            Text(stringResource(R.string.pitch_note), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Label(stringResource(R.string.preview_voice))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(SpeechLang.English to "English", SpeechLang.Bengali to "বাংলা", SpeechLang.Hindi to "हिन्दी")
                    .forEach { (lang, label) ->
                        OutlinedButton(
                            onClick = { voiceVm.preview(lang, settings.toSpeakConfig()) },
                            enabled = ready == true,
                            modifier = Modifier.heightIn(min = 48.dp),
                        ) { Text(label) }
                    }
            }
            when {
                ready == false -> Note(stringResource(R.string.tts_unavailable))
                speakState is SpeakState.Error -> Note((speakState as SpeakState.Error).message)
                speakState is SpeakState.Speaking ->
                    OutlinedButton(onClick = { voiceVm.stop() }) { Text(stringResource(R.string.stop_speaking)) }
            }

            Label(stringResource(R.string.voice_selection))
            VoiceRow(stringResource(R.string.voice_auto), settings.voiceName.isBlank()) {
                vm.update { setVoiceName("") }
            }
            voices.forEach { v ->
                val tag = if (v.likelyFemale) " (female)" else ""
                VoiceRow("${v.name}  [${v.localeTag}]$tag", settings.voiceName == v.name) {
                    vm.update { setVoiceName(v.name) }
                }
            }
            if (ready == true && voices.isEmpty()) Note(stringResource(R.string.no_voices))
            Text(stringResource(R.string.voice_gender_note), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Label(stringResource(R.string.group_conversation))
            ToggleRow(stringResource(R.string.allow_interruption), settings.allowInterruption) {
                vm.update { setAllowInterruption(it) }
            }
            Text(stringResource(R.string.interruption_note), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            ToggleRow(stringResource(R.string.proactive_voice), settings.proactiveEnabled) {
                vm.update { setProactiveEnabled(it) }
            }
            SliderRow(stringResource(R.string.silence_seconds), settings.silenceSeconds.toFloat(), 5f..120f, "%.0f s") {
                vm.update { setSilenceSeconds(it.roundToInt()) }
            }
            SliderRow(stringResource(R.string.max_proactive), settings.maxProactive.toFloat(), 1f..5f, "%.0f") {
                vm.update { setMaxProactive(it.roundToInt()) }
            }
            ToggleRow(stringResource(R.string.quiet_hours), settings.quietEnabled) {
                vm.update { setQuietEnabled(it) }
            }
            SliderRow(stringResource(R.string.quiet_start), settings.quietStartHour.toFloat(), 0f..23f, "%.0f:00") {
                vm.update { setQuietStartHour(it.roundToInt()) }
            }
            SliderRow(stringResource(R.string.quiet_end), settings.quietEndHour.toFloat(), 0f..23f, "%.0f:00") {
                vm.update { setQuietEndHour(it.roundToInt()) }
            }
            SliderRow(stringResource(R.string.conversation_timeout), settings.timeoutMinutes.toFloat(), 1f..30f, "%.0f min") {
                vm.update { setTimeoutMinutes(it.roundToInt()) }
            }
            Text(stringResource(R.string.dnd_note), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun Label(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)

@Composable private fun Note(text: String) =
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Keeps the slider smooth locally and saves once, when the finger lifts. */
@Composable
private fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, format: String,
    onSave: (Float) -> Unit,
) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Row {
            Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
            Text(String.format(format, local), color = MaterialTheme.colorScheme.secondary)
        }
        Slider(value = local, onValueChange = { local = it }, valueRange = range,
            onValueChangeFinished = { onSave(local) })
    }
}

@Composable
private fun VoiceRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(onClick = onSelect),
        verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(label, color = MaterialTheme.colorScheme.onBackground)
    }
}
