package com.riya.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Local fallback voice using the device's own TextToSpeech engine. */
class AndroidTtsProvider(private val context: Context) : TtsProvider {

    private var tts: TextToSpeech? = null
    private var ready = false

    override suspend fun initialize(): Boolean {
        if (ready) return true
        return suspendCancellableCoroutine { cont ->
            var engine: TextToSpeech? = null
            engine = TextToSpeech(context.applicationContext) { status ->
                ready = status == TextToSpeech.SUCCESS
                if (ready) {
                    tts = engine
                    engine?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build(),
                    )
                }
                if (cont.isActive) cont.resume(ready)
            }
        }
    }

    override fun voices(): List<VoiceInfo> {
        val engine = tts ?: return emptyList()
        val supported = SpeechLang.entries.map { it.code }.toSet()
        return runCatching { engine.voices.orEmpty() }.getOrDefault(emptySet())
            .filter { it.locale.language in supported }
            .map { VoiceInfo(it.name, it.locale.toLanguageTag(), it.isNetworkConnectionRequired,
                VoiceHeuristics.looksFemale(it.name)) }
            .sortedWith(compareBy({ it.localeTag }, { !it.likelyFemale }, { it.name }))
    }

    override suspend fun speak(text: String, lang: SpeechLang, config: SpeakConfig) {
        val engine = tts ?: throw IllegalStateException("The text-to-speech engine is not ready.")
        configureVoice(engine, lang, config)
        engine.setSpeechRate((config.rate * config.personality.baseRate).coerceIn(0.3f, 2.5f))
        engine.setPitch((config.pitch * config.personality.basePitch).coerceIn(0.3f, 2.0f))

        suspendCancellableCoroutine<Unit> { cont ->
            val id = UUID.randomUUID().toString()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }
                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }
                @Deprecated("Required by the abstract class")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive)
                        cont.resumeWithException(IllegalStateException("The voice engine reported an error."))
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (utteranceId == id && cont.isActive)
                        cont.resumeWithException(IllegalStateException("The voice engine reported error $errorCode."))
                }
            })
            // Cancelling the coroutine (user interrupts) stops audio right away.
            cont.invokeOnCancellation { engine.stop() }
            val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (result == TextToSpeech.ERROR && cont.isActive)
                cont.resumeWithException(IllegalStateException("The voice engine refused to start speaking."))
        }
    }

    /** Chooses language, then the user's voice, otherwise the highest-quality likely-female voice. */
    private fun configureVoice(engine: TextToSpeech, lang: SpeechLang, config: SpeakConfig) {
        var result = engine.setLanguage(Locale.forLanguageTag(lang.tag))
        if ((result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) &&
            lang == SpeechLang.English
        ) result = engine.setLanguage(Locale.US)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
            throw LanguageUnavailable(lang)

        val sameLanguage = runCatching { engine.voices.orEmpty() }.getOrDefault(emptySet())
            .filter { it.locale.language == lang.code }
        val chosen = config.voiceName?.let { n -> sameLanguage.firstOrNull { it.name == n } }
            ?: sameLanguage.filter { VoiceHeuristics.looksFemale(it.name) }.maxByOrNull { it.quality }
        if (chosen != null) engine.voice = chosen
    }

    override fun stop() { tts?.stop() }

    override fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null; ready = false
    }
}
