package com.riya.assistant.voice

import android.app.NotificationManager
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.riya.assistant.AppContainer
import com.riya.assistant.data.AppSettings
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Runs one live voice session: listen, understand, answer aloud, and let the user
 * interrupt at any time. Every loop is bounded; no infinite retry.
 */
class LiveChatViewModel(private val container: AppContainer) : ViewModel() {

    enum class Phase { Idle, Listening, Thinking, Speaking, Error }

    data class UiState(
        val phase: Phase = Phase.Idle,
        val sessionActive: Boolean = false,
        val partial: String = "",
        val lastUser: String = "",
        val lastReply: String = "",
        val message: String? = null,
        val finished: Boolean = false,
    )

    private val app = container.app
    private val settings: StateFlow<AppSettings> =
        container.settingsRepository.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    private val speech = SpeechController(container.ttsProvider, viewModelScope)
    private val focus = AudioFocusManager(app) { interruptAll() }

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    private var session: Job? = null
    private var replyJob: Job? = null
    private var lastActivity = 0L
    private var proactiveSent = 0
    private var currentSpoken = ""

    init {
        viewModelScope.launch {
            var wasSpeaking = false
            speech.state.collect { st ->
                when (st) {
                    SpeakState.Speaking -> { wasSpeaking = true; setPhase(Phase.Speaking) }
                    SpeakState.Idle -> {
                        if (wasSpeaking) lastActivity = System.currentTimeMillis()
                        wasSpeaking = false
                        if (_ui.value.sessionActive && _ui.value.phase == Phase.Speaking) setPhase(Phase.Listening)
                    }
                    is SpeakState.Error -> _ui.update { it.copy(phase = Phase.Error, message = st.message) }
                }
            }
        }
    }

    fun startSession() {
        if (session?.isActive == true) return
        _ui.update { UiState(sessionActive = true, phase = Phase.Listening) }
        session = viewModelScope.launch {
            if (!container.ttsProvider.initialize()) {
                _ui.update { it.copy(message = "Text-to-speech is unavailable on this device. Listening only.") }
            }
            if (!container.speechListener.isAvailable()) {
                _ui.update { it.copy(phase = Phase.Error, sessionActive = false,
                    message = "No speech recognition service is installed on this device.") }
                return@launch
            }
            focus.acquire()
            lastActivity = System.currentTimeMillis()
            speakText(VoicePhrases.greeting(SpeechLang.fromCode(settings.value.language)))
            launch { proactiveLoop() }
            listenLoop()
        }
    }

    private suspend fun listenLoop() {
        var failures = 0
        while (viewModelScope.isActive && _ui.value.sessionActive) {
            val s = settings.value
            // Without interruption support, wait until Riya has finished talking.
            if (!s.allowInterruption) speech.state.first { it !is SpeakState.Speaking }
            var error: ListenEvent.Error? = null
            container.speechListener.listen(SpeechLang.fromCode(s.language).tag).collect { ev ->
                when (ev) {
                    is ListenEvent.Partial -> onPartial(ev.text, s)
                    is ListenEvent.Final -> { failures = 0; handleUtterance(ev.text) }
                    is ListenEvent.Error -> { error = ev }
                }
            }
            val err = error
            if (err != null) {
                if (err.code == android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    stopWithMessage(err.message); return
                }
                if (!SpeechListener.isBenign(err.code)) failures++
                if (failures >= 3) { stopWithMessage(err.message); return }
                delay(if (err.code == android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 300)
            } else delay(150)
        }
    }

    private fun onPartial(text: String, s: AppSettings) {
        if (text.isBlank()) return
        if (speech.isSpeaking) {
            if (!s.allowInterruption || EchoFilter.isEcho(text, currentSpoken)) return
            interruptAll() // the user is talking over Riya: stop her immediately
        }
        lastActivity = System.currentTimeMillis()
        _ui.update { it.copy(partial = text) }
    }

    private fun handleUtterance(text: String) {
        val heard = text.trim()
        if (heard.isEmpty()) return
        interruptAll()
        lastActivity = System.currentTimeMillis()
        proactiveSent = 0
        _ui.update { it.copy(partial = "", lastUser = heard, phase = Phase.Thinking, message = null) }
        replyJob = viewModelScope.launch {
            val lang = LanguageDetector.detect(heard)
            val reply = container.responder.reply(heard, lang)
            _ui.update { it.copy(lastReply = reply) }
            speakText(reply)
        }
    }

    private fun speakText(text: String) {
        currentSpoken = text
        if (!settings.value.voiceEnabled) { setPhase(Phase.Listening); return }
        speech.speak(text, settings.value.toSpeakConfig())
    }

    private suspend fun proactiveLoop() {
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        while (viewModelScope.isActive && _ui.value.sessionActive) {
            delay(1000)
            val s = settings.value
            val now = System.currentTimeMillis()
            if (ProactivePolicy.shouldTimeout(s, now, lastActivity)) { endSession(timedOut = true); return }
            val idle = !speech.isSpeaking && replyJob?.isActive != true
            val filter = nm.currentInterruptionFilter
            val dnd = filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
                filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (idle && ProactivePolicy.shouldSpeak(s, now, lastActivity, proactiveSent, hour, dnd)) {
                proactiveSent++
                lastActivity = now
                speakText(VoicePhrases.proactive(SpeechLang.fromCode(s.language)))
            }
        }
    }

    /** Stops both speech audio and any pending answer so nothing overlaps or continues. */
    fun interruptAll() {
        replyJob?.cancel(); replyJob = null
        speech.interrupt()
    }

    fun stopSpeaking() = interruptAll()

    private fun stopWithMessage(msg: String) {
        interruptAll(); focus.release()
        _ui.update { it.copy(sessionActive = false, phase = Phase.Error, message = msg) }
    }

    fun endSession(timedOut: Boolean = false) {
        session?.cancel(); session = null
        interruptAll(); focus.release()
        _ui.update { it.copy(sessionActive = false, phase = Phase.Idle, finished = true,
            message = if (timedOut) "Session ended after silence." else null) }
    }

    private fun setPhase(p: Phase) = _ui.update { it.copy(phase = p) }

    override fun onCleared() { endSession() }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { LiveChatViewModel(container) }
        }
    }
}
