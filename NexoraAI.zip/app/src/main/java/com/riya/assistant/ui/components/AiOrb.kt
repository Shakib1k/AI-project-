package com.riya.assistant.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.riya.assistant.ui.theme.LocalOrbStyle
import com.riya.assistant.ui.theme.LocalReducedMotion

/** Every orb state from the spec. Later phases drive these from real engines. */
enum class OrbState(val label: String) {
    Idle("Ready"), Listening("Listening"), Thinking("Thinking"), Speaking("Speaking"),
    ScreenSharing("Screen sharing"), Reading("Reading"), Searching("Searching"),
    Typing("Typing"), Swiping("Swiping"), Coding("Coding"), Uploading("Uploading"),
    Error("Permission required"),
}

private fun OrbState.pulseMillis() = when (this) {
    OrbState.Idle -> 2600
    OrbState.Listening -> 1400
    OrbState.Thinking -> 900
    OrbState.Speaking -> 1100
    OrbState.Error -> 700
    else -> 1500
}

/** Theme-aware animated orb drawn with Canvas gradients (no bitmap assets). */
@Composable
fun AiOrb(state: OrbState, modifier: Modifier = Modifier, level: Float = 0f) {
    val orb = LocalOrbStyle.current
    val reduced = LocalReducedMotion.current
    val transition = rememberInfiniteTransition(label = "orb")
    val pulseAnim by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(state.pulseMillis(), easing = FastOutSlowInEasing), RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val spinAnim by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "spin",
    )
    val pulse = if (reduced) 0.5f else pulseAnim
    val spin = if (reduced) 0f else spinAnim
    val glow = if (state == OrbState.Error) Color(0xFFFFB300) else orb.glow

    Canvas(
        modifier = modifier
            .aspectRatio(1f)
            .semantics { contentDescription = "Assistant orb, ${state.label}" },
    ) {
        val r = size.minDimension / 2f
        val c = center

        drawCircle(
            brush = Brush.radialGradient(
                listOf(glow.copy(alpha = 0.18f + 0.22f * pulse), Color.Transparent),
                center = c, radius = r,
            ),
            radius = r, center = c,
        )

        val coreR = r * (0.50f + 0.03f * pulse + 0.04f * level.coerceIn(0f, 1f))
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(lerp(orb.core, Color.White, 0.45f), orb.core, lerp(orb.core, Color.Black, 0.65f)),
                center = Offset(c.x - coreR * 0.3f, c.y - coreR * 0.35f),
                radius = coreR * 1.6f,
            ),
            radius = coreR, center = c,
        )

        val ringR = r * 0.74f
        val ringTopLeft = Offset(c.x - ringR, c.y - ringR)
        val ringSize = Size(ringR * 2, ringR * 2)
        drawCircle(orb.ring.copy(alpha = 0.15f), radius = ringR, center = c, style = Stroke(1.dp.toPx()))
        rotate(spin, pivot = c) {
            drawArc(orb.ring.copy(alpha = 0.85f), 0f, 70f, false, ringTopLeft, ringSize,
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            drawArc(orb.ring.copy(alpha = 0.45f), 180f, 40f, false, ringTopLeft, ringSize,
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }

        drawOval(
            Color.White.copy(alpha = 0.32f),
            topLeft = Offset(c.x - coreR * 0.55f, c.y - coreR * 0.82f),
            size = Size(coreR * 0.7f, coreR * 0.34f),
        )
    }
}
