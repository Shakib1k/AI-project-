package com.riya.assistant.voice

import com.riya.assistant.data.AppSettings

/** Pure rules for when Riya may gently start talking. Rate-limited and off by default. */
object ProactivePolicy {

    fun isQuietHour(hour: Int, start: Int, end: Int): Boolean = when {
        start == end -> false
        start < end -> hour in start until end
        else -> hour >= start || hour < end // wraps midnight, e.g. 22 to 7
    }

    fun shouldSpeak(
        s: AppSettings, nowMs: Long, lastActivityMs: Long, sentCount: Int,
        hourOfDay: Int, dndActive: Boolean,
    ): Boolean {
        if (!s.proactiveEnabled) return false
        if (sentCount >= s.maxProactive) return false
        if (dndActive) return false
        if (s.quietEnabled && isQuietHour(hourOfDay, s.quietStartHour, s.quietEndHour)) return false
        return nowMs - lastActivityMs >= s.silenceSeconds * 1000L
    }

    fun shouldTimeout(s: AppSettings, nowMs: Long, lastActivityMs: Long): Boolean =
        nowMs - lastActivityMs >= s.timeoutMinutes * 60_000L
}

object VoicePhrases {
    fun greeting(lang: SpeechLang) = when (lang) {
        SpeechLang.Bengali -> "জি বস, আমি শুনছি।"
        SpeechLang.Hindi -> "बॉस, मैं सुन रही हूँ।"
        SpeechLang.English -> "Boss, I'm right here. Tell me what you need."
    }

    fun proactive(lang: SpeechLang) = when (lang) {
        SpeechLang.Bengali -> "বস, কী হলো? কথা বলছেন না কেন?"
        SpeechLang.Hindi -> "बॉस, क्या हुआ? आप बात क्यों नहीं कर रहे?"
        SpeechLang.English -> "Boss, are you still there? I'm listening."
    }

    fun preview(lang: SpeechLang) = greeting(lang)

    /** Honest placeholder until the Gemini connection is built in the next phase. */
    fun notConnected(lang: SpeechLang) = when (lang) {
        SpeechLang.Bengali -> "বস, আমি শুনেছি। আমার Gemini সংযোগ এখনও সেট আপ হয়নি, তাই এখন ঠিকমতো উত্তর দিতে পারছি না।"
        SpeechLang.Hindi -> "बॉस, मैंने सुना। मेरा Gemini कनेक्शन अभी सेट नहीं है, इसलिए अभी सही जवाब नहीं दे पा रही हूँ।"
        SpeechLang.English -> "Boss, I heard you. My Gemini connection is not set up yet, so I can't answer properly."
    }
}

/** Phase 3 replaces this with the real Gemini-backed responder. */
interface Responder { suspend fun reply(userText: String, replyLang: SpeechLang): String }

class NotConnectedResponder : Responder {
    override suspend fun reply(userText: String, replyLang: SpeechLang) = VoicePhrases.notConnected(replyLang)
}
