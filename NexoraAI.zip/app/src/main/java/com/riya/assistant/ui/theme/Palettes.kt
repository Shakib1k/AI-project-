package com.riya.assistant.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/** One complete app palette. Screens never hardcode colors; they read MaterialTheme tokens. */
data class RiyaPalette(
    val id: String,
    val name: String,
    val dark: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val text: Color,
    val textMuted: Color,
    val outline: Color,
) {
    fun toColorScheme(): ColorScheme {
        val onSecondary = if (secondary.luminance() > 0.4f) Color.Black else Color.White
        return if (dark) darkColorScheme(
            primary = primary, onPrimary = onPrimary,
            secondary = secondary, onSecondary = onSecondary,
            background = background, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = surfaceHigh, onSurfaceVariant = textMuted,
            surfaceContainer = surface, surfaceContainerHigh = surfaceHigh,
            outline = outline, outlineVariant = outline,
        ) else lightColorScheme(
            primary = primary, onPrimary = onPrimary,
            secondary = secondary, onSecondary = onSecondary,
            background = background, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = surfaceHigh, onSurfaceVariant = textMuted,
            surfaceContainer = surface, surfaceContainerHigh = surfaceHigh,
            outline = outline, outlineVariant = outline,
        )
    }
}

/** Orb material is a separate setting from the UI palette. */
data class OrbStyle(val id: String, val name: String, val core: Color, val glow: Color, val ring: Color)

private fun c(hex: Long) = Color(0xFF000000 or hex)

object RiyaPalettes {
    const val SYSTEM_ID = "system"

    val all: List<RiyaPalette> = listOf(
        RiyaPalette("obsidian_red", "Obsidian Red", true,
            c(0x0B0B0D), c(0x151518), c(0x1F1F24), c(0xD32F2F), c(0xFFFFFF), c(0xFF8A80), c(0xF5F5F5), c(0xB0B0B8), c(0x3A3A42)),
        RiyaPalette("midnight_blue", "Midnight Blue", true,
            c(0x070B1A), c(0x0F1630), c(0x18224A), c(0x2962FF), c(0xFFFFFF), c(0x82B1FF), c(0xEAF0FF), c(0xA9B6D6), c(0x2B3A6B)),
        RiyaPalette("purple_galaxy", "Purple Galaxy", true,
            c(0x0E0720), c(0x1A0F33), c(0x281750), c(0x7E3FF2), c(0xFFFFFF), c(0xCE93D8), c(0xF3ECFF), c(0xBBA9DD), c(0x44307A)),
        RiyaPalette("emerald_night", "Emerald Night", true,
            c(0x06130E), c(0x0D211A), c(0x14342A), c(0x10A874), c(0x000000), c(0x69F0AE), c(0xFFF8EC), c(0xA8C4B8), c(0x24503F)),
        RiyaPalette("rose_quartz", "Rose Quartz", false,
            c(0xFFF5F7), c(0xFFFFFF), c(0xFCE4EC), c(0xC2185B), c(0xFFFFFF), c(0x880E4F), c(0x2A1520), c(0x6D4C5B), c(0xE8B4C8)),
        RiyaPalette("arctic_silver", "Arctic Silver", true,
            c(0x12161B), c(0x1B2128), c(0x252D36), c(0x9FD8FF), c(0x000000), c(0xE0E6EC), c(0xEEF3F8), c(0xA9B4BF), c(0x3A4552)),
        RiyaPalette("ocean_teal", "Ocean Teal", true,
            c(0x04181B), c(0x0A2A2F), c(0x103C43), c(0x14B8A6), c(0x000000), c(0x80CBC4), c(0xFFFFFF), c(0xA6CFCB), c(0x1F5A63)),
        RiyaPalette("sunset_ember", "Sunset Ember", true,
            c(0x121010), c(0x1E1917), c(0x2A221F), c(0xFF5A1F), c(0x000000), c(0xFFB74D), c(0xFFF1E0), c(0xC9B8A6), c(0x4A3A32)),
        RiyaPalette("cyber_neon", "Cyber Neon", true,
            c(0x0D0F14), c(0x151922), c(0x1E2430), c(0x00E5FF), c(0x000000), c(0xFF2BD6), c(0xF0FBFF), c(0xA8B8C8), c(0x34405A)),
        RiyaPalette("pure_minimal", "Pure Minimal", false,
            c(0xFAFAFA), c(0xFFFFFF), c(0xEEEEEE), c(0x212121), c(0xFFFFFF), c(0x616161), c(0x111111), c(0x616161), c(0xD0D0D0)),
    )

    /** "system" follows the device light/dark setting. */
    fun resolve(id: String, systemDark: Boolean): RiyaPalette =
        if (id == SYSTEM_ID) all.first { it.id == if (systemDark) "obsidian_red" else "pure_minimal" }
        else all.firstOrNull { it.id == id } ?: all.first()
}

object OrbStyles {
    val all: List<OrbStyle> = listOf(
        OrbStyle("obsidian_red", "Obsidian Red", c(0xC62828), c(0xFF1744), c(0xFFFFFF)),
        OrbStyle("midnight_blue", "Midnight Blue", c(0x2962FF), c(0x448AFF), c(0xE3F2FD)),
        OrbStyle("purple_galaxy", "Purple Galaxy", c(0x7E3FF2), c(0xB388FF), c(0xEDE7F6)),
        OrbStyle("emerald_night", "Emerald Night", c(0x10A874), c(0x1DE9B6), c(0xE8F5E9)),
        OrbStyle("rose_quartz", "Rose Quartz", c(0xF06292), c(0xF8BBD0), c(0xFFFFFF)),
        OrbStyle("arctic_silver", "Arctic Silver", c(0x90A4AE), c(0xB3E5FC), c(0xECEFF1)),
        OrbStyle("ocean_teal", "Ocean Teal", c(0x14B8A6), c(0x64FFDA), c(0xFFFFFF)),
        OrbStyle("sunset_ember", "Sunset Ember", c(0xFF5A1F), c(0xFF9100), c(0xFFF3E0)),
        OrbStyle("cyber_neon", "Cyber Neon", c(0x00E5FF), c(0xFF2BD6), c(0xFFFFFF)),
        OrbStyle("pure_minimal", "Pure Minimal", c(0x424242), c(0x9E9E9E), c(0xFFFFFF)),
    )

    fun resolve(id: String): OrbStyle = all.firstOrNull { it.id == id } ?: all.first()
}
