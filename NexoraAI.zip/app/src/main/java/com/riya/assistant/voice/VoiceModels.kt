package com.riya.assistant.voice

import com.riya.assistant.data.AppSettings
import com.riya.assistant.data.VoicePersonality

enum class SpeechLang(val code: String, val tag: String) {
    Bengali("bn", "bn-IN"),
    Hindi("hi", "hi-IN"),
    English("en", "en-IN");

    companion object {
        fun fromCode(code: String) = entries.firstOrNull { it.code == code } ?: English
    }
}

data class VoiceInfo(
    val name: String,
    val localeTag: String,
    val needsNetwork: Boolean,
    /** Android exposes no gender field, so this is only a name-based guess. */
    val likelyFemale: Boolean,
)

data class SpeakConfig(
    val personality: VoicePersonality,
    val rate: Float,
    val pitch: Float,
    val voiceName: String?,
)

fun AppSettings.toSpeakConfig() = SpeakConfig(
    personality = voicePersonality,
    rate = speechRate,
    pitch = pitchAdjust,
    voiceName = voiceName.ifBlank { null },
)

/** The installed TTS engine has no voice data for this language. */
class LanguageUnavailable(val lang: SpeechLang) : Exception("No voice data for ${lang.name}")

sealed interface SpeakState {
    data object Idle : SpeakState
    data object Speaking : SpeakState
    data class Error(val message: String) : SpeakState
}

object VoiceHeuristics {
    fun looksFemale(voiceName: String): Boolean {
        val n = voiceName.lowercase()
        return "female" in n || "-f-" in n || "_f_" in n || n.endsWith("-f") || n.endsWith("_f")
    }
}
