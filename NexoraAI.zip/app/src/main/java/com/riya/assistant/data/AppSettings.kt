package com.riya.assistant.data

enum class SwipeSpeed { Gentle, Normal, Fast }

data class AppSettings(
    val uiThemeId: String = "obsidian_red",
    val orbThemeId: String = "obsidian_red",
    val assistantName: String = "Riya",
    /** "en", "bn" or "hi". */
    val language: String = "en",
    val reducedMotion: Boolean = false,
    val swipeSpeed: SwipeSpeed = SwipeSpeed.Normal,
)
