package com.riya.assistant.data

enum class SwipeSpeed { Gentle, Normal, Fast }

/** Base delivery of each personality. User sliders multiply these values. */
enum class VoicePersonality(val basePitch: Float, val baseRate: Float) {
    /** Softer, higher, slightly slower. */
    Cute(basePitch = 1.3f, baseRate = 0.95f),
    /** Calm, natural, professional. */
    Normal(basePitch = 1.05f, baseRate = 1.0f),
}

data class AppSettings(
    val uiThemeId: String = "obsidian_red",
    val orbThemeId: String = "obsidian_red",
    val assistantName: String = "Riya",
    /** "en", "bn" or "hi". Also used as the speech-recognition language. */
    val language: String = "en",
    val reducedMotion: Boolean = false,
    val swipeSpeed: SwipeSpeed = SwipeSpeed.Normal,

    // Voice
    val voiceEnabled: Boolean = true,
    val voicePersonality: VoicePersonality = VoicePersonality.Cute,
    /** Empty = automatic (closest female voice the engine offers). */
    val voiceName: String = "",
    val speechRate: Float = 1.0f,
    val pitchAdjust: Float = 1.0f,
    val allowInterruption: Boolean = true,

    // Proactive conversation (off by default, rate-limited)
    val proactiveEnabled: Boolean = false,
    val silenceSeconds: Int = 20,
    val maxProactive: Int = 2,
    val quietEnabled: Boolean = true,
    val quietStartHour: Int = 22,
    val quietEndHour: Int = 7,
    val timeoutMinutes: Int = 5,
)
