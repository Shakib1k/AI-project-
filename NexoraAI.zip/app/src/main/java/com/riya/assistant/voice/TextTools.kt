package com.riya.assistant.voice

/** Picks the pronunciation language for a piece of text from its dominant script. */
object LanguageDetector {
    fun detect(text: String): SpeechLang {
        var bn = 0; var hi = 0; var latin = 0
        for (ch in text) when {
            ch in '\u0980'..'\u09FF' -> bn++
            ch in '\u0900'..'\u097F' -> hi++
            ch in 'A'..'Z' || ch in 'a'..'z' -> latin++
        }
        return when {
            bn == 0 && hi == 0 -> SpeechLang.English
            bn >= hi && bn >= latin / 2 -> SpeechLang.Bengali
            hi > bn && hi >= latin / 2 -> SpeechLang.Hindi
            else -> SpeechLang.English
        }
    }
}

object TextSanitizer {
    private val emoji = Regex("[\\p{So}\\uFE0F\\u200D\\u20E3]")
    private val markdown = Regex("[*_#`>~]+")

    /** Emojis and markdown marks are not spoken; they would be read aloud as symbol names. */
    fun forSpeech(text: String): String =
        text.replace(emoji, " ").replace(markdown, " ").replace(Regex("[ \\t]+"), " ").trim()
}

object TextChunker {
    private val sentenceEnd = Regex("(?<=[.!?\u0964\u0965\\n])\\s*")

    /** Splits long replies at sentence ends so each piece fits the engine's input limit. */
    fun split(text: String, max: Int = 3500): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out += cur.toString().trim(); cur.clear() }
        for (sentence in text.split(sentenceEnd).filter { it.isNotBlank() }) {
            if (sentence.length > max) {
                flush()
                sentence.chunked(max).forEach { out += it.trim() }
            } else {
                if (cur.length + sentence.length + 1 > max) flush()
                cur.append(sentence).append(' ')
            }
        }
        flush()
        return out
    }
}

/** While Riya talks, the recognizer can hear her own voice. Ignore text she is currently saying. */
object EchoFilter {
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() || it.isWhitespace() }.trim()

    fun isEcho(heard: String, spoken: String): Boolean {
        val h = norm(heard)
        return h.isNotEmpty() && norm(spoken).contains(h)
    }
}
