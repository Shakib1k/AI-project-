package com.riya.assistant.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.riya.assistant.BuildConfig
import com.riya.assistant.R
import com.riya.assistant.data.AppSettings
import com.riya.assistant.data.SwipeSpeed
import com.riya.assistant.ui.theme.OrbStyles
import com.riya.assistant.ui.theme.RiyaPalettes

@Composable
fun SettingsScreen(
    settings: AppSettings,
    vm: SettingsViewModel,
    onBack: () -> Unit,
    onOpenUiThemes: () -> Unit,
    onOpenOrbThemes: () -> Unit,
    onOpenVoice: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back),
                    tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(stringResource(R.string.settings), style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground)
        }

        // Scrollable, grouped, in the exact order from the spec.
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { PlannedGroup(stringResource(R.string.group_gemini)) }
            item {
                GroupCard(stringResource(R.string.group_voice)) {
                    OutlinedButton(onClick = onOpenVoice,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                        Text(stringResource(R.string.voice_group_open))
                    }
                }
            }
            item { PlannedGroup(stringResource(R.string.group_memory)) }
            item {
                GroupCard(stringResource(R.string.group_themes), startExpanded = true) {
                    ThemeRow(stringResource(R.string.ui_theme),
                        themeName(settings.uiThemeId, ui = true), onOpenUiThemes)
                    ThemeRow(stringResource(R.string.orb_theme),
                        themeName(settings.orbThemeId, ui = false), onOpenOrbThemes)
                }
            }
            item { PlannedGroup(stringResource(R.string.group_character)) }
            item { PlannedGroup(stringResource(R.string.group_permissions)) }
            item { PlannedGroup(stringResource(R.string.group_shizuku)) }
            item { PlannedGroup(stringResource(R.string.group_automation)) }
            item { PlannedGroup(stringResource(R.string.group_screen_privacy)) }
            item { LanguageGroup(settings, vm) }
            item { SwipeGroup(settings, vm) }
            item {
                GroupCard(stringResource(R.string.group_storage)) {
                    Text(stringResource(R.string.about_version, BuildConfig.VERSION_NAME),
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(stringResource(R.string.coming_later),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun themeName(id: String, ui: Boolean): String =
    if (ui && id == RiyaPalettes.SYSTEM_ID) stringResource(R.string.system_default)
    else if (ui) RiyaPalettes.resolve(id, true).name else OrbStyles.resolve(id).name

@Composable
private fun ThemeRow(label: String, value: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
        Text(label, Modifier.weight(1f))
        Text(value, color = MaterialTheme.colorScheme.secondary)
    }
}

/** A group whose feature is not built yet: visible in the right place, honestly disabled. */
@Composable
private fun PlannedGroup(title: String) {
    GroupCard(title) {
        Text(stringResource(R.string.coming_later),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LanguageGroup(settings: AppSettings, vm: SettingsViewModel) {
    GroupCard(stringResource(R.string.group_language)) {
        // Local text state so typing is smooth; saved on every change (trimmed, max 24 chars).
        var name by rememberSaveable(settings.assistantName) { mutableStateOf(settings.assistantName) }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24); if (it.isNotBlank()) vm.setAssistantName(it) },
            label = { Text(stringResource(R.string.assistant_name)) },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Text(stringResource(R.string.language), color = MaterialTheme.colorScheme.onSurface)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("en" to "English", "bn" to "বাংলা", "hi" to "हिन्दी").forEach { (code, label) ->
                FilterChip(selected = settings.language == code,
                    onClick = { vm.setLanguage(code) }, label = { Text(label) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.reduced_motion), Modifier.weight(1f),
                color = MaterialTheme.colorScheme.onSurface)
            Switch(checked = settings.reducedMotion, onCheckedChange = vm::setReducedMotion)
        }
    }
}

@Composable
private fun SwipeGroup(settings: AppSettings, vm: SettingsViewModel) {
    GroupCard(stringResource(R.string.group_swipe)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                SwipeSpeed.Gentle to R.string.swipe_gentle,
                SwipeSpeed.Normal to R.string.swipe_normal,
                SwipeSpeed.Fast to R.string.swipe_fast,
            ).forEach { (speed, label) ->
                FilterChip(selected = settings.swipeSpeed == speed,
                    onClick = { vm.setSwipeSpeed(speed) }, label = { Text(stringResource(label)) })
            }
        }
        Text(stringResource(R.string.swipe_hint), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GroupCard(
    title: String,
    startExpanded: Boolean = false,
    content: @Composable () -> Unit,
) {
    var expanded by rememberSaveable(title) { mutableStateOf(startExpanded) }
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface)
                Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            AnimatedVisibility(expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
            }
        }
    }
}
