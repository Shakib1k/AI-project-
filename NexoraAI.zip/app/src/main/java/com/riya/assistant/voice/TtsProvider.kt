package com.riya.assistant.voice

/**
 * Text-to-speech provider abstraction.
 * Implemented now: AndroidTtsProvider (works offline with the device engine).
 * A cloud/neural provider can implement the same interface later and be chosen in Voice Settings.
 */
interface TtsProvider {
    suspend fun initialize(): Boolean
    fun voices(): List<VoiceInfo>

    /** Suspends until the speech has finished. Cancelling the coroutine stops the audio immediately. */
    suspend fun speak(text: String, lang: SpeechLang, config: SpeakConfig)

    fun stop()
    fun shutdown()
}
