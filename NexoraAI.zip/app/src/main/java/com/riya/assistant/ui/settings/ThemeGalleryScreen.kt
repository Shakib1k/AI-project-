package com.riya.assistant.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.riya.assistant.R
import com.riya.assistant.ui.components.AiOrb
import com.riya.assistant.ui.components.OrbState
import com.riya.assistant.ui.theme.LocalOrbStyle
import com.riya.assistant.ui.theme.OrbStyles
import com.riya.assistant.ui.theme.RiyaPalettes

enum class ThemeKind { Ui, Orb }

private data class ThemeEntry(val id: String, val name: String, val swatches: List<Color>)

/**
 * Gallery with live preview. Tapping a theme only previews it;
 * the setting changes (and persists) only when Apply is pressed.
 */
@Composable
fun ThemeGalleryScreen(kind: ThemeKind, currentId: String, onApply: (String) -> Unit, onBack: () -> Unit) {
    val systemLabel = stringResource(R.string.system_default)
    val entries: List<ThemeEntry> = when (kind) {
        ThemeKind.Ui -> listOf(ThemeEntry(RiyaPalettes.SYSTEM_ID, systemLabel,
            listOf(Color(0xFF0B0B0D), Color(0xFFFAFAFA)))) +
            RiyaPalettes.all.map { ThemeEntry(it.id, it.name, listOf(it.background, it.surfaceHigh, it.primary, it.secondary)) }
        ThemeKind.Orb -> OrbStyles.all.map { ThemeEntry(it.id, it.name, listOf(it.core, it.glow, it.ring)) }
    }
    var previewId by rememberSaveable { mutableStateOf(currentId) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.ArrowBack, stringResource(R.string.back),
                    tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(stringResource(if (kind == ThemeKind.Ui) R.string.ui_theme else R.string.orb_theme),
                style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        }

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text(stringResource(R.string.theme_hint), style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item { Preview(kind, previewId) }
            item {
                val same = previewId == currentId
                Button(
                    onClick = { onApply(previewId) }, enabled = !same,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                ) { Text(stringResource(if (same) R.string.applied else R.string.apply)) }
            }
            items(entries, key = { it.id }) { e ->
                val selected = e.id == previewId
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                    border = BorderStroke(if (selected) 2.dp else 1.dp,
                        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth().clickable { previewId = e.id },
                ) {
                    Row(Modifier.padding(16.dp).heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(e.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface)
                        e.swatches.forEach {
                            Box(Modifier.padding(start = 6.dp).size(20.dp).background(it, CircleShape))
                        }
                        if (e.id == currentId) {
                            Icon(Icons.Default.CheckCircle, stringResource(R.string.applied),
                                Modifier.padding(start = 10.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Preview(kind: ThemeKind, id: String) {
    when (kind) {
        ThemeKind.Ui -> {
            // Re-skin only this card with the previewed palette.
            val palette = RiyaPalettes.resolve(id, androidx.compose.foundation.isSystemInDarkTheme())
            MaterialTheme(colorScheme = palette.toColorScheme()) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(stringResource(R.string.preview), style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground)
                    AiOrb(OrbState.Listening, Modifier.width(120.dp))
                    Column(Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(14.dp))
                        .padding(12.dp)) {
                        Text(stringResource(R.string.live_voice_chat), color = MaterialTheme.colorScheme.onSurface)
                        Text(stringResource(R.string.status_ready), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(onClick = {}, enabled = false) { Text(stringResource(R.string.apply)) }
                }
            }
        }
        ThemeKind.Orb -> {
            CompositionLocalProvider(LocalOrbStyle provides OrbStyles.resolve(id)) {
                Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
                    .padding(16.dp), contentAlignment = Alignment.Center) {
                    AiOrb(OrbState.Listening, Modifier.widthIn(max = 180.dp).fillMaxWidth(0.6f))
                }
            }
        }
    }
}
