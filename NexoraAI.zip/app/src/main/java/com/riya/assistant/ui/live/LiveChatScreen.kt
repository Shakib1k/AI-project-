package com.riya.assistant.ui.live

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riya.assistant.R
import com.riya.assistant.ui.components.AiOrb
import com.riya.assistant.ui.components.OrbState
import com.riya.assistant.voice.LiveChatViewModel
import com.riya.assistant.voice.LiveChatViewModel.Phase

/**
 * Live Voice Chat. No model or voice selector here by design (they live in Settings).
 * Screen Share is still disabled with a reason until its phase is built.
 */
@Composable
fun LiveChatScreen(vm: LiveChatViewModel, onEndChat: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    fun micGranted() = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(micGranted()) }
    var askedOnce by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it; askedOnce = true
    }

    // Recheck when returning from Android Settings.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) granted = micGranted() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(granted) { if (granted) vm.startSession() }
    LaunchedEffect(ui.finished) { if (ui.finished) onEndChat() }

    val orb = when (ui.phase) {
        Phase.Listening -> OrbState.Listening
        Phase.Thinking -> OrbState.Thinking
        Phase.Speaking -> OrbState.Speaking
        Phase.Error -> OrbState.Error
        Phase.Idle -> OrbState.Idle
    }
    val status = when (ui.phase) {
        Phase.Listening -> stringResource(R.string.live_listening)
        Phase.Thinking -> stringResource(R.string.live_thinking)
        Phase.Speaking -> stringResource(R.string.live_speaking)
        Phase.Error -> stringResource(R.string.status_attention)
        Phase.Idle -> stringResource(R.string.status_ready)
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        AiOrb(orb, Modifier.widthIn(max = 280.dp).fillMaxWidth(0.7f))
        Spacer(Modifier.height(16.dp))
        Text(status, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        Text(
            stringResource(if (granted && ui.sessionActive) R.string.mic_on else R.string.mic_off),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (!granted) {
            // Permission labels stay English by design.
            Spacer(Modifier.height(16.dp))
            Text("Microphone Permission", style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground)
            Text("Required for Live Voice Chat so Riya can hear you. Status: Not Granted",
                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = {
                    if (askedOnce) {
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)))
                    } else launcher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.padding(top = 8.dp).heightIn(min = 52.dp),
            ) { Text(if (askedOnce) "Open Settings" else "Grant Permission") }
        }

        if (ui.partial.isNotBlank()) Transcript(stringResource(R.string.live_you_said), ui.partial)
        else if (ui.lastUser.isNotBlank()) Transcript(stringResource(R.string.live_you_said), ui.lastUser)
        if (ui.lastReply.isNotBlank()) Transcript(stringResource(R.string.live_riya_said), ui.lastReply)
        ui.message?.let {
            Text(it, Modifier.padding(top = 12.dp), textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(
            onClick = vm::stopSpeaking, enabled = ui.phase == Phase.Speaking,
            modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp).heightIn(min = 52.dp),
        ) { Text(stringResource(R.string.live_stop_speaking)) }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {}, enabled = false,
            modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp).heightIn(min = 52.dp),
        ) { Text(stringResource(R.string.screen_share)) }
        Text(stringResource(R.string.screen_share_disabled_reason),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.endSession() },
            modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp).heightIn(min = 52.dp),
        ) { Text(stringResource(R.string.end_chat)) }
    }
}

@Composable
private fun Transcript(label: String, text: String) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
    }
}
