package com.riya.assistant.ui.theme

import android.app.Activity
import android.content.res.Configuration
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.riya.assistant.data.AppSettings
import java.util.Locale

val LocalOrbStyle = compositionLocalOf { OrbStyles.all.first() }
val LocalReducedMotion = compositionLocalOf { false }

/**
 * Applies the UI palette, the (independent) orb style, reduced motion, and the
 * in-app language, so stringResource() follows the user's language choice.
 */
@Composable
fun RiyaTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val palette = RiyaPalettes.resolve(settings.uiThemeId, isSystemInDarkTheme())
    val orb = OrbStyles.resolve(settings.orbThemeId)

    val baseContext = LocalContext.current
    val baseConfig = LocalConfiguration.current
    val localizedContext = remember(settings.language, baseConfig) {
        val cfg = Configuration(baseConfig).apply { setLocale(Locale(settings.language)) }
        baseContext.createConfigurationContext(cfg)
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !palette.dark
                isAppearanceLightNavigationBars = !palette.dark
            }
        }
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalOrbStyle provides orb,
        LocalReducedMotion provides settings.reducedMotion,
    ) {
        MaterialTheme(colorScheme = palette.toColorScheme(), content = content)
    }
}
