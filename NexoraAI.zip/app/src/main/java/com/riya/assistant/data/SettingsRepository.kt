package com.riya.assistant.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "riya_settings")

/** Persists every user choice with DataStore so it survives app restarts. */
class SettingsRepository(private val context: Context) {

    private object K {
        val uiTheme = stringPreferencesKey("ui_theme")
        val orbTheme = stringPreferencesKey("orb_theme")
        val name = stringPreferencesKey("assistant_name")
        val language = stringPreferencesKey("language")
        val reducedMotion = booleanPreferencesKey("reduced_motion")
        val swipeSpeed = stringPreferencesKey("swipe_speed")
        val voiceEnabled = booleanPreferencesKey("voice_enabled")
        val personality = stringPreferencesKey("voice_personality")
        val voiceName = stringPreferencesKey("voice_name")
        val rate = floatPreferencesKey("speech_rate")
        val pitch = floatPreferencesKey("pitch_adjust")
        val interrupt = booleanPreferencesKey("allow_interruption")
        val proactive = booleanPreferencesKey("proactive_enabled")
        val silence = intPreferencesKey("silence_seconds")
        val maxProactive = intPreferencesKey("max_proactive")
        val quiet = booleanPreferencesKey("quiet_enabled")
        val quietStart = intPreferencesKey("quiet_start")
        val quietEnd = intPreferencesKey("quiet_end")
        val timeout = intPreferencesKey("timeout_minutes")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                uiThemeId = p[K.uiTheme] ?: d.uiThemeId,
                orbThemeId = p[K.orbTheme] ?: d.orbThemeId,
                assistantName = p[K.name]?.takeIf { it.isNotBlank() } ?: d.assistantName,
                language = p[K.language] ?: d.language,
                reducedMotion = p[K.reducedMotion] ?: d.reducedMotion,
                swipeSpeed = runCatching { SwipeSpeed.valueOf(p[K.swipeSpeed] ?: "") }.getOrDefault(d.swipeSpeed),
                voiceEnabled = p[K.voiceEnabled] ?: d.voiceEnabled,
                voicePersonality = runCatching { VoicePersonality.valueOf(p[K.personality] ?: "") }
                    .getOrDefault(d.voicePersonality),
                voiceName = p[K.voiceName] ?: d.voiceName,
                speechRate = (p[K.rate] ?: d.speechRate).coerceIn(0.5f, 1.5f),
                pitchAdjust = (p[K.pitch] ?: d.pitchAdjust).coerceIn(0.5f, 1.5f),
                allowInterruption = p[K.interrupt] ?: d.allowInterruption,
                proactiveEnabled = p[K.proactive] ?: d.proactiveEnabled,
                silenceSeconds = (p[K.silence] ?: d.silenceSeconds).coerceIn(5, 120),
                maxProactive = (p[K.maxProactive] ?: d.maxProactive).coerceIn(1, 5),
                quietEnabled = p[K.quiet] ?: d.quietEnabled,
                quietStartHour = (p[K.quietStart] ?: d.quietStartHour).coerceIn(0, 23),
                quietEndHour = (p[K.quietEnd] ?: d.quietEndHour).coerceIn(0, 23),
                timeoutMinutes = (p[K.timeout] ?: d.timeoutMinutes).coerceIn(1, 30),
            )
        }

    private suspend fun <T> put(key: Preferences.Key<T>, v: T) = context.settingsStore.edit { it[key] = v }

    suspend fun setUiTheme(id: String) = put(K.uiTheme, id)
    suspend fun setOrbTheme(id: String) = put(K.orbTheme, id)
    suspend fun setAssistantName(name: String) = put(K.name, name.trim().take(24))
    suspend fun setLanguage(code: String) = put(K.language, code)
    suspend fun setReducedMotion(on: Boolean) = put(K.reducedMotion, on)
    suspend fun setSwipeSpeed(s: SwipeSpeed) = put(K.swipeSpeed, s.name)
    suspend fun setVoiceEnabled(on: Boolean) = put(K.voiceEnabled, on)
    suspend fun setPersonality(p: VoicePersonality) = put(K.personality, p.name)
    suspend fun setVoiceName(n: String) = put(K.voiceName, n)
    suspend fun setSpeechRate(v: Float) = put(K.rate, v)
    suspend fun setPitchAdjust(v: Float) = put(K.pitch, v)
    suspend fun setAllowInterruption(on: Boolean) = put(K.interrupt, on)
    suspend fun setProactiveEnabled(on: Boolean) = put(K.proactive, on)
    suspend fun setSilenceSeconds(v: Int) = put(K.silence, v)
    suspend fun setMaxProactive(v: Int) = put(K.maxProactive, v)
    suspend fun setQuietEnabled(on: Boolean) = put(K.quiet, on)
    suspend fun setQuietStartHour(v: Int) = put(K.quietStart, v)
    suspend fun setQuietEndHour(v: Int) = put(K.quietEnd, v)
    suspend fun setTimeoutMinutes(v: Int) = put(K.timeout, v)
}
