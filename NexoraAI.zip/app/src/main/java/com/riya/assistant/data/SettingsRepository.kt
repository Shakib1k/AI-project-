package com.riya.assistant.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "riya_settings")

/** Persists every user choice with DataStore so it survives app restarts. */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val uiTheme = stringPreferencesKey("ui_theme")
        val orbTheme = stringPreferencesKey("orb_theme")
        val name = stringPreferencesKey("assistant_name")
        val language = stringPreferencesKey("language")
        val reducedMotion = booleanPreferencesKey("reduced_motion")
        val swipeSpeed = stringPreferencesKey("swipe_speed")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                uiThemeId = p[Keys.uiTheme] ?: d.uiThemeId,
                orbThemeId = p[Keys.orbTheme] ?: d.orbThemeId,
                assistantName = p[Keys.name]?.takeIf { it.isNotBlank() } ?: d.assistantName,
                language = p[Keys.language] ?: d.language,
                reducedMotion = p[Keys.reducedMotion] ?: d.reducedMotion,
                swipeSpeed = runCatching { SwipeSpeed.valueOf(p[Keys.swipeSpeed] ?: "") }
                    .getOrDefault(d.swipeSpeed),
            )
        }

    suspend fun setUiTheme(id: String) = context.settingsStore.edit { it[Keys.uiTheme] = id }
    suspend fun setOrbTheme(id: String) = context.settingsStore.edit { it[Keys.orbTheme] = id }
    suspend fun setAssistantName(name: String) =
        context.settingsStore.edit { it[Keys.name] = name.trim().take(24) }
    suspend fun setLanguage(code: String) = context.settingsStore.edit { it[Keys.language] = code }
    suspend fun setReducedMotion(on: Boolean) = context.settingsStore.edit { it[Keys.reducedMotion] = on }
    suspend fun setSwipeSpeed(s: SwipeSpeed) = context.settingsStore.edit { it[Keys.swipeSpeed] = s.name }
}
