package com.riya.assistant.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.riya.assistant.data.AppSettings
import com.riya.assistant.data.SettingsRepository
import com.riya.assistant.data.SwipeSpeed
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val repo: SettingsRepository) : ViewModel() {

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setUiTheme(id: String) = viewModelScope.launch { repo.setUiTheme(id) }
    fun setOrbTheme(id: String) = viewModelScope.launch { repo.setOrbTheme(id) }
    fun setAssistantName(name: String) = viewModelScope.launch { repo.setAssistantName(name) }
    fun setLanguage(code: String) = viewModelScope.launch { repo.setLanguage(code) }
    fun setReducedMotion(on: Boolean) = viewModelScope.launch { repo.setReducedMotion(on) }
    fun setSwipeSpeed(s: SwipeSpeed) = viewModelScope.launch { repo.setSwipeSpeed(s) }

    /** Generic write used by the voice settings controls: vm.update { setPitchAdjust(1.1f) }. */
    fun update(block: suspend SettingsRepository.() -> Unit) = viewModelScope.launch { repo.block() }

    companion object {
        fun factory(repo: SettingsRepository): ViewModelProvider.Factory = viewModelFactory {
            initializer { SettingsViewModel(repo) }
        }
    }
}
