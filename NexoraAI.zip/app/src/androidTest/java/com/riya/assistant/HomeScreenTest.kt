package com.riya.assistant

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.riya.assistant.data.AppSettings
import com.riya.assistant.ui.home.HomeScreen
import com.riya.assistant.ui.theme.RiyaTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HomeScreenTest {
    @get:Rule val rule = createComposeRule()

    @Test fun homeHasSettingsIconAndNoModelOrVoiceSelectors() {
        var opened = false
        rule.setContent {
            RiyaTheme(AppSettings()) { HomeScreen(AppSettings(), onLiveVoice = {}, onSettings = { opened = true }) }
        }
        rule.onNodeWithText("Live Voice Chat").assertIsDisplayed()
        rule.onNodeWithText("Gemini Model").assertDoesNotExist()
        rule.onNodeWithText("Voice Personality").assertDoesNotExist()
        rule.onNodeWithContentDescription("Settings").performClick()
        assertTrue(opened)
    }
}
