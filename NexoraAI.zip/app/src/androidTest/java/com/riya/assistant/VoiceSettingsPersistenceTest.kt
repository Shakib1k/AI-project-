package com.riya.assistant

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.riya.assistant.data.SettingsRepository
import com.riya.assistant.data.VoicePersonality
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class VoiceSettingsPersistenceTest {
    private val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test fun defaultsAreCuteFemaleWithProactiveOff() = runBlocking {
        val d = com.riya.assistant.data.AppSettings()
        assertEquals(VoicePersonality.Cute, d.voicePersonality)
        assertTrue(!d.proactiveEnabled)
    }

    @Test fun voiceSettingsSurviveRestart() = runBlocking {
        SettingsRepository(ctx).apply {
            setPersonality(VoicePersonality.Normal); setSpeechRate(1.2f); setPitchAdjust(0.8f)
            setProactiveEnabled(true); setSilenceSeconds(45); setVoiceName("test-voice")
        }
        val s = SettingsRepository(ctx).settings.first()
        assertEquals(VoicePersonality.Normal, s.voicePersonality)
        assertEquals(1.2f, s.speechRate, 0.001f)
        assertEquals(0.8f, s.pitchAdjust, 0.001f)
        assertTrue(s.proactiveEnabled)
        assertEquals(45, s.silenceSeconds)
        assertEquals("test-voice", s.voiceName)
    }
}
