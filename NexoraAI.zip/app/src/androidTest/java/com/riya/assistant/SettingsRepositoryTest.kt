package com.riya.assistant

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.riya.assistant.data.SettingsRepository
import com.riya.assistant.data.SwipeSpeed
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SettingsRepositoryTest {
    private val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test fun uiAndOrbThemesPersistIndependently() = runBlocking {
        SettingsRepository(ctx).apply {
            setUiTheme("midnight_blue"); setOrbTheme("cyber_neon")
        }
        // A fresh repository instance simulates an app restart.
        val s = SettingsRepository(ctx).settings.first()
        assertEquals("midnight_blue", s.uiThemeId)
        assertEquals("cyber_neon", s.orbThemeId)
    }

    @Test fun otherSettingsPersist() = runBlocking {
        SettingsRepository(ctx).apply {
            setLanguage("bn"); setReducedMotion(true); setSwipeSpeed(SwipeSpeed.Fast); setAssistantName("Maya")
        }
        val s = SettingsRepository(ctx).settings.first()
        assertEquals("bn", s.language)
        assertEquals(true, s.reducedMotion)
        assertEquals(SwipeSpeed.Fast, s.swipeSpeed)
        assertEquals("Maya", s.assistantName)
    }
}
