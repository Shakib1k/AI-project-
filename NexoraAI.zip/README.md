# Riya AI Assistant (Android) — Phase 2: Foundation + Voice

Brand-new project. Kotlin, Jetpack Compose, Material 3, MVVM, Coroutines/StateFlow, DataStore, Navigation.

## Open and run
1. Android Studio Ladybug (2024.2) or newer, JDK 17.
2. File > Open > select this folder. Let Gradle sync (it downloads the wrapper and libraries).
3. Run the `app` configuration on a device or emulator (Android 8.0+, API 26).
4. Unit tests: `./gradlew test`. Device tests: `./gradlew connectedAndroidTest`.

NOTE: this phase was written without a build server. It has NOT been compiled or run yet.
If Gradle reports an error, send me the message and I will fix it first thing.

## Added in Phase 2 (Voice)
- TTS provider abstraction (`voice/TtsProvider`) with a working offline `AndroidTtsProvider`.
  A cloud/neural provider can implement the same interface later.
- Two personalities, Cute Female (default) and Normal Female, plus speed/pitch sliders,
  a voice list, and preview buttons in English, Bengali and Hindi (Settings > Voice Settings).
- Language per sentence is detected from the script, so mixed replies are pronounced correctly.
  Emojis and markdown marks are never read aloud.
- Live Voice Chat: contextual Microphone Permission request (English labels), speech recognition
  (one language per turn: the app language), spoken replies, live transcript, Stop Speaking.
- Interruption: speaking over Riya stops her audio and cancels her pending answer. Her own words
  picked up by the mic are ignored (echo filter). Headphones work best.
- Proactive speech: off by default, silence timer, max count, quiet hours, Android Do Not Disturb,
  conversation timeout.
- Audio focus: losing focus (call, other media) stops speech. No overlapping playback.
- Replies are an honest "Gemini is not connected yet" message until Phase 3 adds Gemini.

Honest limits:
- Android gives no voice-gender field, so "female" is a name-based guess; you pick the voice.
- Bengali/Hindi quality depends on the voice data installed on the phone.
- The built-in recognizer cannot auto-detect the spoken language. It uses the app language.
- A truly "extremely cute" voice may need a cloud neural provider (planned as a provider).

## What works in Phase 1
- Home: assistant name, status, animated orb, Live Voice Chat, Settings icon (top corner),
  small Memory and Automation indicators. No model or voice selector on Home.
- Live Voice Chat shell: orb, status, End Chat. Screen Share is shown but disabled, with the reason.
- Settings: scrollable, 12 groups in the spec order. Working now: Theme Gallery, Language and
  App Appearance (name, language, reduce motion), Swipe Speed preference, About.
  Other groups say plainly that they arrive in a later phase.
- 10 UI themes plus System Default, and 10 independent Orb themes, each with live preview and Apply.
- 3 interface languages (English, Bengali, Hindi). Permission Center and Shizuku titles stay English.
- Everything persists in DataStore.
- No sensitive Android permissions are declared yet; they arrive with the features that need them.

## Phase roadmap
2 Voice (DONE, see above)
3 Gemini (secure API key, model discovery, custom models) and chat
4 Permission Center and Screen Share (MediaProjection)
5 Accessibility automation, gesture engine, typing/delete, messaging apps, MT Manager
6 Shizuku module and task router
7 YouTube and social media adapters, thumbnails
8 Memory engine (growing database, backup/restore) and 3D character gallery

## Structure
app/src/main/java/com/riya/assistant/
  RiyaApp.kt, MainActivity.kt      app container (manual DI), entry point
  data/                            AppSettings, SettingsRepository (DataStore)
  ui/theme/                        Palettes (10 UI + 10 orb), RiyaTheme
  ui/components/AiOrb.kt           animated orb, all 12 spec states
  ui/home, ui/live, ui/settings    screens, ViewModel, theme gallery
  ui/nav/RiyaNavHost.kt            navigation
