# Riya AI Assistant (Android) — Phase 1: Foundation

Brand-new project. Kotlin, Jetpack Compose, Material 3, MVVM, Coroutines/StateFlow, DataStore, Navigation.

## Open and run
1. Android Studio Ladybug (2024.2) or newer, JDK 17.
2. File > Open > select this folder. Let Gradle sync (it downloads the wrapper and libraries).
3. Run the `app` configuration on a device or emulator (Android 8.0+, API 26).
4. Unit tests: `./gradlew test`. Device tests: `./gradlew connectedAndroidTest`.

NOTE: this phase was written without a build server. It has NOT been compiled or run yet.
If Gradle reports an error, send me the message and I will fix it first thing.

## What works in Phase 1
- Home: assistant name, status, animated orb, Live Voice Chat, Settings icon (top corner),
  small Memory and Automation indicators. No model or voice selector on Home.
- Live Voice Chat shell: orb, status, End Chat. Screen Share is shown but disabled, with the reason.
- Settings: scrollable, 12 groups in the spec order. Working now: Theme Gallery, Language and
  App Appearance (name, language, reduce motion), Swipe Speed preference, About.
  Other groups say plainly that they arrive in a later phase.
- 10 UI themes plus System Default, and 10 independent Orb themes, each with live preview and Apply.
- 3 interface languages (English, Bengali, Hindi). Permission Center and Shizuku titles stay English.
- Everything persists in DataStore.
- No sensitive Android permissions are declared yet; they arrive with the features that need them.

## Phase roadmap
2 Voice (TTS pipeline, cute female voices, speech recognition, interruption, proactive speech)
3 Gemini (secure API key, model discovery, custom models) and chat
4 Permission Center and Screen Share (MediaProjection)
5 Accessibility automation, gesture engine, typing/delete, messaging apps, MT Manager
6 Shizuku module and task router
7 YouTube and social media adapters, thumbnails
8 Memory engine (growing database, backup/restore) and 3D character gallery

## Structure
app/src/main/java/com/riya/assistant/
  RiyaApp.kt, MainActivity.kt      app container (manual DI), entry point
  data/                            AppSettings, SettingsRepository (DataStore)
  ui/theme/                        Palettes (10 UI + 10 orb), RiyaTheme
  ui/components/AiOrb.kt           animated orb, all 12 spec states
  ui/home, ui/live, ui/settings    screens, ViewModel, theme gallery
  ui/nav/RiyaNavHost.kt            navigation
