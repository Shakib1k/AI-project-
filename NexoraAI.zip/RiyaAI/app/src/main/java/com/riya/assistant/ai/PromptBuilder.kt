package com.riya.assistant.ai

import com.riya.assistant.data.Prefs
import com.riya.assistant.voice.LanguageDetector

object PromptBuilder {
    fun build(p: Prefs, memory: List<String>, accessibilityOn: Boolean, screenOn: Boolean, userText: String): String {
        val cute = p.personality == "cute"
        val flavor = LanguageDetector.flavor(userText)
        val sb = StringBuilder()
        sb.appendLine("You are ${p.aiName}, a ${if (cute) "very cute, sweet, warm and expressive" else "calm, friendly and professional"} female personal AI assistant living on the user's Android phone.")
        sb.appendLine("Address the user as \"Boss\" in English and Hindi-English, and \"বস\" in Bengali. Hindi: \"बॉस\".")
        sb.appendLine("Reply in the language the user just used: Bengali, Hindi or English. Mixed input (Banglish, Hinglish, Bengali-English, Hindi-English) gets a natural reply in the same mix. Never translate unless asked. ${flavor?.let { "The user is writing $it." } ?: ""}")
        sb.appendLine(if (cute) "Style: soft, affectionate, playful, short natural spoken sentences. Example tone: \"জি বস, আমি শুনছি 😊\"." else "Style: soft, polite, composed, concise.")
        sb.appendLine("Your replies are spoken aloud: keep them short and conversational unless the user asks for long content. No markdown, no bullet lists in spoken replies. Use emojis sparingly and only where natural; if the user says no emojis, use none.")
        sb.appendLine("Never claim you executed code, sent a message or opened an app unless an action result confirms it. Never invent screen contents.")
        sb.appendLine()
        sb.appendLine("PHONE ACTIONS. Accessibility automation is ${if (accessibilityOn) "ENABLED" else "NOT enabled (tell the user to enable it in Settings if they ask for phone control)"}. Screen observation is ${if (screenOn) "ACTIVE" else "off"}.")
        sb.appendLine("When the user wants a phone action, your reply MUST begin with exactly one line: <<ACTION>>{json}  followed by a newline and then your spoken reply.")
        sb.appendLine("""JSON types: {"type":"open_app","app":"MT Manager"} {"type":"open_chat","app":"telegram|whatsapp|messenger","query":"channel or contact name as spoken"} {"type":"send_message","app":"telegram|whatsapp|messenger","text":"exact message"} {"type":"tap","text":"visible label"} {"type":"type","text":"text","replace":false} {"type":"scroll","dir":"up|down|left|right"} {"type":"back"} {"type":"home"} {"type":"read_screen"} {"type":"describe_screen"} {"type":"read_text","text":"text to read aloud"} {"type":"write_code","language":"python","spec":"what the code must do"} {"type":"ui_task","app":"MT Manager","goal":"create a file named bot.py"}""")
        sb.appendLine("""Add "ask":true when your spoken reply is a yes/no confirmation question (e.g. "বস, MT Manager খুলে দেব?"). Add "approved":true ONLY if the user already clearly approved this exact action in this same message or just answered yes to your question. Opening apps, sending messages, deleting or overwriting files always need a spoken confirmation first unless approved.""")
        sb.appendLine("For \"write_code\" use it when the user wants code typed directly into an editor (for example MT Manager). For ordinary code questions, just answer with complete, valid code and no placeholders.")
        sb.appendLine("If the user tells you something worth remembering long-term (a preference, a name, an important instruction), add a line <<REMEMBER>>short fact BEFORE your reply. Only when it is genuinely durable.")
        sb.appendLine("If a request is ambiguous (several chats with similar names), ask one short clarifying question instead of acting.")
        if (memory.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("Relevant things you remember about the user (use only if helpful):")
            memory.forEach { sb.appendLine("- $it") }
        }
        return sb.toString()
    }
}

/** Events parsed from the model's stream. Header lines first, then the spoken reply sentence by sentence. */
sealed interface StreamEvent {
    data class Action(val json: org.json.JSONObject) : StreamEvent
    data class Remember(val text: String) : StreamEvent
    data class Say(val sentence: String) : StreamEvent
}

class StreamParser {
    private val buf = StringBuilder()
    private var header = true
    private val terminators = charArrayOf('.', '!', '?', '।', '\n', '॥')

    fun feed(chunk: String): List<StreamEvent> {
        buf.append(chunk)
        val out = mutableListOf<StreamEvent>()
        while (header) {
            val s = buf.toString().trimStart()
            if (s.isEmpty()) return out
            if (!s.startsWith("<<")) { header = false; break }
            val nl = s.indexOf('\n')
            if (nl < 0) return out // wait for the full header line
            parseHeader(s.substring(0, nl))?.let { out += it }
            buf.setLength(0); buf.append(s.substring(nl + 1))
        }
        out += cutSentences(false)
        return out
    }

    fun finish(): List<StreamEvent> {
        val out = mutableListOf<StreamEvent>()
        if (header) {
            val s = buf.toString().trim()
            header = false
            if (s.startsWith("<<")) { parseHeader(s)?.let { out += it }; buf.setLength(0) }
        }
        out += cutSentences(true)
        return out
    }

    private fun parseHeader(line: String): StreamEvent? = runCatching {
        when {
            line.startsWith("<<ACTION>>") -> StreamEvent.Action(org.json.JSONObject(line.removePrefix("<<ACTION>>").trim()))
            line.startsWith("<<REMEMBER>>") -> StreamEvent.Remember(line.removePrefix("<<REMEMBER>>").trim())
            else -> null
        }
    }.getOrNull()

    private fun cutSentences(flush: Boolean): List<StreamEvent> {
        val out = mutableListOf<StreamEvent>()
        while (true) {
            val s = buf.toString()
            var i = s.indexOfAny(terminators)
            while (i in 0 until s.length - 1 && s[i] != '\n' && s[i] != '।' && !s[i + 1].isWhitespace()) i = s.indexOfAny(terminators, i + 1)
            if (i < 0 || (i == s.length - 1 && !flush && s[i] != '\n' && s[i] != '।')) break
            val sentence = s.substring(0, i + 1).trim()
            buf.delete(0, i + 1)
            if (sentence.length >= 2) out += StreamEvent.Say(sentence)
        }
        if (flush && buf.isNotBlank()) { out += StreamEvent.Say(buf.toString().trim()); buf.setLength(0) }
        return out
    }
}
