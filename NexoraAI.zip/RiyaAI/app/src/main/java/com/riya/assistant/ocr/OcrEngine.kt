package com.riya.assistant.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.riya.assistant.ai.GeminiClient
import com.riya.assistant.ai.Turn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Bengali, Hindi and English OCR.
 * Gemini vision is used when a key and model are set (best for Bengali). ML Kit works offline for Latin + Devanagari (Hindi/English).
 * ML Kit has no Bengali model, so Bengali text offline is not supported and the result says so instead of guessing.
 */
class OcrEngine(private val ctx: Context, private val gemini: GeminiClient) {
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val deva by lazy { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }

    private fun jpeg(b: Bitmap) = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()

    suspend fun read(bitmap: Bitmap, model: String): Result<String> {
        if (model.isNotBlank()) {
            val r = gemini.generate(model,
                "You are an OCR engine. Extract ALL visible text exactly as written, in its original language and script (Bengali, Hindi, English, mixed). Keep line breaks. Do not translate, summarise or add commentary. If there is no text, reply with nothing.",
                listOf(Turn("user", "Extract the text from this image.")), 0.0f, 4096, listOf(jpeg(bitmap) to "image/jpeg"))
            if (r.isSuccess) return r
        }
        return offline(bitmap)
    }

    private suspend fun offline(bitmap: Bitmap): Result<String> = runCatching {
        val img = InputImage.fromBitmap(bitmap, 0)
        val a = run(latin, img); val b = run(deva, img)
        val text = if (b.count { it in '\u0900'..'\u097F' } > 3) b else a.ifBlank { b }
        if (text.isBlank()) error("No Hindi/English text found offline. Bengali OCR needs a Gemini key (no offline Bengali model).")
        text
    }

    private suspend fun run(rec: com.google.mlkit.vision.text.TextRecognizer, img: InputImage): String =
        suspendCancellableCoroutine { c -> rec.process(img).addOnSuccessListener { c.resume(it.text) }.addOnFailureListener { c.resume("") } }

    /** Image or PDF (first [maxPages] pages) picked through the system file picker. */
    suspend fun readUri(uri: Uri, mime: String?, model: String, maxPages: Int = 5): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (mime == "application/pdf") {
                val pfd: ParcelFileDescriptor = ctx.contentResolver.openFileDescriptor(uri, "r")!!
                val sb = StringBuilder()
                PdfRenderer(pfd).use { r ->
                    for (i in 0 until minOf(r.pageCount, maxPages)) r.openPage(i).use { p ->
                        val bmp = Bitmap.createBitmap(p.width * 2, p.height * 2, Bitmap.Config.ARGB_8888).also { it.eraseColor(android.graphics.Color.WHITE) }
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        sb.appendLine(read(bmp, model).getOrThrow())
                    }
                }
                sb.toString().trim()
            } else {
                val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: error("Cannot decode image")
                read(bmp, model).getOrThrow()
            }
        }
    }
}
