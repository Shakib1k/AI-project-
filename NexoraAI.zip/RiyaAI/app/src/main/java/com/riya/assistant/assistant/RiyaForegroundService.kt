package com.riya.assistant.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import com.riya.assistant.R
import com.riya.assistant.RiyaApp
import com.riya.assistant.screen.OrbOverlayView
import com.riya.assistant.screen.ScreenSession
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

/** Keeps the live voice session alive in the background and hosts the floating orb (while screen observation is active). */
class RiyaForegroundService : Service() {
    companion object { const val ACTION_STOP = "stop"; private const val CH = "riya_live" }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var view: OrbOverlayView? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as RiyaApp
        if (intent?.action == ACTION_STOP) { app.container.assistant.stopLive(); stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Live voice", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 3, Intent(this, RiyaForegroundService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Riya is listening").setContentText("Live voice session is active")
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        scope.launch {
            combine(app.container.assistant.orb, ScreenSession.active) { o, s -> o to s }.collect { (o, s) ->
                val show = s && Settings.canDrawOverlays(this@RiyaForegroundService)
                if (show && view == null) addOrb()
                if (!show) removeOrb()
                view?.state = o; view?.observing = s
            }
        }
        return START_STICKY
    }

    private fun addOrb() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = (96 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 300 }
        view = OrbOverlayView(this, lp, wm).also { wm.addView(it, lp) }
    }

    private fun removeOrb() {
        view?.let { runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } }
        view = null
    }

    override fun onDestroy() { removeOrb(); scope.cancel(); super.onDestroy() }
}
