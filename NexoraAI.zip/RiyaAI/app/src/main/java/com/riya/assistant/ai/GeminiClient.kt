package com.riya.assistant.ai

import android.util.Base64
import com.riya.assistant.data.SecureKeyStore
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Turn(val role: String, val text: String) // role: "user" | "model"
data class ModelInfo(val id: String, val displayName: String, val methods: List<String>)
class GeminiException(message: String) : Exception(message)

/** Official Gemini REST API. The key is sent in a header, so it never appears in URLs or logs. */
class GeminiClient(private val keys: SecureKeyStore) {
    private val base = "https://generativelanguage.googleapis.com/v1beta"
    private val json = "application/json".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // streaming; cancellation is done by Call.cancel()
        .build()

    private fun req(path: String) = Request.Builder().url("$base/$path")
        .header("x-goog-api-key", keys.geminiKey)

    private fun err(resp: Response): String {
        val body = runCatching { resp.body?.string() }.getOrNull()
        val msg = runCatching { JSONObject(body ?: "").getJSONObject("error").getString("message") }.getOrNull()
        return "HTTP ${resp.code}: ${msg ?: resp.message}"
    }

    /** Dynamic discovery: only models this key can actually call with generateContent. */
    suspend fun listModels(): Result<List<ModelInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!keys.hasKey) throw GeminiException("No API key")
            val out = mutableListOf<ModelInfo>()
            var token: String? = null
            do {
                val path = "models?pageSize=100" + (token?.let { "&pageToken=$it" } ?: "")
                val o = http.newCall(req(path).get().build()).execute().use {
                    if (!it.isSuccessful) throw GeminiException(err(it))
                    JSONObject(it.body!!.string())
                }
                val a = o.optJSONArray("models") ?: JSONArray()
                for (i in 0 until a.length()) {
                    val m = a.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods")?.let { x -> (0 until x.length()).map { x.getString(it) } } ?: emptyList()
                    if ("generateContent" in methods)
                        out += ModelInfo(m.getString("name").removePrefix("models/"), m.optString("displayName"), methods)
                }
                token = o.optString("nextPageToken").ifBlank { null }
            } while (token != null)
            out.sortedBy { it.id }
        }
    }

    suspend fun testConnection(): Result<Int> = listModels().map { it.size }

    private fun body(system: String, history: List<Turn>, temp: Float, maxTokens: Int,
                     images: List<Pair<ByteArray, String>> = emptyList(), jsonOut: Boolean = false): RequestBody {
        val contents = JSONArray()
        history.forEachIndexed { idx, t ->
            val parts = JSONArray().put(JSONObject().put("text", t.text))
            if (idx == history.lastIndex && t.role == "user") images.forEach { (bytes, mime) ->
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime)
                    .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))))
            }
            contents.put(JSONObject().put("role", t.role).put("parts", parts))
        }
        val gen = JSONObject().put("temperature", temp.toDouble()).put("maxOutputTokens", maxTokens)
        if (jsonOut) gen.put("responseMimeType", "application/json")
        return JSONObject().put("contents", contents).put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .toString().toRequestBody(json)
    }

    private fun textOf(chunk: JSONObject): String {
        val parts = chunk.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        return buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }
    }

    /** Streaming. Cancelling the collector cancels the HTTP call, which is what makes voice barge-in instant. */
    fun stream(model: String, system: String, history: List<Turn>, temp: Float, maxTokens: Int): Flow<String> = callbackFlow {
        if (model.isBlank()) { close(GeminiException("No model selected")); return@callbackFlow }
        val call = http.newCall(req("models/$model:streamGenerateContent?alt=sse")
            .post(body(system, history, temp, maxTokens)).build())
        val job = launch(Dispatchers.IO) {
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) throw GeminiException(err(r))
                    val src = r.body!!.source()
                    while (isActive) {
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val t = textOf(JSONObject(line.removePrefix("data:").trim()))
                        if (t.isNotEmpty()) trySend(t)
                    }
                }
                close()
            } catch (e: Exception) {
                if (call.isCanceled()) close() else close(e)
            }
        }
        awaitClose { call.cancel(); job.cancel() }
    }

    /** Single-shot call, optionally with images (vision / OCR / screen understanding). */
    suspend fun generate(model: String, system: String, history: List<Turn>, temp: Float = 0.4f, maxTokens: Int = 2048,
                         images: List<Pair<ByteArray, String>> = emptyList(), jsonOut: Boolean = false): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (model.isBlank()) throw GeminiException("No model selected")
                val call = http.newCall(req("models/$model:generateContent").post(body(system, history, temp, maxTokens, images, jsonOut)).build())
                suspendCancellableCoroutine<String> { cont ->
                    cont.invokeOnCancellation { call.cancel() }
                    try {
                        call.execute().use { r ->
                            if (!r.isSuccessful) throw GeminiException(err(r))
                            cont.resumeWith(Result.success(textOf(JSONObject(r.body!!.string()))))
                        }
                    } catch (e: Exception) { if (cont.isActive) cont.resumeWith(Result.failure(e)) }
                }
            }
        }
}
