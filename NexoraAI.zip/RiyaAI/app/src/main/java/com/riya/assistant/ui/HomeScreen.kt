package com.riya.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.riya.assistant.assistant.OrbState

@Composable
fun HomeScreen(vm: MainViewModel, actions: Actions, go: (Screen) -> Unit) {
    val p by vm.prefs.collectAsState()
    val orb by vm.orb.collectAsState()
    val live by vm.live.collectAsState()
    val conn by vm.connection.collectAsState()
    val acc by vm.accessibilityOn.collectAsState()
    val screenOn by vm.screenActive.collectAsState()
    val err by vm.error.collectAsState()
    val usage by vm.usage.collectAsState()
    val ctx = LocalContext.current
    val t = { k: String -> S.t(p.uiLang, k) }
    LaunchedEffect(Unit) { vm.refreshMemory() }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { go(Screen.READER) }) { Icon(Icons.Default.RecordVoiceOver, t("read"), tint = RC.Muted) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { go(Screen.SETTINGS) }) { Icon(Icons.Default.Settings, t("settings"), tint = RC.White) }
        }
        Text(p.aiName, fontSize = 34.sp, fontWeight = FontWeight.Light, color = RC.White, letterSpacing = 6.sp)
        Spacer(Modifier.height(6.dp))
        val (connText, connColor) = when (conn) {
            "connected" -> t("connected") to RC.Ok; "no_key" -> t("no_key") to RC.Red
            "not_tested" -> t("not_tested") to RC.Muted; else -> "Error" to RC.Red
        }
        Row(Modifier.clip(CircleShape).background(RC.Panel).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(connColor)); Spacer(Modifier.width(8.dp))
            Text(connText, fontSize = 12.sp, color = RC.Muted)
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            AiOrb(orb, Modifier.fillMaxWidth().aspectRatio(1f))
        }

        Text(
            when {
                err == "mic" -> t("error_mic"); err == "key" -> t("error_key")
                orb == OrbState.LISTENING -> t("listening"); orb == OrbState.THINKING -> t("thinking")
                orb == OrbState.SPEAKING -> t("speaking"); orb == OrbState.ACTING -> t("acting"); else -> t("idle")
            }, color = RC.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (!mic && !live) actions.requestMic() else vm.toggleLive()
            },
            modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RC.Red), contentPadding = PaddingValues(0.dp),
        ) {
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(RC.DeepRed, RC.Red))), contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (live) Icons.Default.Stop else Icons.Default.Mic, null, tint = RC.White)
                    Spacer(Modifier.width(10.dp))
                    Text(if (live) t("stop") else t("live"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = RC.White)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip(Icons.Default.AutoAwesome, t("model"), p.modelId.ifBlank { t("none") }, Modifier.weight(1f)) { go(Screen.MODELS) }
            Chip(Icons.Default.Face, t("voice"), if (p.personality == "cute") t("cute") else t("normal"), Modifier.weight(1f)) {
                vm.update { it.copy(personality = if (it.personality == "cute") "normal" else "cute", pitch = if (it.personality == "cute") 1.0f else 1.2f) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip(Icons.Default.Memory, t("memory"), usage?.let { "${it.usedBytes / 1024} KB / 500 MB" } ?: "—", Modifier.weight(1f)) { go(Screen.MEMORY) }
            Chip(Icons.Default.SmartToy, t("automation"),
                (if (acc) t("on") else t("off")) + if (screenOn) " · " + t("screen") else "", Modifier.weight(1f)) { go(Screen.SETTINGS) }
        }
    }
}

@Composable
private fun Chip(icon: ImageVector, title: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), color = RC.Panel, border = BorderStroke(1.dp, RC.Border)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = RC.Red, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 11.sp, color = RC.Muted)
                Text(value, fontSize = 13.sp, color = RC.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
        }
    }
}
