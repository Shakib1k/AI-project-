package com.riya.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.riya.assistant.data.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

data class ReadState(val index: Int = 0, val total: Int = 0, val playing: Boolean = false)

/**
 * Speech recognition + female TTS + read-aloud engine.
 * Every speak call carries a generation id; stopSpeaking() bumps it, so late callbacks from cancelled audio are ignored
 * and two replies can never overlap.
 */
class VoiceEngine(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    val speaking = MutableStateFlow(false)
    val readState = MutableStateFlow(ReadState())
    val ttsAvailable = MutableStateFlow(true)

    var onFinal: (String) -> Unit = {}
    var onPartial: (String) -> Unit = {}
    var onRecError: (Int) -> Unit = {}
    var onIdle: () -> Unit = {}

    @Volatile private var gen = 0
    private val pending = AtomicInteger(0)
    private var seq = 0
    private var prefs = Prefs()

    private var readSegs: List<Seg> = emptyList()
    private var readIdx = 0

    fun applyPrefs(p: Prefs) { prefs = p }

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            ttsAvailable.value = ttsReady
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String) {
                    if (id.startsWith("r")) parseId(id)?.let { (g, i) -> if (g == gen) readIdx = i.also { readState.value = ReadState(i, readSegs.size, true) } }
                }
                override fun onDone(id: String) = finished(id)
                @Deprecated("Deprecated in Java") override fun onError(id: String) = finished(id)
            })
        }
    }

    private fun parseId(id: String): Pair<Int, Int>? {
        val parts = id.substring(1).split("_")
        return if (parts.size == 2) parts[0].toIntOrNull()?.let { g -> parts[1].toIntOrNull()?.let { g to it } } else null
    }

    private fun finished(id: String) {
        val g = parseId(id)?.first ?: return
        if (g != gen) return // audio from a cancelled generation
        if (pending.decrementAndGet() <= 0) {
            pending.set(0)
            main.post {
                speaking.value = false
                if (id.startsWith("r")) readState.value = readState.value.copy(playing = false)
                onIdle()
            }
        }
    }

    // ---------- voices ----------
    private fun score(v: Voice): Int {
        val n = v.name.lowercase()
        var s = v.quality / 100
        if ("female" in n) s += 30
        if (Regex("-[a-z]{3}f-|[-_]f[-_]|#female").containsMatchIn(n)) s += 20
        if (Regex("(?<!fe)male|-[a-z]{3}m-|[-_]m[-_]|#male").containsMatchIn(n)) s -= 40
        if (v.isNetworkConnectionRequired) s += 4 // neural voices are usually the network ones
        return s
    }

    fun voicesFor(lang: Lang): List<Voice> =
        tts?.voices.orEmpty().filter { it.locale.language == lang.code }.sortedByDescending { score(it) }

    fun languageSupported(lang: Lang): Boolean =
        ttsReady && tts?.isLanguageAvailable(Locale.forLanguageTag(lang.tag)).let { it != null && it >= TextToSpeech.LANG_AVAILABLE }

    fun installVoiceDataIntent() = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun applyVoice(lang: Lang) {
        val t = tts ?: return
        val list = voicesFor(lang)
        val chosen = list.firstOrNull { it.name == prefs.voiceName } ?: list.firstOrNull()
        if (chosen != null) t.voice = chosen else t.language = Locale.forLanguageTag(lang.tag)
        t.setPitchAndRate(lang)
    }

    private fun TextToSpeech.setPitchAndRate(@Suppress("UNUSED_PARAMETER") lang: Lang) {
        setPitch(prefs.pitch.coerceIn(0.5f, 2f)); setSpeechRate(prefs.rate.coerceIn(0.5f, 2f))
    }

    // ---------- speaking ----------
    /** Queue a reply sentence. Safe to call repeatedly while a reply streams in. */
    fun say(text: String) {
        val clean = TextCleaner.forSpeech(text)
        if (clean.isBlank() || !ttsReady) return
        LanguageDetector.segments(clean).forEach { enqueue("s", it) }
    }

    private fun enqueue(prefix: String, seg: Seg, index: Int = seq++) {
        val t = tts ?: return
        val spoken = TextCleaner.speakMath(seg.text, seg.lang)
        val max = TextToSpeech.getMaxSpeechInputLength() - 50
        spoken.chunked(max).forEach { part ->
            pending.incrementAndGet(); speaking.value = true
            applyVoice(seg.lang)
            t.speak(part, TextToSpeech.QUEUE_ADD, null, "$prefix${gen}_$index")
        }
    }

    fun stopSpeaking() {
        gen++; pending.set(0)
        tts?.stop()
        speaking.value = false
        readState.value = readState.value.copy(playing = false)
    }

    suspend fun awaitIdle() { speaking.first { !it } }

    // ---------- read aloud (pause / resume / replay) ----------
    fun readAloud(text: String) {
        stopSpeaking()
        readSegs = TextCleaner.sentences(TextCleaner.forSpeech(text)).flatMap { LanguageDetector.segments(it) }
        readIdx = 0
        playFrom(0)
    }
    private fun playFrom(i: Int) {
        if (readSegs.isEmpty() || !ttsReady) return
        stopSpeaking()
        readState.value = ReadState(i, readSegs.size, true)
        for (k in i until readSegs.size) enqueue("r", readSegs[k], k)
    }
    fun pauseRead() { val i = readIdx; stopSpeaking(); readIdx = i; readState.value = ReadState(i, readSegs.size, false) }
    fun resumeRead() = playFrom(readIdx)
    fun replayRead() = playFrom(0)
    fun stopRead() { stopSpeaking(); readIdx = 0; readState.value = ReadState(0, readSegs.size, false) }

    // ---------- recognition ----------
    fun recognitionAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun startRecognition(tag: String) {
        main.post {
            stopRecognitionNow()
            if (!recognitionAvailable()) { onRecError(SpeechRecognizer.ERROR_CLIENT); return@post }
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(res: Bundle) {
                    val t = res.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isBlank()) onRecError(SpeechRecognizer.ERROR_NO_MATCH) else onFinal(t)
                }
                override fun onPartialResults(p: Bundle) {
                    p.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.takeIf { it.isNotBlank() }?.let(onPartial)
                }
                override fun onError(error: Int) = onRecError(error)
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            })
        }
    }

    fun stopRecognition() = main.post { stopRecognitionNow() }

    private fun stopRecognitionNow() {
        recognizer?.runCatching { setRecognitionListener(null); cancel(); destroy() }
        recognizer = null
    }

    fun release() { stopRecognitionNow(); tts?.shutdown(); tts = null; ttsReady = false }
}
