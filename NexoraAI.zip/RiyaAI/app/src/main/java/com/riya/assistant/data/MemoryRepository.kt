package com.riya.assistant.data

import android.content.Context
import android.net.Uri
import com.riya.assistant.ai.Turn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class StorageUsage(val usedBytes: Long, val capBytes: Long, val deviceFreeBytes: Long) {
    /** The 500 MB figure is a ceiling, not a reservation. It shrinks if the device is nearly full. */
    val effectiveCap: Long get() = minOf(capBytes, usedBytes + deviceFreeBytes)
}

class MemoryRepository(private val ctx: Context, private val db: RiyaDb) {
    private val dao = db.dao()

    companion object { const val CAP_BYTES = 500L * 1024 * 1024 }

    suspend fun add(kind: String, text: String, pinned: Boolean = false) =
        dao.add(MemoryItem(kind = kind, text = text.trim(), createdAt = System.currentTimeMillis(), pinned = pinned))

    suspend fun update(m: MemoryItem) = dao.update(m)
    suspend fun delete(m: MemoryItem) = dao.delete(m)
    suspend fun all() = dao.allMemory()
    suspend fun search(q: String) = if (q.isBlank()) dao.allMemory() else dao.searchMemory(q.trim(), 100)
    suspend fun tasks() = dao.tasks()

    suspend fun logTask(summary: String, ok: Boolean) =
        dao.addTask(TaskLog(summary = summary.take(300), ok = ok, createdAt = System.currentTimeMillis()))

    suspend fun saveMessage(session: Long, role: String, text: String) {
        dao.addMessage(ChatMessage(sessionId = session, role = role, text = text, createdAt = System.currentTimeMillis()))
        enforceCap()
    }

    suspend fun recentTurns(session: Long, n: Int): List<Turn> =
        dao.recent(session, n).reversed().map { Turn(it.role, it.text) }

    /** Keyword recall over saved memory + older conversations. */
    suspend fun recall(query: String, k: Int = 6): List<String> = withContext(Dispatchers.IO) {
        val tokens = query.split(Regex("[\\s,.!?।]+")).filter { it.length >= 3 }.distinct().take(8)
        if (tokens.isEmpty()) return@withContext dao.allMemory().filter { it.pinned }.take(k).map { it.text }
        val score = HashMap<String, Int>()
        val pinned = dao.allMemory().filter { it.pinned }
        pinned.forEach { score[it.text] = 5 }
        tokens.forEach { t ->
            dao.searchMemory(t, 10).forEach { score[it.text] = (score[it.text] ?: 0) + 3 }
            dao.searchMessages(t, 5).filter { it.role == "user" }.forEach { score[it.text.take(200)] = (score[it.text.take(200)] ?: 0) + 1 }
        }
        score.entries.sortedByDescending { it.value }.take(k).map { it.key }
    }

    fun usage(): StorageUsage {
        val used = ctx.getDatabasePath("riya.db").parentFile?.listFiles()
            ?.filter { it.name.startsWith("riya.db") }?.sumOf { it.length() } ?: 0L
        return StorageUsage(used, CAP_BYTES, ctx.filesDir.usableSpace)
    }

    private suspend fun enforceCap() {
        val u = usage()
        if (u.usedBytes > u.effectiveCap * 9 / 10) dao.pruneOldest(500) // pinned memory is a separate table and is never pruned
    }

    suspend fun exportTo(uri: Uri) = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("memory", JSONArray().also { a -> dao.allMemory().forEach {
            a.put(JSONObject().put("kind", it.kind).put("text", it.text).put("createdAt", it.createdAt).put("pinned", it.pinned)) } })
        root.put("messages", JSONArray().also { a -> dao.allMessages().forEach {
            a.put(JSONObject().put("session", it.sessionId).put("role", it.role).put("text", it.text).put("createdAt", it.createdAt)) } })
        root.put("tasks", JSONArray().also { a -> dao.allTasks().forEach {
            a.put(JSONObject().put("summary", it.summary).put("ok", it.ok).put("createdAt", it.createdAt)) } })
        ctx.contentResolver.openOutputStream(uri, "w")!!.use { it.write(root.toString(2).toByteArray()) }
    }

    suspend fun importFrom(uri: Uri): Int = withContext(Dispatchers.IO) {
        val txt = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
        val root = JSONObject(txt)
        var n = 0
        root.optJSONArray("memory")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let {
            dao.add(MemoryItem(kind = it.optString("kind", "fact"), text = it.getString("text"),
                createdAt = it.optLong("createdAt", System.currentTimeMillis()), pinned = it.optBoolean("pinned")))
            n++ } }
        root.optJSONArray("messages")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let {
            dao.addMessage(ChatMessage(sessionId = it.optLong("session"), role = it.getString("role"),
                text = it.getString("text"), createdAt = it.optLong("createdAt"))) } }
        n
    }

    suspend fun clearAll() { dao.clearMemory(); dao.clearMessages() }
}
