package com.riya.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = RC.White) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = RC.White)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = RC.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = RC.Red, checkedThumbColor = RC.White))
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, show: String = "%.2f".format(value), onChange: (Float) -> Unit) {
    Column {
        Row { Text(label, color = RC.White, fontSize = 14.sp, modifier = Modifier.weight(1f)); Text(show, color = RC.Muted, fontSize = 13.sp) }
        Slider(value, onChange, valueRange = range, steps = steps, colors = SliderDefaults.colors(thumbColor = RC.Red, activeTrackColor = RC.Red))
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, singleLine: Boolean = true, password: Boolean = false) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = modifier.fillMaxWidth(), singleLine = singleLine,
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RC.Red, unfocusedBorderColor = RC.Border,
            focusedLabelColor = RC.Red, cursorColor = RC.Red, focusedTextColor = RC.White, unfocusedTextColor = RC.White))
}

@Composable
fun RedButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick, modifier, enabled, colors = ButtonDefaults.buttonColors(containerColor = RC.Red)) { Text(text) }

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) =
    OutlinedButton(onClick, modifier, border = androidx.compose.foundation.BorderStroke(1.dp, RC.Border)) { Text(text, color = RC.White) }

@Composable
fun H(text: String) = Text(text, color = RC.Red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
