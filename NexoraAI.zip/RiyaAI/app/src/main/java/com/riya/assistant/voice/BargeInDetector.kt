package com.riya.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.*
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Lightweight voice-activity detector that runs only while Riya is speaking.
 * Uses the VOICE_COMMUNICATION source so the platform echo canceller removes Riya's own voice where supported.
 * A headset gives the most reliable interruption on devices without good echo cancellation.
 */
class BargeInDetector(private val onVoice: () -> Unit) {
    private var job: Job? = null
    private val main = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @SuppressLint("MissingPermission")
    fun start() {
        if (job?.isActive == true) return
        job = CoroutineScope(Dispatchers.Default).launch {
            val rate = 16000
            val frame = rate / 50 // 20 ms
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(min, frame * 8))
            } catch (e: Exception) { return@launch }
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@launch }
            if (AcousticEchoCanceler.isAvailable()) runCatching { AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true }
            if (NoiseSuppressor.isAvailable()) runCatching { NoiseSuppressor.create(rec.audioSessionId)?.enabled = true }
            val buf = ShortArray(frame)
            var floor = 400.0
            var run = 0
            try {
                rec.startRecording()
                while (isActive) {
                    val n = rec.read(buf, 0, frame)
                    if (n <= 0) continue
                    var s = 0.0
                    for (i in 0 until n) s += buf[i] * buf[i].toDouble()
                    val rms = sqrt(s / n)
                    if (rms > max(floor * 3.5, 1400.0)) {
                        if (++run >= 8) { main.launch { onVoice() }; return@launch } // ~160 ms of sustained voice
                    } else { run = 0; floor = floor * 0.95 + rms * 0.05 }
                }
            } finally {
                runCatching { rec.stop() }; rec.release()
            }
        }
    }

    /** Suspends until the microphone is actually released so SpeechRecognizer can take it. */
    suspend fun stop() { job?.cancelAndJoin(); job = null }
}
