package com.riya.assistant

import android.app.Application
import com.riya.assistant.data.AppContainer

class RiyaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
