package com.riya.assistant.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.riya.assistant.voice.Lang

@Composable
fun SettingsScreen(vm: MainViewModel, actions: Actions, back: () -> Unit, go: (Screen) -> Unit) {
    val p by vm.prefs.collectAsState()
    val conn by vm.connection.collectAsState()
    val detail by vm.connectionDetail.collectAsState()
    val busy by vm.busy.collectAsState()
    val acc by vm.accessibilityOn.collectAsState()
    val screenOn by vm.screenActive.collectAsState()
    val ctx = LocalContext.current
    val t = { k: String -> S.t(p.uiLang, k) }
    var key by remember { mutableStateOf("") }
    var name by remember(p.aiName) { mutableStateOf(p.aiName) }
    var wake by remember(p.wakeWord) { mutableStateOf(p.wakeWord) }
    val voiceLang = Lang.of(if (p.speechLang == "auto") p.uiLang else p.speechLang)
    val voices = remember(voiceLang, p.voiceName) { vm.c.voice.voicesFor(voiceLang) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        TopBar(t("settings"), back)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            H(t("language").uppercase())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("bn" to "বাংলা", "hi" to "हिन्दी", "en" to "English").forEach { (c, l) ->
                    FilterChip(p.uiLang == c, { vm.update { it.copy(uiLang = c) } }, { Text(l) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RC.Red, selectedLabelColor = RC.White))
                }
            }

            H("GEMINI")
            Field(key, { key = it }, t("api_key") + if (vm.hasKey()) " (saved)" else "", password = true)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                RedButton(t("save"), enabled = key.isNotBlank()) { vm.saveKey(key); key = "" }
                GhostButton(t("test")) { vm.test() }
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = RC.Red, strokeWidth = 2.dp)
            }
            Text(when (conn) { "connected" -> "✓ ${t("connected")} · $detail"; "error" -> "✗ $detail"; "no_key" -> t("no_key"); else -> t("not_tested") },
                color = if (conn == "connected") RC.Ok else RC.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            GhostButton(t("models_title") + " → " + p.modelId.ifBlank { t("none") }, Modifier.fillMaxWidth().padding(top = 8.dp)) { go(Screen.MODELS) }
            SliderRow(t("temperature"), p.temperature, 0f..2f) { v -> vm.update { it.copy(temperature = v) } }
            SliderRow(t("max_tokens"), p.maxTokens.toFloat(), 128f..8192f, show = p.maxTokens.toString()) { v -> vm.update { it.copy(maxTokens = v.toInt()) } }

            H(t("ai_name").uppercase())
            Field(name, { name = it }, t("ai_name"))
            Field(wake, { wake = it }, t("wake") + "  (Hey Riya / Riya / মায়া)", Modifier.padding(top = 8.dp))
            RedButton(t("save"), Modifier.padding(top = 8.dp)) { vm.update { it.copy(aiName = name.trim().ifBlank { "Riya" }, wakeWord = wake.trim().ifBlank { name.trim() }) } }

            H(t("personality").uppercase())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("cute" to t("cute"), "normal" to t("normal")).forEach { (c, l) ->
                    FilterChip(p.personality == c, { vm.update { it.copy(personality = c, pitch = if (c == "cute") 1.2f else 1.0f) } }, { Text(l) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RC.Red, selectedLabelColor = RC.White))
                }
            }
            SliderRow(t("rate"), p.rate, 0.6f..1.6f) { v -> vm.update { it.copy(rate = v) } }
            SliderRow(t("pitch"), p.pitch, 0.7f..1.8f) { v -> vm.update { it.copy(pitch = v) } }
            Text(t("voice_pick") + " (${voiceLang.code})", color = RC.White, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            if (voices.none { it.name == p.voiceName } && p.voiceName.isNotBlank()) Text(t("no_female"), color = RC.Red, fontSize = 12.sp)
            if (voices.isEmpty()) GhostButton(t("install_voice")) { ctx.startActivity(vm.c.voice.installVoiceDataIntent()) }
            voices.take(8).forEach { v ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(v.name == p.voiceName, { vm.update { it.copy(voiceName = v.name) } }, colors = RadioButtonDefaults.colors(selectedColor = RC.Red))
                    Text(v.name + if (v.isNetworkConnectionRequired) " ☁" else "", color = RC.White, fontSize = 12.sp)
                }
            }
            GhostButton("Auto (best female match)", Modifier.padding(top = 4.dp)) { vm.update { it.copy(voiceName = "") } }
            Text("Speech recognition language", color = RC.White, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("auto" to "Auto", "bn" to "বাংলা", "hi" to "हिन्दी", "en" to "EN").forEach { (c, l) ->
                    FilterChip(p.speechLang == c, { vm.update { it.copy(speechLang = c) } }, { Text(l) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RC.Red, selectedLabelColor = RC.White))
                }
            }

            H(t("proactive").uppercase())
            SwitchRow(t("proactive"), p.proactiveOn) { v -> vm.update { it.copy(proactiveOn = v) } }
            SliderRow(t("silence"), p.silenceSec.toFloat(), 10f..120f, show = "${p.silenceSec}") { v -> vm.update { it.copy(silenceSec = v.toInt()) } }
            SliderRow(t("max_proactive"), p.maxProactive.toFloat(), 1f..5f, 3, "${p.maxProactive}") { v -> vm.update { it.copy(maxProactive = v.toInt()) } }
            SwitchRow(t("quiet"), p.quietMode) { v -> vm.update { it.copy(quietMode = v) } }
            SwitchRow(t("dnd") + " (${p.dndStart}:00–${p.dndEnd}:00)", p.dndOn) { v -> vm.update { it.copy(dndOn = v) } }
            SliderRow("DND start", p.dndStart.toFloat(), 0f..23f, 22, "${p.dndStart}:00") { v -> vm.update { it.copy(dndStart = v.toInt()) } }
            SliderRow("DND end", p.dndEnd.toFloat(), 0f..23f, 22, "${p.dndEnd}:00") { v -> vm.update { it.copy(dndEnd = v.toInt()) } }
            SliderRow(t("timeout"), p.timeoutSec.toFloat(), 60f..1800f, show = "${p.timeoutSec}") { v -> vm.update { it.copy(timeoutSec = v.toInt()) } }

            H(t("memory").uppercase())
            SwitchRow(t("memory_on"), p.memoryEnabled) { v -> vm.update { it.copy(memoryEnabled = v) } }
            SwitchRow(t("save_chats"), p.saveChats) { v -> vm.update { it.copy(saveChats = v) } }
            SwitchRow(t("confirm_open"), p.confirmOpenApp) { v -> vm.update { it.copy(confirmOpenApp = v) } }
            GhostButton(t("memory"), Modifier.fillMaxWidth()) { go(Screen.MEMORY) }

            H(t("permissions").uppercase())
            PermRow(t("accessibility"), acc) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            PermRow(t("overlay"), Settings.canDrawOverlays(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
            PermRow(t("screen"), screenOn, if (screenOn) t("stop") else t("start")) { if (screenOn) vm.stopScreen() else actions.requestScreen() }
            PermRow(t("mic"), false, t("start")) { actions.requestMic() }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun PermRow(label: String, on: Boolean, action: String = "Open", onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = RC.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Text(if (on) "●" else "○", color = if (on) RC.Ok else RC.Muted, modifier = Modifier.padding(end = 10.dp))
        GhostButton(action, onClick = onClick)
    }
}
