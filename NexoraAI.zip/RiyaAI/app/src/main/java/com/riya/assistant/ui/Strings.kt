package com.riya.assistant.ui

/** In-app translations (Bengali / Hindi / English) so the language switches instantly from Settings. */
object S {
    private val en = mapOf(
        "connected" to "Connected", "no_key" to "No API key", "not_tested" to "Key saved, not tested",
        "live" to "Live Voice Chat", "stop" to "Stop", "settings" to "Settings", "model" to "Model", "voice" to "Voice",
        "memory" to "Memory", "automation" to "Automation", "on" to "On", "off" to "Off", "cute" to "Cute Female",
        "normal" to "Normal Female", "listening" to "Listening…", "thinking" to "Thinking…", "speaking" to "Speaking…",
        "acting" to "Working on it…", "idle" to "Tap Live Voice Chat to talk", "ai_name" to "AI name", "wake" to "Wake word",
        "language" to "Language", "personality" to "Personality", "api_key" to "Gemini API key", "save" to "Save",
        "test" to "Test connection", "discover" to "Discover models", "custom_model" to "Custom model ID", "add" to "Add",
        "delete" to "Delete", "edit" to "Edit", "temperature" to "Temperature", "max_tokens" to "Max tokens",
        "proactive" to "Proactive voice", "silence" to "Silence before prompting (sec)", "max_proactive" to "Max proactive messages",
        "quiet" to "Quiet mode", "dnd" to "Do Not Disturb hours", "timeout" to "Conversation timeout (sec)",
        "rate" to "Speed", "pitch" to "Pitch", "voice_pick" to "Voice", "no_female" to "Selected voice unavailable. Female alternatives:",
        "install_voice" to "Install voice data", "permissions" to "Permissions", "mic" to "Microphone", "overlay" to "Floating orb overlay",
        "accessibility" to "Accessibility automation", "screen" to "Screen observation", "start" to "Start", "read" to "Read aloud & OCR",
        "back" to "Back", "export" to "Export", "import" to "Import", "clear" to "Clear all", "search" to "Search", "used" to "Used",
        "memory_on" to "Save memory", "save_chats" to "Save conversations", "confirm_open" to "Confirm before opening apps",
        "play" to "Play", "pause" to "Pause", "resume" to "Resume", "replay" to "Replay", "pick_file" to "Pick image / PDF",
        "paste_text" to "Paste or type text here", "models_title" to "Gemini models", "none" to "None selected", "new_memory" to "Add a memory",
        "notif" to "Notifications", "tools" to "Tools", "error_mic" to "Microphone permission needed", "error_key" to "Add your Gemini key and pick a model first",
    )
    private val bn = mapOf(
        "connected" to "সংযুক্ত", "no_key" to "API key নেই", "not_tested" to "Key আছে, টেস্ট হয়নি",
        "live" to "লাইভ ভয়েস চ্যাট", "stop" to "থামান", "settings" to "সেটিংস", "model" to "মডেল", "voice" to "ভয়েস",
        "memory" to "মেমরি", "automation" to "অটোমেশন", "on" to "চালু", "off" to "বন্ধ", "cute" to "কিউট ফিমেল",
        "normal" to "নরমাল ফিমেল", "listening" to "শুনছি…", "thinking" to "ভাবছি…", "speaking" to "বলছি…",
        "acting" to "কাজ করছি…", "idle" to "কথা বলতে লাইভ ভয়েস চ্যাট চাপুন", "ai_name" to "AI-এর নাম", "wake" to "ওয়েক ওয়ার্ড",
        "language" to "ভাষা", "personality" to "পার্সোনালিটি", "api_key" to "Gemini API key", "save" to "সেভ",
        "test" to "কানেকশন টেস্ট", "discover" to "মডেল খুঁজুন", "custom_model" to "কাস্টম মডেল ID", "add" to "যোগ করুন",
        "delete" to "মুছুন", "edit" to "এডিট", "temperature" to "টেম্পারেচার", "max_tokens" to "সর্বোচ্চ টোকেন",
        "proactive" to "নিজে থেকে কথা", "silence" to "চুপ থাকার সময় (সেকেন্ড)", "max_proactive" to "সর্বোচ্চ প্রোঅ্যাক্টিভ মেসেজ",
        "quiet" to "কোয়ায়েট মোড", "dnd" to "বিরক্ত করবেন না (ঘণ্টা)", "timeout" to "কথোপকথন টাইমআউট (সেকেন্ড)",
        "rate" to "গতি", "pitch" to "পিচ", "voice_pick" to "ভয়েস", "no_female" to "নির্বাচিত ভয়েস নেই। ফিমেল বিকল্প:",
        "install_voice" to "ভয়েস ডেটা ইনস্টল", "permissions" to "পারমিশন", "mic" to "মাইক্রোফোন", "overlay" to "ভাসমান অর্ব",
        "accessibility" to "অ্যাক্সেসিবিলিটি অটোমেশন", "screen" to "স্ক্রিন অবজারভেশন", "start" to "শুরু", "read" to "পড়ে শোনানো ও OCR",
        "back" to "পিছনে", "export" to "এক্সপোর্ট", "import" to "ইমপোর্ট", "clear" to "সব মুছুন", "search" to "খুঁজুন", "used" to "ব্যবহৃত",
        "memory_on" to "মেমরি সেভ", "save_chats" to "কথোপকথন সেভ", "confirm_open" to "অ্যাপ খোলার আগে জিজ্ঞেস করুন",
        "play" to "চালান", "pause" to "পজ", "resume" to "আবার চালান", "replay" to "রিপ্লে", "pick_file" to "ছবি / PDF বাছুন",
        "paste_text" to "এখানে লেখা পেস্ট করুন বা টাইপ করুন", "models_title" to "Gemini মডেল", "none" to "কিছু বাছা হয়নি", "new_memory" to "মেমরি যোগ করুন",
        "notif" to "নোটিফিকেশন", "tools" to "টুলস", "error_mic" to "মাইক্রোফোন পারমিশন লাগবে", "error_key" to "আগে Gemini key দিন ও মডেল বাছুন",
    )
    private val hi = mapOf(
        "connected" to "कनेक्टेड", "no_key" to "API key नहीं", "not_tested" to "Key सेव, टेस्ट नहीं हुई",
        "live" to "लाइव वॉइस चैट", "stop" to "रोकें", "settings" to "सेटिंग्स", "model" to "मॉडल", "voice" to "आवाज़",
        "memory" to "मेमोरी", "automation" to "ऑटोमेशन", "on" to "चालू", "off" to "बंद", "cute" to "क्यूट फ़ीमेल",
        "normal" to "नॉर्मल फ़ीमेल", "listening" to "सुन रही हूँ…", "thinking" to "सोच रही हूँ…", "speaking" to "बोल रही हूँ…",
        "acting" to "काम कर रही हूँ…", "idle" to "बात करने के लिए लाइव वॉइस चैट दबाएँ", "ai_name" to "AI का नाम", "wake" to "वेक वर्ड",
        "language" to "भाषा", "personality" to "पर्सनैलिटी", "api_key" to "Gemini API key", "save" to "सेव",
        "test" to "कनेक्शन टेस्ट", "discover" to "मॉडल खोजें", "custom_model" to "कस्टम मॉडल ID", "add" to "जोड़ें",
        "delete" to "हटाएँ", "edit" to "एडिट", "temperature" to "टेम्परेचर", "max_tokens" to "अधिकतम टोकन",
        "proactive" to "अपने-आप बात", "silence" to "चुप रहने का समय (सेकंड)", "max_proactive" to "अधिकतम प्रोएक्टिव मैसेज",
        "quiet" to "क्वाइट मोड", "dnd" to "परेशान न करें (घंटे)", "timeout" to "बातचीत टाइमआउट (सेकंड)",
        "rate" to "गति", "pitch" to "पिच", "voice_pick" to "आवाज़", "no_female" to "चुनी हुई आवाज़ उपलब्ध नहीं। फ़ीमेल विकल्प:",
        "install_voice" to "वॉइस डेटा इंस्टॉल करें", "permissions" to "परमिशन", "mic" to "माइक्रोफ़ोन", "overlay" to "फ़्लोटिंग ऑर्ब",
        "accessibility" to "एक्सेसिबिलिटी ऑटोमेशन", "screen" to "स्क्रीन ऑब्ज़र्वेशन", "start" to "शुरू", "read" to "पढ़कर सुनाओ और OCR",
        "back" to "वापस", "export" to "एक्सपोर्ट", "import" to "इम्पोर्ट", "clear" to "सब हटाएँ", "search" to "खोजें", "used" to "उपयोग",
        "memory_on" to "मेमोरी सेव", "save_chats" to "बातचीत सेव", "confirm_open" to "ऐप खोलने से पहले पूछें",
        "play" to "चलाएँ", "pause" to "पॉज़", "resume" to "फिर चलाएँ", "replay" to "रीप्ले", "pick_file" to "तस्वीर / PDF चुनें",
        "paste_text" to "यहाँ टेक्स्ट पेस्ट या टाइप करें", "models_title" to "Gemini मॉडल", "none" to "कुछ चुना नहीं", "new_memory" to "मेमोरी जोड़ें",
        "notif" to "नोटिफ़िकेशन", "tools" to "टूल्स", "error_mic" to "माइक्रोफ़ोन परमिशन चाहिए", "error_key" to "पहले Gemini key डालें और मॉडल चुनें",
    )

    fun t(lang: String, key: String): String = when (lang) { "bn" -> bn; "hi" -> hi; else -> en }[key] ?: en[key] ?: key
}
