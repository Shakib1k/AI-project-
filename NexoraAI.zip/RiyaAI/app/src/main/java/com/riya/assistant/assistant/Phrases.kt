package com.riya.assistant.assistant

import com.riya.assistant.voice.Lang
import kotlin.random.Random

/** Canned phrases in Bengali / Hindi / English. Emojis are shown in text but stripped before speech. */
object Phrases {
    private fun <T> List<T>.pick() = this[Random.nextInt(size)]
    private val yes = setOf("yes", "yeah", "yep", "yup", "sure", "ok", "okay", "go", "do", "send", "open", "please", "haan", "ha", "han",
        "hya", "hyan", "thik", "theek", "korun", "koro", "pathao", "kholo", "হ্যাঁ", "হ্যা", "জি", "ঠিক", "পাঠাও", "খোলো", "করো", "কর", "হাঁ",
        "हां", "हाँ", "जी", "ठीक", "भेजो", "खोलो", "करो", "कर")
    private val no = setOf("no", "nope", "nah", "cancel", "stop", "don't", "dont", "na", "nay", "thak", "না", "থাক", "বাদ", "থামো", "নয়",
        "नहीं", "नही", "मत", "रुको", "रहने")

    enum class Answer { YES, NO, OTHER }

    fun classify(text: String): Answer {
        val tokens = text.lowercase().split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
        if (tokens.any { it in no }) return Answer.NO
        if (tokens.any { it in yes } && tokens.size <= 6) return Answer.YES
        return Answer.OTHER
    }

    fun listening(l: Lang, cute: Boolean = true) = when (l) {
        Lang.BN -> listOf("জি বস, আমি শুনছি।", "বলুন বস, আমি এখানেই আছি। 😊")
        Lang.HI -> listOf("जी बॉस, मैं सुन रही हूँ।", "बोलिए बॉस, मैं यहीं हूँ। 😊")
        Lang.EN -> listOf("Yes Boss, I'm listening.", "Boss, I'm right here. Tell me what you need. ❤️")
    }.pick()

    fun proactive(l: Lang, cute: Boolean) = when (l) {
        Lang.BN -> if (cute) listOf("বস, কী হলো? কথা বলছেন না কেন? 😊", "বস, আমি এখানে আছি। কিছু বলবেন?") else listOf("বস, আপনি কি আছেন? আমি শুনছি।")
        Lang.HI -> if (cute) listOf("बॉस, क्या हुआ? आप बात क्यों नहीं कर रहे? 😊", "बॉस, मैं यहीं हूँ। कुछ कहेंगे?") else listOf("बॉस, क्या आप वहाँ हैं? मैं सुन रही हूँ।")
        Lang.EN -> if (cute) listOf("Boss, are you still there? I'm listening. 😊", "Boss, I'm here. Want to tell me something?") else listOf("Boss, are you still there? I'm listening.")
    }.pick()

    fun confirm(l: Lang, what: String) = when (l) {
        Lang.BN -> "বস, $what করে দেব?"
        Lang.HI -> "बॉस, $what कर दूँ?"
        Lang.EN -> "Boss, shall I $what?"
    }

    fun done(l: Lang) = when (l) { Lang.BN -> "হয়ে গেছে বস। ✅"; Lang.HI -> "हो गया बॉस। ✅"; Lang.EN -> "Done, Boss. ✅" }
    fun cancelled(l: Lang) = when (l) { Lang.BN -> "ঠিক আছে বস, করছি না।"; Lang.HI -> "ठीक है बॉस, नहीं कर रही।"; Lang.EN -> "Okay Boss, I won't do it." }
    fun failed(l: Lang, why: String) = when (l) {
        Lang.BN -> "দুঃখিত বস, হয়নি। $why"; Lang.HI -> "माफ़ कीजिए बॉस, नहीं हो पाया। $why"; Lang.EN -> "Sorry Boss, that didn't work. $why"
    }
    fun noKey(l: Lang) = when (l) {
        Lang.BN -> "বস, আগে Settings-এ Gemini API key দিন।"; Lang.HI -> "बॉस, पहले Settings में Gemini API key डालिए।"
        Lang.EN -> "Boss, please add your Gemini API key in Settings first."
    }
    fun needAccessibility(l: Lang) = when (l) {
        Lang.BN -> "বস, ফোন কন্ট্রোলের জন্য Settings থেকে Accessibility চালু করুন।"
        Lang.HI -> "बॉस, फ़ोन कंट्रोल के लिए Settings से Accessibility चालू कीजिए।"
        Lang.EN -> "Boss, please turn on Accessibility in Settings so I can control the phone."
    }
    fun which(l: Lang, options: List<String>) = when (l) {
        Lang.BN -> "বস, কয়েকটা পেলাম: ${options.joinToString(", ")}। কোনটা?"
        Lang.HI -> "बॉस, कई मिले: ${options.joinToString(", ")}। कौन सा?"
        Lang.EN -> "Boss, I found a few: ${options.joinToString(", ")}. Which one?"
    }
}
