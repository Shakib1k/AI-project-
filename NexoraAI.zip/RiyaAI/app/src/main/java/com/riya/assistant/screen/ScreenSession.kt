package com.riya.assistant.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream

/** Holds the user-authorised MediaProjection. Frames are captured on demand, never stored or uploaded unless you ask a screen question. */
object ScreenSession {
    val active = MutableStateFlow(false)
    val changed = MutableStateFlow(0) // increments when the screen content changes noticeably

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var watcher: Job? = null
    private var lastHash: LongArray? = null

    fun start(ctx: Context, p: MediaProjection) {
        stop()
        projection = p
        val m = ctx.resources.displayMetrics
        val w = m.widthPixels / 2; val h = m.heightPixels / 2
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, null) // required on Android 14+
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = p.createVirtualDisplay("riya-screen", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        active.value = true
        watcher = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                delay(1500)
                val b = frame() ?: continue
                val hash = signature(b); b.recycle()
                val prev = lastHash
                if (prev != null && distance(prev, hash) > 12) changed.value++
                lastHash = hash
            }
        }
    }

    fun frame(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        img.use {
            val pl = it.planes[0]
            val rowPad = pl.rowStride - pl.pixelStride * it.width
            val bmp = Bitmap.createBitmap(it.width + rowPad / pl.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(pl.buffer)
            return Bitmap.createBitmap(bmp, 0, 0, it.width, it.height)
        }
    }

    fun jpegFrame(): ByteArray? = frame()?.let { b ->
        ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
    }

    private fun signature(b: Bitmap): LongArray {
        val s = Bitmap.createScaledBitmap(b, 8, 8, true)
        return LongArray(64) { i -> val c = s.getPixel(i % 8, i / 8); (((c shr 16) and 0xFF) + ((c shr 8) and 0xFF) + (c and 0xFF)).toLong() / 3 }
    }
    private fun distance(a: LongArray, b: LongArray) = a.indices.count { kotlin.math.abs(a[it] - b[it]) > 24 }

    fun stop() {
        watcher?.cancel(); watcher = null
        display?.release(); display = null
        reader?.close(); reader = null
        runCatching { projection?.stop() }; projection = null
        lastHash = null
        active.value = false
    }
}
