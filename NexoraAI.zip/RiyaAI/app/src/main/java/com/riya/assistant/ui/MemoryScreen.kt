package com.riya.assistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.riya.assistant.data.MemoryItem

@Composable
fun MemoryScreen(vm: MainViewModel, back: () -> Unit) {
    val p by vm.prefs.collectAsState()
    val items by vm.memory.collectAsState()
    val usage by vm.usage.collectAsState()
    val t = { k: String -> S.t(p.uiLang, k) }
    var q by remember { mutableStateOf("") }
    var newText by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<MemoryItem?>(null) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::exportMemory) }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importMemory) }
    LaunchedEffect(Unit) { vm.refreshMemory("") }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        TopBar(t("memory"), back)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp)) {
            item {
                usage?.let { u ->
                    Glass(Modifier.fillMaxWidth()) {
                        Text("${t("used")}: ${fmt(u.usedBytes)} / ${fmt(u.effectiveCap)}", color = RC.White)
                        LinearProgressIndicator(progress = { (u.usedBytes.toFloat() / u.effectiveCap.coerceAtLeast(1)).coerceIn(0f, 1f) },
                            Modifier.fillMaxWidth().padding(top = 8.dp), color = RC.Red, trackColor = RC.Border)
                        Text("500 MB is a ceiling, not a reservation. Device free space: ${fmt(u.deviceFreeBytes)}.", color = RC.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton(t("export")) { export.launch("riya-memory.json") }
                    GhostButton(t("import")) { import.launch(arrayOf("application/json", "text/plain")) }
                    GhostButton(t("clear")) { vm.clearMemory() }
                }
                Field(q, { q = it; vm.refreshMemory(it) }, t("search"))
                Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { Field(newText, { newText = it }, t("new_memory")) }
                    Spacer(Modifier.width(8.dp))
                    RedButton(t("add"), enabled = newText.isNotBlank()) { vm.addMemory(newText); newText = "" }
                }
            }
            items(items, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        if (editing?.id == m.id) {
                            var txt by remember { mutableStateOf(m.text) }
                            Field(txt, { txt = it }, t("edit"), singleLine = false)
                            Row { RedButton(t("save")) { vm.editMemory(m, txt); editing = null } }
                        } else Text(m.text, color = RC.White, fontSize = 14.sp)
                    }
                    IconButton({ vm.pinMemory(m) }) { Icon(Icons.Default.PushPin, null, tint = if (m.pinned) RC.Red else RC.Muted) }
                    IconButton({ editing = m }) { Icon(Icons.Default.Edit, t("edit"), tint = RC.Muted) }
                    IconButton({ vm.deleteMemory(m) }) { Icon(Icons.Default.Delete, t("delete"), tint = RC.Muted) }
                }
                HorizontalDivider(color = RC.Border)
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

private fun fmt(b: Long) = when {
    b >= 1 shl 20 -> "%.1f MB".format(b / 1048576.0)
    b >= 1 shl 10 -> "%.1f KB".format(b / 1024.0)
    else -> "$b B"
}
