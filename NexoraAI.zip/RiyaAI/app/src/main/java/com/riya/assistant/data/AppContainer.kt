package com.riya.assistant.data

import android.content.Context
import androidx.room.Room
import com.riya.assistant.ai.GeminiClient
import com.riya.assistant.assistant.AssistantController
import com.riya.assistant.automation.AutomationController
import com.riya.assistant.ocr.OcrEngine
import com.riya.assistant.voice.VoiceEngine

/** Manual dependency injection: one container, constructed once in [com.riya.assistant.RiyaApp]. */
class AppContainer(val ctx: Context) {
    val settings = SettingsStore(ctx)
    val keys = SecureKeyStore(ctx)
    private val db = Room.databaseBuilder(ctx, RiyaDb::class.java, "riya.db").fallbackToDestructiveMigration().build()
    val memory = MemoryRepository(ctx, db)
    val gemini = GeminiClient(keys)
    val voice = VoiceEngine(ctx)
    val ocr = OcrEngine(ctx, gemini)
    val automation = AutomationController(ctx)
    val assistant by lazy { AssistantController(ctx, this) }
}
