package com.riya.assistant.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.riya.assistant.ai.*
import com.riya.assistant.automation.ActionResult
import com.riya.assistant.automation.RiyaAccessibilityService
import com.riya.assistant.automation.UiAgent
import com.riya.assistant.data.AppContainer
import com.riya.assistant.data.Prefs
import com.riya.assistant.screen.ScreenSession
import com.riya.assistant.voice.BargeInDetector
import com.riya.assistant.voice.Lang
import com.riya.assistant.voice.LanguageDetector
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.util.Calendar

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING, ACTING, ERROR }

/**
 * The live voice session state machine.
 * One turn job at a time; a new utterance cancels the previous generation (HTTP call + audio) so replies never overlap.
 */
class AssistantController(private val ctx: Context, private val c: AppContainer) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val orb = MutableStateFlow(OrbState.IDLE)
    val active = MutableStateFlow(false)
    val heard = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)

    private var prefs = Prefs()
    private var turnJob: Job? = null
    private var busy = false
    private var askWait: CompletableDeferred<String>? = null
    private var reroute: String? = null
    private var session = 0L
    private var lastActivity = 0L
    private var proactiveCount = 0
    private var watcher: Job? = null
    private var userLang = Lang.BN
    private val bargeIn = BargeInDetector { onBargeIn() }
    private val agent = UiAgent(c.gemini, c.automation)

    init {
        c.voice.init()
        scope.launch { c.settings.prefs.collect { prefs = it; c.voice.applyPrefs(it) } }
        c.voice.onFinal = { onUser(it) }
        c.voice.onPartial = { touch(); if (orb.value == OrbState.LISTENING) heard.value = it }
        c.voice.onRecError = { onRecError(it) }
        c.voice.onIdle = { onSpeechIdle() }
    }

    private fun touch() { lastActivity = System.currentTimeMillis() }
    private fun uiLang() = Lang.of(prefs.uiLang)
    private fun speechTag() = when (prefs.speechLang) { "auto" -> uiLang().tag; else -> Lang.of(prefs.speechLang).tag }
    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- session ----------
    fun startLive() {
        if (active.value) return
        if (!hasMic()) { error.value = "mic"; return }
        if (!c.keys.hasKey || prefs.modelId.isBlank()) { error.value = "key"; c.voice.say(Phrases.noKey(uiLang())); return }
        error.value = null
        active.value = true; session = System.currentTimeMillis(); proactiveCount = 0; touch()
        ContextCompat.startForegroundService(ctx, Intent(ctx, RiyaForegroundService::class.java))
        userLang = uiLang()
        busy = true
        c.voice.say(Phrases.listening(userLang))
        orb.value = OrbState.SPEAKING
        busy = false
        watcher = scope.launch { while (isActive) { delay(1000); tick() } }
    }

    fun stopLive() {
        active.value = false
        watcher?.cancel(); turnJob?.cancel(); askWait?.cancel(); askWait = null; busy = false
        scope.launch { bargeIn.stop() }
        c.voice.stopSpeaking(); c.voice.stopRecognition()
        orb.value = OrbState.IDLE
        ctx.stopService(Intent(ctx, RiyaForegroundService::class.java))
    }

    private fun inDnd(): Boolean {
        if (!prefs.dndOn) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (prefs.dndStart <= prefs.dndEnd) h in prefs.dndStart until prefs.dndEnd else h >= prefs.dndStart || h < prefs.dndEnd
    }

    private fun tick() {
        val idleMs = System.currentTimeMillis() - lastActivity
        if (idleMs > prefs.timeoutSec * 1000L) { stopLive(); return }
        if (prefs.proactiveOn && !prefs.quietMode && !inDnd() && proactiveCount < prefs.maxProactive &&
            orb.value == OrbState.LISTENING && !busy && idleMs > prefs.silenceSec * 1000L) {
            proactiveCount++; touch()
            scope.launch {
                busy = true
                c.voice.stopRecognition()
                speak(Phrases.proactive(userLang, prefs.personality == "cute"))
                busy = false
            }
        }
    }

    // ---------- listening ----------
    private fun startListening() {
        if (!active.value) return
        orb.value = OrbState.LISTENING
        c.voice.startRecognition(speechTag())
    }

    private fun onRecError(code: Int) {
        if (!active.value || busy && askWait == null) return
        when (code) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { error.value = "mic"; stopLive() }
            SpeechRecognizer.ERROR_CLIENT -> { error.value = "recognizer"; stopLive() }
            else -> scope.launch { delay(if (code == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 800 else 200); if (active.value && (!busy || askWait != null) && !c.voice.speaking.value) startListening() }
        }
    }

    private fun onSpeechIdle() {
        scope.launch {
            bargeIn.stop()
            if (!active.value || busy) return@launch
            startListening()
        }
    }

    private fun onBargeIn() {
        if (!active.value || !c.voice.speaking.value) return
        c.voice.stopSpeaking()
        if (askWait == null) { turnJob?.cancel(); busy = false } // waiting for a yes/no must survive the interruption
        scope.launch { bargeIn.stop(); startListening() }
    }

    // ---------- turns ----------
    private fun onUser(raw: String) {
        touch(); proactiveCount = 0
        val text = raw.trim()
        if (text.isEmpty()) { startListening(); return }
        heard.value = text
        askWait?.let { it.complete(text); return }
        turnJob?.cancel()
        c.voice.stopSpeaking()
        turnJob = scope.launch {
            busy = true
            try { handleTurn(text); busy = false; finishTurn() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { speak(Phrases.failed(userLang, e.message.orEmpty().take(120))); busy = false; finishTurn() }
        }
        scope.launch { turnJob?.join(); reroute?.let { r -> reroute = null; onUser(r) } }
    }

    private fun finishTurn() {
        if (!active.value) return
        if (c.voice.speaking.value) return // onSpeechIdle will resume listening
        startListening()
    }

    private fun stripWake(t: String): String {
        var s = t.trim()
        for (n in listOf(prefs.wakeWord, prefs.aiName).filter { it.isNotBlank() }.distinct()) {
            val re = Regex("^(hey|hi|ok|okay|ও|এই|हे|अरे)?\\s*${Regex.escape(n)}[\\s,।.!:-]*", RegexOption.IGNORE_CASE)
            s = s.replace(re, "")
        }
        return s.trim()
    }

    private suspend fun speak(text: String) {
        orb.value = OrbState.SPEAKING
        c.voice.say(text)
        bargeIn.start()
    }

    private suspend fun handleTurn(raw: String) {
        val text = stripWake(raw)
        c.voice.stopRecognition()
        userLang = LanguageDetector.dominant(raw) ?: uiLang()
        if (text.isBlank()) { speak(Phrases.listening(userLang)); return }
        orb.value = OrbState.THINKING
        if (prefs.saveChats) c.memory.saveMessage(session, "user", text)
        val memory = if (prefs.memoryEnabled) c.memory.recall(text) else emptyList()
        val system = PromptBuilder.build(prefs, memory, RiyaAccessibilityService.enabled, ScreenSession.active.value, text)
        val history = c.memory.recentTurns(session, 12).let { if (it.lastOrNull()?.text == text) it else it + Turn("user", text) }
        val parser = StreamParser()
        var action: JSONObject? = null
        val reply = StringBuilder()

        suspend fun handle(ev: StreamEvent) {
            when (ev) {
                is StreamEvent.Action -> action = ev.json
                is StreamEvent.Remember -> if (prefs.memoryEnabled) c.memory.add("fact", ev.text)
                is StreamEvent.Say -> { reply.append(ev.sentence).append(' '); speak(ev.sentence) }
            }
        }
        try {
            c.gemini.stream(prefs.modelId, system, history, prefs.temperature, prefs.maxTokens).collect { chunk ->
                parser.feed(chunk).forEach { handle(it) }
            }
            parser.finish().forEach { handle(it) }
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) { speak(Phrases.failed(userLang, e.message.orEmpty().take(100))); return }

        if (prefs.saveChats && reply.isNotBlank()) c.memory.saveMessage(session, "model", reply.toString().trim())
        action?.let { runAction(it) }
    }

    // ---------- asking the user by voice ----------
    private suspend fun askUser(timeoutMs: Long = 30_000): String? {
        c.voice.awaitIdle()
        bargeIn.stop()
        val d = CompletableDeferred<String>()
        askWait = d
        startListening()
        val ans = withTimeoutOrNull(timeoutMs) { d.await() }
        askWait = null
        c.voice.stopRecognition()
        return ans
    }

    /** Natural spoken yes/no. Anything else is treated as a brand-new command and re-routed. */
    private suspend fun confirmByVoice(): Boolean {
        val ans = askUser() ?: return false
        return when (Phrases.classify(ans)) {
            Phrases.Answer.YES -> true
            Phrases.Answer.NO -> { speak(Phrases.cancelled(userLang)); false }
            Phrases.Answer.OTHER -> { reroute = ans; false }
        }
    }

    private fun describe(a: JSONObject): String = when (a.optString("type")) {
        "open_app" -> "open ${a.optString("app")}"
        "send_message" -> "send \"${a.optString("text").take(60)}\" on ${a.optString("app")}"
        "open_chat" -> "open ${a.optString("query")} on ${a.optString("app")}"
        else -> a.optString("type").replace('_', ' ')
    }

    private fun needsConfirm(a: JSONObject): Boolean {
        if (a.optBoolean("approved")) return false
        if (a.optBoolean("ask")) return true
        return when (a.optString("type")) {
            "send_message" -> true
            "open_app" -> prefs.confirmOpenApp
            else -> false
        }
    }

    // ---------- actions ----------
    private suspend fun runAction(a: JSONObject) {
        val type = a.optString("type")
        val phoneTypes = setOf("open_app", "open_chat", "send_message", "tap", "type", "scroll", "back", "home", "write_code", "ui_task")
        if (type in phoneTypes && !c.automation.ready && type != "open_app") { speak(Phrases.needAccessibility(userLang)); return }
        if (needsConfirm(a)) {
            if (!a.optBoolean("ask")) speak(Phrases.confirm(userLang, describe(a)))
            if (!confirmByVoice()) return
        }
        orb.value = OrbState.ACTING
        val res = execute(a)
        c.memory.logTask(describe(a) + if (res.message.isNotBlank()) " -> ${res.message}" else "", res.ok)
        val silentOk = type in setOf("read_screen", "describe_screen", "read_text")
        if (res.ok && silentOk) return
        speak(if (res.ok) Phrases.done(userLang) else Phrases.failed(userLang, res.message))
    }

    private suspend fun execute(a: JSONObject): ActionResult {
        val auto = c.automation
        return when (val type = a.optString("type")) {
            "open_app" -> auto.openApp(a.optString("app"))
            "open_chat" -> openChat(a.optString("app"), a.optString("query"))
            "send_message" -> {
                if (a.optString("to").isNotBlank()) { val r = openChat(a.optString("app"), a.optString("to")); if (!r.ok) return r }
                auto.sendMessage(a.optString("text"))
            }
            "tap" -> auto.tapText(a.optString("text"))
            "type" -> auto.typeFocused(a.optString("text"), a.optBoolean("replace"))
            "scroll" -> auto.scroll(a.optString("dir", "down"))
            "back" -> auto.back()
            "home" -> auto.home()
            "read_screen" -> {
                val t = auto.screenText()
                if (t.isBlank()) ActionResult(false, "Nothing readable on screen") else { speak2(t); ActionResult(true) }
            }
            "describe_screen" -> describeScreen()
            "read_text" -> { speak2(a.optString("text")); ActionResult(true) }
            "write_code" -> writeCode(a.optString("language"), a.optString("spec"))
            "ui_task" -> agent.run(prefs.modelId, a.optString("goal"), a.optString("app"),
                confirm = { q -> speak(q); confirmByVoice() })
            else -> ActionResult(false, "Unsupported action: $type")
        }
    }

    private suspend fun speak2(text: String) { orb.value = OrbState.SPEAKING; c.voice.readAloud(text); bargeIn.start() }

    private suspend fun openChat(app: String, query: String): ActionResult {
        val r = c.automation.openChat(app, query)
        if (r.message != "ambiguous") return r
        speak(Phrases.which(userLang, r.options))
        val ans = askUser() ?: return ActionResult(false, "No answer")
        val pick = r.options.firstOrNull { ans.contains(it, true) || it.contains(ans.trim(), true) }
            ?: r.options.getOrNull(Regex("\\d").find(ans)?.value?.toInt()?.minus(1) ?: -1)
            ?: return ActionResult(false, "Could not tell which one you meant")
        return c.automation.openCandidateByLabel(pick)
    }

    private suspend fun describeScreen(): ActionResult {
        val lang = when (userLang) { Lang.BN -> "Bengali"; Lang.HI -> "Hindi"; Lang.EN -> "English" }
        val jpeg = if (ScreenSession.active.value) ScreenSession.jpegFrame() else null
        val prompt = "Briefly explain what is visible on this phone screen, in $lang, in 2-4 short spoken sentences. Name the app if you can tell."
        val r = if (jpeg != null)
            c.gemini.generate(prefs.modelId, prompt, listOf(Turn("user", "Describe the screen.")), 0.3f, 600, listOf(jpeg to "image/jpeg"))
        else {
            val t = c.automation.screenText()
            if (t.isBlank()) return ActionResult(false, "Start screen observation or enable Accessibility first")
            c.gemini.generate(prefs.modelId, prompt, listOf(Turn("user", "Visible text on screen:\n$t")), 0.3f, 600)
        }
        return r.fold({ speak(it); ActionResult(true) }, { ActionResult(false, it.message.orEmpty().take(100)) })
    }

    private suspend fun writeCode(language: String, spec: String): ActionResult {
        val raw = c.gemini.generate(prefs.modelId,
            "You write complete, valid, correctly indented $language code. Output ONLY the raw code: no markdown fences, no explanations, no placeholders or TODOs.",
            listOf(Turn("user", spec)), 0.2f, 8192).getOrElse { return ActionResult(false, it.message.orEmpty().take(100)) }.trim()
        val code = (if (raw.startsWith("```")) raw.substringAfter('\n') else raw).removeSuffix("```").trim()
        if (code.isBlank()) return ActionResult(false, "Empty code from model")
        return c.automation.typeCodeIntoEditor(code)
    }
}
