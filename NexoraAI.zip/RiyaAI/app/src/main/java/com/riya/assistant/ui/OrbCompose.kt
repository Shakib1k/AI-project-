package com.riya.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import com.riya.assistant.assistant.OrbState
import kotlin.math.PI
import kotlin.math.sin

/** Glowing 3D-style AI orb: red/white glow, rotating rings, state-dependent pulse speed. */
@Composable
fun AiOrb(state: OrbState, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "orb")
    val spin by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin")
    val ms = when (state) { OrbState.THINKING -> 500; OrbState.ACTING -> 700; OrbState.SPEAKING -> 650; OrbState.LISTENING -> 1100; else -> 2200 }
    val pulse by tr.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val ringSpeed = when (state) { OrbState.THINKING -> 4f; OrbState.ACTING -> 3f; OrbState.SPEAKING -> 2f; else -> 1f }
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension * 0.28f * pulse
        drawCircle(Brush.radialGradient(listOf(RC.Red.copy(alpha = 0.55f), Color.Transparent), c, r * 2.3f), r * 2.3f, c)
        drawCircle(Brush.radialGradient(listOf(Color.White, RC.Red, Color(0xFF2A0006)), Offset(c.x - r * .3f, c.y - r * .35f), r * 1.25f), r, c)
        drawCircle(Color.White.copy(alpha = 0.18f), r * 0.35f, Offset(c.x - r * .35f, c.y - r * .4f)) // specular highlight
        fun ring(scale: Float, start: Float, sweep: Float, color: Color, w: Float) = drawArc(
            color, start, sweep, false, Offset(c.x - r * scale, c.y - r * scale), Size(r * scale * 2, r * scale * 2),
            style = Stroke(w, cap = StrokeCap.Round))
        ring(1.35f, spin * ringSpeed, 120f, Color.White, 3f)
        ring(1.55f, -spin * ringSpeed, 90f, RC.Red, 4f)
        ring(1.75f, spin * 2 * ringSpeed, 40f, Color.White.copy(alpha = .6f), 2f)
        if (state == OrbState.LISTENING || state == OrbState.SPEAKING) {
            for (i in 0 until 3) {
                val a = ((spin * 2 + i * 120) % 360) / 360f
                drawCircle(RC.Red.copy(alpha = (1 - a) * .5f), r * (1.2f + a * 1.1f), c, style = Stroke(2f))
            }
        }
        if (state == OrbState.ERROR) drawCircle(Color.White.copy(alpha = (0.5f + 0.5f * sin(spin * PI / 90).toFloat()) * .4f), r * 1.1f, c, style = Stroke(5f))
    }
}
