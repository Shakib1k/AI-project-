package com.riya.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.ds by preferencesDataStore("riya_prefs")

data class CustomModel(val id: String, val label: String)

data class Prefs(
    val uiLang: String = "bn",
    val speechLang: String = "auto",
    val aiName: String = "Riya",
    val wakeWord: String = "Riya",
    val personality: String = "cute", // cute | normal
    val voiceName: String = "",
    val rate: Float = 1f,
    val pitch: Float = 1.2f,
    val modelId: String = "",
    val temperature: Float = 0.8f,
    val maxTokens: Int = 1024,
    val proactiveOn: Boolean = true,
    val silenceSec: Int = 25,
    val maxProactive: Int = 1,
    val quietMode: Boolean = false,
    val dndOn: Boolean = false,
    val dndStart: Int = 23,
    val dndEnd: Int = 7,
    val timeoutSec: Int = 300,
    val confirmOpenApp: Boolean = true,
    val memoryEnabled: Boolean = true,
    val saveChats: Boolean = true,
    val customModels: List<CustomModel> = emptyList(),
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val uiLang = stringPreferencesKey("uiLang"); val speechLang = stringPreferencesKey("speechLang")
        val aiName = stringPreferencesKey("aiName"); val wakeWord = stringPreferencesKey("wakeWord")
        val personality = stringPreferencesKey("personality"); val voiceName = stringPreferencesKey("voiceName")
        val rate = floatPreferencesKey("rate"); val pitch = floatPreferencesKey("pitch")
        val modelId = stringPreferencesKey("modelId"); val temperature = floatPreferencesKey("temperature")
        val maxTokens = intPreferencesKey("maxTokens"); val proactiveOn = booleanPreferencesKey("proactiveOn")
        val silenceSec = intPreferencesKey("silenceSec"); val maxProactive = intPreferencesKey("maxProactive")
        val quietMode = booleanPreferencesKey("quietMode"); val dndOn = booleanPreferencesKey("dndOn")
        val dndStart = intPreferencesKey("dndStart"); val dndEnd = intPreferencesKey("dndEnd")
        val timeoutSec = intPreferencesKey("timeoutSec"); val confirmOpenApp = booleanPreferencesKey("confirmOpenApp")
        val memoryEnabled = booleanPreferencesKey("memoryEnabled"); val saveChats = booleanPreferencesKey("saveChats")
        val customModels = stringPreferencesKey("customModels")
    }

    val prefs: Flow<Prefs> = ctx.ds.data.map { read(it) }

    suspend fun update(f: (Prefs) -> Prefs) {
        ctx.ds.edit { write(it, f(read(it))) }
    }

    private fun read(p: Preferences): Prefs {
        val d = Prefs()
        return Prefs(
            p[K.uiLang] ?: d.uiLang, p[K.speechLang] ?: d.speechLang, p[K.aiName] ?: d.aiName,
            p[K.wakeWord] ?: d.wakeWord, p[K.personality] ?: d.personality, p[K.voiceName] ?: d.voiceName,
            p[K.rate] ?: d.rate, p[K.pitch] ?: d.pitch, p[K.modelId] ?: d.modelId,
            p[K.temperature] ?: d.temperature, p[K.maxTokens] ?: d.maxTokens,
            p[K.proactiveOn] ?: d.proactiveOn, p[K.silenceSec] ?: d.silenceSec,
            p[K.maxProactive] ?: d.maxProactive, p[K.quietMode] ?: d.quietMode,
            p[K.dndOn] ?: d.dndOn, p[K.dndStart] ?: d.dndStart, p[K.dndEnd] ?: d.dndEnd,
            p[K.timeoutSec] ?: d.timeoutSec, p[K.confirmOpenApp] ?: d.confirmOpenApp,
            p[K.memoryEnabled] ?: d.memoryEnabled, p[K.saveChats] ?: d.saveChats,
            decodeModels(p[K.customModels]),
        )
    }

    private fun write(m: MutablePreferences, v: Prefs) {
        m[K.uiLang] = v.uiLang; m[K.speechLang] = v.speechLang; m[K.aiName] = v.aiName
        m[K.wakeWord] = v.wakeWord; m[K.personality] = v.personality; m[K.voiceName] = v.voiceName
        m[K.rate] = v.rate; m[K.pitch] = v.pitch; m[K.modelId] = v.modelId
        m[K.temperature] = v.temperature; m[K.maxTokens] = v.maxTokens
        m[K.proactiveOn] = v.proactiveOn; m[K.silenceSec] = v.silenceSec; m[K.maxProactive] = v.maxProactive
        m[K.quietMode] = v.quietMode; m[K.dndOn] = v.dndOn; m[K.dndStart] = v.dndStart; m[K.dndEnd] = v.dndEnd
        m[K.timeoutSec] = v.timeoutSec; m[K.confirmOpenApp] = v.confirmOpenApp
        m[K.memoryEnabled] = v.memoryEnabled; m[K.saveChats] = v.saveChats
        m[K.customModels] = JSONArray().also { a ->
            v.customModels.forEach { a.put(JSONObject().put("id", it.id).put("label", it.label)) }
        }.toString()
    }

    private fun decodeModels(s: String?): List<CustomModel> = runCatching {
        val a = JSONArray(s ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> CustomModel(o.getString("id"), o.optString("label")) } }
    }.getOrDefault(emptyList())
}
