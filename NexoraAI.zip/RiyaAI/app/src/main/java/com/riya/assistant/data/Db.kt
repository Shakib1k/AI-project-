package com.riya.assistant.data

import androidx.room.*

@Entity(tableName = "memory")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // preference | fact | instruction | project | code
    val text: String,
    val createdAt: Long,
    val pinned: Boolean = false,
)

@Entity(tableName = "message", indices = [Index("sessionId")])
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String, // user | model
    val text: String,
    val createdAt: Long,
)

@Entity(tableName = "task")
data class TaskLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val summary: String,
    val ok: Boolean,
    val createdAt: Long,
)

@Dao
interface RiyaDao {
    @Insert suspend fun add(m: MemoryItem): Long
    @Update suspend fun update(m: MemoryItem)
    @Delete suspend fun delete(m: MemoryItem)
    @Query("SELECT * FROM memory ORDER BY pinned DESC, createdAt DESC") suspend fun allMemory(): List<MemoryItem>
    @Query("SELECT * FROM memory WHERE text LIKE '%' || :q || '%' ORDER BY pinned DESC, createdAt DESC LIMIT :limit")
    suspend fun searchMemory(q: String, limit: Int): List<MemoryItem>
    @Query("DELETE FROM memory") suspend fun clearMemory()

    @Insert suspend fun addMessage(m: ChatMessage)
    @Query("SELECT * FROM message WHERE sessionId = :s ORDER BY createdAt DESC LIMIT :n")
    suspend fun recent(s: Long, n: Int): List<ChatMessage>
    @Query("SELECT * FROM message WHERE text LIKE '%' || :q || '%' ORDER BY createdAt DESC LIMIT :limit")
    suspend fun searchMessages(q: String, limit: Int): List<ChatMessage>
    @Query("SELECT * FROM message ORDER BY createdAt ASC") suspend fun allMessages(): List<ChatMessage>
    @Query("DELETE FROM message") suspend fun clearMessages()
    @Query("DELETE FROM message WHERE id IN (SELECT id FROM message ORDER BY createdAt ASC LIMIT :n)")
    suspend fun pruneOldest(n: Int)

    @Insert suspend fun addTask(t: TaskLog)
    @Query("SELECT * FROM task ORDER BY createdAt DESC LIMIT 50") suspend fun tasks(): List<TaskLog>
    @Query("SELECT * FROM task ORDER BY createdAt ASC") suspend fun allTasks(): List<TaskLog>
}

@Database(entities = [MemoryItem::class, ChatMessage::class, TaskLog::class], version = 1, exportSchema = false)
abstract class RiyaDb : RoomDatabase() {
    abstract fun dao(): RiyaDao
}
