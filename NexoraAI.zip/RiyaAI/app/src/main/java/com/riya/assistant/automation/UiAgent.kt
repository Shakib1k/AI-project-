package com.riya.assistant.automation

import com.riya.assistant.ai.GeminiClient
import com.riya.assistant.ai.Turn
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Generic observe -> decide -> act loop for multi-step UI tasks (for example "create bot.py in MT Manager").
 * Safeguards: step cap, repeated-action detection, and a spoken confirmation callback for destructive steps.
 */
class UiAgent(private val gemini: GeminiClient, private val auto: AutomationController) {
    private val maxSteps = 20

    suspend fun run(
        model: String, goal: String, app: String,
        confirm: suspend (String) -> Boolean,
        onStep: (String) -> Unit = {},
    ): ActionResult {
        val svc = RiyaAccessibilityService.instance ?: return ActionResult(false, "Accessibility service is not enabled")
        val seen = HashMap<String, Int>()
        val system = """You control an Android UI through accessibility nodes. Goal: $goal (app: $app).
Each step you get the visible nodes as "[index] Class "label" flags". Reply with ONE JSON object only:
{"op":"click","index":N} | {"op":"type","index":N,"text":"..."} | {"op":"scroll","dir":"down|up"} | {"op":"back"} | {"op":"done","summary":"..."} | {"op":"fail","reason":"..."}
Add "sensitive":true and "say":"short question" for destructive steps (delete, overwrite, send, install).
Use only indexes shown. Never guess. If the goal is already achieved, reply done. Prefer the app's own menus (e.g. MT Manager: the "+" or "New" action for creating files)."""
        val history = mutableListOf<Turn>()
        repeat(maxSteps) { step ->
            delay(700)
            val nodes = svc.dump(80)
            val screen = "Package: ${svc.currentPackage()}\n" + nodes.joinToString("\n") { it.brief() }
            history += Turn("user", screen)
            val raw = gemini.generate(model, system, history.takeLast(7), 0.1f, 400, jsonOut = true).getOrElse {
                return ActionResult(false, "Model error: ${it.message}")
            }
            history += Turn("model", raw)
            val j = runCatching { JSONObject(raw) }.getOrNull() ?: return ActionResult(false, "Could not understand the next step")
            val op = j.optString("op")
            val key = "$op|${j.optInt("index", -1)}|${j.optString("text")}"
            if ((seen.merge(key, 1, Int::plus) ?: 0) >= 3) return ActionResult(false, "Stopped: repeating the same step without progress")
            if (j.optBoolean("sensitive") && !confirm(j.optString("say", "Continue with this step?"))) return ActionResult(false, "Cancelled by user")
            onStep(op)
            when (op) {
                "done" -> return ActionResult(true, j.optString("summary", "Done"))
                "fail" -> return ActionResult(false, j.optString("reason", "Failed"))
                "back" -> svc.back()
                "scroll" -> svc.scroll(j.optString("dir", "down"))
                "click" -> nodes.getOrNull(j.optInt("index", -1))?.let { svc.clickNode(it) } ?: return ActionResult(false, "Invalid element index")
                "type" -> {
                    val n = nodes.getOrNull(j.optInt("index", -1))?.takeIf { it.editable } ?: return ActionResult(false, "That field is not editable")
                    if (!svc.typeInto(n.node, j.optString("text"), false)) return ActionResult(false, "Typing failed")
                }
                else -> return ActionResult(false, "Unknown step: $op")
            }
        }
        return ActionResult(false, "Stopped after $maxSteps steps without finishing")
    }
}
