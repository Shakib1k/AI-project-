package com.riya.assistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object RC {
    val Black = Color(0xFF000000); val Matte = Color(0xFF0A0A0B); val Panel = Color(0x14FFFFFF)
    val Red = Color(0xFFFF1E3C); val DeepRed = Color(0xFF8A0017); val White = Color(0xFFFFFFFF)
    val Muted = Color(0xFF9A9AA3); val Border = Color(0x24FFFFFF); val Ok = Color(0xFF3DDC84)
}

private val scheme = darkColorScheme(
    primary = RC.Red, onPrimary = RC.White, background = RC.Black, onBackground = RC.White,
    surface = RC.Matte, onSurface = RC.White, secondary = RC.White, onSecondary = RC.Black,
    surfaceVariant = RC.Panel, onSurfaceVariant = RC.Muted, outline = RC.Border,
)

@Composable
fun RiyaTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)

/** Glass-style panel. */
@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, shape = RoundedCornerShape(22.dp), color = RC.Panel, border = BorderStroke(1.dp, RC.Border)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}
