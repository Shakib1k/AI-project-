package com.riya.assistant.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.delay

data class ActionResult(val ok: Boolean, val message: String = "", val options: List<String> = emptyList())

/** High-level phone actions built on the accessibility service. Never types into an unidentified field. */
class AutomationController(private val ctx: Context) {
    private val svc get() = RiyaAccessibilityService.instance

    val ready get() = svc != null

    private val searchLabels = listOf("search", "অনুসন্ধান", "খুঁজুন", "সার্চ", "खोज", "खोजें", "सर्च")
    private val sendLabels = listOf("send", "পাঠান", "পাঠাও", "भेजें", "भेजो")
    private val messageLabels = listOf("message", "type a message", "মেসেজ", "বার্তা", "संदेश", "मैसेज")

    private val appPackages = mapOf(
        "telegram" to "org.telegram.messenger", "whatsapp" to "com.whatsapp",
        "messenger" to "com.facebook.orca", "facebook" to "com.facebook.katana",
    )

    // ---------- apps ----------
    fun resolveApp(name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val q = norm(name)
        val launchers = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
        appPackages[name.lowercase().trim()]?.let { pkg -> if (launchers.any { it.activityInfo.packageName == pkg }) return pkg to name }
        val scored = launchers.map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .map { (pkg, label) ->
                val l = norm(label)
                (if (l == q) 3 else if (l.startsWith(q) || q.startsWith(l)) 2 else if (l.contains(q) || q.contains(l)) 1 else 0) to (pkg to label)
            }.filter { it.first > 0 }.sortedByDescending { it.first }
        return scored.firstOrNull()?.second
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    suspend fun openApp(name: String): ActionResult {
        val (pkg, label) = resolveApp(name) ?: return ActionResult(false, "App not found: $name")
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return ActionResult(false, "Cannot launch $label")
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        repeat(15) { delay(300); if (svc?.currentPackage() == pkg) return ActionResult(true, label) }
        return ActionResult(svc == null, if (svc == null) "$label launched (accessibility off, not verified)" else "$label did not come to the foreground")
    }

    // ---------- generic ----------
    private fun need() = ActionResult(false, "Accessibility service is not enabled")

    suspend fun tapText(text: String): ActionResult {
        val s = svc ?: return need()
        val n = best(s.dump(), text) ?: return ActionResult(false, "Could not find \"$text\" on screen")
        return if (s.clickNode(n)) ActionResult(true) else ActionResult(false, "Tap failed")
    }

    suspend fun typeFocused(text: String, replace: Boolean): ActionResult {
        val s = svc ?: return need()
        return if (s.typeInto(null, text, replace)) ActionResult(true)
        else ActionResult(false, "No focused text field to type into")
    }

    suspend fun scroll(dir: String) = svc?.let { ActionResult(it.scroll(dir)) } ?: need()
    fun back() = svc?.let { ActionResult(it.back()) } ?: need()
    fun home() = svc?.let { ActionResult(it.home()) } ?: need()
    fun screenText() = svc?.visibleText().orEmpty()

    private fun score(n: UiNode, q: String): Int {
        val l = n.label.lowercase().trim(); val t = q.lowercase().trim()
        return when { l.isEmpty() -> 0; l == t -> 3; l.startsWith(t) -> 2; l.contains(t) -> 1; else -> 0 }
    }
    private fun best(nodes: List<UiNode>, q: String) = nodes.maxByOrNull { score(it, q) }?.takeIf { score(it, q) > 0 }

    // ---------- messaging (Telegram / WhatsApp / Messenger) ----------
    private var lastChat: String? = null

    /** Finds the chat through the app's own search. Returns the options if several similar names exist. */
    suspend fun openChat(app: String, query: String): ActionResult {
        val s = svc ?: return need()
        val pkg = appPackages[app.lowercase()]
        if (pkg != null && s.currentPackage() != pkg) {
            val r = openApp(app); if (!r.ok) return r
            delay(800)
        }
        val search = s.dump().firstOrNull { n -> searchLabels.any { n.label.lowercase().contains(it) } && !n.editable }
        if (search != null) { s.clickNode(search); delay(700) }
        if (!s.typeInto(null, query, true)) {
            // some apps show the search field directly
            val field = s.dump().firstOrNull { it.editable } ?: return ActionResult(false, "Search field not found")
            if (!s.typeInto(field.node, query, true)) return ActionResult(false, "Could not type in search")
        }
        delay(1600)
        val tokens = query.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        val cands = s.dump(200).filter { !it.editable && it.label.isNotBlank() &&
            tokens.all { t -> it.label.lowercase().contains(t) } }
        val distinct = cands.distinctBy { it.label.lowercase().trim() }
        val exact = distinct.filter { it.label.lowercase().trim() == query.lowercase().trim() }
        val pick = when {
            distinct.isEmpty() -> return ActionResult(false, "No chat matching \"$query\"")
            exact.size == 1 -> exact.first()
            distinct.size == 1 -> distinct.first()
            else -> return ActionResult(false, "ambiguous", distinct.map { it.label.take(50) }.take(5))
        }
        return openCandidate(pick)
    }

    suspend fun openCandidateByLabel(label: String): ActionResult {
        val s = svc ?: return need()
        val n = best(s.dump(200).filter { !it.editable }, label) ?: return ActionResult(false, "Option not on screen anymore")
        return openCandidate(n)
    }

    private suspend fun openCandidate(n: UiNode): ActionResult {
        val s = svc ?: return need()
        val title = n.label.lineSequence().first().take(60)
        if (!s.clickNode(n)) return ActionResult(false, "Could not open $title")
        delay(1200)
        // verify: the chat title must be visible near the top, and a message box must exist
        val top = s.dump(60).filter { it.bounds.top < s.resources.displayMetrics.heightPixels * 0.25 }
        val shown = top.any { it.label.contains(title.take(20), ignoreCase = true) }
        val box = s.dump(80).any { it.editable }
        return if (shown && box) { lastChat = title; ActionResult(true, title) } else ActionResult(false, "Opened something, but could not confirm the chat \"$title\"")
    }

    suspend fun sendMessage(text: String): ActionResult {
        val s = svc ?: return need()
        val chat = lastChat ?: return ActionResult(false, "Recipient not identified")
        val top = s.dump(60).filter { it.bounds.top < s.resources.displayMetrics.heightPixels * 0.25 }
        if (top.none { it.label.contains(chat.take(20), ignoreCase = true) })
            return ActionResult(false, "The open chat is not \"$chat\"; I will not send to an unverified recipient")
        val nodes = s.dump(120)
        val box = nodes.firstOrNull { it.editable && messageLabels.any { m -> (it.desc + it.text).lowercase().contains(m) } }
            ?: nodes.filter { it.editable }.maxByOrNull { it.bounds.top }
            ?: return ActionResult(false, "Message box not found")
        if (!s.typeInto(box.node, text, true)) return ActionResult(false, "Could not type the message")
        delay(400)
        val send = s.dump(120).firstOrNull { n -> !n.editable && sendLabels.any { n.label.lowercase().contains(it) } }
            ?: return ActionResult(false, "Send button not found")
        if (!s.clickNode(send)) return ActionResult(false, "Send tap failed")
        delay(900)
        val after = s.dump(150)
        val inBubble = after.any { !it.editable && it.label.contains(text.take(30)) }
        val boxEmpty = after.filter { it.editable }.all { it.text.isBlank() || it.text != text }
        return if (inBubble && boxEmpty) ActionResult(true, "Sent and verified in $chat")
        else ActionResult(true, "Tapped send in $chat, but I could not verify delivery on screen")
    }

    // ---------- editor / code ----------
    /** Types code into the focused editor and reads it back. Reports failure instead of claiming success. */
    suspend fun typeCodeIntoEditor(code: String): ActionResult {
        val s = svc ?: return need()
        val node = s.focusedEditable()
            ?: s.dump(150).filter { it.editable }.maxByOrNull { it.bounds.height() * it.bounds.width() }?.node
            ?: return ActionResult(false, "No editor field found. Open the file in the editor and tap into it first")
        val ok = s.typeInto(node, code, true)
        node.refresh()
        val len = node.text?.length ?: 0
        return if (ok && len >= code.length * 0.98) ActionResult(true, "Typed ${code.length} characters and verified")
        else ActionResult(false, "The editor did not accept all the text (read back $len of ${code.length} characters)")
    }
}
