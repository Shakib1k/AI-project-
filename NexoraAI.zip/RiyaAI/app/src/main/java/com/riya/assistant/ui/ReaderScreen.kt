package com.riya.assistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Read any text aloud (pause / resume / replay / speed / pitch) and OCR images, PDFs and the observed screen. */
@Composable
fun ReaderScreen(vm: MainViewModel, actions: Actions, back: () -> Unit) {
    val p by vm.prefs.collectAsState()
    val text by vm.readText.collectAsState()
    val rs by vm.readState.collectAsState()
    val busy by vm.ocrBusy.collectAsState()
    val err by vm.ocrError.collectAsState()
    val screenOn by vm.screenActive.collectAsState()
    val ctx = LocalContext.current
    val t = { k: String -> S.t(p.uiLang, k) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { vm.ocrUri(it, ctx.contentResolver.getType(it)) }
    }

    Column(Modifier.fillMaxSize().navigationBarsPadding().imePadding()) {
        TopBar(t("read"), back)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            OutlinedTextField(text, { vm.readText.value = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
                placeholder = { Text(t("paste_text")) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RC.Red, unfocusedBorderColor = RC.Border,
                    focusedTextColor = RC.White, unfocusedTextColor = RC.White, cursorColor = RC.Red))
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                GhostButton(t("pick_file")) { pick.launch(arrayOf("image/*", "application/pdf")) }
                if (screenOn) GhostButton(t("screen")) { vm.ocrScreen() }
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = RC.Red, strokeWidth = 2.dp)
            }
            if (err.isNotBlank()) Text(err, color = RC.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RedButton(t("play"), enabled = text.isNotBlank()) { vm.read() }
                GhostButton(if (rs.playing) t("pause") else t("resume")) { if (rs.playing) vm.pause() else vm.resume() }
                GhostButton(t("replay")) { vm.replay() }
                GhostButton(t("stop")) { vm.stopRead() }
            }
            if (rs.total > 0) {
                LinearProgressIndicator(progress = { (rs.index + 1f) / rs.total }, Modifier.fillMaxWidth().padding(top = 10.dp), color = RC.Red, trackColor = RC.Border)
                Text("${rs.index + 1} / ${rs.total}", color = RC.Muted, fontSize = 11.sp)
            }
            SliderRow(t("rate"), p.rate, 0.6f..1.6f) { v -> vm.update { it.copy(rate = v) } }
            SliderRow(t("pitch"), p.pitch, 0.7f..1.8f) { v -> vm.update { it.copy(pitch = v) } }
            Spacer(Modifier.height(40.dp))
        }
    }
}
