package com.riya.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class UiNode(
    val index: Int, val text: String, val desc: String, val id: String, val cls: String,
    val clickable: Boolean, val editable: Boolean, val bounds: Rect, val node: AccessibilityNodeInfo,
) {
    val label: String get() = text.ifBlank { desc }
    fun brief() = "[$index] ${cls.substringAfterLast('.')} \"${label.take(60)}\"" +
        (if (id.isNotBlank()) " id=${id.substringAfter(':')}" else "") +
        (if (clickable) " clickable" else "") + (if (editable) " editable" else "")
}

/** Uses accessibility node identification (never fixed coordinates, except as a last-resort tap fallback). */
class RiyaAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: RiyaAccessibilityService? = null
        val enabled get() = instance != null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString().orEmpty()

    fun dump(limit: Int = 120): List<UiNode> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<UiNode>()
        val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        while (queue.isNotEmpty() && out.size < limit) {
            val n = queue.removeFirst()
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
            if (!n.isVisibleToUser) continue
            val text = (if (n.isShowingHintText) "" else n.text?.toString()).orEmpty()
            val desc = n.contentDescription?.toString().orEmpty()
            if (text.isBlank() && desc.isBlank() && !n.isClickable && !n.isEditable) continue
            val r = Rect(); n.getBoundsInScreen(r)
            out += UiNode(out.size, text, desc, n.viewIdResourceName.orEmpty(), n.className?.toString().orEmpty(),
                n.isClickable, n.isEditable, r, n)
        }
        return out
    }

    fun visibleText(): String = dump(300).filter { !it.editable }.map { it.label }.filter { it.isNotBlank() }.distinct().joinToString("\n")

    fun click(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        repeat(6) {
            if (cur?.isClickable == true) return cur!!.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur?.parent
        }
        return false
    }

    suspend fun tapCenter(r: Rect): Boolean = gesture(Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }, 60)

    suspend fun clickNode(u: UiNode): Boolean = click(u.node) || tapCenter(u.bounds)

    private suspend fun gesture(path: Path, ms: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    suspend fun scroll(dir: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "down" -> { p.moveTo(w / 2, h * 0.7f); p.lineTo(w / 2, h * 0.3f) }
            "up" -> { p.moveTo(w / 2, h * 0.3f); p.lineTo(w / 2, h * 0.7f) }
            "left" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            "right" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    fun focusedEditable(): AccessibilityNodeInfo? =
        rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }

    /**
     * Types into an identified editable field only. Falls back to clipboard paste for custom editors
     * (some code editors ignore ACTION_SET_TEXT) and then reads the field back to verify.
     */
    suspend fun typeInto(target: AccessibilityNodeInfo?, text: String, replace: Boolean): Boolean {
        val node = target ?: focusedEditable() ?: return false
        if (!node.isEditable) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val existing = if (replace || node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val chunk = if (text.length < 400) 24 else 300
        var typed = 0
        var ok = true
        while (typed < text.length && ok) {
            typed = minOf(text.length, typed + chunk)
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, existing + text.substring(0, typed))
            }
            ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (text.length < 400) delay(18) // human-like cadence for short messages
        }
        node.refresh()
        if (ok && node.text?.toString()?.endsWith(text.takeLast(20)) == true) return true
        // fallback: paste
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("riya", text))
        if (replace) node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") })
        node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        delay(300)
        node.refresh()
        return node.text?.toString()?.contains(text.take(20)) == true
    }
}
