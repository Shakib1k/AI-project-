package com.riya.assistant.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ModelsScreen(vm: MainViewModel, back: () -> Unit) {
    val p by vm.prefs.collectAsState()
    val models by vm.models.collectAsState()
    val busy by vm.busy.collectAsState()
    val detail by vm.connectionDetail.collectAsState()
    val conn by vm.connection.collectAsState()
    val t = { k: String -> S.t(p.uiLang, k) }
    var id by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        TopBar(t("models_title"), back)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp)) {
            item {
                Glass(Modifier.fillMaxWidth()) {
                    Text(t("model") + ": " + p.modelId.ifBlank { t("none") }, color = RC.White)
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RedButton(t("discover")) { vm.discover() }
                        Spacer(Modifier.width(10.dp))
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = RC.Red, strokeWidth = 2.dp)
                        else if (conn == "error") Text(detail, color = RC.Red, fontSize = 12.sp)
                    }
                    Text("Models come from your own API account; nothing is hard-coded.", color = RC.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(12.dp))
                Glass(Modifier.fillMaxWidth()) {
                    Field(id, { id = it }, t("custom_model") + " (e.g. gemini-…)")
                    Field(label, { label = it }, "Label", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RedButton(if (editing == null) t("add") else t("save"), enabled = id.isNotBlank()) {
                            if (editing == null) vm.addCustom(id, label) else vm.renameCustom(editing!!, id, label.ifBlank { id })
                            id = ""; label = ""; editing = null
                        }
                        if (editing != null) GhostButton(t("back")) { id = ""; label = ""; editing = null }
                    }
                }
                if (p.customModels.isNotEmpty()) H(t("custom_model").uppercase())
            }
            items(p.customModels, key = { "c" + it.id }) { m ->
                ModelRow(m.id, m.label, p.modelId == m.id, onPick = { vm.selectModel(m.id) }) {
                    IconButton({ editing = m.id; id = m.id; label = m.label }) { Icon(Icons.Default.Edit, t("edit"), tint = RC.Muted) }
                    IconButton({ vm.deleteCustom(m.id) }) { Icon(Icons.Default.Delete, t("delete"), tint = RC.Muted) }
                }
            }
            if (models.isNotEmpty()) item { H("AVAILABLE · ${models.size}") }
            items(models, key = { "m" + it.id }) { m -> ModelRow(m.id, m.displayName, p.modelId == m.id, { vm.selectModel(m.id) }) {} }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun ModelRow(id: String, label: String, selected: Boolean, onPick: () -> Unit, trailing: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onPick).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onPick, colors = RadioButtonDefaults.colors(selectedColor = RC.Red))
        Column(Modifier.weight(1f)) {
            Text(id, color = RC.White, fontSize = 14.sp)
            if (label.isNotBlank() && label != id) Text(label, color = RC.Muted, fontSize = 11.sp)
        }
        trailing()
    }
}
