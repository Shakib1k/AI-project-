package com.riya.assistant.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Gemini API key lives only here: AES-256 encrypted, never logged, never in source. */
class SecureKeyStore(private val ctx: Context) {
    private val sp by lazy {
        EncryptedSharedPreferences.create(
            ctx, "riya_secure",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }
    var geminiKey: String
        get() = runCatching { sp.getString("gemini", "") ?: "" }.getOrDefault("")
        set(v) { sp.edit().putString("gemini", v.trim()).apply() }
    val hasKey: Boolean get() = geminiKey.isNotBlank()
}
