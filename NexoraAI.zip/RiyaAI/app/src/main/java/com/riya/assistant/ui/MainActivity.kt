package com.riya.assistant.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.riya.assistant.screen.ScreenCaptureService

enum class Screen { HOME, SETTINGS, MODELS, MEMORY, READER }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RiyaTheme {
                var screen by remember { mutableStateOf(Screen.HOME) }
                val owner = LocalLifecycleOwner.current
                DisposableEffect(owner) {
                    val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refreshStatus() }
                    owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
                }
                val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.toggleLive() }
                val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
                    if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                        startForegroundService(Intent(this, ScreenCaptureService::class.java)
                            .putExtra(ScreenCaptureService.EXTRA_CODE, r.resultCode).putExtra(ScreenCaptureService.EXTRA_DATA, r.data))
                    }
                }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                val actions = remember {
                    Actions(
                        requestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                        requestScreen = {
                            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            projLauncher.launch(mpm.createScreenCaptureIntent())
                        },
                    )
                }
                BackHandler(screen != Screen.HOME) { screen = Screen.HOME }
                Box(Modifier.fillMaxSize().background(RC.Black)) {
                    when (screen) {
                        Screen.HOME -> HomeScreen(vm, actions) { screen = it }
                        Screen.SETTINGS -> SettingsScreen(vm, actions, { screen = Screen.HOME }) { screen = it }
                        Screen.MODELS -> ModelsScreen(vm) { screen = Screen.SETTINGS }
                        Screen.MEMORY -> MemoryScreen(vm) { screen = Screen.HOME }
                        Screen.READER -> ReaderScreen(vm, actions) { screen = Screen.HOME }
                    }
                }
            }
        }
    }
}

class Actions(val requestMic: () -> Unit, val requestScreen: () -> Unit)
