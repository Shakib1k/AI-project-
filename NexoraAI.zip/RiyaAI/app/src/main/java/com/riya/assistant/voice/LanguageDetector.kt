package com.riya.assistant.voice

enum class Lang(val code: String, val tag: String) {
    EN("en", "en-US"), BN("bn", "bn-IN"), HI("hi", "hi-IN");
    companion object { fun of(code: String) = entries.firstOrNull { it.code == code } ?: EN }
}

data class Seg(val text: String, val lang: Lang)

object LanguageDetector {
    private val banglish = setOf("ami", "tumi", "apni", "kemon", "achho", "acho", "bhalo", "valo", "kore", "koro", "korbo",
        "bolo", "ache", "nai", "hobe", "jabo", "khub", "ekta", "amar", "tomar", "apnar", "kothay", "dao", "pathao", "kholo", "bondho")
    private val hinglish = setOf("hai", "hain", "nahi", "nahin", "kya", "kaise", "aap", "tum", "mera", "meri", "karo", "acha",
        "theek", "haan", "mujhe", "kyun", "abhi", "bhejo", "kholo", "batao", "suno")

    fun scriptOf(c: Char): Lang? = when {
        c in '\u0980'..'\u09FF' -> Lang.BN
        c in '\u0900'..'\u097F' -> Lang.HI
        c.isLetter() && c.code < 0x250 -> Lang.EN
        else -> null
    }

    fun dominant(text: String): Lang? {
        val n = IntArray(3)
        text.forEach { c -> scriptOf(c)?.let { n[it.ordinal]++ } }
        val max = n.max()
        return if (max == 0) null else Lang.entries[n.indexOf(max)]
    }

    /** "banglish", "hinglish" or null for Latin-script text containing romanised Bengali/Hindi. */
    fun flavor(text: String): String? {
        if (dominant(text) != Lang.EN) return null
        val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val b = words.count { it in banglish }; val h = words.count { it in hinglish }
        return when {
            b >= 2 || (b >= 1 && b * 3 >= words.size) -> if (b >= h) "Banglish" else "Hinglish"
            h >= 2 || (h >= 1 && h * 3 >= words.size) -> "Hinglish"
            else -> null
        }
    }

    /** Splits mixed-script text into runs so each run is spoken by a voice for its own language. */
    fun segments(text: String): List<Seg> {
        val out = mutableListOf<Seg>()
        val cur = StringBuilder(); var curLang: Lang? = null
        fun flush() { if (cur.isNotBlank()) out += Seg(cur.toString(), curLang ?: Lang.EN); cur.setLength(0) }
        for (c in text) {
            val s = scriptOf(c)
            if (s == null) cur.append(c)
            else if (curLang == null) { curLang = s; cur.append(c) }
            else if (s == curLang) cur.append(c)
            else { flush(); curLang = s; cur.append(c) }
        }
        flush()
        return out
    }
}

object TextCleaner {
    private val emoji = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}\\x{2B50}\\x{2B06}-\\x{2B55}\\x{2764}]")
    private val md = Regex("(\\*\\*|__|`{1,3}|^#{1,6}\\s*|^\\s*[-*•]\\s+)", RegexOption.MULTILINE)

    fun forSpeech(t: String): String = t.replace(emoji, "").replace(md, "").replace(Regex("[ \\t]{2,}"), " ").trim()

    fun sentences(t: String): List<String> =
        t.split(Regex("(?<=[.!?।॥])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }

    /** Basic spoken maths: "2 + 3 = 5" read in the segment's own language. */
    fun speakMath(t: String, lang: Lang): String {
        val w = when (lang) {
            Lang.EN -> listOf("plus", "minus", "times", "divided by", "equals")
            Lang.BN -> listOf("যোগ", "বিয়োগ", "গুণ", "ভাগ", "সমান")
            Lang.HI -> listOf("जोड़", "घटा", "गुणा", "भाग", "बराबर")
        }
        return t.replace(Regex("(?<=\\d)\\s*\\+\\s*(?=\\d)"), " ${w[0]} ")
            .replace(Regex("(?<=\\d)\\s*[-−]\\s*(?=\\d)"), " ${w[1]} ")
            .replace(Regex("(?<=\\d)\\s*[×x*]\\s*(?=\\d)"), " ${w[2]} ")
            .replace(Regex("(?<=\\d)\\s*[÷/]\\s*(?=\\d)"), " ${w[3]} ")
            .replace(Regex("(?<=\\d)\\s*=\\s*(?=\\d)"), " ${w[4]} ")
    }
}
