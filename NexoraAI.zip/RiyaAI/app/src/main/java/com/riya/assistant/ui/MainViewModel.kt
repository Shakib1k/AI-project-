package com.riya.assistant.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.riya.assistant.RiyaApp
import com.riya.assistant.ai.ModelInfo
import com.riya.assistant.automation.RiyaAccessibilityService
import com.riya.assistant.data.CustomModel
import com.riya.assistant.data.MemoryItem
import com.riya.assistant.data.Prefs
import com.riya.assistant.data.StorageUsage
import com.riya.assistant.screen.ScreenSession
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val c = (app as RiyaApp).container
    val assistant = c.assistant // also initialises TTS

    val prefs = c.settings.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, Prefs())
    val orb = assistant.orb
    val live = assistant.active
    val heard = assistant.heard
    val error = assistant.error
    val screenActive = ScreenSession.active

    val connection = MutableStateFlow(if (c.keys.hasKey) "not_tested" else "no_key")
    val connectionDetail = MutableStateFlow("")
    val models = MutableStateFlow<List<ModelInfo>>(emptyList())
    val busy = MutableStateFlow(false)
    val accessibilityOn = MutableStateFlow(false)

    val memory = MutableStateFlow<List<MemoryItem>>(emptyList())
    val usage = MutableStateFlow<StorageUsage?>(null)
    val readText = MutableStateFlow("")
    val readState = c.voice.readState
    val ocrBusy = MutableStateFlow(false)
    val ocrError = MutableStateFlow("")

    fun lang() = prefs.value.uiLang
    fun t(key: String) = S.t(lang(), key)

    fun refreshStatus() { accessibilityOn.value = RiyaAccessibilityService.enabled; refreshMemory() }

    fun update(f: (Prefs) -> Prefs) = viewModelScope.launch { c.settings.update(f) }

    // ---------- Gemini ----------
    fun saveKey(k: String) { c.keys.geminiKey = k; connection.value = if (k.isBlank()) "no_key" else "not_tested" }
    fun hasKey() = c.keys.hasKey

    fun test() = viewModelScope.launch {
        busy.value = true
        c.gemini.testConnection().fold(
            { connection.value = "connected"; connectionDetail.value = "$it models" },
            { connection.value = "error"; connectionDetail.value = it.message.orEmpty().take(120) })
        busy.value = false
    }

    fun discover() = viewModelScope.launch {
        busy.value = true
        c.gemini.listModels().fold({ list ->
            models.value = list; connection.value = "connected"; connectionDetail.value = "${list.size} models"
            if (prefs.value.modelId.isBlank()) // first run: pick a sensible default from what the account really has
                list.firstOrNull { "flash" in it.id && listOf("lite", "image", "tts", "live", "thinking", "preview", "exp").none { x -> x in it.id } }
                    ?.let { m -> update { it.copy(modelId = m.id) } }
        }, { connection.value = "error"; connectionDetail.value = it.message.orEmpty().take(120) })
        busy.value = false
    }

    fun selectModel(id: String) = update { it.copy(modelId = id) }
    fun addCustom(id: String, label: String) = update { p ->
        if (id.isBlank()) p else p.copy(customModels = p.customModels.filter { it.id != id.trim() } + CustomModel(id.trim().removePrefix("models/"), label.ifBlank { id }.trim()))
    }
    fun deleteCustom(id: String) = update { p -> p.copy(customModels = p.customModels.filter { it.id != id }, modelId = if (p.modelId == id) "" else p.modelId) }
    fun renameCustom(oldId: String, id: String, label: String) = update { p ->
        p.copy(customModels = p.customModels.map { if (it.id == oldId) CustomModel(id.trim(), label.trim()) else it },
            modelId = if (p.modelId == oldId) id.trim() else p.modelId)
    }

    // ---------- live ----------
    fun toggleLive() { if (live.value) assistant.stopLive() else assistant.startLive() }
    fun stopScreen() = ScreenSession.stop()

    // ---------- memory ----------
    private var query = ""
    fun refreshMemory(q: String = query) = viewModelScope.launch {
        query = q; memory.value = c.memory.search(q); usage.value = c.memory.usage()
    }
    fun addMemory(text: String) = viewModelScope.launch { if (text.isNotBlank()) c.memory.add("fact", text); refreshMemory() }
    fun editMemory(m: MemoryItem, text: String) = viewModelScope.launch { c.memory.update(m.copy(text = text)); refreshMemory() }
    fun pinMemory(m: MemoryItem) = viewModelScope.launch { c.memory.update(m.copy(pinned = !m.pinned)); refreshMemory() }
    fun deleteMemory(m: MemoryItem) = viewModelScope.launch { c.memory.delete(m); refreshMemory() }
    fun exportMemory(u: Uri) = viewModelScope.launch { runCatching { c.memory.exportTo(u) } }
    fun importMemory(u: Uri) = viewModelScope.launch { runCatching { c.memory.importFrom(u) }; refreshMemory() }
    fun clearMemory() = viewModelScope.launch { c.memory.clearAll(); refreshMemory() }

    // ---------- reader / OCR ----------
    fun ocrUri(u: Uri, mime: String?) = viewModelScope.launch {
        ocrBusy.value = true; ocrError.value = ""
        c.ocr.readUri(u, mime, prefs.value.modelId).fold({ readText.value = it }, { ocrError.value = it.message.orEmpty().take(160) })
        ocrBusy.value = false
    }
    fun ocrScreen() = viewModelScope.launch {
        val b: Bitmap = ScreenSession.frame() ?: run { ocrError.value = "Start screen observation first"; return@launch }
        ocrBusy.value = true
        c.ocr.read(b, prefs.value.modelId).fold({ readText.value = it }, { ocrError.value = it.message.orEmpty().take(160) })
        ocrBusy.value = false
    }
    fun read() = c.voice.readAloud(readText.value)
    fun pause() = c.voice.pauseRead()
    fun resume() = c.voice.resumeRead()
    fun replay() = c.voice.replayRead()
    fun stopRead() = c.voice.stopRead()
}
