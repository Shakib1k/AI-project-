package com.riya.assistant.screen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import com.riya.assistant.assistant.OrbState

/** Floating draggable orb drawn with Canvas (no Compose lifecycle needed in a WindowManager overlay). */
class OrbOverlayView(ctx: Context, private val lp: WindowManager.LayoutParams, private val wm: WindowManager) : View(ctx) {
    var state: OrbState = OrbState.IDLE; set(v) { field = v; invalidate() }
    var observing: Boolean = false; set(v) { field = v; invalidate() }
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    private val red = Color.parseColor("#FF1E3C")

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy) * 0.62f
        val speed = when (state) { OrbState.THINKING -> 4f; OrbState.ACTING -> 3f; OrbState.SPEAKING -> 2f; else -> 1f }
        val pulse = 1f + 0.06f * Math.sin(Math.toRadians((t * speed * 2).toDouble())).toFloat()
        p.shader = RadialGradient(cx, cy, r * 1.6f * pulse, intArrayOf(Color.argb(150, 255, 30, 60), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r * 1.6f * pulse, p)
        p.shader = RadialGradient(cx - r * .3f, cy - r * .3f, r * pulse, intArrayOf(Color.WHITE, red, Color.parseColor("#3A0008")), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * pulse, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f; p.color = Color.WHITE
        c.drawArc(RectF(cx - r * 1.25f, cy - r * 1.25f, cx + r * 1.25f, cy + r * 1.25f), t * speed, 110f, false, p)
        p.color = red
        c.drawArc(RectF(cx - r * 1.4f, cy - r * 1.4f, cx + r * 1.4f, cy + r * 1.4f), -t * speed, 80f, false, p)
        if (observing) { // eye ring + dot: the screen is being observed
            p.color = Color.WHITE; p.strokeWidth = 2f
            c.drawCircle(cx, cy, r * 1.52f, p)
            p.style = Paint.Style.FILL; p.color = red; c.drawCircle(cx + r * 1.52f, cy, 6f, p)
        }
    }

    private var dx = 0f; private var dy = 0f; private var sx = 0; private var sy = 0
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
            MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(this, lp) }
        }
        return true
    }
}
