# Riya – Personal AI Assistant (Android)

Brand-new Kotlin / Jetpack Compose project. Package `com.riya.assistant`, minSdk 26, targetSdk 34.

## Open and build
1. Android Studio (Koala or newer, JDK 17): **File > Open** this folder. Let Gradle sync. If `gradle/wrapper` is missing, Android Studio offers to create it (or run `gradle wrapper --gradle-version 8.7`).
2. Run on a real phone (speech recognition, TTS voices and accessibility do not work properly on most emulators).
3. CLI: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`

## First-run setup (in the app)
1. Settings > paste your **Gemini API key** (from Google AI Studio) > Save > Test connection.
2. Models > **Discover models** (lists what your key can call; the first Flash model is auto-picked) or add a custom model ID.
3. Settings > Permissions: Microphone, Accessibility (enable "Riya"), Floating orb overlay, Screen observation (optional).
4. Install Google speech-recognition and Bengali/Hindi voice data if missing (Settings > voice > Install voice data).
5. Home > **Live Voice Chat**.

## Architecture (MVVM, manual DI via `AppContainer`)
- `ai/` GeminiClient (REST, SSE streaming, model discovery), PromptBuilder, StreamParser
- `voice/` VoiceEngine (SpeechRecognizer + TTS + read-aloud), BargeInDetector (VAD), LanguageDetector
- `assistant/` AssistantController (live session state machine), Phrases, foreground service
- `automation/` RiyaAccessibilityService, AutomationController (apps, Telegram/WhatsApp/Messenger), UiAgent (MT Manager and other multi-step tasks)
- `screen/` MediaProjection session, floating orb overlay
- `ocr/` Gemini vision + ML Kit offline (Latin, Devanagari)
- `data/` Room (memory, messages, tasks), DataStore prefs, encrypted API-key store
- `ui/` Compose screens: Home, Settings, Models, Memory, Reader

## How key behaviours work
- **Interruption:** while Riya speaks, a VAD (echo-cancelled mic) watches for your voice; on ~160 ms of speech it stops TTS, cancels the HTTP stream, and starts listening. Generation ids prevent overlapping audio.
- **Voice confirmation:** the model marks actions; the app asks by voice and accepts yes/no in Bengali, Hindi, English (incl. romanised). Anything else is treated as a new command.
- **Messaging:** chats are found through the app's own search; ambiguous names trigger a spoken question; messages are only sent after the chat title is verified on screen.
- **MT Manager / generic tasks:** observe > decide > act loop over accessibility nodes (max 20 steps, repeat detection, spoken confirmation for destructive steps). Code is generated, typed into the editor, and read back to verify.
- **Memory:** private Room database, 500 MB is a ceiling (shown against real free space), export/import JSON, oldest unpinned chat lines are pruned near the cap.

## Known limits (please read)
- Not compiled or run in the environment that generated it. Expect some first-build fixes.
- Always-on wake-word detection is not implemented (battery/privacy); the name/wake word is recognised during an active live session.
- Speech recognition uses Android's recognizer with one language at a time (Settings > recognition language); true auto-detect is limited.
- Voices are Android TTS voices. "Female" is chosen by voice-name heuristics; pick manually if needed. Cloud neural TTS (e.g. Gemini TTS) is not wired in.
- ML Kit has no Bengali model: Bengali OCR uses Gemini vision (needs key + internet).
- Accessibility automation depends on each app's UI labels and can break after app updates; custom editors may reject text injection (the app reports this instead of claiming success).
- First syllable after an interruption can be clipped because the recognizer starts after the VAD fires.
- Apps with secure windows (banking, DRM, password fields) block screen capture and accessibility by design; Riya does not try to bypass this.
