# Riya – Personal AI Assistant (Android)

Kotlin / Jetpack Compose Android project. Package `com.riya.assistant`, minSdk 26, targetSdk 34.

## Build with GitHub Actions

The repository includes `.github/workflows/android-build.yml`. Push to `main` or `master`, or run **Actions → Android Build → Run workflow**. The workflow installs JDK 17 and Gradle 8.7, builds the debug APK, and uploads it as the `NEXORA-AI-debug-apk` artifact.

## Open and build locally

1. Open this folder in Android Studio with JDK 17.
2. Let Gradle sync and install the Android SDK platform/build tools requested by Android Studio.
3. Build with `gradle --no-daemon assembleDebug` (Gradle 8.7 required).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The Gradle wrapper distribution configuration is included at `gradle/wrapper/gradle-wrapper.properties`. If you want to generate the platform-specific wrapper launcher files locally, run `gradle wrapper --gradle-version 8.7` once from this folder.

## First-run setup (in the app)
1. Settings > paste your **Gemini API key** (from Google AI Studio) > Save > Test connection.
2. Models > **Discover models** (lists what your key can call; the first Flash model is auto-picked) or add a custom model ID.
3. Settings > Permissions: Microphone, Accessibility (enable "Riya"), Floating orb overlay, Screen observation (optional).
4. Install Google speech-recognition and Bengali/Hindi voice data if missing (Settings > voice > Install voice data).
5. Home > **Live Voice Chat**.

## Architecture (MVVM, manual DI via `AppContainer`)
- `ai/` GeminiClient (REST, SSE streaming), PromptBuilder
- `voice/` SpeechRecognizer, TTS, interruption detection, language detection
- `assistant/` AssistantController and foreground service
- `automation/` Accessibility service and UI automation controller
- `screen/` MediaProjection session and floating orb overlay
- `ocr/` Gemini vision and ML Kit OCR
- `data/` Room, DataStore, encrypted API-key storage
- `ui/` Compose screens: Home, Settings, Models, Memory, Reader

## Known limits
This project still requires a successful CI build and on-device testing before release. Android speech recognition, TTS, accessibility automation, and screen capture depend on device settings and Android restrictions. Always-on wake-word detection is not implemented. Bengali OCR uses Gemini vision and requires an API key and internet access. Secure windows and password fields are not bypassed.
