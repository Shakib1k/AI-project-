# Nexora AI
Status: new source code. It has NOT been compiled or tested on a device.

## Build the APK with GitHub (works from a phone)
1. Create a private GitHub repository.
2. In Termux: `pkg install git unzip`, then `unzip NexoraAI.zip && cd NexoraAI`
3. `git init && git add . && git commit -m "Nexora" && git branch -M main`
4. `git remote add origin <your repo URL> && git push -u origin main`
   (GitHub asks for a personal access token with repo and workflow access, not your password.)
5. Repository > Actions > Build APK > download the `nexora-debug` artifact and install the APK.
If the build fails, copy the first lines starting with `e:` or `What went wrong`.

Building directly in Termux is not recommended: Google's Android build tools do not ship for Termux.
On a computer: open the folder in Android Studio (JDK 17, SDK 35). Build > Build APK(s).
Command line with Gradle 8.11.1: `gradle :app:assembleDebug`.
Output: app/build/outputs/apk/debug/app-debug.apk
This is a debug build. A release needs your own signing key.
If you already have a Nexora app, this uses package `com.nexora.ai`. Do not uninstall the old app
until you have backed up anything you need from it.

## Setup on the phone
1. Settings > enter Gemini API key > Save and load models > choose a model.
2. Grant microphone, notifications and overlay.
3. Accessibility > Nexora Automation. If greyed out on Android 13+: App info > menu > Allow restricted settings.

## Using it
- New chat > Live voice. Talk over Nexora to interrupt.
- Start Screen Sharing: tap orb = describe screen; hold = return to Nexora.
- Phone task: type or say "MT Manager ওপেন করে VIP.html ফাইল তৈরি করো".
- When a task asks a question, send a new, complete instruction (each task starts fresh).

## Current scope
- Voice runs only while Nexora is on screen. During a phone task, use the on-screen STOP button.
- Barge-in is volume-based; tune the threshold. The first word of an interruption may be lost.
- App launch uses Android's launch intent, not swiping through the home screen.
- Typing sets a field's full text at once. It replaces the old content after asking you.
- Telegram goes through the same task runner. Every tap in common messaging apps requires Allow.
  Check the chat name and message before you tap Allow.
- The risk check is keyword based and cannot catch every consequential tap. Watch tasks as they run.
- "DONE" means the quoted text was seen on screen. It is not proof the file was saved to disk.
- Not included: Room and DataStore (JSON and SharedPreferences are used), cloud TTS, multi-folder
  project explorer, horizontal-container targeting, drag gestures, persistent task history.

## Test checklist
[ ] Build  [ ] Load models  [ ] Streaming reply  [ ] History reopen  [ ] Bengali/English voice
[ ] Interrupt on speaker and headphones  [ ] Share, orb drag/tap/hold, notification Stop
[ ] Rotate while sharing  [ ] Open MT Manager  [ ] Create/save a test file, then check it yourself
[ ] STOP mid-task  [ ] Cancel at confirmation  [ ] Telegram to Saved Messages only
[ ] HTML preview  [ ] Save and reopen from Coding Studio
