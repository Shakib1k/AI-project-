# NEXORA AI — ধাপ ১: Live Conversation (v0.1.0)

এই ধাপে যা **আছে**: Live Conversation (continuous listen → Gemini streaming → বাক্য ধরে বলা),
VAD-ভিত্তিক barge-in, state machine, Bengali/English TTS ভয়েস সেটিংস, Gemini model discovery,
অ্যানিমেটেড orb, ড্যাশবোর্ড, সেটিংস।

যা **নেই** (ড্যাশবোর্ডে ধূসর, ধাপ ২–৫-এ আসবে): Text Chat, Screen Vision/MediaProjection, Accessibility
অটোমেশন, Floating orb, Coding Studio, File tools, Task planner, Telegram/MT Manager।

## সতর্কতা
- কোডটি লেখা হয়েছে কিন্তু **কম্পাইল ও ডিভাইসে টেস্ট করা হয়নি** (লেখার পরিবেশে Android SDK/নেটওয়ার্ক ছিল না)।
  প্রথম বিল্ডে ছোটখাটো কম্পাইল ত্রুটি আসতে পারে; ত্রুটির টেক্সট পাঠালে ঠিক করে দেবো।
- Barge-in: কথা ধরা পড়ার পরেই SpeechRecognizer চালু হয়, তাই আপনার বাক্যের প্রথম এক-দুটি শব্দ হারাতে পারে।
  স্পিকারে ইকো থাকলে হেডফোন ব্যবহার করুন বা সেটিংসে সংবেদনশীলতা কমান।
- অ্যাপ ব্যাকগ্রাউন্ডে গেলে লাইভ সেশন নিজে থেমে যায় (ফোরগ্রাউন্ড সার্ভিস ধাপ ২-৩-এ)।
- API key DataStore-এ plain text-এ থাকে (অ্যাপ-প্রাইভেট)। পাবলিক রিলিজে ব্যাকএন্ড প্রক্সি লাগবে।

## বিল্ড করার উপায় (সহজ থেকে কঠিন)
1. **GitHub Actions (শুধু ফোন থাকলেও চলে):** প্রজেক্টটি একটি GitHub রিপোতে আপলোড করুন →
   Actions ট্যাব → "Build debug APK" → Run workflow → শেষে `nexora-debug-apk` আর্টিফ্যাক্ট নামান।
2. **Android Studio (PC):** ফোল্ডার Open করুন → Gradle sync → Run।
   টার্মিনালে: `gradle wrapper --gradle-version 8.9` তারপর `./gradlew assembleDebug`।
   APK: `app/build/outputs/apk/debug/app-debug.apk`
3. **Termux (পরীক্ষামূলক, নিশ্চিত নয়):** `pkg install openjdk-17 gradle`। Android SDK (platform 35, build-tools)
   আলাদা সেটআপ লাগে এবং Google-এর aapt2 ARM-এ চলে না, তাই `pkg install aapt2` করে `gradle.properties`-এ
   `android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2` দিতে হয়। এটা আমি যাচাই করিনি,
   তাই সুপারিশ করছি না।

## প্রথমবার ব্যবহার
1. অ্যাপ খুলে **ভয়েস ও AI সেটিংস** → Gemini API key দিন → সংরক্ষণ → **মডেল খুঁজুন** (অ্যাপ নিজে মডেল তালিকা আনে)।
2. বাংলা ভয়েস না থাকলে: ফোনের Settings → Text-to-speech → Google ইঞ্জিন → বাংলা ডাউনলোড।
3. **Live Conversation** খুলুন, মাইক অনুমতি দিন, কথা বলুন। AI বলার সময় কথা বললে সে থেমে যাবে।
