# NEXORA AI — Android personal AI assistant

Kotlin · Jetpack Compose (Material 3) · MVVM · Coroutines/Flow · OkHttp · Gemini API · Room · DataStore ·
SpeechRecognizer · TextToSpeech · MediaProjection · AccessibilityService · WebView

## 1. Project layout
```
app/src/main/java/com/nexora/ai/
  NexoraApp.kt            Application + manual DI container (AppContainer), UiEvent bus
  MainActivity.kt         Compose root, NavHost, confirmation dialog, screen-share banner
  data/                   Room (chats, messages, tool log), DataStore settings, encrypted API-key store
  ai/GeminiClient.kt      Streaming Gemini REST (SSE), retry/backoff, error mapping, usage stats
  ai/Tools.kt             Function-calling declarations + ToolExecutor (phone, files, preview)
  ai/Agent.kt             Plan/execute loop (stream -> tool calls -> results -> continue, max 12 steps)
  voice/VoiceController   SpeechRecognizer + TextToSpeech, watchdogs, sentence-level streaming TTS
  screen/                 MediaProjection foreground service, frame holder, consent + permission flow
  automation/             AccessibilityService (tap/scroll/swipe/type/back/home/read screen)
  workspace/              SAF-based file repo, HTML preview builder, formatter + syntax highlighter
  ui/                     Theme, glass/orb/waveform components, all screens
```

## 2. Setup
1. Install **Android Studio Koala (2024.1.1) or newer** with Android SDK 34 and JDK 17 (bundled JBR is fine).
2. Open the `NexoraAI` folder (File > Open). Android Studio reads `gradle/wrapper/gradle-wrapper.properties`
   and downloads Gradle 8.7. (For command-line builds run once: `gradle wrapper --gradle-version 8.7`.)
3. **Gemini API key** (never commit it). Pick ONE:
   - Recommended: run the app, open **Settings > Gemini API > paste key > Save key**. It is stored in
     EncryptedSharedPreferences (Android Keystore) and never written to source or logs.
   - Dev only: copy `local.properties.example` to `local.properties` and set `GEMINI_API_KEY=...`
     (`local.properties` is git-ignored; note the key is then compiled into your debug APK).
   Get a key at https://aistudio.google.com/apikey.

## 3. Build & run
- Android Studio: select a device/emulator (API 26+; a real phone is needed for voice, screen share, accessibility) and press Run.
- CLI: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.

## 4. Feature setup / permissions
| Feature | What the user must do |
|---|---|
| Voice chat | Grant Microphone. Needs Google app / speech service. For Bengali TTS install the Bengali voice in Android Settings > Text-to-speech. |
| Screen sharing | Dashboard > Screen Share > accept the in-app consent > accept Android's official capture dialog. A red banner + notification show while active. |
| Automation | Automation screen > Enable in Accessibility settings. On Android 13+ sideloaded apps: App info > ⋮ > Allow restricted settings. |
| Files | File Manager > folder icon > choose a folder (Storage Access Framework). Until then files live in private app storage. |

## 5. Testing checklist (manual, on a real device)
1. **API**: Settings > Test connection -> "✔ OK". Wrong key -> readable error, loading stops.
2. **Chat**: "হ্যালো" -> streamed reply addressing you as বস; chat appears in History; export from History; delete works.
3. **Voice**: Dashboard > Live Voice > grant mic > speak. Orb/waveform change Listening > Thinking > Speaking. Tap orb while speaking to interrupt. Switch keyboard/mic icon to toggle text/voice. Turn off network -> error shown, state returns to Idle.
4. **Screen share**: start sharing, ask "এই স্ক্রিনে কী আছে?" (a 🖼 context is attached automatically while sharing). Stop from the banner/notification. Deny the system dialog -> nothing happens.
5. **Automation**: enable service, say "Boss, MT Manager ওপেন করো" (or Automation > Quick test). Tool history shows `ok`/`verified`. Ask for "delete ..." -> confirmation dialog appears.
6. **Files**: "BD.txt ফাইল তৈরি করো" -> AI asks/creates file; open File Manager to see it; rename/delete/export ZIP.
7. **Studio**: "একটা premium HTML landing page বানাও" (chat) or Studio > Generate. Tabs open, Save, Preview (eye) shows the real page; Console shows JS errors; test Format/Explain/Debug/Complete.
8. **Preview**: mobile/tablet/full toggles, refresh, console panel; on tablets Studio shows editor + preview side by side.

## 6. Security notes
- No private key in source; key stored encrypted. Header-based auth (`x-goog-api-key`), not in URLs.
- Screen frames: in memory only, sent to Gemini only while sharing is ON *and* consent is granted, with the latest frame per message.
- Accessibility never types into password fields; sensitive taps/overwrites/deletes require confirmation (60 s timeout = deny).
- WebView: no JS bridges, no file/content access, no mixed content, external navigation blocked.

## 7. Known limitations (be aware, nothing is faked)
- Voice "interruption" is tap-to-interrupt (software barge-in by voice would trigger on the assistant's own speech).
- Android may block launching apps from the background; the agent only reports success when it can verify the foreground app.
- UI taps are reported as "dispatched"; the AI re-reads the screen to confirm. Apps that hide content from accessibility cannot be read.
- Code formatting: JSON/XML/HTML are structural; C-style languages use brace-based re-indenting; Python/SQL only trim whitespace. The studio does not execute code.
- Bengali speech recognition/TTS quality depends on the device's Google speech services.
