package com.nexora.ai.live

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.*
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Energy-based Voice Activity Detector used for barge-in.
 * Runs only while the AI is thinking/speaking. It releases the microphone BEFORE calling
 * onSpeech(), so the SpeechRecognizer can take the mic immediately afterwards.
 * Echo cancellation / noise suppression are enabled when the device supports them.
 */
class VadMonitor {
    private var job: Job? = null

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope, sensitivity: Float, onSpeech: () -> Unit, onFail: (String) -> Unit) {
        stop()
        job = scope.launch(Dispatchers.Default) {
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) {
                withContext(Dispatchers.Main) { onFail("এই ফোনে ভয়েস ইন্টারাপশন (VAD) চালু করা যায়নি।") }
                return@launch
            }
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, rate / 5 * 2)
                )
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { onFail("VAD মাইক খোলা যায়নি: ${e.message}") }
                return@launch
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                withContext(Dispatchers.Main) { onFail("VAD মাইক চালু হয়নি (অন্য অ্যাপ মাইক ব্যবহার করছে?)।") }
                return@launch
            }
            val aec = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true } else null
            val ns = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true } else null

            var triggered = false
            try {
                rec.startRecording()
                val buf = ShortArray(rate / 50) // 20 ms frames
                var floor = 0.0
                var warm = 0
                var hot = 0
                while (isActive) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    var sum = 0.0
                    for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    if (warm < WARMUP_FRAMES) { floor += rms / WARMUP_FRAMES; warm++; continue }
                    val threshold = max(MIN_RMS, floor * sensitivity)
                    if (rms > threshold) {
                        hot++
                        if (hot >= HOT_FRAMES) { triggered = true; break }
                    } else {
                        hot = 0
                        floor = floor * 0.97 + rms * 0.03   // slowly track the noise floor
                    }
                }
            } finally {
                aec?.release(); ns?.release()
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
            if (triggered) withContext(Dispatchers.Main) { onSpeech() }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    private companion object {
        const val WARMUP_FRAMES = 10   // 200 ms to learn the noise floor
        const val HOT_FRAMES = 8       // 160 ms of sustained loud audio = speech
        const val MIN_RMS = 700.0
    }
}
