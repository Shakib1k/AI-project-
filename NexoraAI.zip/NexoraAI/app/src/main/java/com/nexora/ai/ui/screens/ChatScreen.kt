@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.nexora.ai.screen.rememberScreenShareToggle
import com.nexora.ai.ui.components.*
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.voice.Phase

@Composable
fun ChatScreen(vm: ChatViewModel, chatId: Long, startVoice: Boolean, onBack: () -> Unit, onChatCreated: (Long) -> Unit) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsState()
    val msgs by vm.messages.collectAsState()
    val share = rememberScreenShareToggle()
    var input by rememberSaveable { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.setVoiceMode(true) else vm.setError("Microphone permission দেওয়া হয়নি — voice chat চালানো যাবে না।")
    }
    fun enableVoice() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.setVoiceMode(true)
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    val attachLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.attach(uri) }

    LaunchedEffect(chatId) {
        vm.load(chatId)
        if (startVoice) enableVoice()
    }
    // Replace the "new chat" route with the real id once the first message created the conversation.
    LaunchedEffect(ui.chatId) { if (chatId < 0 && ui.chatId > 0) onChatCreated(ui.chatId) }

    val busy = ui.phase == Phase.Thinking || ui.phase == Phase.Speaking && ui.streaming.isNotEmpty()
    val listState = rememberLazyListState()
    val showExtra = ui.streaming.isNotEmpty() || ui.phase == Phase.Thinking
    val total = msgs.size + if (showExtra) 1 else 0
    LaunchedEffect(total, ui.streaming.length) { if (total > 0) listState.animateScrollToItem(total - 1) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(if (ui.voiceMode) "Live Voice" else "NEXORA Chat") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = { if (ui.voiceMode) vm.setVoiceMode(false) else enableVoice() }) {
                        Icon(if (ui.voiceMode) Icons.Default.Keyboard else Icons.Default.Mic, "Toggle voice/text", tint = cs.primary)
                    }
                    IconButton(onClick = share.toggle) {
                        Icon(
                            if (share.active) Icons.Default.StopScreenShare else Icons.Default.ScreenShare, "Screen share",
                            tint = if (share.active) NX.Danger else cs.primary
                        )
                    }
                    IconButton(onClick = { vm.cancelAll(); vm.load(-1); onChatCreated(-1) }) { Icon(Icons.Default.Add, "New chat") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (ui.voiceMode) {
                Column(Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AiOrb(ui.phase, ui.level, Modifier.clickable {
                        when (ui.phase) {
                            Phase.Idle -> vm.startListening()
                            Phase.Listening -> vm.stopListening()
                            else -> vm.interrupt()
                        }
                    }, 150.dp)
                    Text(
                        when (ui.phase) {
                            Phase.Listening -> "শুনছি, বস…"
                            Phase.Thinking -> "ভাবছি…"
                            Phase.Speaking -> "বলছি… (থামাতে ট্যাপ করুন)"
                            Phase.Idle -> "কথা বলতে অর্ব-এ ট্যাপ করুন"
                        }, color = cs.primary
                    )
                    Waveform(ui.phase, ui.level, Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
                    if (ui.partial.isNotEmpty()) Text(ui.partial, fontStyle = FontStyle.Italic, color = cs.onSurfaceVariant)
                    ui.ttsNote?.let { Text(it, color = NX.Danger, style = MaterialTheme.typography.labelLarge) }
                }
            }

            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs.size) { i ->
                    val m = msgs[i]
                    Bubble(m.text, mine = m.role == "user", error = m.isError)
                }
                if (showExtra) item {
                    if (ui.streaming.isNotEmpty()) Bubble(ui.streaming, mine = false)
                    else GlassCard(Modifier.widthIn(max = 120.dp)) { TypingDots() }
                }
            }

            ui.toolStatus?.let {
                AssistChip(onClick = {}, label = { Text(it) }, modifier = Modifier.padding(horizontal = 12.dp))
            }
            ui.error?.let {
                Text(it, color = NX.Danger, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodyMedium)
            }
            ui.attachment?.let {
                InputChip(selected = true, onClick = {}, label = { Text("📎 ${it.name}") },
                    trailingIcon = { Icon(Icons.Default.Close, "Remove", Modifier.clickable { vm.clearAttachment() }) },
                    modifier = Modifier.padding(horizontal = 12.dp))
            }

            if (ui.voiceMode) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    FilledIconButton(
                        onClick = {
                            when (ui.phase) {
                                Phase.Idle -> vm.startListening()
                                Phase.Listening -> vm.stopListening()
                                else -> vm.interrupt()
                            }
                        },
                        modifier = Modifier.size(64.dp)
                    ) {
                        Icon(
                            when (ui.phase) { Phase.Idle -> Icons.Default.Mic; Phase.Listening -> Icons.Default.Stop; else -> Icons.Default.Stop },
                            "Mic", Modifier.size(30.dp)
                        )
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { attachLauncher.launch("*/*") }) { Icon(Icons.Default.AttachFile, "Attach", tint = cs.primary) }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("বস, কী করতে হবে?") },
                        shape = CircleShape, maxLines = 4
                    )
                    Spacer(Modifier.width(6.dp))
                    when {
                        busy -> FilledIconButton(onClick = { vm.cancelAll() }) { Icon(Icons.Default.Stop, "Stop") }
                        input.isBlank() -> FilledIconButton(onClick = { enableVoice() }) { Icon(Icons.Default.Mic, "Voice") }
                        else -> FilledIconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                    }
                }
            }
        }
    }
}
