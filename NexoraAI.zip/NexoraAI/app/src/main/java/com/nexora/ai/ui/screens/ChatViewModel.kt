package com.nexora.ai.ui.screens

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.ai.NexoraApp
import com.nexora.ai.ai.AgentEvent
import com.nexora.ai.data.ChatEntity
import com.nexora.ai.data.MessageEntity
import com.nexora.ai.screen.ScreenShare
import com.nexora.ai.voice.Phase
import com.nexora.ai.voice.SentenceSpeaker
import com.nexora.ai.voice.VoiceController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.ByteArrayOutputStream

data class Attachment(val name: String, val imageB64: String? = null, val text: String? = null)

data class ChatUi(
    val chatId: Long = -1,
    val phase: Phase = Phase.Idle,
    val streaming: String = "",
    val voiceMode: Boolean = false,
    val partial: String = "",
    val error: String? = null,
    val toolStatus: String? = null,
    val attachment: Attachment? = null,
    val level: Float = 0f,
    val ttsNote: String? = null
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as NexoraApp).container
    private val dao = c.db.dao()
    val voice = VoiceController(app)
    private val speaker = SentenceSpeaker(voice)

    private val chatId = MutableStateFlow(-1L)

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = chatId
        .flatMapLatest { if (it < 0) flowOf(emptyList()) else dao.messages(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ui = MutableStateFlow(ChatUi())

    private var job: Job? = null
    private var generating = false
    private var runId = 0

    init {
        voice.onQueueEmpty = { if (!generating) afterTurn() }
    }

    fun load(id: Long) {
        if (id != chatId.value || id < 0) {
            cancelAll()
            chatId.value = id
            ui.update { ChatUi(chatId = id, voiceMode = false) }
        }
    }

    fun setError(msg: String?) = ui.update { it.copy(error = msg) }

    // ------------ voice ------------
    fun setVoiceMode(on: Boolean) {
        ui.update { it.copy(voiceMode = on, error = null) }
        if (on) startListening() else {
            voice.stopListening(); voice.stopSpeaking()
            ui.update { it.copy(phase = if (generating) Phase.Thinking else Phase.Idle, partial = "", level = 0f) }
        }
    }

    fun startListening() {
        if (generating) return
        viewModelScope.launch {
            val s = c.settings.flow.first()
            voice.configure(s.language, s.voiceName)
            voice.stopSpeaking()
            ui.update { it.copy(phase = Phase.Listening, partial = "", error = null, ttsNote = voice.ttsNote) }
            voice.listen(
                s.language,
                partial = { t -> ui.update { it.copy(partial = t) } },
                done = { t -> ui.update { it.copy(partial = "", level = 0f) }; send(t) },
                fail = { m -> ui.update { it.copy(phase = Phase.Idle, error = m, level = 0f) } },
                level = { l -> ui.update { it.copy(level = l) } }
            )
        }
    }

    fun stopListening() {
        voice.stopListening()
        ui.update { it.copy(phase = Phase.Idle, partial = "", level = 0f) }
    }

    /** Tap-to-interrupt: stop speaking / generating and listen again. */
    fun interrupt() {
        cancelAll()
        if (ui.value.voiceMode) startListening()
    }

    fun cancelAll() {
        runId++
        job?.cancel()
        generating = false
        voice.stopListening()
        voice.stopSpeaking()
        ui.update { it.copy(phase = Phase.Idle, streaming = "", toolStatus = null, partial = "", level = 0f) }
    }

    private fun afterTurn() {
        ui.update { it.copy(phase = Phase.Idle, level = 0f) }
        if (ui.value.voiceMode && ui.value.error == null) {
            viewModelScope.launch { if (c.settings.flow.first().continuousVoice) startListening() }
        }
    }

    // ------------ send ------------
    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || generating) return
        generating = true
        val myRun = ++runId
        job = viewModelScope.launch {
            val s = c.settings.flow.first()
            val speak = ui.value.voiceMode || s.autoSpeak
            voice.configure(s.language, s.voiceName)
            speaker.reset()
            ui.update { it.copy(phase = Phase.Thinking, streaming = "", error = null, toolStatus = null) }
            val sb = StringBuilder()
            var saved = false
            var cancelled = false
            var cid = chatId.value
            try {
                val now = System.currentTimeMillis()
                if (cid < 0) {
                    cid = dao.insertChat(ChatEntity(title = text.take(40), createdAt = now, updatedAt = now))
                    chatId.value = cid
                    ui.update { it.copy(chatId = cid) }
                }
                val att = ui.value.attachment
                ui.update { it.copy(attachment = null) }
                val image = att?.imageB64 ?: if (ScreenShare.active.value && s.screenConsent) ScreenShare.jpegBase64() else null
                val promptText = if (att?.text != null) "$text\n\n[Attached file: ${att.name}]\n${att.text}" else text
                val history = dao.messagesOnce(cid)
                dao.insertMessage(
                    MessageEntity(chatId = cid, role = "user", text = text + (att?.let { "\n📎 ${it.name}" } ?: ""), createdAt = now, hasImage = image != null)
                )
                dao.touch(cid, now)

                withTimeout(150_000) {
                    c.agent.run(cid, history, promptText, image, s.language).collect { ev ->
                        when (ev) {
                            is AgentEvent.Delta -> {
                                sb.append(ev.text)
                                if (speak) speaker.feed(ev.text)
                                ui.update { it.copy(streaming = sb.toString(), phase = if (speak && voice.isSpeaking) Phase.Speaking else Phase.Thinking) }
                            }
                            is AgentEvent.ToolStart -> ui.update { it.copy(toolStatus = "⚙ ${ev.name}…") }
                            is AgentEvent.ToolEnd -> ui.update { it.copy(toolStatus = null) }
                        }
                    }
                }
                dao.insertMessage(MessageEntity(chatId = cid, role = "model", text = sb.toString().ifBlank { "…" }, createdAt = System.currentTimeMillis()))
                saved = true
            } catch (e: TimeoutCancellationException) {
                saveError(cid, "AI সময়মতো সাড়া দেয়নি (timeout)। আবার চেষ্টা করুন।")
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Exception) {
                saveError(cid, e.message ?: e.toString())
            } finally {
                withContext(NonCancellable) {
                    if (!saved && sb.isNotBlank() && cid > 0) {
                        dao.insertMessage(MessageEntity(chatId = cid, role = "model", text = sb.toString(), createdAt = System.currentTimeMillis()))
                    }
                }
                if (myRun == runId) {
                    generating = false
                    ui.update { it.copy(streaming = "", toolStatus = null) }
                    if (!cancelled) {
                        speaker.flush()
                        if (voice.isSpeaking) ui.update { it.copy(phase = Phase.Speaking) } else afterTurn()
                    }
                }
            }
        }
    }

    private suspend fun saveError(cid: Long, msg: String) {
        if (cid > 0) dao.insertMessage(MessageEntity(chatId = cid, role = "model", text = msg, createdAt = System.currentTimeMillis(), isError = true))
        ui.update { it.copy(error = msg) }
    }

    // ------------ attachments ------------
    fun attach(uri: Uri) {
        viewModelScope.launch {
            try {
                val a = withContext(Dispatchers.IO) {
                    val cr = getApplication<Application>().contentResolver
                    val name = cr.query(uri, null, null, null, null)?.use { cur ->
                        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cur.moveToFirst() && i >= 0) cur.getString(i) else null
                    } ?: "attachment"
                    val mime = cr.getType(uri).orEmpty()
                    if (mime.startsWith("image/")) {
                        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                        var sample = 1
                        while (maxOf(opts.outWidth, opts.outHeight) / sample > 2000) sample *= 2
                        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
                            ?: error("Cannot read image")
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                        Attachment(name, imageB64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
                    } else {
                        val txt = cr.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(20_000) } ?: error("Cannot read file")
                        Attachment(name, text = txt)
                    }
                }
                ui.update { it.copy(attachment = a) }
            } catch (e: Exception) {
                ui.update { it.copy(error = "Attach failed: ${e.message}") }
            }
        }
    }

    fun clearAttachment() = ui.update { it.copy(attachment = null) }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }
}
