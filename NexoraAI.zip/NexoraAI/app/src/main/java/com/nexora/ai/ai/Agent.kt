package com.nexora.ai.ai

import com.nexora.ai.AppContainer
import com.nexora.ai.data.MessageEntity
import com.nexora.ai.data.ToolLogEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.*

sealed interface AgentEvent {
    data class Delta(val text: String) : AgentEvent
    data class ToolStart(val name: String) : AgentEvent
    data class ToolEnd(val name: String, val ok: Boolean) : AgentEvent
}

/** Plans + executes: streams Gemini, runs requested tools, feeds results back, repeats (max 12 steps). */
class Agent(private val c: AppContainer) {

    fun systemPrompt(language: String): String = """
You are NEXORA AI, a futuristic personal AI assistant living on the user's Android phone.
PERSONA: Respectful, warm, concise. Address the user as "বস" when replying in Bengali and "Boss" when replying in English, in every conversational reply (e.g. "জি বস, বলুন কী করতে হবে?").
LANGUAGE: Reply in the language the user writes in (Bengali or English). Preferred language setting: ${if (language == "bn") "Bengali" else "English"}.
STYLE: Replies are often spoken aloud, so keep them short and natural; avoid tables and long markdown unless writing code. Put code in fenced blocks.
TOOLS: You can control the phone and the user's workspace only through the provided tools.
HONESTY RULES (important):
- Only say a task is done if the tool result says ok=true. If verified=false, say you sent the action but could not confirm it, or call read_screen_ui to check. If ok=false, explain the problem plainly.
- If required info is missing (e.g. a file name), ask the user first.
- To create files, prefer create_file / create_project (workspace). Use phone automation only when the user wants to operate another app.
- For phone automation: call read_screen_ui first to see what is on screen, act step by step, re-read the screen to confirm.
- Never pay, delete, send messages or change security settings unless the user clearly asked; the app will ask the user to confirm sensitive taps.
- Never type into password fields.
CODING: For code requests, write complete, working files with create_project, then open_in_studio or preview_html for web pages, and summarise briefly.
SCREEN: If an image is attached, it is the user's shared screen. Describe only what is visible; do not guess hidden content.
""".trimIndent()

    fun run(chatId: Long, history: List<MessageEntity>, userText: String, imageB64: String?, language: String): Flow<AgentEvent> = flow {
        val merged = mutableListOf<Pair<String, String>>()
        for (m in history.takeLast(40)) {
            if (m.isError || m.text.isBlank()) continue
            if (merged.isNotEmpty() && merged.last().first == m.role) {
                merged[merged.lastIndex] = m.role to (merged.last().second + "\n" + m.text)
            } else merged += m.role to m.text
        }
        if (merged.isNotEmpty() && merged.first().first == "model") merged.removeAt(0)
        if (merged.isNotEmpty() && merged.last().first == "user") merged.removeAt(merged.lastIndex)

        val contents = mutableListOf<JsonElement>()
        for ((r, t) in merged) contents += Gj.msg(r, t)
        contents += buildJsonObject {
            put("role", "user")
            put("parts", buildJsonArray {
                if (imageB64 != null) add(buildJsonObject {
                    put("inlineData", buildJsonObject { put("mimeType", "image/jpeg"); put("data", imageB64) })
                })
                add(buildJsonObject { put("text", userText) })
            })
        }

        val system = systemPrompt(language)
        for (step in 0 until 12) {
            val modelParts = mutableListOf<JsonElement>()
            val calls = mutableListOf<GeminiEvent.Call>()
            c.gemini.stream(JsonArray(contents), system, Tools.declarations).collect { ev ->
                when (ev) {
                    is GeminiEvent.Text -> emit(AgentEvent.Delta(ev.text))
                    is GeminiEvent.Call -> calls += ev
                    is GeminiEvent.Raw -> modelParts += ev.parts
                }
            }
            if (calls.isEmpty()) return@flow

            contents += buildJsonObject { put("role", "model"); put("parts", JsonArray(modelParts)) }
            val responses = mutableListOf<JsonElement>()
            for (call in calls) {
                emit(AgentEvent.ToolStart(call.name))
                val res = c.tools.execute(call.name, call.args)
                c.db.dao().insertTool(
                    ToolLogEntity(
                        chatId = chatId, name = call.name, args = call.args.toString().take(2000),
                        result = res.message.take(2000), ok = res.ok, createdAt = System.currentTimeMillis()
                    )
                )
                emit(AgentEvent.ToolEnd(call.name, res.ok))
                responses += buildJsonObject {
                    put("functionResponse", buildJsonObject {
                        put("name", call.name)
                        put("response", buildJsonObject {
                            put("ok", res.ok); put("verified", res.verified); put("message", res.message)
                        })
                    })
                }
            }
            contents += buildJsonObject { put("role", "user"); put("parts", JsonArray(responses)) }
            emit(AgentEvent.Delta("\n"))
        }
        emit(AgentEvent.Delta("\n(ধাপ সীমা পূর্ণ হয়েছে — আরও করতে বললে চালিয়ে যাব, বস।)"))
    }
}
