package com.nexora.ai.ui

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object NX {
    val Bg = Color(0xFF05060F)
    val Navy = Color(0xFF0B1030)
    val Cyan = Color(0xFF00E5FF)
    val Purple = Color(0xFF7C4DFF)
    val Glass = Color(0x14FFFFFF)
    val Text = Color(0xFFE8ECFF)
    val Muted = Color(0xFF8E96B8)
    val Danger = Color(0xFFFF5470)
}

fun Modifier.nexoraBackground(): Modifier =
    background(Brush.verticalGradient(listOf(NX.Bg, NX.Navy, NX.Bg)))

@Composable
fun NexoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NX.Cyan, secondary = NX.Purple, background = NX.Bg, surface = NX.Navy,
            onBackground = NX.Text, onSurface = NX.Text, error = NX.Danger
        ),
        content = content
    )
}
