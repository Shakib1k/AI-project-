package com.nexora.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.ai.LiveViewModel
import com.nexora.ai.data.Keys
import com.nexora.ai.voice.VoiceInfo

@Composable
fun SettingsScreen(vm: LiveViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val status by vm.modelStatus.collectAsStateWithLifecycle()
    val voices by vm.voice.voices.collectAsStateWithLifecycle()
    val ready by vm.voice.ready.collectAsStateWithLifecycle()
    var key by remember(s.apiKey) { mutableStateOf(s.apiKey) }
    var rate by remember(s.rate) { mutableFloatStateOf(s.rate) }
    var pitch by remember(s.pitch) { mutableFloatStateOf(s.pitch) }
    var volume by remember(s.volume) { mutableFloatStateOf(s.volume) }
    var sens by remember(s.bargeSensitivity) { mutableFloatStateOf(s.bargeSensitivity) }

    Column(Modifier.fillMaxSize().nexoraBackground().systemBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "ফিরে যান", tint = NX.Text) }
            Text("সেটিংস", color = NX.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Section("Gemini") {
                OutlinedTextField(
                    key, { key = it }, label = { Text("API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.set(Keys.apiKey, key.trim()) }) { Text("সংরক্ষণ") }
                    OutlinedButton(onClick = {
                        vm.set(Keys.apiKey, key.trim()); vm.loadModels()
                    }) { Text("মডেল খুঁজুন") }
                }
                Text("key ফোনের অ্যাপ-প্রাইভেট স্টোরেজে থাকে। পাবলিক APK-তে key বসাবেন না; প্রোডাকশনে ব্যাকএন্ড প্রক্সি ব্যবহার করুন।", color = NX.Muted, fontSize = 11.sp)
                status?.let { Text(it, color = NX.Cyan, fontSize = 12.sp) }
                Text("বর্তমান মডেল: ${s.model.ifBlank { "বাছাই হয়নি" }}", color = NX.Text, fontSize = 13.sp)
                Column(Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())) {
                    models.forEach { m ->
                        Row(Modifier.fillMaxWidth().clickable { vm.set(Keys.model, m.id) }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(s.model == m.id, { vm.set(Keys.model, m.id) })
                            Text(m.id, color = NX.Text, fontSize = 13.sp)
                        }
                    }
                }
            }

            Section("কণ্ঠ") {
                if (!ready) Text("TextToSpeech চালু হচ্ছে…", color = NX.Muted, fontSize = 12.sp)
                else if (voices.none { it.lang == "bn" })
                    Text("এই ফোনে বাংলা TTS ভয়েস পাওয়া যায়নি। Google Text-to-speech আপডেট করে Settings > Text-to-speech থেকে বাংলা ভয়েস ডাউনলোড করুন। ততক্ষণ বাংলা বাক্য ডিফল্ট ইঞ্জিনের উপর নির্ভর করবে।", color = NX.Danger, fontSize = 12.sp)
                Text("Android ভয়েসের লিঙ্গ জানায় না। প্রিভিউ শুনে বেছে নিন।", color = NX.Muted, fontSize = 11.sp)
                VoicePicker("বাংলা ভয়েস", voices.filter { it.lang == "bn" }, s.voiceBn) { vm.set(Keys.voiceBn, it) }
                OutlinedButton(onClick = { vm.preview(true) }) { Text("বাংলা প্রিভিউ") }
                VoicePicker("English voice", voices.filter { it.lang == "en" }, s.voiceEn) { vm.set(Keys.voiceEn, it) }
                OutlinedButton(onClick = { vm.preview(false) }) { Text("English preview") }
                Slide("গতি", rate, 0.5f..1.5f, { rate = it }) { vm.set(Keys.rate, rate) }
                Slide("পিচ", pitch, 0.7f..1.5f, { pitch = it }) { vm.set(Keys.pitch, pitch) }
                Slide("ভলিউম", volume, 0.3f..1f, { volume = it }) { vm.set(Keys.volume, volume) }
                SwitchRow("উত্তর নিজে নিজে বলবে", s.autoSpeak) { vm.set(Keys.autoSpeak, it) }
            }

            Section("ভয়েস ইন্টারাপশন (barge-in)") {
                SwitchRow("কথা বললে AI থেমে যাবে", s.bargeIn) { vm.set(Keys.bargeIn, it) }
                Slide("সংবেদনশীলতা (কম = বেশি সংবেদনশীল)", sens, 1.5f..6f, { sens = it }) { vm.set(Keys.sensitivity, sens) }
                Text("স্পিকারে জোরে আওয়াজ হলে AI নিজের কণ্ঠকে আপনার কথা ভেবে থেমে যেতে পারে। হেডফোন ব্যবহার করুন বা সংবেদনশীলতা কমান।", color = NX.Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(NX.Glass).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = NX.Cyan, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun VoicePicker(title: String, list: List<VoiceInfo>, selected: String, onPick: (String) -> Unit) {
    Text(title, color = NX.Text, fontSize = 13.sp)
    Column(Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().clickable { onPick("") }, verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected.isBlank(), { onPick("") }); Text("অটো (সেরা মানের)", color = NX.Text, fontSize = 12.sp)
        }
        list.forEach { v ->
            Row(Modifier.fillMaxWidth().clickable { onPick(v.name) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected == v.name, { onPick(v.name) })
                Text("${v.name} (${v.locale}${if (v.needsNetwork) ", অনলাইন" else ", অফলাইন"})", color = NX.Text, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Slide(name: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Text("$name: ${"%.2f".format(value)}", color = NX.Text, fontSize = 12.sp)
    Slider(value, onChange, valueRange = range, onValueChangeFinished = onDone)
}

@Composable
private fun SwitchRow(name: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = NX.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(on, onChange)
    }
}
