package com.nexora.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.ai.LiveViewModel
import com.nexora.ai.data.Keys
import com.nexora.ai.live.LiveState

private fun label(s: LiveState) = when (s) {
    LiveState.IDLE -> "অপেক্ষায়"
    LiveState.LISTENING -> "শুনছি…"
    LiveState.PROCESSING -> "বুঝছি…"
    LiveState.THINKING -> "ভাবছি…"
    LiveState.SPEAKING -> "বলছি (বাধা দিতে পারেন)"
    LiveState.INTERRUPTED -> "থেমে গেলাম"
    LiveState.SCREEN_SHARING -> "স্ক্রিন শেয়ারিং"
    LiveState.EXECUTING_TASK -> "কাজ চলছে"
    LiveState.WAITING_FOR_CONFIRMATION -> "নিশ্চিতকরণের অপেক্ষায়"
    LiveState.ERROR -> "ত্রুটি"
}

@Composable
fun LiveScreen(vm: LiveViewModel, onExit: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val e = vm.engine
    val state by e.state.collectAsStateWithLifecycle()
    val level by e.level.collectAsStateWithLifecycle()
    val userText by e.userText.collectAsStateWithLifecycle()
    val aiText by e.aiText.collectAsStateWithLifecycle()
    val error by e.error.collectAsStateWithLifecycle()
    val muted by e.muted.collectAsStateWithLifecycle()
    val active by e.active.collectAsStateWithLifecycle()
    val history by e.history.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    var hasMic by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        hasMic = ok
        if (ok) e.start()
    }
    fun startOrAsk() { if (hasMic) e.start() else launcher.launch(Manifest.permission.RECORD_AUDIO) }

    LaunchedEffect(Unit) { startOrAsk() }
    // No foreground service yet (phase 2): the mic must not keep running in the background.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { e.end() }

    Column(
        Modifier.fillMaxSize().nexoraBackground().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { e.end(); onExit() }) { Icon(Icons.Default.Close, "বন্ধ", tint = NX.Text) }
            Spacer(Modifier.weight(1f))
            StatusPill(if (active && !muted) "মাইক চালু" else "মাইক বন্ধ", active && !muted)
            Spacer(Modifier.width(6.dp))
            StatusPill("স্ক্রিন শেয়ার বন্ধ", false)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "সেটিংস", tint = NX.Text) }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            NexoraOrb(state, level, Modifier.sizeIn(maxWidth = 280.dp, maxHeight = 280.dp).fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true))
        }
        Text(label(state), color = NX.Cyan, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))

        if (error != null) {
            Text(error!!, color = NX.Danger, fontSize = 13.sp)
            if (error!!.contains("সেটিংস")) TextButton(onClick = onSettings) { Text("সেটিংস খুলুন") }
        }
        Transcript("আপনি", userText)
        Spacer(Modifier.height(6.dp))
        Transcript("NEXORA", aiText)
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 110.dp), reverseLayout = true) {
            items(history.takeLast(6).reversed()) { t ->
                Text(
                    (if (t.role == "user") "আপনি: " else "NEXORA: ") + t.text,
                    color = NX.Muted, fontSize = 11.sp, maxLines = 2, modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
            listOf("bn-BD" to "বাংলা", "en-US" to "English").forEach { (code, name) ->
                FilterChip(
                    selected = settings.recogLang == code,
                    onClick = { vm.set(Keys.recogLang, code) },
                    label = { Text("শোনা: $name") },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Ctl(if (muted) Icons.Default.MicOff else Icons.Default.Mic, if (muted) "আনমিউট" else "মিউট", enabled = active) { e.toggleMute() }
            Ctl(Icons.Default.PanTool, "থামান", enabled = active && (state == LiveState.SPEAKING || state == LiveState.THINKING)) { e.interrupt() }
            if (active) Ctl(Icons.Default.Stop, "শেষ", danger = true) { e.end() }
            else Ctl(Icons.Default.PlayArrow, "শুরু") { startOrAsk() }
            Ctl(Icons.Default.ScreenShare, "স্ক্রিন (ধাপ ৩)", enabled = false) {}
        }
    }
}

@Composable
private fun StatusPill(text: String, on: Boolean) {
    Text(
        text, fontSize = 11.sp, color = if (on) NX.Cyan else NX.Muted,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(NX.Glass).padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
private fun Transcript(who: String, text: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(NX.Glass).padding(10.dp).heightIn(min = 44.dp, max = 90.dp)) {
        Text(who, color = NX.Muted, fontSize = 10.sp)
        Text(text.ifBlank { "…" }, color = NX.Text, fontSize = 14.sp, maxLines = 3)
    }
}

@Composable
private fun Ctl(icon: ImageVector, name: String, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(if (enabled) 1f else 0.4f)) {
        FilledIconButton(
            onClick = onClick, enabled = enabled, shape = CircleShape, modifier = Modifier.size(54.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (danger) NX.Danger else NX.Purple.copy(alpha = 0.55f), contentColor = Color.White,
                disabledContainerColor = NX.Glass, disabledContentColor = NX.Muted
            )
        ) { Icon(icon, name) }
        Text(name, color = NX.Muted, fontSize = 10.sp)
    }
}
