@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.nexora.ai.ui.screens

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nexora.ai.container
import com.nexora.ai.data.AppSettings
import com.nexora.ai.data.SK
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.theme.NX
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit, openPermissions: () -> Unit, openToolLog: () -> Unit) {
    val ctx = LocalContext.current
    val c = ctx.container
    val scope = rememberCoroutineScope()
    val s by c.settings.flow.collectAsState(initial = AppSettings())
    var keyInput by remember { mutableStateOf("") }
    var keyMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var modelInput by remember(s.model) { mutableStateOf(s.model) }
    val voices = rememberTtsVoices(s.language)

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Section("Gemini API") {
                Text(
                    if (c.keys.get().isNotBlank()) "A key is configured (${if (c.keys.hasStoredKey()) "stored encrypted on device" else "from local.properties build config"})."
                    else "No API key yet. Get one from Google AI Studio and paste it below.",
                    color = if (c.keys.get().isNotBlank()) NX.Ok else NX.Danger
                )
                OutlinedTextField(
                    keyInput, { keyInput = it }, label = { Text("API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = keyInput.isNotBlank(), onClick = {
                        keyMsg = if (c.keys.set(keyInput)) "Saved securely." else "Secure storage unavailable on this device."
                        keyInput = ""
                    }) { Text("Save key") }
                    OutlinedButton(enabled = !testing, onClick = {
                        scope.launch {
                            testing = true; testResult = null
                            try { testResult = "✔ OK: " + c.gemini.generateOnce("Reply with one short word.", "ping").take(60) }
                            catch (e: Exception) { testResult = "✖ ${e.message}" }
                            finally { testing = false }
                        }
                    }) { Text("Test connection") }
                    if (testing) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
                keyMsg?.let { Text(it) }
                testResult?.let { Text(it, color = if (it.startsWith("✔")) NX.Ok else NX.Danger) }
                OutlinedTextField(modelInput, { modelInput = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-2.0-flash").forEach { m ->
                        FilterChip(s.model == m, { modelInput = m; scope.launch { c.settings.set(SK.model, m) } }, label = { Text(m) })
                    }
                }
                TextButton(onClick = { scope.launch { c.settings.set(SK.model, modelInput.trim().ifBlank { "gemini-2.5-flash" }) } }) { Text("Apply model name") }
            }

            Section("API usage & status") {
                Text("Requests: ${s.requests}   Failures: ${s.failures}")
                Text("Tokens — prompt: ${s.promptTokens}, output: ${s.outputTokens}")
                Text("Last error: ${s.lastError.ifBlank { "none" }}", color = if (s.lastError.isBlank()) NX.Muted else NX.Danger)
            }

            Section("Language & voice") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.language == "bn", { scope.launch { c.settings.set(SK.language, "bn"); c.settings.set(SK.voiceName, "") } }, label = { Text("বাংলা") })
                    FilterChip(s.language == "en", { scope.launch { c.settings.set(SK.language, "en"); c.settings.set(SK.voiceName, "") } }, label = { Text("English") })
                }
                if (voices.isEmpty()) Text("No installed TTS voices found for this language. Install one in Android Settings → Text-to-speech.", color = NX.Muted)
                else FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(s.voiceName.isBlank(), { scope.launch { c.settings.set(SK.voiceName, "") } }, label = { Text("Default") })
                    voices.take(12).forEach { v -> FilterChip(s.voiceName == v, { scope.launch { c.settings.set(SK.voiceName, v) } }, label = { Text(v.takeLast(18)) }) }
                }
                ToggleRow("Keep listening after each reply (voice chat)", s.continuousVoice) { scope.launch { c.settings.set(SK.continuousVoice, it) } }
                ToggleRow("Speak replies in text chat too", s.autoSpeak) { scope.launch { c.settings.set(SK.autoSpeak, it) } }
            }

            Section("Theme") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.accent == "cyan", { scope.launch { c.settings.set(SK.accent, "cyan") } }, label = { Text("Neon cyan") })
                    FilterChip(s.accent == "purple", { scope.launch { c.settings.set(SK.accent, "purple") } }, label = { Text("Electric purple") })
                }
                ToggleRow("AMOLED pure black", s.amoled) { scope.launch { c.settings.set(SK.amoled, it) } }
            }

            Section("Privacy") {
                ToggleRow("Allow screenshots to be sent to Gemini while sharing", s.screenConsent) { scope.launch { c.settings.set(SK.screenConsent, it) } }
                Text("When off, the AI never receives your screen even if sharing is on.", color = NX.Muted)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = openPermissions) { Text("Permissions") }
                OutlinedButton(onClick = openToolLog) { Text("Tool history") }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(value, onChange)
    }
}

@Composable
fun rememberTtsVoices(lang: String): List<String> {
    val ctx = LocalContext.current
    var names by remember(lang) { mutableStateOf(emptyList<String>()) }
    DisposableEffect(lang) {
        var tts: TextToSpeech? = null
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                names = tts?.voices?.filter { it.locale.language == lang }?.map { it.name }?.sorted().orEmpty()
            }
        }
        onDispose { tts?.shutdown() }
    }
    return names
}
