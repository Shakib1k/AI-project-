package com.nexora.ai.workspace

data class PreviewContent(val html: String = "", val sourcePath: String? = null, val version: Int = 0)

/** Builds a single self-contained HTML string by inlining relative CSS/JS files from the workspace. */
object PreviewBuilder {
    private val linkRe = Regex("""<link[^>]*href\s*=\s*["']([^"']+\.css)["'][^>]*>""", RegexOption.IGNORE_CASE)
    private val scriptRe = Regex("""<script[^>]*src\s*=\s*["']([^"']+\.js)["'][^>]*>\s*</script>""", RegexOption.IGNORE_CASE)

    suspend fun build(ws: WorkspaceRepo, htmlPath: String, version: Int = 0): PreviewContent {
        var html = ws.read(htmlPath)
        val dir = htmlPath.substringBeforeLast('/', "")
        html = inline(ws, html, dir, linkRe) { "<style>\n$it\n</style>" }
        html = inline(ws, html, dir, scriptRe) { "<script>\n$it\n</script>" }
        return PreviewContent(html, htmlPath, version)
    }

    private suspend fun inline(ws: WorkspaceRepo, html: String, dir: String, re: Regex, wrap: (String) -> String): String {
        val sb = StringBuilder()
        var last = 0
        for (m in re.findAll(html)) {
            sb.append(html, last, m.range.first)
            val ref = m.groupValues[1]
            val content = if (ref.startsWith("http") || ref.startsWith("//") || ref.startsWith("data:")) null
            else runCatching {
                val clean = ref.removePrefix("./")
                ws.read(if (clean.startsWith("/")) clean.trimStart('/') else if (dir.isEmpty()) clean else "$dir/$clean")
            }.getOrNull()
            sb.append(content?.let(wrap) ?: m.value)
            last = m.range.last + 1
        }
        sb.append(html, last, html.length)
        return sb.toString()
    }
}
