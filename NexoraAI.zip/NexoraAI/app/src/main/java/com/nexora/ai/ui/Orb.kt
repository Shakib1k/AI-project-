package com.nexora.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.nexora.ai.live.LiveState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NexoraOrb(state: LiveState, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val breath by t.animateFloat(
        0.94f, 1.05f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b"
    )
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "r")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "w")
    val lv by animateFloatAsState(level.coerceIn(0f, 1f), tween(120), label = "lv")

    val (c1, c2) = when (state) {
        LiveState.THINKING, LiveState.PROCESSING -> NX.Purple to NX.Cyan
        LiveState.SPEAKING -> NX.Cyan to NX.Purple
        LiveState.ERROR -> NX.Danger to NX.Purple
        LiveState.INTERRUPTED -> NX.Purple to NX.Purple
        else -> NX.Cyan to NX.Purple
    }
    val dim = if (state == LiveState.IDLE) 0.45f else 1f

    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = center
        val energy = when (state) {
            LiveState.LISTENING -> lv
            LiveState.SPEAKING -> 0.5f + 0.5f * sin(phase)
            else -> 0.15f
        }
        val core = r * 0.5f * breath * (1f + energy * 0.18f)

        drawCircle(
            Brush.radialGradient(listOf(c1.copy(alpha = 0.30f * dim), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )
        drawCircle(
            Brush.radialGradient(
                listOf(c1.copy(alpha = dim), c2.copy(alpha = dim), Color(0xFF05060F)), center = c, radius = core
            ),
            radius = core, center = c
        )
        rotate(rot, pivot = c) {
            drawCircle(
                Brush.sweepGradient(listOf(c1, Color.Transparent, c2, Color.Transparent, c1), center = c),
                radius = r * 0.86f, center = c, style = Stroke(3.dp.toPx())
            )
        }
        if (state == LiveState.SPEAKING || state == LiveState.LISTENING) {
            for (i in 0..2) {
                val rr = core * (1.25f + 0.22f * i) + 6.dp.toPx() * sin(phase - i) * energy
                drawCircle(c2.copy(alpha = 0.35f - 0.09f * i), radius = rr, center = c, style = Stroke(2.dp.toPx()))
            }
        }
        if (state == LiveState.THINKING || state == LiveState.PROCESSING || state == LiveState.EXECUTING_TASK) {
            for (i in 0 until 8) {
                val a = Math.toRadians((rot * 2 + i * 45).toDouble())
                val pr = r * 0.7f
                drawCircle(
                    c1, radius = 3.dp.toPx(),
                    center = Offset(c.x + (pr * cos(a)).toFloat(), c.y + (pr * sin(a)).toFloat())
                )
            }
        }
    }
}
