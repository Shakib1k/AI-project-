package com.nexora.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class Phase { Idle, Listening, Thinking, Speaking }

/** Wraps SpeechRecognizer (STT) and TextToSpeech. Must be created and used on the main thread. */
class VoiceController(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pending = 0
    private var utterId = 0
    private var lang = "bn"
    private var voiceName = ""

    var onQueueEmpty: (() -> Unit)? = null
    var ttsNote: String? = null
        private set
    val isSpeaking: Boolean get() = pending > 0

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { finishOne() }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { finishOne() }
    }

    private fun finishOne() {
        main.post {
            if (pending > 0) pending--
            if (pending == 0) onQueueEmpty?.invoke()
        }
    }

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(listener)
                applyLanguage()
            } else ttsNote = "Text-to-speech ইনিশিয়ালাইজ হয়নি।"
        }
    }

    fun configure(lang: String, voice: String) {
        if (lang != this.lang || voice != this.voiceName) {
            this.lang = lang; this.voiceName = voice
            if (ttsReady) applyLanguage()
        }
    }

    private fun applyLanguage() {
        val t = tts ?: return
        val loc = if (lang == "bn") Locale("bn", "BD") else Locale.US
        val r = t.setLanguage(loc)
        ttsNote = if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.US)
            "এই ফোনে ${if (lang == "bn") "বাংলা" else "English"} TTS voice নেই। Android Settings → Text-to-speech থেকে voice ইনস্টল করুন।"
        } else null
        if (voiceName.isNotBlank()) t.voices?.firstOrNull { it.name == voiceName }?.let { t.voice = it }
    }

    fun speak(text: String) {
        val t = tts
        if (!ttsReady || t == null || text.isBlank()) return
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        for (chunk in text.chunked(max)) {
            pending++
            val r = t.speak(chunk, TextToSpeech.QUEUE_ADD, null, "u${utterId++}")
            if (r != TextToSpeech.SUCCESS) pending--
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        pending = 0
    }

    private var watchdogRunnable: Runnable? = null

    fun isRecognitionAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun listen(
        lang: String,
        partial: (String) -> Unit,
        done: (String) -> Unit,
        fail: (String) -> Unit,
        level: (Float) -> Unit
    ) {
        stopListening()
        if (!isRecognitionAvailable()) {
            fail("এই ডিভাইসে speech recognition সার্ভিস নেই (Google app লাগবে)।")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        var retries = 0
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "bn") "bn-BD" else "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        armWatchdog(25_000) { stopListening(); fail("মাইক সাড়া দেয়নি। আবার ট্যাপ করুন।") }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { armWatchdog(30_000) { stopListening(); fail("মাইক সাড়া দেয়নি। আবার ট্যাপ করুন।") } }
            override fun onRmsChanged(rmsdB: Float) { level(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(partial)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                stopListening()
                if (t.isBlank()) fail("কিছু বুঝতে পারিনি, বস। আবার বলুন।") else done(t)
            }
            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        if (retries++ < 1) main.post { recognizer?.startListening(intent) }
                        else { stopListening(); fail("কিছু শুনতে পাইনি, বস। মাইক বাটনে ট্যাপ করুন।") }
                    }
                    SpeechRecognizer.ERROR_CLIENT -> {}
                    else -> { stopListening(); fail(describe(error)) }
                }
            }
        })
        r.startListening(intent)
    }

    private fun armWatchdog(ms: Long, action: () -> Unit) {
        watchdogRunnable?.let { main.removeCallbacks(it) }
        val w = Runnable { action() }
        watchdogRunnable = w
        main.postDelayed(w, ms)
    }

    fun stopListening() {
        watchdogRunnable?.let { main.removeCallbacks(it) }
        watchdogRunnable = null
        recognizer?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        recognizer = null
    }

    private fun describe(code: Int) = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোনে সমস্যা।"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission দিন।"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech-এর জন্য নেটওয়ার্ক সমস্যা।"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer ব্যস্ত, আবার চেষ্টা করুন।"
        SpeechRecognizer.ERROR_SERVER -> "Speech সার্ভার সমস্যা।"
        12, 13 -> "এই ভাষা speech recognition-এ সাপোর্টেড নয়/ডাউনলোড করা নেই।"
        else -> "Speech error ($code)।"
    }

    fun release() {
        stopListening()
        tts?.stop(); tts?.shutdown(); tts = null
    }
}

/** Speaks streamed text sentence-by-sentence; skips code blocks and strips markdown symbols. */
class SentenceSpeaker(private val voice: VoiceController) {
    private val buf = StringBuilder()
    private var inCode = false
    private val fenced = Regex("```[\\s\\S]*?```")

    fun reset() { buf.clear(); inCode = false }

    fun feed(delta: String) {
        buf.append(delta)
        while (true) {
            val idx = buf.indexOfFirst { it == '।' || it == '.' || it == '!' || it == '?' || it == '\n' }
            if (idx < 0) break
            val sentence = buf.substring(0, idx + 1)
            buf.delete(0, idx + 1)
            say(sentence)
        }
    }

    fun flush() {
        if (buf.isNotBlank()) say(buf.toString())
        buf.clear()
    }

    private fun say(raw: String) {
        var s = raw.replace(fenced, "")
        val fences = Regex("```").findAll(s).count()
        if (inCode) {
            if (fences % 2 == 1) { inCode = false; s = s.substringAfter("```") } else return
        } else if (fences > 0) {
            s = s.substringBefore("```")
            inCode = true
        }
        s = s.replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1").replace(Regex("[*#`~>|_]"), "").trim()
        if (s.length > 1) voice.speak(s)
    }
}
