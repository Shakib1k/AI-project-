package com.nexora.ai

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs
import kotlin.math.sin

enum class OrbState { IDLE, LISTENING, ANALYZING, THINKING, SPEAKING }

object Orb { val state = MutableStateFlow(OrbState.IDLE) }

/** Floating, draggable orb. Tap: describe screen. Long press: open Nexora. Red dot: sharing is active. */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class OrbView(
    context: Context,
    private val windows: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val onTap: () -> Unit,
    private val onHold: () -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragged = false
    private var downAt = 0L
    private val tick = object : Runnable {
        // ~25 fps keeps CPU use modest.
        override fun run() { invalidate(); postDelayed(this, 40) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f
        val cx = width / 2f
        val cy = height / 2f
        val state = Orb.state.value
        val breathe = 1f + 0.07f * sin(t * 2.5f)
        val r = width * 0.28f * breathe
        val inner = if (state == OrbState.THINKING) 0xFF7C4DFF.toInt() else 0xFF00E5FF.toInt()
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r * 1.6f, intArrayOf(inner, 0x887C4DFF.toInt(), 0), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 1.6f, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width * 0.025f
        paint.color = 0xFF00E5FF.toInt()
        val speed = if (state == OrbState.ANALYZING) 360f else 60f
        val ring = RectF(cx - r * 1.35f, cy - r * 1.35f, cx + r * 1.35f, cy + r * 1.35f)
        canvas.drawArc(ring, (t * speed) % 360, 110f, false, paint)
        paint.color = 0xFF7C4DFF.toInt()
        canvas.drawArc(ring, (t * speed + 180) % 360, 110f, false, paint)
        if (state == OrbState.SPEAKING || state == OrbState.LISTENING) {
            paint.color = Color.WHITE
            val amp = if (state == OrbState.SPEAKING) 0.6f else 0.25f
            for (i in -2..2) {
                val h = r * (0.15f + amp * abs(sin(t * 8f + i)))
                canvas.drawLine(cx + i * r * 0.25f, cy - h, cx + i * r * 0.25f, cy + h, paint)
            }
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.RED
        canvas.drawCircle(width * 0.84f, height * 0.16f, width * 0.07f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y
                dragged = false; downAt = e.eventTime
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (abs(dx) + abs(dy) > ViewConfiguration.get(context).scaledTouchSlop) dragged = true
                if (dragged) {
                    params.x = startX + dx.toInt(); params.y = startY + dy.toInt()
                    windows.updateViewLayout(this, params)
                }
            }
            MotionEvent.ACTION_UP -> if (!dragged) {
                if (e.eventTime - downAt > 500) onHold() else onTap()
            }
        }
        return true
    }
}
