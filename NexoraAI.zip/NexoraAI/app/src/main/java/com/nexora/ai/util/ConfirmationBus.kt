package com.nexora.ai.util

import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

data class ConfirmRequest(val title: String, val detail: String, val result: CompletableDeferred<Boolean>)

/**
 * Human-in-the-loop gate for destructive / sensitive actions.
 * The UI (MainActivity) shows a dialog for [pending]. If the user does not answer in 60s, the answer is "no".
 */
class ConfirmationBus(private val ctx: Context) {
    val pending = MutableStateFlow<ConfirmRequest?>(null)
    private val mutex = Mutex()

    suspend fun ask(title: String, detail: String): Boolean = mutex.withLock {
        val req = ConfirmRequest(title, detail, CompletableDeferred())
        pending.value = req
        Notifier.confirmNeeded(ctx, title)
        val answer = withTimeoutOrNull(60_000) { req.result.await() } ?: false
        if (pending.value === req) pending.value = null
        answer
    }
}
