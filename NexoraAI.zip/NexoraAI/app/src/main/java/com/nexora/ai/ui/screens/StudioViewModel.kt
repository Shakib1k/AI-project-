package com.nexora.ai.ui.screens

import android.app.Application
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.ai.NexoraApp
import com.nexora.ai.UiEvent
import com.nexora.ai.workspace.CodeTools
import com.nexora.ai.workspace.PreviewBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

data class EditorTab(val path: String, val value: TextFieldValue, val saved: String) {
    val dirty: Boolean get() = value.text != saved
}

data class StudioUi(
    val tabs: List<EditorTab> = emptyList(),
    val active: Int = 0,
    val busy: Boolean = false,
    val aiTitle: String? = null,
    val aiText: String? = null,
    val aiFix: String? = null,
    val message: String? = null
)

class StudioViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as NexoraApp).container
    val ui = MutableStateFlow(StudioUi())

    private fun cur(): EditorTab? = ui.value.tabs.getOrNull(ui.value.active)

    /** Runs a block with a busy flag that ALWAYS clears, surfacing errors as messages. */
    private suspend fun busy(block: suspend () -> Unit) {
        ui.update { it.copy(busy = true, message = null) }
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { ui.update { it.copy(message = e.message ?: e.toString()) } }
        finally { ui.update { it.copy(busy = false) } }
    }

    private suspend fun langName() = if (c.settings.flow.first().language == "bn") "Bengali" else "English"
    private suspend fun sys() =
        "You are an expert programming assistant inside the NEXORA AI coding studio. Be precise and practical. " +
            "Write explanations in ${langName()} (address the user as ${if (langName() == "Bengali") "বস" else "Boss"} briefly), keep code and code comments in English."

    fun select(i: Int) = ui.update { it.copy(active = i.coerceIn(0, (it.tabs.size - 1).coerceAtLeast(0))) }

    fun open(path: String) {
        val idx = ui.value.tabs.indexOfFirst { it.path == path }
        if (idx >= 0) { select(idx); return }
        viewModelScope.launch {
            busy {
                val text = c.workspace.read(path)
                ui.update { it.copy(tabs = it.tabs + EditorTab(path, TextFieldValue(text), text), active = it.tabs.size) }
            }
        }
    }

    fun newFile(path: String) {
        viewModelScope.launch {
            busy {
                val p = path.trim().trimStart('/')
                require(p.isNotBlank()) { "File name required" }
                if (!c.workspace.exists(p)) c.workspace.write(p, "")
                val text = c.workspace.read(p)
                ui.update { it.copy(tabs = it.tabs + EditorTab(p, TextFieldValue(text), text), active = it.tabs.size) }
            }
        }
    }

    fun close(i: Int) = ui.update {
        val t = it.tabs.toMutableList().also { l -> l.removeAt(i) }
        it.copy(tabs = t, active = it.active.coerceAtMost((t.size - 1).coerceAtLeast(0)))
    }

    fun edit(v: TextFieldValue) = ui.update { s ->
        val t = s.tabs.getOrNull(s.active) ?: return@update s
        val nv = CodeTools.autoIndent(t.value, v, CodeTools.langOf(t.path))
        s.copy(tabs = s.tabs.toMutableList().also { it[s.active] = t.copy(value = nv) })
    }

    private fun setText(text: String, cursor: Int = -1) = ui.update { s ->
        val t = s.tabs.getOrNull(s.active) ?: return@update s
        val pos = if (cursor >= 0) cursor else minOf(t.value.selection.start, text.length)
        s.copy(tabs = s.tabs.toMutableList().also { it[s.active] = t.copy(value = TextFieldValue(text, TextRange(pos))) })
    }

    private suspend fun saveAllInternal() {
        for (t in ui.value.tabs) {
            if (t.dirty) {
                c.workspace.write(t.path, t.value.text)
                ui.update { s -> s.copy(tabs = s.tabs.map { x -> if (x.path == t.path) x.copy(saved = t.value.text) else x }) }
            }
        }
    }

    fun saveAll() { viewModelScope.launch { busy { saveAllInternal(); ui.update { it.copy(message = "Saved ✔") } } } }

    fun format() {
        val t = cur() ?: return
        try { setText(CodeTools.format(CodeTools.langOf(t.path), t.value.text)) }
        catch (e: Exception) { ui.update { it.copy(message = e.message) } }
    }

    fun closeAi() = ui.update { it.copy(aiTitle = null, aiText = null, aiFix = null) }
    fun clearMessage() = ui.update { it.copy(message = null) }

    fun explain() {
        val t = cur() ?: return
        viewModelScope.launch {
            busy {
                val r = c.gemini.generateOnce(sys(), "Explain this ${CodeTools.langOf(t.path)} code (file ${t.path}) clearly and step by step:\n```\n${t.value.text.take(12000)}\n```")
                ui.update { it.copy(aiTitle = "Explanation", aiText = r, aiFix = null) }
            }
        }
    }

    fun debug(errorText: String) {
        val t = cur() ?: return
        viewModelScope.launch {
            busy {
                val schema = buildJsonObject {
                    put("type", "OBJECT")
                    put("properties", buildJsonObject {
                        put("analysis", buildJsonObject { put("type", "STRING") })
                        put("fixedCode", buildJsonObject { put("type", "STRING") })
                    })
                    put("required", JsonArray(listOf(JsonPrimitive("analysis"), JsonPrimitive("fixedCode"))))
                }
                val prompt = "Analyze this ${CodeTools.langOf(t.path)} code for bugs and errors." +
                    (if (errorText.isNotBlank()) "\nReported error/output:\n$errorText" else "") +
                    "\nReturn JSON: analysis (explanation of problems) and fixedCode (the COMPLETE corrected file).\n```\n${t.value.text.take(12000)}\n```"
                val obj = parseJson(c.gemini.generateOnce(sys(), prompt, schema)).jsonObject
                ui.update {
                    it.copy(aiTitle = "Debug analysis", aiText = obj["analysis"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                        aiFix = obj["fixedCode"]?.jsonPrimitive?.contentOrNull)
                }
            }
        }
    }

    fun applyFix() {
        val fix = ui.value.aiFix ?: return
        setText(fix, 0)
        closeAi()
    }

    fun complete() {
        val t = cur() ?: return
        viewModelScope.launch {
            busy {
                val v = t.value
                val before = v.text.substring(0, v.selection.start).takeLast(4000)
                val after = v.text.substring(v.selection.end).take(1000)
                val prompt = "Complete the ${CodeTools.langOf(t.path)} code at <CURSOR>. Return ONLY the code to insert, no explanation, no markdown fences.\n$before<CURSOR>$after"
                val ins = stripFences(c.gemini.generateOnce(sys(), prompt))
                val full = v.text.substring(0, v.selection.start) + ins + v.text.substring(v.selection.end)
                setText(full, v.selection.start + ins.length)
            }
        }
    }

    fun generate(request: String) {
        viewModelScope.launch {
            busy {
                fun s(t: String) = buildJsonObject { put("type", t) }
                val schema = buildJsonObject {
                    put("type", "OBJECT")
                    put("properties", buildJsonObject {
                        put("projectFolder", s("STRING"))
                        put("summary", s("STRING"))
                        put("files", buildJsonObject {
                            put("type", "ARRAY")
                            put("items", buildJsonObject {
                                put("type", "OBJECT")
                                put("properties", buildJsonObject { put("path", s("STRING")); put("content", s("STRING")) })
                                put("required", JsonArray(listOf(JsonPrimitive("path"), JsonPrimitive("content"))))
                            })
                        })
                    })
                    put("required", JsonArray(listOf(JsonPrimitive("projectFolder"), JsonPrimitive("summary"), JsonPrimitive("files"))))
                }
                val prompt = "Create a complete, working project for this request:\n$request\n\n" +
                    "Rules: return JSON with projectFolder (short folder name, no spaces), summary (short, mention dependencies / how to run), " +
                    "files (each with relative path and FULL content). For websites use index.html + style.css + script.js linked relatively. " +
                    "For Python include requirements.txt when third-party libraries are used. Max 12 files."
                val obj = parseJson(c.gemini.generateOnce(sys(), prompt, schema)).jsonObject
                val folder = obj["projectFolder"]?.jsonPrimitive?.contentOrNull.orEmpty().replace(Regex("[^A-Za-z0-9_.-]"), "_").ifBlank { "project" }
                val files = obj["files"]?.jsonArray ?: error("AI returned no files")
                val paths = mutableListOf<String>()
                for (f in files.take(12)) {
                    val o = f.jsonObject
                    val rel = o["path"]?.jsonPrimitive?.contentOrNull?.trim()?.trimStart('/').orEmpty()
                    if (rel.isBlank()) continue
                    val content = o["content"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    c.workspace.write("$folder/$rel", content)
                    paths += "$folder/$rel"
                }
                ui.update { it.copy(tabs = emptyList(), active = 0) }
                for (p in paths.take(8)) {
                    val text = c.workspace.read(p)
                    ui.update { it.copy(tabs = it.tabs + EditorTab(p, TextFieldValue(text), text)) }
                }
                val summary = obj["summary"]?.jsonPrimitive?.contentOrNull.orEmpty()
                ui.update {
                    it.copy(aiTitle = "Project created: $folder", aiFix = null,
                        aiText = summary + "\n\nSaved ${paths.size} files (verified): " + paths.joinToString(", ") +
                            if (paths.any { p -> p.endsWith(".html") }) "\n\nTap the Preview (eye) button to see it live." else "")
                }
            }
        }
    }

    /** Saves tabs, builds the preview from the workspace, then calls [then] (e.g. to navigate). */
    fun preview(then: () -> Unit) {
        viewModelScope.launch {
            busy {
                saveAllInternal()
                val path = cur()?.path?.takeIf { CodeTools.langOf(it) == "html" }
                    ?: ui.value.tabs.firstOrNull { CodeTools.langOf(it.path) == "html" }?.path
                    ?: error("Preview করার জন্য কোনো HTML ফাইল খোলা নেই।")
                c.preview.value = PreviewBuilder.build(c.workspace, path, c.preview.value.version + 1)
                then()
            }
        }
    }

    private fun stripFences(t: String): String {
        val s = t.trim()
        if (!s.startsWith("```")) return s
        return s.substringAfter('\n', "").removeSuffix("```").trimEnd()
    }

    private fun parseJson(t: String): JsonElement {
        val cleaned = t.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return Json.parseToJsonElement(cleaned)
    }
}
