package com.nexora.ai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "nexora_settings")

data class Settings(
    val apiKey: String = "",
    val model: String = "",
    val recogLang: String = "bn-BD",
    val voiceBn: String = "",
    val voiceEn: String = "",
    val rate: Float = 1.0f,
    val pitch: Float = 1.05f,
    val volume: Float = 1.0f,
    val autoSpeak: Boolean = true,
    val bargeIn: Boolean = true,
    val bargeSensitivity: Float = 3.0f
)

object Keys {
    val apiKey = stringPreferencesKey("api_key")
    val model = stringPreferencesKey("model")
    val recogLang = stringPreferencesKey("recog_lang")
    val voiceBn = stringPreferencesKey("voice_bn")
    val voiceEn = stringPreferencesKey("voice_en")
    val rate = floatPreferencesKey("rate")
    val pitch = floatPreferencesKey("pitch")
    val volume = floatPreferencesKey("volume")
    val autoSpeak = booleanPreferencesKey("auto_speak")
    val bargeIn = booleanPreferencesKey("barge_in")
    val sensitivity = floatPreferencesKey("barge_sensitivity")
}

class SettingsStore(private val context: Context) {
    val flow: Flow<Settings> = context.dataStore.data.map { p ->
        val d = Settings()
        Settings(
            apiKey = p[Keys.apiKey] ?: d.apiKey,
            model = p[Keys.model] ?: d.model,
            recogLang = p[Keys.recogLang] ?: d.recogLang,
            voiceBn = p[Keys.voiceBn] ?: d.voiceBn,
            voiceEn = p[Keys.voiceEn] ?: d.voiceEn,
            rate = p[Keys.rate] ?: d.rate,
            pitch = p[Keys.pitch] ?: d.pitch,
            volume = p[Keys.volume] ?: d.volume,
            autoSpeak = p[Keys.autoSpeak] ?: d.autoSpeak,
            bargeIn = p[Keys.bargeIn] ?: d.bargeIn,
            bargeSensitivity = p[Keys.sensitivity] ?: d.bargeSensitivity
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { it[key] = value }
    }
}
