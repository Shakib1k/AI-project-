package com.nexora.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun Header(title: String, back: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = back) { Text("‹ Back") }
        Text(title, fontSize = 22.sp, color = Color.White)
    }
}

@Composable
fun Confirm(title: String, body: String, yes: () -> Unit, no: () -> Unit) {
    AlertDialog(onDismissRequest = no, title = { Text(title) }, text = { Text(body) },
        confirmButton = { TextButton(onClick = yes) { Text("Allow") } },
        dismissButton = { TextButton(onClick = no) { Text("Cancel") } })
}

@Composable
fun ChatScreen(model: NexoraViewModel, back: () -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var attachScreen by remember { mutableStateOf(false) }
    var screenConsent by remember { mutableStateOf(false) }
    var agentConsent by remember { mutableStateOf(false) }
    val sharing by ScreenService.active.collectAsStateWithLifecycle()
    val task by TaskRunner.state.collectAsStateWithLifecycle()
    val list = rememberLazyListState()

    val capture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            context.startForegroundService(Intent(context, ScreenService::class.java)
                .putExtra("code", result.resultCode).putExtra("data", data))
        } else model.status = "Screen capture permission was not granted."
    }
    val microphone = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) model.startVoice() else model.status = "Microphone permission was denied."
    }
    LaunchedEffect(model.chat.messages.size) {
        if (model.chat.messages.isNotEmpty()) list.animateScrollToItem(model.chat.messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Header("Chat", back)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(model.liveVoice, {
                if (model.liveVoice) model.stopVoice()
                else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) model.startVoice()
                else microphone.launch(Manifest.permission.RECORD_AUDIO)
            }, { Text("Live voice") })
            FilterChip(model.agentMode, {
                if (model.agentMode) { model.agentMode = false; TaskRunner.stop() } else agentConsent = true
            }, { Text("Phone task") })
            FilterChip(sharing, {
                if (sharing) context.stopService(Intent(context, ScreenService::class.java)) else screenConsent = true
            }, { Text(if (sharing) "Stop sharing" else "Start Screen Sharing") })
            if (sharing && !model.agentMode) FilterChip(attachScreen, { attachScreen = !attachScreen }, { Text("Send screen with messages") })
        }
        if (model.status.isNotBlank()) Text(model.status, color = Cyan, fontSize = 13.sp)
        if (task.status != TaskStatus.IDLE) TaskCard(task) { TaskRunner.start(context, task.goal) }
        LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(model.chat.messages) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = if (m.role == "user") Purple.copy(alpha = .25f) else Panel),
                    modifier = Modifier.fillMaxWidth()) {
                    SelectionContainer { Text(m.text, Modifier.padding(12.dp), color = Color.White) }
                }
            }
        }
        if (model.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), maxLines = 4,
                placeholder = { Text(if (model.agentMode) "Describe the task" else "বার্তা লিখুন / Message") })
            if (model.busy) TextButton(onClick = { model.cancelReply() }) { Text("Stop") }
            TextButton(onClick = { model.send(input, attachScreen && sharing); input = "" }) { Text("Send") }
        }
    }

    if (screenConsent) Confirm("Share your screen?",
        "While sharing, a screen image goes to Google Gemini when you tap the orb, or with each message while 'Send screen with messages' is on. It can include private content. Choose 'Entire screen' if Android asks.",
        yes = {
            screenConsent = false
            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            capture.launch(if (Build.VERSION.SDK_INT >= 34)
                manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            else manager.createScreenCaptureIntent())
        }, no = { screenConsent = false })
    if (agentConsent) Confirm("Turn on phone tasks?",
        "While a task runs, visible on-screen text (including private messages and file contents) is sent to Google Gemini. Risky taps ask first, and a STOP button stays on screen.",
        yes = { agentConsent = false; model.agentMode = true }, no = { agentConsent = false })
}

@Composable
fun TaskCard(task: TaskState, retry: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp)) {
            Text("TASK: ${task.goal}", color = Color.White)
            Text(task.status.name, color = Cyan)
            task.steps.takeLast(4).forEach { Text(it, fontSize = 12.sp, color = Color(0xFF9AA6BF)) }
            if (task.message.isNotBlank()) Text(task.message, fontSize = 13.sp, color = Color.White)
            Row {
                if (task.status == TaskStatus.RUNNING) TextButton(onClick = { TaskRunner.stop() }) { Text("Stop") }
                else TextButton(onClick = retry) { Text("Retry") }
                if (task.status != TaskStatus.RUNNING) TextButton(onClick = { TaskRunner.state.value = TaskState() }) { Text("Dismiss") }
            }
        }
    }
}
