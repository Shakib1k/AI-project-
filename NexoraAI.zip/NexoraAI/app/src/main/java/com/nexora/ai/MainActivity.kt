package com.nexora.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.nexora.ai.data.AppSettings
import com.nexora.ai.screen.ScreenCaptureService
import com.nexora.ai.screen.ScreenShare
import com.nexora.ai.ui.components.NexoraBackground
import com.nexora.ai.ui.screens.*
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.ui.theme.NexoraTheme

class MainActivity : ComponentActivity() {
    private val chatVm: ChatViewModel by viewModels()
    private val studioVm: StudioViewModel by viewModels()
    private val filesVm: FilesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NexoraRoot(chatVm, studioVm, filesVm) }
    }
}

private const val CHAT_ROUTE = "chat/{id}?voice={voice}"

@Composable
fun NexoraRoot(chatVm: ChatViewModel, studioVm: StudioViewModel, filesVm: FilesViewModel) {
    val ctx = LocalContext.current
    val c = ctx.container
    val s by c.settings.flow.collectAsState(initial = AppSettings())
    NexoraTheme(s.accent, s.amoled) {
        val nav = rememberNavController()
        val sharing by ScreenShare.active.collectAsState()
        val pending by c.confirmations.pending.collectAsState()

        LaunchedEffect(Unit) {
            c.uiEvents.collect { ev ->
                when (ev) {
                    UiEvent.OpenPreview -> nav.navigate("preview") { launchSingleTop = true }
                    is UiEvent.OpenStudio -> { studioVm.open(ev.path); nav.navigate("studio") { launchSingleTop = true } }
                }
            }
        }

        Box(Modifier.fillMaxSize()) {
            NexoraBackground()
            Column(Modifier.fillMaxSize()) {
                if (sharing) {
                    Row(
                        Modifier.fillMaxWidth().background(NX.Danger.copy(alpha = .85f)).statusBarsPadding().padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("● Screen sharing is ON — NEXORA can see your screen", Modifier.weight(1f), color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { ScreenCaptureService.stop(ctx) }) { Text("Stop", color = androidx.compose.ui.graphics.Color.White) }
                    }
                }
                Box(Modifier.weight(1f).then(if (sharing) Modifier.consumeWindowInsets(WindowInsets.statusBars) else Modifier)) {
                    NavHost(nav, startDestination = "dashboard") {
                        composable("dashboard") { DashboardScreen(go = { nav.navigate(it) }) }
                        composable(
                            CHAT_ROUTE,
                            arguments = listOf(
                                navArgument("id") { type = NavType.LongType },
                                navArgument("voice") { type = NavType.BoolType; defaultValue = false }
                            )
                        ) { e ->
                            val id = e.arguments?.getLong("id") ?: -1L
                            val voice = e.arguments?.getBoolean("voice") ?: false
                            ChatScreen(
                                chatVm, id, voice, onBack = { nav.popBackStack() },
                                onChatCreated = { newId ->
                                    nav.navigate("chat/$newId?voice=false") { popUpTo(CHAT_ROUTE) { inclusive = true } }
                                }
                            )
                        }
                        composable("history") {
                            HistoryScreen(onBack = { nav.popBackStack() }, open = { nav.navigate("chat/$it?voice=false") })
                        }
                        composable("studio") { StudioScreen(studioVm, onBack = { nav.popBackStack() }, onPreview = { nav.navigate("preview") { launchSingleTop = true } }) }
                        composable("files") { FilesScreen(filesVm, onBack = { nav.popBackStack() }) }
                        composable("preview") { PreviewScreen(onBack = { nav.popBackStack() }) }
                        composable("automation") { AutomationScreen(onBack = { nav.popBackStack() }, openToolLog = { nav.navigate("toollog") }) }
                        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }, openPermissions = { nav.navigate("permissions") }, openToolLog = { nav.navigate("toollog") }) }
                        composable("permissions") { PermissionsScreen(onBack = { nav.popBackStack() }) }
                        composable("toollog") { ToolLogScreen(onBack = { nav.popBackStack() }) }
                    }
                }
            }
        }

        pending?.let { req ->
            AlertDialog(
                onDismissRequest = { req.result.complete(false); c.confirmations.pending.value = null },
                title = { Text(req.title) },
                text = { Text(req.detail) },
                confirmButton = { TextButton(onClick = { req.result.complete(true); c.confirmations.pending.value = null }) { Text("Allow") } },
                dismissButton = { TextButton(onClick = { req.result.complete(false); c.confirmations.pending.value = null }) { Text("Deny") } }
            )
        }
    }
}
