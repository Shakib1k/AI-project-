package com.nexora.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF00E5FF)
val Purple = Color(0xFF7C4DFF)
val Ink = Color(0xFF05070D)
val Panel = Color(0xFF0D1220)

class MainActivity : ComponentActivity() {
    private val model: NexoraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, secondary = Purple, background = Ink, surface = Panel, onPrimary = Ink)) {
                Surface(Modifier.fillMaxSize(), color = Ink) {
                    Box(Modifier.safeDrawingPadding()) { App(model) }
                }
            }
        }
    }

    override fun onStop() {
        // The microphone is only used while Nexora is visible.
        model.stopVoice()
        super.onStop()
    }
}

@Composable
fun App(model: NexoraViewModel) {
    var page by rememberSaveable { mutableStateOf("home") }
    fun leave() { model.stopVoice(); page = "home" }
    BackHandler(page != "home") { leave() }
    when (page) {
        "chat" -> ChatScreen(model, ::leave)
        "code" -> CodingStudio(model, ::leave)
        "history" -> HistoryScreen(model, ::leave) { model.openChat(it); page = "chat" }
        "settings" -> SettingsScreen(model, ::leave)
        else -> Dashboard { if (it == "chat") model.newChat(); page = it }
    }
}

@Composable
fun Dashboard(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(32.dp))
        Text("Nexora", fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("What shall we build today?", fontSize = 18.sp, color = Color(0xFF9AA6BF))
        Spacer(Modifier.height(18.dp))
        DashboardBlock("New chat", "Text and live voice") { open("chat") }
        DashboardBlock("Coding Studio", "Write, generate and preview") { open("code") }
        DashboardBlock("Chat history", "Continue a conversation") { open("history") }
        DashboardBlock("Settings", "API, voice and permissions") { open("settings") }
    }
}

@Composable
private fun DashboardBlock(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Purple.copy(alpha = .35f))) {
        Column(Modifier.padding(22.dp)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(subtitle, fontSize = 13.sp, color = Color(0xFF7F8BA6))
        }
    }
}
