package com.nexora.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexora.ai.ui.DashboardScreen
import com.nexora.ai.ui.LiveScreen
import com.nexora.ai.ui.NexoraTheme
import com.nexora.ai.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexoraTheme {
                val vm: LiveViewModel = viewModel()
                var screen by rememberSaveable { mutableStateOf("home") }
                BackHandler(enabled = screen != "home") {
                    if (screen == "live") vm.engine.end()
                    screen = "home"
                }
                when (screen) {
                    "live" -> LiveScreen(vm, onExit = { screen = "home" }, onSettings = { vm.engine.end(); screen = "settings" })
                    "settings" -> SettingsScreen(vm, onBack = { screen = "home" })
                    else -> DashboardScreen(onLive = { screen = "live" }, onSettings = { screen = "settings" })
                }
            }
        }
    }
}
