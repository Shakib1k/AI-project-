@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.ai.container
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.components.PreviewPane
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.workspace.CodeTools
import com.nexora.ai.workspace.FileItem
import com.nexora.ai.workspace.Highlighter

@Composable
fun StudioScreen(vm: StudioViewModel, onBack: () -> Unit, onPreview: () -> Unit) {
    val c = LocalContext.current.container
    val ui by vm.ui.collectAsState()
    val previewContent by c.preview.collectAsState()
    val console = remember { mutableStateListOf<String>() }
    val cs = MaterialTheme.colorScheme
    val snack = remember { SnackbarHostState() }
    var showOpen by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var showGen by remember { mutableStateOf(false) }
    var showDebug by remember { mutableStateOf(false) }
    val tab = ui.tabs.getOrNull(ui.active)
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    val isHtml = tab != null && CodeTools.langOf(tab.path) == "html"

    LaunchedEffect(ui.message) { ui.message?.let { snack.showSnackbar(it); vm.clearMessage() } }

    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("Coding Studio") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = { vm.saveAll() }) { Icon(Icons.Default.Save, "Save all") }
                    IconButton(onClick = { vm.preview { if (wide) Unit else onPreview() } }) { Icon(Icons.Default.Visibility, "Preview") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (ui.tabs.isNotEmpty()) {
                ScrollableTabRow(selectedTabIndex = ui.active.coerceIn(0, ui.tabs.size - 1), edgePadding = 8.dp, containerColor = Color.Transparent) {
                    ui.tabs.forEachIndexed { i, t ->
                        Tab(selected = i == ui.active, onClick = { vm.select(i) }) {
                            Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(t.path.substringAfterLast('/') + if (t.dirty) " •" else "", maxLines = 1)
                                IconButton(onClick = { vm.close(i) }, Modifier.size(24.dp)) { Icon(Icons.Default.Close, "Close", Modifier.size(14.dp)) }
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToolChip(Icons.Default.NoteAdd, "New") { showNew = true }
                ToolChip(Icons.Default.FolderOpen, "Open") { showOpen = true }
                ToolChip(Icons.Default.AutoFixHigh, "Generate") { showGen = true }
                if (tab != null) {
                    ToolChip(Icons.Default.FormatAlignLeft, "Format") { vm.format() }
                    ToolChip(Icons.Default.Lightbulb, "Explain") { vm.explain() }
                    ToolChip(Icons.Default.BugReport, "Debug") { showDebug = true }
                    ToolChip(Icons.Default.Code, "Complete") { vm.complete() }
                }
            }

            if (tab == null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("New / Open / Generate দিয়ে শুরু করুন, বস।", color = cs.onSurfaceVariant)
                }
            } else {
                val lang = CodeTools.langOf(tab.path)
                val transform = remember(lang) { VisualTransformation { t -> TransformedText(Highlighter.highlight(t.text, lang), OffsetMapping.Identity) } }
                val editor: @Composable (Modifier) -> Unit = { m ->
                    Box(m.verticalScroll(rememberScrollState()).padding(8.dp)) {
                        BasicTextField(
                            value = tab.value, onValueChange = { vm.edit(it) },
                            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = NX.Text, lineHeight = 19.sp),
                            cursorBrush = SolidColor(cs.primary),
                            visualTransformation = transform,
                            keyboardOptions = KeyboardOptions(autoCorrect = false, capitalization = KeyboardCapitalization.None),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 300.dp)
                        )
                    }
                }
                if (wide && isHtml) {
                    Row(Modifier.weight(1f)) {
                        editor(Modifier.weight(1f).fillMaxHeight())
                        Column(Modifier.weight(1f).fillMaxHeight()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Live preview", Modifier.weight(1f).padding(8.dp), color = cs.primary)
                                IconButton(onClick = { vm.preview {} }) { Icon(Icons.Default.Refresh, "Refresh preview") }
                            }
                            PreviewPane(previewContent, null, console, Modifier.weight(1f).fillMaxWidth())
                            ConsolePanel(console)
                        }
                    }
                } else editor(Modifier.weight(1f).fillMaxWidth())
            }

            if (ui.aiText != null) {
                GlassCard(Modifier.fillMaxWidth().padding(8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(ui.aiTitle.orEmpty(), color = cs.primary, style = MaterialTheme.typography.titleMedium)
                        Box(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) { Text(ui.aiText.orEmpty()) }
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            if (ui.aiFix != null) TextButton(onClick = { vm.applyFix() }) { Text("Apply fix") }
                            TextButton(onClick = { vm.closeAi() }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var n by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNew = false }, title = { Text("New file") },
            text = { OutlinedTextField(n, { n = it }, label = { Text("e.g. app/main.py") }, singleLine = true) },
            confirmButton = { TextButton(enabled = n.isNotBlank(), onClick = { vm.newFile(n); showNew = false }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancel") } }
        )
    }
    if (showGen) {
        var p by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGen = false }, title = { Text("AI project generator") },
            text = { OutlinedTextField(p, { p = it }, label = { Text("কী বানাতে চান? (e.g. premium HTML landing page)") }, minLines = 3) },
            confirmButton = { TextButton(enabled = p.isNotBlank(), onClick = { vm.generate(p); showGen = false }) { Text("Generate") } },
            dismissButton = { TextButton(onClick = { showGen = false }) { Text("Cancel") } }
        )
    }
    if (showDebug) {
        var e by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDebug = false }, title = { Text("Debug / error analysis") },
            text = { OutlinedTextField(e, { e = it }, label = { Text("Error message / traceback (optional)") }, minLines = 3) },
            confirmButton = { TextButton(onClick = { vm.debug(e); showDebug = false }) { Text("Analyze") } },
            dismissButton = { TextButton(onClick = { showDebug = false }) { Text("Cancel") } }
        )
    }
    if (showOpen) WorkspacePicker(onPick = { vm.open(it); showOpen = false }, onDismiss = { showOpen = false })
}

@Composable
private fun ToolChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    AssistChip(onClick = onClick, label = { Text(label) }, leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) })
}

@Composable
private fun WorkspacePicker(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalContext.current.container
    var path by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(path) {
        try { items = c.workspace.list(path); error = null } catch (e: Exception) { error = e.message }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open file  /$path") },
        text = {
            Column {
                error?.let { Text(it, color = NX.Danger) }
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    if (path.isNotEmpty()) item { TextButton(onClick = { path = path.substringBeforeLast('/', "") }) { Text("⬆ ..") } }
                    items(items, key = { it.path }) { f ->
                        TextButton(onClick = { if (f.isDir) path = f.path else onPick(f.path) }, modifier = Modifier.fillMaxWidth()) {
                            Text((if (f.isDir) "📁 " else "📄 ") + f.name, Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
