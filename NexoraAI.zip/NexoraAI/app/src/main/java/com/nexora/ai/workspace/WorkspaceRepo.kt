package com.nexora.ai.workspace

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.nexora.ai.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class FileItem(val name: String, val path: String, val isDir: Boolean, val size: Long)

/**
 * File workspace on top of DocumentFile: works for a user-chosen SAF folder (OpenDocumentTree)
 * and falls back to app-private storage (filesDir/workspace) until a folder is chosen.
 */
class WorkspaceRepo(private val ctx: Context, private val settings: SettingsStore) {

    private fun split(p: String) = p.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." && it != ".." }

    suspend fun root(): DocumentFile = withContext(Dispatchers.IO) {
        val uri = settings.flow.first().workspaceUri
        if (uri.isNotBlank()) {
            val d = runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(uri)) }.getOrNull()
            if (d != null && d.exists() && d.canWrite()) return@withContext d
        }
        DocumentFile.fromFile(File(ctx.filesDir, "workspace").apply { mkdirs() })
    }

    suspend fun isCustomLocation(): Boolean = settings.flow.first().workspaceUri.isNotBlank()

    suspend fun find(path: String): DocumentFile? = withContext(Dispatchers.IO) {
        var cur = root()
        for (s in split(path)) cur = cur.findFile(s) ?: return@withContext null
        cur
    }

    suspend fun exists(path: String) = find(path) != null

    suspend fun ensureDir(path: String): DocumentFile = withContext(Dispatchers.IO) {
        var cur = root()
        for (s in split(path)) {
            val n = cur.findFile(s)
            cur = when {
                n == null -> cur.createDirectory(s) ?: error("Cannot create folder $s")
                n.isDirectory -> n
                else -> error("$s is a file, not a folder")
            }
        }
        cur
    }

    suspend fun list(path: String = ""): List<FileItem> = withContext(Dispatchers.IO) {
        val d = find(path) ?: return@withContext emptyList()
        val base = split(path).joinToString("/")
        d.listFiles().mapNotNull { f ->
            val n = f.name ?: return@mapNotNull null
            FileItem(n, if (base.isEmpty()) n else "$base/$n", f.isDirectory, if (f.isFile) f.length() else 0L)
        }.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    suspend fun read(path: String): String = withContext(Dispatchers.IO) {
        val d = find(path) ?: error("File not found: $path")
        require(d.isFile) { "$path is a folder" }
        require(d.length() <= 1_500_000) { "File too large to open" }
        ctx.contentResolver.openInputStream(d.uri)?.bufferedReader()?.use { it.readText() } ?: error("Cannot read $path")
    }

    /** Writes then reads back to verify. "application/octet-stream" keeps the exact file name on every provider. */
    suspend fun write(path: String, content: String): Uri = withContext(Dispatchers.IO) {
        val parts = split(path)
        require(parts.isNotEmpty()) { "Empty path" }
        val dir = ensureDir(parts.dropLast(1).joinToString("/"))
        val name = parts.last()
        val doc = dir.findFile(name) ?: dir.createFile("application/octet-stream", name) ?: error("Cannot create $name")
        require(doc.isFile) { "$name is a folder" }
        ctx.contentResolver.openOutputStream(doc.uri, "wt")?.use { it.write(content.toByteArray()) } ?: error("Cannot open $name for writing")
        val back = ctx.contentResolver.openInputStream(doc.uri)?.bufferedReader()?.use { it.readText() }
        check(back == content) { "Write verification failed for $name" }
        doc.uri
    }

    suspend fun rename(path: String, newName: String): String = withContext(Dispatchers.IO) {
        require(newName.isNotBlank() && !newName.contains('/')) { "Invalid name" }
        val d = find(path) ?: error("Not found: $path")
        check(d.renameTo(newName)) { "Rename failed" }
        split(path).dropLast(1).plus(newName).joinToString("/")
    }

    suspend fun delete(path: String) = withContext(Dispatchers.IO) {
        require(split(path).isNotEmpty()) { "Refusing to delete workspace root" }
        val d = find(path) ?: error("Not found: $path")
        check(d.delete()) { "Delete failed" }
    }

    fun shareableUri(doc: DocumentFile): Uri =
        if (doc.uri.scheme == "file") FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(doc.uri.path!!))
        else doc.uri

    suspend fun zipTo(path: String, out: Uri): Int = withContext(Dispatchers.IO) {
        val dir = find(path) ?: error("Not found: $path")
        var count = 0
        val os = ctx.contentResolver.openOutputStream(out) ?: error("Cannot open output file")
        os.use {
            ZipOutputStream(it.buffered()).use { zip ->
                fun add(d: DocumentFile, prefix: String) {
                    for (f in d.listFiles()) {
                        val name = f.name ?: continue
                        if (f.isDirectory) add(f, "$prefix$name/")
                        else {
                            zip.putNextEntry(ZipEntry(prefix + name))
                            ctx.contentResolver.openInputStream(f.uri)?.use { s -> s.copyTo(zip) }
                            zip.closeEntry()
                            count++
                        }
                    }
                }
                add(dir, if (split(path).isEmpty()) "" else "${dir.name}/")
            }
        }
        count
    }
}
