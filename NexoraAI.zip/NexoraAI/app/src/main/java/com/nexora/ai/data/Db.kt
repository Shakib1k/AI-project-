package com.nexora.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    foreignKeys = [ForeignKey(entity = ChatEntity::class, parentColumns = ["id"], childColumns = ["chatId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("chatId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val role: String, // "user" | "model"
    val text: String,
    val createdAt: Long,
    val hasImage: Boolean = false,
    val isError: Boolean = false
)

@Entity
data class ToolLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val name: String,
    val args: String,
    val result: String,
    val ok: Boolean,
    val createdAt: Long
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM ChatEntity ORDER BY updatedAt DESC")
    fun chats(): Flow<List<ChatEntity>>

    @Insert suspend fun insertChat(c: ChatEntity): Long

    @Query("UPDATE ChatEntity SET updatedAt = :t WHERE id = :id")
    suspend fun touch(id: Long, t: Long)

    @Query("DELETE FROM ChatEntity WHERE id = :id")
    suspend fun deleteChat(id: Long)

    @Query("SELECT * FROM MessageEntity WHERE chatId = :chatId ORDER BY id")
    fun messages(chatId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM MessageEntity WHERE chatId = :chatId ORDER BY id")
    suspend fun messagesOnce(chatId: Long): List<MessageEntity>

    @Insert suspend fun insertMessage(m: MessageEntity): Long

    @Insert suspend fun insertTool(t: ToolLogEntity)

    @Query("SELECT * FROM ToolLogEntity ORDER BY id DESC LIMIT 200")
    fun toolLogs(): Flow<List<ToolLogEntity>>

    @Query("DELETE FROM ToolLogEntity")
    suspend fun clearToolLogs()
}

@Database(entities = [ChatEntity::class, MessageEntity::class, ToolLogEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ChatDao

    companion object {
        fun build(c: Context): AppDatabase =
            Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "nexora.db").build()
    }
}
