package com.nexora.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Msg(val role: String, val text: String)
data class Chat(val id: Long, val title: String, val messages: List<Msg>)

/** Settings, chat history and task log. The API key is encrypted with Android Keystore. */
class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexora", Context.MODE_PRIVATE)

    var apiKey: String
        get() = runCatching {
            val (iv, data) = prefs.getString("key", null)!!.split(":").map { Base64.decode(it, Base64.NO_WRAP) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, iv))
            String(c.doFinal(data))
        }.getOrDefault("")
        set(value) {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secret())
            val enc = { b: ByteArray -> Base64.encodeToString(b, Base64.NO_WRAP) }
            prefs.edit().putString("key", enc(c.iv) + ":" + enc(c.doFinal(value.trim().toByteArray()))).apply()
        }

    private fun secret(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("nexora_api", null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder("nexora_api", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return gen.generateKey()
    }

    fun string(key: String, default: String = "") = prefs.getString(key, default) ?: default
    fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun float(key: String, default: Float) = prefs.getFloat(key, default)
    fun put(key: String, value: Float) = prefs.edit().putFloat(key, value).apply()
    fun flag(key: String, default: Boolean) = prefs.getBoolean(key, default)
    fun put(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    private val chatFile get() = File(context.filesDir, "chats.json")

    fun chats(): List<Chat> = runCatching {
        val a = JSONArray(chatFile.readText())
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val m = o.getJSONArray("messages")
            Chat(o.getLong("id"), o.getString("title"), List(m.length()) { j ->
                Msg(m.getJSONObject(j).getString("role"), m.getJSONObject(j).getString("text"))
            })
        }
    }.getOrDefault(emptyList())

    fun saveChat(chat: Chat) = writeChats(listOf(chat) + chats().filter { it.id != chat.id })
    fun deleteChat(id: Long) = writeChats(chats().filter { it.id != id })

    private fun writeChats(list: List<Chat>) {
        val a = JSONArray()
        list.take(50).forEach { c ->
            val m = JSONArray()
            c.messages.forEach { m.put(JSONObject().put("role", it.role).put("text", it.text)) }
            a.put(JSONObject().put("id", c.id).put("title", c.title).put("messages", m))
        }
        chatFile.writeText(a.toString())
    }
}
