package com.nexora.ai.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.ai.live.LiveState

private data class Tile(val title: String, val sub: String, val icon: ImageVector, val enabled: Boolean, val onClick: () -> Unit)

@Composable
fun DashboardScreen(onLive: () -> Unit, onSettings: () -> Unit) {
    val tiles = listOf(
        Tile("Live Conversation", "কথা বলুন, মাঝপথে থামান", Icons.Default.Mic, true, onLive),
        Tile("ভয়েস ও AI সেটিংস", "API key, মডেল, কণ্ঠ", Icons.Default.Settings, true, onSettings),
        Tile("Text Chat", "ধাপ ২", Icons.Default.Chat, false) {},
        Tile("Screen Vision", "ধাপ ৩", Icons.Default.Visibility, false) {},
        Tile("Phone Automation", "ধাপ ৪", Icons.Default.PhoneAndroid, false) {},
        Tile("Coding Studio", "ধাপ ৫", Icons.Default.Code, false) {},
        Tile("HTML Preview", "ধাপ ৫", Icons.Default.Web, false) {},
        Tile("File Tools", "ধাপ ৪", Icons.Default.Folder, false) {},
        Tile("Task History", "ধাপ ৪", Icons.Default.History, false) {}
    )
    Column(
        Modifier.fillMaxSize().nexoraBackground().systemBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "NEXORA AI", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            style = TextStyle(brush = Brush.horizontalGradient(listOf(NX.Cyan, NX.Purple)), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        )
        Text("ব্যক্তিগত AI সহকারী", color = NX.Muted, fontSize = 13.sp)
        NexoraOrb(LiveState.IDLE, 0f, Modifier.size(150.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tiles) { t ->
                Column(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(NX.Glass)
                        .border(BorderStroke(1.dp, if (t.enabled) NX.Cyan.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.08f)), RoundedCornerShape(20.dp))
                        .clickable(enabled = t.enabled, onClick = t.onClick)
                        .alpha(if (t.enabled) 1f else 0.5f).padding(14.dp)
                ) {
                    Icon(t.icon, null, tint = if (t.enabled) NX.Cyan else NX.Muted)
                    Spacer(Modifier.height(8.dp))
                    Text(t.title, color = NX.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(t.sub, color = NX.Muted, fontSize = 11.sp)
                }
            }
        }
    }
}
