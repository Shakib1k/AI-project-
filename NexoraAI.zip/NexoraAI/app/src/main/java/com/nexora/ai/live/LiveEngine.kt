package com.nexora.ai.live

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import com.nexora.ai.ai.GeminiClient
import com.nexora.ai.ai.GeminiException
import com.nexora.ai.ai.Turn
import com.nexora.ai.data.Settings
import com.nexora.ai.voice.SpeechInput
import com.nexora.ai.voice.VoiceEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException

enum class LiveState {
    IDLE, LISTENING, PROCESSING, THINKING, SPEAKING, INTERRUPTED,
    SCREEN_SHARING, EXECUTING_TASK, WAITING_FOR_CONFIRMATION, ERROR
}

/**
 * Continuous voice conversation: listen -> Gemini (streamed) -> speak sentence by sentence -> listen.
 * While the AI is thinking/speaking a VAD watches the mic; real speech cancels the reply
 * (barge-in) and goes straight back to listening. All methods must be called on the main thread.
 */
class LiveEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settings: () -> Settings,
    private val gemini: GeminiClient,
    private val voice: VoiceEngine
) {
    private val speech = SpeechInput(context)
    private val vad = VadMonitor()
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusReq: AudioFocusRequest? = null

    private val _state = MutableStateFlow(LiveState.IDLE)
    val state: StateFlow<LiveState> = _state.asStateFlow()
    private val _userText = MutableStateFlow("")
    val userText: StateFlow<String> = _userText.asStateFlow()
    private val _aiText = MutableStateFlow("")
    val aiText: StateFlow<String> = _aiText.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()
    private val _history = MutableStateFlow<List<Turn>>(emptyList())
    val history: StateFlow<List<Turn>> = _history.asStateFlow()

    private var replyJob: Job? = null
    private var recogErrors = 0
    private val spoken = StringBuilder()

    // ---------- public controls ----------

    fun start() {
        if (_active.value) return
        val s = settings()
        _error.value = null
        when {
            s.apiKey.isBlank() -> return fail("আগে সেটিংসে Gemini API key দিন।")
            s.model.isBlank() -> return fail("সেটিংসে গিয়ে 'মডেল খুঁজুন' চাপুন ও একটি মডেল বেছে নিন।")
            !speech.available() -> return fail("এই ফোনে স্পিচ রিকগনিশন সার্ভিস পাওয়া যায়নি (Google অ্যাপ/ভয়েস ইনপুট দেখুন)।")
        }
        requestFocus()
        _active.value = true
        _muted.value = false
        recogErrors = 0
        listen()
    }

    fun end() {
        _active.value = false
        replyJob?.cancel(); replyJob = null
        vad.stop(); speech.stop(); voice.stop()
        commitSpoken(interrupted = true)
        abandonFocus()
        _level.value = 0f
        if (_state.value != LiveState.ERROR) _state.value = LiveState.IDLE
    }

    fun toggleMute() {
        val m = !_muted.value
        _muted.value = m
        if (!_active.value) return
        if (m) {
            speech.stop()
            if (_state.value == LiveState.LISTENING) _state.value = LiveState.IDLE
        } else if (replyJob?.isActive != true) {
            listen()
        }
    }

    /** Manual interrupt button AND the VAD barge-in both land here. */
    fun interrupt() {
        if (!_active.value) return
        val st = _state.value
        if (st != LiveState.THINKING && st != LiveState.SPEAKING && st != LiveState.PROCESSING) return
        replyJob?.cancel(); replyJob = null
        vad.stop(); voice.stop()
        commitSpoken(interrupted = true)
        _state.value = LiveState.INTERRUPTED
        scope.launch {
            delay(250)   // lets the VAD release the mic before the recognizer takes it
            if (_active.value && _state.value == LiveState.INTERRUPTED) listen()
        }
    }

    fun release() {
        end()
        speech.stop()
    }

    // ---------- listening ----------

    private fun listen() {
        if (!_active.value) return
        vad.stop()
        if (_muted.value) { _state.value = LiveState.IDLE; return }
        _state.value = LiveState.LISTENING
        _userText.value = ""
        scope.launch {
            delay(60)
            if (_active.value && !_muted.value && _state.value == LiveState.LISTENING) {
                speech.start(settings().recogLang, recognitionListener)
            }
        }
    }

    private val recognitionListener = object : SpeechInput.Listener {
        override fun onPartial(text: String) { _userText.value = text }
        override fun onRms(level: Float) { if (_state.value == LiveState.LISTENING) _level.value = level }
        override fun onFinal(text: String) {
            recogErrors = 0
            _level.value = 0f
            if (text.isBlank()) listen() else onUserSpoke(text.trim())
        }
        override fun onError(code: Int) {
            _level.value = 0f
            when (code) {
                6, 7 -> listen()                       // no speech / no match: just keep listening
                8, 5 -> scope.launch { delay(400); listen() }
                9 -> { fail("মাইক্রোফোনের অনুমতি নেই।"); end() }
                else -> {
                    recogErrors++
                    if (recogErrors > 3) {
                        fail("স্পিচ সার্ভিসে সমস্যা (কোড $code)। নেটওয়ার্ক ও Google ভয়েস ইনপুট চেক করুন।")
                        end()
                    } else scope.launch { delay(800); listen() }
                }
            }
        }
    }

    // ---------- reply pipeline ----------

    private fun onUserSpoke(text: String) {
        _userText.value = text
        addTurn("user", text)
        replyJob = scope.launch { respond() }
    }

    private suspend fun respond() {
        val s = settings()
        _state.value = LiveState.PROCESSING
        _aiText.value = ""
        spoken.setLength(0)
        if (s.bargeIn) {
            vad.start(scope, s.bargeSensitivity, onSpeech = { interrupt() },
                onFail = { _error.value = it })
        }
        _state.value = LiveState.THINKING
        val sentences = Channel<String>(Channel.UNLIMITED)
        val full = StringBuilder()
        try {
            coroutineScope {
                launch {
                    for (sent in sentences) {
                        if (_state.value != LiveState.SPEAKING) _state.value = LiveState.SPEAKING
                        _aiText.value = (spoken.toString() + " " + sent).trim()
                        if (s.autoSpeak) voice.speak(clean(sent), settings())
                        if (spoken.isNotEmpty()) spoken.append(' ')
                        spoken.append(sent)
                    }
                }
                val buf = StringBuilder()
                try {
                    gemini.stream(s.apiKey, s.model, SYSTEM_PROMPT, trimmedHistory()).collect { chunk ->
                        full.append(chunk); buf.append(chunk); drain(buf, sentences)
                    }
                    val rest = buf.toString().trim()
                    if (rest.isNotEmpty()) sentences.trySend(rest)
                    if (full.isBlank()) sentences.trySend("দুঃখিত বস, এই অনুরোধে আমি উত্তর দিতে পারছি না।")
                } finally {
                    sentences.close()
                }
            }
            vad.stop()
            val reply = if (full.isBlank()) spoken.toString() else full.toString().trim()
            if (reply.isNotBlank()) addTurn("model", reply)
            spoken.setLength(0)
            listen()
        } catch (e: CancellationException) {
            throw e   // interrupt()/end() already handled history and state
        } catch (e: GeminiException) {
            vad.stop()
            val fatal = e.code in 400..403
            aiFailure(
                when (e.code) {
                    429 -> "Gemini অনুরোধের সীমা শেষ বা খুব দ্রুত অনুরোধ হয়েছে। একটু পরে চেষ্টা করুন।"
                    in 400..403 -> "API key বা মডেল ঠিক নেই: ${e.message}"
                    else -> "Gemini সার্ভার সমস্যা (${e.code})।"
                }, fatal
            )
        } catch (e: IOException) {
            vad.stop()
            aiFailure("নেটওয়ার্ক সমস্যা: ইন্টারনেট সংযোগ চেক করুন।", false)
        }
    }

    private fun aiFailure(msg: String, fatal: Boolean) {
        _error.value = msg
        _state.value = LiveState.ERROR
        spoken.setLength(0)
        if (fatal) { end(); return }
        scope.launch {
            delay(2500)
            if (_active.value && _state.value == LiveState.ERROR) listen()
        }
    }

    // ---------- helpers ----------

    private fun fail(msg: String) {
        _error.value = msg
        _state.value = LiveState.ERROR
    }

    private fun addTurn(role: String, text: String) {
        val list = _history.value.toMutableList()
        val last = list.lastOrNull()
        if (last != null && last.role == role) list[list.size - 1] = Turn(role, last.text + "\n" + text)
        else list.add(Turn(role, text))
        _history.value = list
    }

    /** Keeps what was actually spoken before the user cut in, so context is preserved. */
    private fun commitSpoken(interrupted: Boolean) {
        val said = spoken.toString().trim()
        spoken.setLength(0)
        if (said.isNotEmpty()) addTurn("model", if (interrupted) "$said …[ব্যবহারকারী মাঝপথে থামিয়েছেন]" else said)
    }

    private fun trimmedHistory(): List<Turn> {
        var h = _history.value.takeLast(24)
        while (h.isNotEmpty() && h.first().role != "user") h = h.drop(1)
        return h
    }

    private fun drain(buf: StringBuilder, out: Channel<String>) {
        while (true) {
            var cut = -1
            for (i in buf.indices) {
                val c = buf[i]
                val delim = c == '।' || c == '!' || c == '?' || c == '\n' ||
                    (c == '.' && i + 1 < buf.length && buf[i + 1].isWhitespace())
                if (delim && i + 1 >= MIN_SENTENCE) { cut = i + 1; break }
            }
            if (cut < 0) return
            val sent = buf.substring(0, cut).trim()
            buf.delete(0, cut)
            if (sent.isNotEmpty()) out.trySend(sent)
        }
    }

    private fun clean(s: String) = s.replace(Regex("[*#`_]+"), "").trim()

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS) scope.launch { end() }
            }.build()
        audio.requestAudioFocus(req)
        focusReq = req
    }

    private fun abandonFocus() {
        focusReq?.let { audio.abandonAudioFocusRequest(it) }
        focusReq = null
    }

    companion object {
        private const val MIN_SENTENCE = 20
        const val SYSTEM_PROMPT =
            "তুমি NEXORA, ব্যবহারকারীর ব্যক্তিগত নারী-কণ্ঠের AI সহকারী। ব্যবহারকারীকে 'বস' বলে সম্বোধন করো। " +
            "ব্যবহারকারী যে ভাষায় বলে (বাংলা বা ইংরেজি) সেই ভাষাতেই উত্তর দাও। " +
            "উত্তর ছোট ও কথোপকথনের মতো রাখো (সাধারণত ২-৩ বাক্য), কারণ উত্তর জোরে পড়ে শোনানো হবে। " +
            "markdown, তারকাচিহ্ন, তালিকা বা emoji ব্যবহার করবে না। " +
            "বর্তমানে তুমি শুধু কথোপকথন করতে পারো। ফোন নিয়ন্ত্রণ, স্ক্রিন দেখা, অ্যাপ খোলা, ফাইল তৈরি বা মেসেজ পাঠানো " +
            "এখনো চালু হয়নি। এগুলো করতে পারো বলে কখনো দাবি করবে না; চাইলে সৎভাবে জানাও যে এটি পরের ধাপে আসবে।"
    }
}
