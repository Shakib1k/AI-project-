package com.nexora.ai

import android.app.Application
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.ai.ai.GeminiClient
import com.nexora.ai.ai.GeminiException
import com.nexora.ai.ai.GeminiModel
import com.nexora.ai.data.Keys
import com.nexora.ai.data.Settings
import com.nexora.ai.data.SettingsStore
import com.nexora.ai.live.LiveEngine
import com.nexora.ai.voice.VoiceEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.IOException

class LiveViewModel(app: Application) : AndroidViewModel(app) {
    val store = SettingsStore(app)
    val settings: StateFlow<Settings> = store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val gemini = GeminiClient()
    val voice = VoiceEngine(app)
    val engine = LiveEngine(app, viewModelScope, { settings.value }, gemini, voice)

    private val _models = MutableStateFlow<List<GeminiModel>>(emptyList())
    val models: StateFlow<List<GeminiModel>> = _models.asStateFlow()
    private val _modelStatus = MutableStateFlow<String?>(null)
    val modelStatus: StateFlow<String?> = _modelStatus.asStateFlow()

    fun <T> set(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { store.set(key, value) }
    }

    fun loadModels() {
        viewModelScope.launch {
            val key = settings.value.apiKey
            if (key.isBlank()) { _modelStatus.value = "আগে API key সংরক্ষণ করুন।"; return@launch }
            _modelStatus.value = "মডেল খোঁজা হচ্ছে…"
            try {
                val list = gemini.listModels(key)
                _models.value = list
                if (list.isEmpty()) { _modelStatus.value = "এই key দিয়ে কোনো উপযুক্ত মডেল পাওয়া যায়নি।"; return@launch }
                if (list.none { it.id == settings.value.model }) {
                    gemini.pickDefault(list)?.let { store.set(Keys.model, it) }
                }
                _modelStatus.value = "${list.size}টি মডেল পাওয়া গেছে।"
            } catch (e: GeminiException) {
                _modelStatus.value = "ত্রুটি (${e.code}): ${e.message}"
            } catch (e: IOException) {
                _modelStatus.value = "নেটওয়ার্ক সমস্যা।"
            }
        }
    }

    fun preview(bengali: Boolean) {
        viewModelScope.launch {
            voice.speak(
                if (bengali) "জি বস, আমি NEXORA। আমার কণ্ঠ কেমন লাগছে?" else "Hello boss, I am NEXORA. How does my voice sound?",
                settings.value
            )
        }
    }

    override fun onCleared() {
        engine.release()
        voice.release()
    }
}
