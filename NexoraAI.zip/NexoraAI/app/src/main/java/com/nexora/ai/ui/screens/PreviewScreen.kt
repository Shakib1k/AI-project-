@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.ai.container
import com.nexora.ai.ui.components.PreviewPane
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.workspace.PreviewBuilder
import kotlinx.coroutines.launch

@Composable
fun PreviewScreen(onBack: () -> Unit) {
    val c = LocalContext.current.container
    val content by c.preview.collectAsState()
    val console = remember { mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    var mode by remember { mutableIntStateOf(0) } // 0 mobile, 1 tablet, 2 full
    var showConsole by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf<String?>(null) }
    val widths = listOf(390, 768, null)

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(content.sourcePath?.substringAfterLast('/') ?: "Preview") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = { mode = 0 }) { Icon(Icons.Default.PhoneAndroid, "Mobile", tint = if (mode == 0) NX.Cyan else NX.Muted) }
                    IconButton(onClick = { mode = 1 }) { Icon(Icons.Default.TabletAndroid, "Tablet", tint = if (mode == 1) NX.Cyan else NX.Muted) }
                    IconButton(onClick = { mode = 2 }) { Icon(Icons.Default.Fullscreen, "Full", tint = if (mode == 2) NX.Cyan else NX.Muted) }
                    IconButton(onClick = { showConsole = !showConsole }) { Icon(Icons.Default.Terminal, "Console", tint = if (showConsole) NX.Cyan else NX.Muted) }
                    IconButton(onClick = {
                        val p = content.sourcePath ?: return@IconButton
                        scope.launch {
                            try { c.preview.value = PreviewBuilder.build(c.workspace, p, content.version + 1); err = null }
                            catch (e: Exception) { err = e.message }
                        }
                    }) { Icon(Icons.Default.Refresh, "Refresh") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (content.html.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Preview করার মতো কিছু নেই। Studio থেকে HTML ফাইল Preview করুন।") }
            } else {
                PreviewPane(content, widths[mode], console, Modifier.weight(1f).fillMaxWidth().border(1.dp, NX.Cyan.copy(.3f)))
            }
            err?.let { Text(it, color = NX.Danger, modifier = Modifier.padding(8.dp)) }
            if (showConsole) ConsolePanel(console)
        }
    }
}

@Composable
fun ConsolePanel(console: SnapshotStateList<String>) {
    Column(Modifier.fillMaxWidth().height(130.dp).padding(8.dp)) {
        Text("Console (${console.size})", color = NX.Muted, fontSize = 12.sp)
        if (console.isEmpty()) Text("No messages or errors.", color = NX.Muted, fontSize = 12.sp)
        LazyColumn {
            items(console.toList()) { line ->
                Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (line.contains("ERROR")) NX.Danger else NX.Text)
            }
        }
    }
}
