package com.nexora.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class Screen(val pkg: String, val description: String, val nodes: List<AccessibilityNodeInfo>, val hasPassword: Boolean)

/** Low-level phone control. Policy and confirmations live in TaskRunner. */
class AgentService : AccessibilityService() {
    private var stopPanel: LinearLayout? = null
    private var confirmPanel: LinearLayout? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        TaskRunner.stop("Accessibility service stopped")
        hidePanels(); instance = null
        super.onDestroy()
    }

    fun read(): Screen {
        val root = rootInActiveWindow ?: return Screen("", "(no readable window)", emptyList(), false)
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        val lines = StringBuilder()
        var password = false
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 40 || ++visited > 1500 || !n.isVisibleToUser) return
            if (n.isPassword) password = true
            val text = if (n.isPassword) "" else n.text?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty()
            val useful = text.isNotBlank() || desc.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (useful && nodes.size < 180) {
                val box = Rect().also { n.getBoundsInScreen(it) }
                lines.append("[${nodes.size}] ${n.className?.toString()?.substringAfterLast('.')}")
                if (text.isNotBlank()) lines.append(" text=\"${text.take(200)}\"")
                if (desc.isNotBlank()) lines.append(" desc=\"${desc.take(100)}\"")
                n.viewIdResourceName?.let { lines.append(" id=${it.substringAfterLast('/')}") }
                if (n.isClickable) lines.append(" clickable")
                if (n.isEditable) lines.append(" editable")
                if (n.isScrollable) lines.append(" scrollable")
                lines.append(" @${box.centerX()},${box.centerY()}\n")
                nodes += n
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return Screen(root.packageName?.toString().orEmpty(), lines.toString(), nodes, password)
    }

    fun hasPasswordField() = read().hasPassword

    /** All labels in a node and its children, used by the risk check and confirmation text. */
    fun label(node: AccessibilityNodeInfo, depth: Int = 0): String {
        val own = listOfNotNull(node.text, node.contentDescription).joinToString(" ")
        if (depth > 4) return own
        val children = (0 until node.childCount).mapNotNull { node.getChild(it) }.joinToString(" ") { label(it, depth + 1) }
        return "$own $children".trim()
    }

    fun click(node: AccessibilityNodeInfo, long: Boolean): Boolean {
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        // Only act on the node itself: falling back to a parent could hit a control that was not checked.
        return node.refresh() && node.performAction(action)
    }

    fun type(node: AccessibilityNodeInfo, text: String): Boolean {
        if (!node.refresh() || !node.isEditable || node.isPassword) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
        val clipboard = getSystemService(android.content.ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("nexora", text))
        // Select everything so paste replaces, matching ACTION_SET_TEXT.
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, node.text?.length ?: 0)
        })
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    suspend fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val (from, to) = when (direction) {
            "up" -> (w / 2 to h * .72f) to (w / 2 to h * .32f)
            "down" -> (w / 2 to h * .32f) to (w / 2 to h * .72f)
            "left" -> (w * .8f to h / 2) to (w * .2f to h / 2)
            "right" -> (w * .2f to h / 2) to (w * .8f to h / 2)
            else -> return false
        }
        val path = Path().apply { moveTo(from.first, from.second); lineTo(to.first, to.second) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        return suspendCancellableCoroutine { cont ->
            val sent = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!sent && cont.isActive) cont.resume(false)
        }
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)

    /** Package for an installed launcher app: exact name first, otherwise a single unambiguous match. */
    fun findApp(name: String): String? {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(query, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
        apps.firstOrNull { it.first.equals(name, true) || it.second == name }?.let { return it.second }
        return apps.filter { it.first.contains(name, true) }.map { it.second }.distinct().singleOrNull()
    }

    fun launch(pkg: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun panel(gravityValue: Int) = Pair(
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xF20B1020.toInt()); setPadding(24, 24, 24, 24) },
        WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = gravityValue }
    )

    private fun windows() = getSystemService(WindowManager::class.java)

    fun showStop() {
        if (stopPanel != null) return
        val (view, params) = panel(Gravity.TOP or Gravity.END)
        view.addView(Button(this).apply { text = "■ STOP NEXORA"; setOnClickListener { TaskRunner.stop("Stopped by user") } })
        windows().addView(view, params)
        stopPanel = view
    }

    /** Confirmation drawn over the current app. Only the user's tap on Allow returns true. */
    suspend fun confirm(message: String): Boolean = suspendCancellableCoroutine { cont ->
        val (view, params) = panel(Gravity.BOTTOM)
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        val scroll = ScrollView(this).apply {
            addView(TextView(this@AgentService).apply { text = message; setTextColor(Color.WHITE); textSize = 15f })
        }
        view.addView(scroll, LinearLayout.LayoutParams(-1, resources.displayMetrics.heightPixels / 4))
        fun answer(value: Boolean) { removeConfirm(); if (cont.isActive) cont.resume(value) }
        view.addView(Button(this).apply { text = "Allow"; filterTouchesWhenObscured = true; setOnClickListener { answer(true) } })
        view.addView(Button(this).apply { text = "Cancel"; setOnClickListener { answer(false) } })
        windows().addView(view, params)
        confirmPanel = view
        cont.invokeOnCancellation { view.post { removeConfirm() } }
    }

    private fun removeConfirm() {
        confirmPanel?.let { if (it.isAttachedToWindow) windows().removeView(it) }
        confirmPanel = null
    }

    fun hidePanels() {
        removeConfirm()
        stopPanel?.let { if (it.isAttachedToWindow) windows().removeView(it) }
        stopPanel = null
    }

    companion object { @Volatile var instance: AgentService? = null }
}
