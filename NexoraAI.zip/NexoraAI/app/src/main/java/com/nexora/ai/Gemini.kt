package com.nexora.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Gemini REST client. Model IDs are never hardcoded: they come from the models endpoint. */
class Gemini(private val store: Store) {
    private val base = "https://generativelanguage.googleapis.com/v1beta"
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()

    private fun request(url: String): Request.Builder {
        check(store.apiKey.isNotBlank()) { "Add your Gemini API key in Settings." }
        return Request.Builder().url(url).header("x-goog-api-key", store.apiKey)
    }

    private suspend fun Call.await(): String = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                try {
                    response.use {
                        val body = it.body?.string().orEmpty()
                        if (!it.isSuccessful) throw IOException(errorText(it.code, body))
                        if (cont.isActive) cont.resume(body)
                    }
                } catch (e: Exception) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
        })
    }

    private fun errorText(code: Int, body: String): String {
        val message = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrDefault("")
        return "Gemini error $code. $message"
    }

    /** Models this key can use with generateContent. */
    suspend fun models(): List<String> {
        val out = mutableListOf<String>()
        var token = ""
        do {
            val url = "$base/models".toHttpUrl().newBuilder().addQueryParameter("pageSize", "1000")
            if (token.isNotEmpty()) url.addQueryParameter("pageToken", token)
            val json = JSONObject(http.newCall(request(url.build().toString()).build()).await())
            val list = json.optJSONArray("models") ?: JSONArray()
            for (i in 0 until list.length()) {
                val m = list.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                val name = m.getString("name").removePrefix("models/")
                if ("generateContent" in methods && name.startsWith("gemini")) out += name
            }
            token = json.optString("nextPageToken")
        } while (token.isNotEmpty())
        return out.sorted()
    }

    private fun model() = store.string("model").ifBlank {
        error("Open Settings, load the model list and choose a model.")
    }

    private fun body(history: List<Msg>, system: String, jpeg: ByteArray?, jsonMode: Boolean): RequestBody {
        val contents = JSONArray()
        history.forEachIndexed { i, m ->
            val parts = JSONArray().put(JSONObject().put("text", m.text))
            if (jpeg != null && i == history.lastIndex) {
                parts.put(JSONObject().put("inlineData", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            }
            contents.put(JSONObject().put("role", if (m.role == "user") "user" else "model").put("parts", parts))
        }
        val root = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        if (jsonMode) root.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return root.toString().toRequestBody("application/json".toMediaType())
    }

    private fun textOf(json: JSONObject): String {
        val parts = json.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        return (0 until parts.length()).map { parts.getJSONObject(it) }
            .filterNot { it.optBoolean("thought") }.joinToString("") { it.optString("text") }
    }

    suspend fun generate(history: List<Msg>, system: String, jpeg: ByteArray? = null, jsonMode: Boolean = false): String {
        val req = request("$base/models/${model()}:generateContent").post(body(history, system, jpeg, jsonMode)).build()
        return textOf(JSONObject(http.newCall(req).await())).ifBlank { throw IOException("Gemini returned no text.") }
    }

    fun stream(history: List<Msg>, system: String, jpeg: ByteArray? = null): Flow<String> = callbackFlow {
        val req = request("$base/models/${model()}:streamGenerateContent?alt=sse")
            .post(body(history, system, jpeg, false)).build()
        val call = http.newCall(req)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { close(e) }
            override fun onResponse(call: Call, response: Response) {
                try {
                    response.use {
                        if (!it.isSuccessful) throw IOException(errorText(it.code, it.body?.string().orEmpty()))
                        val source = it.body!!.source()
                        var received = false
                        while (true) {
                            val line = source.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val piece = textOf(JSONObject(line.removePrefix("data:").trim()))
                            if (piece.isNotEmpty()) { received = true; trySend(piece) }
                        }
                        if (!received) throw IOException("Gemini returned no text.")
                    }
                    close()
                } catch (e: Exception) { close(e) }
            }
        })
        awaitClose { call.cancel() }
    }.buffer(Channel.UNLIMITED).flowOn(Dispatchers.IO)
}

const val PERSONA = "You are Nexora, a warm, friendly female personal assistant. Address the user as বস when speaking Bengali. " +
    "Reply in the user's language (Bengali or English). Keep spoken answers short and natural. " +
    "Never claim you performed a phone action: only the task runner can do that."
