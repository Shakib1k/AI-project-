package com.nexora.ai.ui.components

import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import com.nexora.ai.workspace.PreviewContent

private const val BASE = "https://preview.nexora.local/"

/**
 * Safe WebView host: JS enabled (needed for generated pages) but no file/content access,
 * no JavaScript bridges, no mixed content, and external navigation is blocked.
 */
@Composable
fun PreviewPane(content: PreviewContent, widthDp: Int?, console: SnapshotStateList<String>, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.TopCenter) {
        val m = if (widthDp != null) Modifier.width(widthDp.dp).fillMaxHeight() else Modifier.fillMaxSize()
        AndroidView(
            modifier = m,
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.setSupportMultipleWindows(false)
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val u = request.url.toString()
                            return !(u.startsWith(BASE) && u.contains('#'))
                        }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            console.add("[NET-ERROR] ${request.url} — ${error.description}")
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(cm: ConsoleMessage): Boolean {
                            console.add("[${cm.messageLevel()}] ${cm.message()} (line ${cm.lineNumber()})")
                            return true
                        }
                    }
                }
            },
            update = { wv ->
                val stamp = "${content.version}:${content.html.hashCode()}"
                if (wv.tag != stamp) {
                    wv.tag = stamp
                    console.clear()
                    if (content.html.isNotEmpty()) wv.loadDataWithBaseURL(BASE, content.html, "text/html", "utf-8", null)
                }
            },
            onRelease = { it.destroy() }
        )
    }
}
