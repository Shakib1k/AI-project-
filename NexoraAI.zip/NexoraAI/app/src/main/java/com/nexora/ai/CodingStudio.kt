package com.nexora.ai

import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val rules = listOf(
    Regex("\\b(def|class|import|from|return|if|else|elif|for|while|try|except|fun|val|var|function|const|let|public|private|static|void|new|when|SELECT|FROM|WHERE|INSERT|UPDATE)\\b") to Cyan,
    Regex("</?[A-Za-z][\\w-]*|/?>") to Color(0xFFB388FF),
    Regex("\\b\\d+(\\.\\d+)?\\b") to Color(0xFFFFB86C),
    Regex("\"[^\"\\n]*\"|'[^'\\n]*'") to Color(0xFF7CE38B),
    Regex("(?m)^\\s*(#|//).*$") to Color(0xFF6B7690)
)

private val highlight = VisualTransformation { source ->
    val builder = AnnotatedString.Builder(source.text)
    if (source.length < 20_000) rules.forEach { (regex, color) ->
        regex.findAll(source.text).forEach { builder.addStyle(SpanStyle(color = color), it.range.first, it.range.last + 1) }
    }
    TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
}

/** Keeps the previous line's indent after Enter, adding one level after { or : */
private fun autoIndent(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    val at = new.selection.start
    if (new.text.length != old.text.length + 1 || at < 1 || new.text[at - 1] != '\n') return new
    val line = new.text.substring(0, at - 1).substringAfterLast('\n')
    val extra = if (line.trimEnd().endsWith("{") || line.trimEnd().endsWith(":")) "    " else ""
    val indent = line.takeWhile { it == ' ' || it == '\t' } + extra
    return TextFieldValue(new.text.substring(0, at) + indent + new.text.substring(at),
        androidx.compose.ui.text.TextRange(at + indent.length))
}

@Composable
fun CodingStudio(model: NexoraViewModel, back: () -> Unit) {
    val context = LocalContext.current
    val current = model.tabs[model.tab]
    var field by remember { mutableStateOf(TextFieldValue(current.text)) }
    if (field.text != current.text) field = TextFieldValue(current.text)
    var request by remember { mutableStateOf("") }
    var find by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf(false) }

    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val text = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            require(text.length < 500_000) { "File is too large for this editor." }
            model.addTab(uri.lastPathSegment?.substringAfterLast('/') ?: "file.txt", text)
        }.onFailure { model.codeNote = it.message ?: "Could not open file" }
    }
    // The system file picker asks before replacing an existing file.
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(model.tabs[model.tab].text.toByteArray()) }
            val saved = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            model.codeNote = if (saved == model.tabs[model.tab].text) "Saved and verified." else "Saved file does not match. Try again."
        }.onFailure { model.codeNote = it.message ?: "Save failed" }
    }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Header("Coding Studio", back)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            model.tabs.forEachIndexed { i, t -> FilterChip(i == model.tab, { model.tab = i }, { Text(t.name) }, Modifier.padding(end = 6.dp)) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("py", "html", "js", "kt").forEach { ext ->
                TextButton(onClick = { model.addTab("new${model.tabs.size}.$ext") }) { Text("+$ext") }
            }
            TextButton(onClick = { open.launch(arrayOf("*/*")) }) { Text("Open") }
            TextButton(onClick = { save.launch(current.name) }) { Text("Save") }
            TextButton(onClick = { preview = !preview }) { Text(if (preview) "Editor" else "HTML preview") }
        }
        if (preview) {
            AndroidView(modifier = Modifier.fillMaxWidth().height(420.dp), factory = {
                WebView(it).apply {
                    // Preview runs offline with no file access and no app bridge.
                    settings.javaScriptEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.blockNetworkLoads = true
                }
            }, update = { it.loadDataWithBaseURL(null, current.text, "text/html", "UTF-8", null) },
                onRelease = { it.destroy() })
        } else {
            OutlinedTextField(field, { val next = autoIndent(field, it); field = next; model.edit(next.text) },
                Modifier.fillMaxWidth().height(360.dp), visualTransformation = highlight,
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White))
        }
        Row {
            OutlinedTextField(find, { find = it }, Modifier.weight(1f), label = { Text("Find") }, singleLine = true)
            OutlinedTextField(replacement, { replacement = it }, Modifier.weight(1f), label = { Text("Replace") }, singleLine = true)
        }
        TextButton(onClick = {
            val count = if (find.isEmpty()) 0 else current.text.split(find).size - 1
            if (count > 0) model.edit(current.text.replace(find, replacement))
            model.codeNote = "$count match(es) replaced."
        }) { Text("Replace all") }
        OutlinedTextField(request, { request = it }, Modifier.fillMaxWidth(), label = { Text("Ask Nexora to write or change code") })
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Button(onClick = { model.askCode(request, true) }, enabled = !model.codeBusy && request.isNotBlank()) { Text("Generate") }
            TextButton(onClick = { model.askCode("Explain this code in simple Bengali.", false) }, enabled = !model.codeBusy) { Text("Explain") }
            TextButton(onClick = { model.askCode("Find bugs, explain them and suggest fixes and performance improvements. $request", false) }, enabled = !model.codeBusy) { Text("Debug") }
            TextButton(onClick = { model.askCode("Format and indent this file without changing behaviour.", true) }, enabled = !model.codeBusy) { Text("Format") }
        }
        if (model.codeBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(model.codeNote, color = Color.White, fontSize = 13.sp)
    }
    model.proposal?.let { code ->
        AlertDialog(onDismissRequest = { model.proposal = null }, title = { Text("Replace ${current.name}?") },
            text = { Text(code, Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
            confirmButton = { TextButton(onClick = { model.edit(code); model.proposal = null }) { Text("Replace") } },
            dismissButton = {
                TextButton(onClick = { model.addTab("ai-${current.name}", code); model.proposal = null }) { Text("New tab") }
            })
    }
}
