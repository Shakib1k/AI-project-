package com.nexora.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Live voice loop: listen -> think -> speak -> listen.
 * While speaking, BargeInDetector watches the mic; user speech stops TTS and restarts recognition.
 * All public methods must be called on the main thread.
 */
class VoiceEngine(private val context: Context, private val store: Store) {
    var onHeard: (String) -> Unit = {}
    var onStatus: (String) -> Unit = {}
    var live = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ready = false
    private var utterance = 0
    private var errors = 0
    private val detector = BargeInDetector(context) { main.post { if (live) { stopSpeaking(); listen() } } }
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String) {}
            override fun onDone(id: String) { finished(id) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String) { finished(id) }
        })
    }

    private fun finished(id: String) = main.post {
        if (id == "u$utterance") {
            detector.stop()
            Orb.state.value = OrbState.IDLE
            if (live) main.postDelayed({ if (live) listen() }, 250)
        }
    }

    /** Voices the device really has for Bengali and English. Android does not report gender. */
    fun voices(): List<Voice> = runCatching {
        tts.voices.orEmpty().filter { it.locale.language == "bn" || it.locale.language == "en" }
            .sortedBy { it.locale.toString() + it.name }
    }.getOrDefault(emptyList())

    fun speak(text: String) {
        recognizer?.cancel()
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " code block. ").replace(Regex("[*#`_>]"), "").trim()
        if (!ready || !store.flag("speak", true) || clean.isEmpty()) {
            if (live) listen()
            return
        }
        val lang = if (clean.any { it in 'ঀ'..'৿' }) "bn" else "en"
        val chosen = voices().firstOrNull { it.name == store.string("voice_$lang") }
        if (chosen != null) tts.voice = chosen else {
            val result = tts.setLanguage(if (lang == "bn") Locale("bn", "BD") else Locale.US)
            if (result < TextToSpeech.LANG_AVAILABLE) onStatus("No $lang voice installed on this device.")
        }
        tts.setPitch(store.float("pitch", 1.1f))
        tts.setSpeechRate(store.float("rate", 1.0f))
        // Communication usage gives the echo canceller a reference signal on most devices.
        tts.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(if (live) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, store.float("volume", 1f)) }
        utterance++
        val chunks = clean.chunked(TextToSpeech.getMaxSpeechInputLength() - 1)
        chunks.forEachIndexed { i, chunk ->
            val id = if (i == chunks.lastIndex) "u$utterance" else "part$utterance-$i"
            tts.speak(chunk, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, id)
        }
        Orb.state.value = OrbState.SPEAKING
        onStatus("Speaking (talk to interrupt)")
        if (live) detector.start(store.float("barge", 1800f))
    }

    fun stopSpeaking() {
        utterance++ // ignore callbacks from the old utterance
        detector.stop()
        if (ready) tts.stop()
        Orb.state.value = OrbState.IDLE
    }

    fun startLive() {
        live = true
        errors = 0
        audio().mode = AudioManager.MODE_IN_COMMUNICATION
        routeToSpeaker(true)
        listen()
    }

    fun stopLive() {
        live = false
        recognizer?.cancel()
        stopSpeaking()
        routeToSpeaker(false)
        audio().mode = AudioManager.MODE_NORMAL
        onStatus("Voice off")
    }

    private fun audio() = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Suppress("DEPRECATION")
    private fun routeToSpeaker(on: Boolean) {
        val am = audio()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (on) {
                val devices = am.availableCommunicationDevices
                val headset = devices.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                if (!headset) devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    ?.let { am.setCommunicationDevice(it) }
            } else am.clearCommunicationDevice()
        } else am.isSpeakerphoneOn = on
    }

    private fun listen() {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            onStatus("Microphone permission needed"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onStatus("No speech recognition service on this device"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    errors = 0
                    val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) retry() else { Orb.state.value = OrbState.THINKING; onStatus("Thinking"); onHeard(text) }
                }
                override fun onError(error: Int) {
                    val silence = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    if (!silence) errors++
                    if (errors >= 4) { stopLive(); onStatus("Voice stopped (recognizer error $error)") } else retry()
                }
                override fun onReadyForSpeech(params: Bundle?) { Orb.state.value = OrbState.LISTENING; onStatus("Listening") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.string("stt", "bn-BD")))
        }
    }

    private fun retry() { main.postDelayed({ if (live) listen() }, 600) }

    fun release() {
        stopLive()
        recognizer?.destroy()
        tts.shutdown()
    }
}

/** Energy-based speech detector on an echo-cancelled mic stream. */
class BargeInDetector(private val context: Context, private val onSpeech: () -> Unit) {
    @Volatile private var session: Any? = null

    @SuppressLint("MissingPermission")
    fun start(minLevel: Float) {
        stop()
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val token = Any()
        session = token
        Thread {
            val rate = 16000
            val size = max(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 3200)
            val record = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            if (record.state != AudioRecord.STATE_INITIALIZED) { record.release(); return@Thread }
            val aec = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(record.audioSessionId) else null
            val ns = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(record.audioSessionId) else null
            aec?.enabled = true
            ns?.enabled = true
            val buffer = ShortArray(320) // 20 ms
            var frames = 0
            var loud = 0
            var floor = 0.0
            try {
                record.startRecording()
                while (session === token) {
                    val n = record.read(buffer, 0, buffer.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (i in 0 until n) sum += buffer[i].toDouble() * buffer[i]
                    val level = sqrt(sum / n)
                    // First 400 ms calibrates against leftover echo.
                    if (++frames <= 20) { floor = max(floor, level); continue }
                    loud = if (level > max(minLevel.toDouble(), floor * 1.8)) loud + 1 else max(0, loud - 1)
                    if (loud >= 10 && session === token) { session = null; onSpeech(); break }
                }
            } finally {
                runCatching { record.stop() }
                aec?.release(); ns?.release(); record.release()
            }
        }.start()
    }

    fun stop() { session = null }
}
