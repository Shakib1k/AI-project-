package com.nexora.ai.workspace

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.TextFieldValue
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

object CodeTools {
    fun langOf(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "py" -> "py"; "html", "htm" -> "html"; "css" -> "css"; "js", "mjs" -> "js"
        "java" -> "java"; "kt", "kts" -> "kt"; "json" -> "json"; "xml" -> "xml"; "sql" -> "sql"
        else -> "txt"
    }

    fun autoIndent(old: TextFieldValue, new: TextFieldValue, lang: String): TextFieldValue {
        if (new.text.length == old.text.length + 1 && new.selection.collapsed && old.selection.collapsed &&
            new.selection.start > 0 && new.text[new.selection.start - 1] == '\n'
        ) {
            val pos = new.selection.start
            val prevLine = new.text.substring(0, pos - 1).substringAfterLast('\n')
            val indent = prevLine.takeWhile { it == ' ' || it == '\t' }
            val t = prevLine.trimEnd()
            val extra = if (t.endsWith("{") || t.endsWith("(") || t.endsWith("[") || (lang == "py" && t.endsWith(":"))) "    " else ""
            val ins = indent + extra
            if (ins.isNotEmpty()) {
                return new.copy(text = new.text.substring(0, pos) + ins + new.text.substring(pos), selection = TextRange(pos + ins.length))
            }
        }
        return new
    }

    // ---------- Formatting ----------
    fun format(lang: String, text: String): String = when (lang) {
        "json" -> fmtJson(text)
        "xml", "html" -> fmtMarkup(text)
        "py", "sql", "txt" -> text.replace("\t", "    ").lines().joinToString("\n") { it.trimEnd() }.trimEnd() + "\n"
        else -> fmtBraces(text, if (lang == "java" || lang == "kt") 4 else 2)
    }

    private val pretty = Json { prettyPrint = true; prettyPrintIndent = "  " }

    private fun fmtJson(t: String): String = try {
        pretty.encodeToString(JsonElement.serializer(), Json.parseToJsonElement(t))
    } catch (e: Exception) {
        throw IllegalArgumentException("Invalid JSON: ${e.message}")
    }

    private val strRe = Regex("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'")

    private fun fmtBraces(t: String, w: Int): String {
        var depth = 0
        var blank = 0
        val out = StringBuilder()
        for (raw in t.replace("\t", "    ").lines()) {
            val line = raw.trim()
            if (line.isEmpty()) { if (++blank <= 1) out.append("\n"); continue }
            blank = 0
            val s = line.replace(strRe, "").substringBefore("//")
            val opens = s.count { it == '{' || it == '(' || it == '[' }
            val closes = s.count { it == '}' || it == ')' || it == ']' }
            val lead = s.takeWhile { it == '}' || it == ')' || it == ']' }.length
            out.append(" ".repeat((depth - lead).coerceAtLeast(0) * w)).append(line).append("\n")
            depth = (depth + opens - closes).coerceAtLeast(0)
        }
        return out.toString().trimEnd() + "\n"
    }

    private val void = setOf("br", "img", "meta", "link", "input", "hr", "area", "base", "col", "embed", "source", "track", "wbr", "!doctype")

    private fun fmtMarkup(t: String): String {
        val lines = t.replace(Regex(">\\s*<"), ">\n<").lines()
        val out = StringBuilder()
        var depth = 0
        var raw: String? = null
        for (l in lines) {
            val line = l.trim()
            if (raw != null) {
                if (line.contains("</$raw", true)) {
                    depth = (depth - 1).coerceAtLeast(0)
                    out.append("  ".repeat(depth)).append(line).append("\n")
                    raw = null
                } else out.append(l).append("\n")
                continue
            }
            if (line.isEmpty()) continue
            if (line.startsWith("</")) depth = (depth - 1).coerceAtLeast(0)
            out.append("  ".repeat(depth)).append(line).append("\n")
            if (line.startsWith("<") && !line.startsWith("</") && !line.startsWith("<!--") && !line.startsWith("<?")) {
                val tag = Regex("^<([A-Za-z!][\\w:-]*)").find(line)?.groupValues?.get(1)?.lowercase()
                if (tag != null && tag !in void && !line.endsWith("/>") &&
                    !Regex("</$tag\\s*>\\s*$", RegexOption.IGNORE_CASE).containsMatchIn(line)
                ) {
                    depth++
                    if (tag == "script" || tag == "style") raw = tag
                }
            }
        }
        return out.toString().trimEnd() + "\n"
    }
}

/** Regex-based syntax highlighter (good enough for an on-device editor; not a full parser). */
object Highlighter {
    private val cCmt = Color(0xFF6B7A99)
    private val cStr = Color(0xFF9CFFB0)
    private val cNum = Color(0xFFFFB86C)
    private val cKw = Color(0xFFB388FF)
    private val cTag = Color(0xFF00E5FF)
    private val cAttr = Color(0xFF82AAFF)
    private val cMeta = Color(0xFFFF8BD1)

    private val kw = mapOf(
        "py" to "def class import from return if elif else for while try except finally with as lambda yield pass break continue in is not and or None True False async await raise global nonlocal del assert",
        "js" to "function const let var return if else for while switch case break continue new this class extends import export from default async await try catch finally throw typeof instanceof null undefined true false",
        "java" to "public private protected class interface extends implements static final void int long double float boolean char byte short new return if else for while switch case break continue try catch finally throw throws import package this super null true false abstract enum instanceof",
        "kt" to "fun val var class object interface override private public protected internal data sealed when if else for while return import package null true false is in as try catch finally throw suspend companion init this super by lateinit const open abstract enum",
        "sql" to "select from where insert into values update set delete create table drop alter join left right inner outer on group by order having limit and or not null as distinct union primary key foreign references index"
    )

    private val cache = HashMap<String, Pair<Regex, List<Color>>>()

    private const val DQ = "\"(?:\\\\.|[^\"\\\\\\n])*\""
    private const val SQ = "'(?:\\\\.|[^'\\\\\\n])*'"
    private const val BT = "`(?:\\\\.|[^`\\\\])*`"

    private fun build(lang: String): Pair<Regex, List<Color>> {
        val parts = mutableListOf<Pair<String, Color>>()
        val cmt = when (lang) {
            "py" -> "#.*"
            "sql" -> "--.*|/\\*[\\s\\S]*?\\*/"
            "html", "xml" -> "<!--[\\s\\S]*?-->"
            "css" -> "/\\*[\\s\\S]*?\\*/"
            "json" -> null
            else -> "//.*|/\\*[\\s\\S]*?\\*/"
        }
        if (cmt != null) parts += cmt to cCmt
        if (lang == "py") parts += "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''" to cStr
        if (lang == "json") parts += "\"(?:\\\\.|[^\"\\\\\\n])*\"(?=\\s*:)" to cTag
        parts += (if (lang == "js") "$DQ|$SQ|$BT" else "$DQ|$SQ") to cStr
        when (lang) {
            "html", "xml" -> { parts += "</?[A-Za-z][\\w:-]*|/?>" to cTag; parts += "[A-Za-z_:][\\w:.-]*(?=\\s*=)" to cAttr }
            "css" -> {
                parts += "#[0-9a-fA-F]{3,8}\\b" to cNum
                parts += "[A-Za-z-]+(?=\\s*:)" to cAttr
                parts += "@[\\w-]+" to cMeta
            }
            "kt", "java", "py" -> parts += "@\\w+" to cMeta
        }
        parts += "\\b\\d+(?:\\.\\d+)?\\b" to cNum
        kw[lang]?.let { parts += "\\b(?:${it.split(" ").joinToString("|")})\\b" to cKw }
        val re = Regex(parts.joinToString("|") { "(${it.first})" }, if (lang == "sql") setOf(RegexOption.IGNORE_CASE) else emptySet())
        return re to parts.map { it.second }
    }

    fun highlight(text: String, lang: String): AnnotatedString {
        if (lang == "txt" || text.length > 60_000) return AnnotatedString(text)
        val (re, colors) = cache.getOrPut(lang) { build(lang) }
        return buildAnnotatedString {
            append(text)
            for (m in re.findAll(text)) {
                val i = (1..colors.size).firstOrNull { m.groups[it] != null } ?: continue
                addStyle(SpanStyle(color = colors[i - 1]), m.range.first, m.range.last + 1)
            }
        }
    }
}
