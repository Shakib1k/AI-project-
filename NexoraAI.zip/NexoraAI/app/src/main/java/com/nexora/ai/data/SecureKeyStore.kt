package com.nexora.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.nexora.ai.BuildConfig

/** Gemini API key lives in EncryptedSharedPreferences (Android Keystore backed). Never logged or exported. */
class SecureKeyStore(ctx: Context) {
    private val prefs: SharedPreferences? = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "nexora_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }

    fun get(): String =
        prefs?.getString("gemini_key", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_API_KEY

    fun hasStoredKey(): Boolean = !prefs?.getString("gemini_key", null).isNullOrBlank()

    fun set(key: String): Boolean {
        val p = prefs ?: return false
        p.edit().putString("gemini_key", key.trim()).apply()
        return true
    }
}
