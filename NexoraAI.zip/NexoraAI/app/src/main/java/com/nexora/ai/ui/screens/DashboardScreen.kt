@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nexora.ai.container
import com.nexora.ai.screen.rememberScreenShareToggle
import com.nexora.ai.ui.components.AiOrb
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.voice.Phase

@Composable
fun DashboardScreen(go: (String) -> Unit) {
    val c = LocalContext.current.container
    val share = rememberScreenShareToggle()
    val chats by c.db.dao().chats().collectAsState(initial = emptyList())
    val cs = MaterialTheme.colorScheme

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("NEXORA AI", color = cs.primary, style = MaterialTheme.typography.titleLarge) },
                actions = {
                    IconButton(onClick = { go("history") }) { Icon(Icons.Default.History, "History") }
                    IconButton(onClick = { go("settings") }) { Icon(Icons.Default.Settings, "Settings") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AiOrb(Phase.Idle, 0f, orbSize = 190.dp)
            Text("জি বস, বলুন কী করতে হবে?", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
            Text("Your futuristic personal AI assistant", color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(Icons.Default.Mic, "Live Voice", "কথা বলুন", Modifier.weight(1f)) { go("chat/-1?voice=true") }
                Tile(Icons.Default.Chat, "Text Chat", "লিখে জিজ্ঞেস করুন", Modifier.weight(1f)) { go("chat/-1?voice=false") }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(
                    if (share.active) Icons.Default.StopScreenShare else Icons.Default.ScreenShare,
                    if (share.active) "Stop Sharing" else "Screen Share",
                    if (share.active) "● চলছে" else "স্ক্রিন বোঝার জন্য",
                    Modifier.weight(1f), highlight = share.active, onClick = share.toggle
                )
                Tile(Icons.Default.Code, "Coding Studio", "কোড লিখুন", Modifier.weight(1f)) { go("studio") }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(Icons.Default.FolderOpen, "File Manager", "ফাইল ও প্রজেক্ট", Modifier.weight(1f)) { go("files") }
                Tile(Icons.Default.Bolt, "Automation", "ফোন নিয়ন্ত্রণ", Modifier.weight(1f)) { go("automation") }
            }

            if (chats.isNotEmpty()) {
                Text("Recent chats", Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 8.dp), color = cs.onSurfaceVariant)
                chats.take(4).forEach { ch ->
                    GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { go("chat/${ch.id}?voice=false") }) {
                        Text(ch.title, Modifier.padding(14.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun Tile(icon: ImageVector, title: String, sub: String, modifier: Modifier, highlight: Boolean = false, onClick: () -> Unit) {
    GlassCard(modifier, onClick, glow = if (highlight) NX.Danger else MaterialTheme.colorScheme.primary) {
        Column(Modifier.padding(16.dp).heightIn(min = 96.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = if (highlight) NX.Danger else MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
