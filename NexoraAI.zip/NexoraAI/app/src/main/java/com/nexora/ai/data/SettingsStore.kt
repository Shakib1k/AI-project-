package com.nexora.ai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore("nexora_settings")

data class AppSettings(
    val model: String = "gemini-2.5-flash",
    val language: String = "bn", // "bn" | "en"
    val voiceName: String = "",
    val accent: String = "cyan", // "cyan" | "purple"
    val amoled: Boolean = true,
    val workspaceUri: String = "",
    val screenConsent: Boolean = false,
    val autoSpeak: Boolean = false,
    val continuousVoice: Boolean = true,
    val requests: Long = 0,
    val failures: Long = 0,
    val promptTokens: Long = 0,
    val outputTokens: Long = 0,
    val lastError: String = ""
)

object SK {
    val model = stringPreferencesKey("model")
    val language = stringPreferencesKey("language")
    val voiceName = stringPreferencesKey("voiceName")
    val accent = stringPreferencesKey("accent")
    val amoled = booleanPreferencesKey("amoled")
    val workspaceUri = stringPreferencesKey("workspaceUri")
    val screenConsent = booleanPreferencesKey("screenConsent")
    val autoSpeak = booleanPreferencesKey("autoSpeak")
    val continuousVoice = booleanPreferencesKey("continuousVoice")
    val requests = longPreferencesKey("requests")
    val failures = longPreferencesKey("failures")
    val promptTokens = longPreferencesKey("promptTokens")
    val outputTokens = longPreferencesKey("outputTokens")
    val lastError = stringPreferencesKey("lastError")
}

class SettingsStore(private val ctx: Context) {
    val flow: Flow<AppSettings> = ctx.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                model = p[SK.model] ?: d.model,
                language = p[SK.language] ?: d.language,
                voiceName = p[SK.voiceName] ?: d.voiceName,
                accent = p[SK.accent] ?: d.accent,
                amoled = p[SK.amoled] ?: d.amoled,
                workspaceUri = p[SK.workspaceUri] ?: d.workspaceUri,
                screenConsent = p[SK.screenConsent] ?: d.screenConsent,
                autoSpeak = p[SK.autoSpeak] ?: d.autoSpeak,
                continuousVoice = p[SK.continuousVoice] ?: d.continuousVoice,
                requests = p[SK.requests] ?: 0,
                failures = p[SK.failures] ?: 0,
                promptTokens = p[SK.promptTokens] ?: 0,
                outputTokens = p[SK.outputTokens] ?: 0,
                lastError = p[SK.lastError] ?: ""
            )
        }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        ctx.dataStore.edit { it[key] = value }
    }

    suspend fun recordUsage(ok: Boolean, prompt: Long, out: Long, error: String) {
        ctx.dataStore.edit { p ->
            p[SK.requests] = (p[SK.requests] ?: 0) + 1
            if (ok) {
                p[SK.promptTokens] = (p[SK.promptTokens] ?: 0) + prompt
                p[SK.outputTokens] = (p[SK.outputTokens] ?: 0) + out
            } else {
                p[SK.failures] = (p[SK.failures] ?: 0) + 1
                p[SK.lastError] = error
            }
        }
    }
}
