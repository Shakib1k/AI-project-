package com.nexora.ai.voice

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.nexora.ai.data.Settings
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

data class VoiceInfo(val name: String, val locale: String, val lang: String, val needsNetwork: Boolean, val quality: Int)

/**
 * Wraps Android TextToSpeech. Speaks ONE sentence per call and suspends until it finishes,
 * so the voice (Bengali/English) can be switched per sentence and cancellation is instant.
 * Android does not expose voice gender, so the user picks a voice by listening to previews.
 */
class VoiceEngine(context: Context) {
    private var tts: TextToSpeech? = null
    private var rawVoices: List<Voice> = emptyList()
    private val waiters = ConcurrentHashMap<String, CancellableContinuation<Unit>>()
    private var counter = 0L

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()
    private val _voices = MutableStateFlow<List<VoiceInfo>>(emptyList())
    val voices: StateFlow<List<VoiceInfo>> = _voices.asStateFlow()

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) = finish(utteranceId)
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finish(utteranceId)
        override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
        override fun onStop(utteranceId: String?, interrupted: Boolean) = finish(utteranceId)
    }

    private fun finish(id: String?) {
        val c = id?.let { waiters.remove(it) } ?: return
        if (c.isActive) c.resume(Unit)
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                t.setOnUtteranceProgressListener(listener)
                refreshVoices(t)
                _ready.value = true
            }
        }
    }

    private fun refreshVoices(t: TextToSpeech) {
        rawVoices = try { t.voices?.toList().orEmpty() } catch (e: Exception) { emptyList() }
        _voices.value = rawVoices
            .filter { it.locale.language == "bn" || it.locale.language == "en" }
            .map { VoiceInfo(it.name, it.locale.toLanguageTag(), it.locale.language, it.isNetworkConnectionRequired, it.quality) }
            .sortedWith(compareBy({ it.lang }, { it.name }))
    }

    fun hasBengali(): Boolean = _voices.value.any { it.lang == "bn" }

    private fun apply(t: TextToSpeech, lang: String, preferred: String) {
        val chosen = rawVoices.firstOrNull { it.name == preferred && it.locale.language == lang }
            ?: rawVoices.filter { it.locale.language == lang }.maxByOrNull { it.quality }
        if (chosen != null) t.voice = chosen
        else t.language = if (lang == "bn") Locale("bn", "BD") else Locale.US
    }

    fun isBengali(text: String): Boolean {
        val letters = text.count { it.isLetter() }
        if (letters == 0) return false
        val bn = text.count { it in '\u0980'..'\u09FF' }
        return bn * 2 >= letters
    }

    suspend fun speak(text: String, s: Settings) {
        val t = tts ?: return
        if (!_ready.value || text.isBlank()) return
        val bn = isBengali(text)
        apply(t, if (bn) "bn" else "en", if (bn) s.voiceBn else s.voiceEn)
        t.setSpeechRate(s.rate)
        t.setPitch(s.pitch)
        val id = "u${counter++}"
        suspendCancellableCoroutine<Unit> { cont ->
            waiters[id] = cont
            cont.invokeOnCancellation { waiters.remove(id); t.stop() }
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, s.volume) }
            if (t.speak(text, TextToSpeech.QUEUE_FLUSH, params, id) != TextToSpeech.SUCCESS) {
                waiters.remove(id)
                if (cont.isActive) cont.resume(Unit)
            }
        }
    }

    fun stop() { tts?.stop() }

    fun release() {
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
