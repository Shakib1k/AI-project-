package com.nexora.ai.ai

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiException(val code: Int, message: String) : Exception(message)

data class GeminiModel(val id: String, val display: String)

/** role = "user" | "model" */
data class Turn(val role: String, val text: String)

class GeminiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val base = "https://generativelanguage.googleapis.com/v1beta"

    /** Asks the API which models this key can really use (no hardcoded model IDs). */
    suspend fun listModels(key: String): List<GeminiModel> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$base/models?pageSize=200").header("x-goog-api-key", key).build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw GeminiException(r.code, errorMessage(body, r.code))
            val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
            val out = ArrayList<GeminiModel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val methods = o.optJSONArray("supportedGenerationMethods") ?: continue
                var ok = false
                for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
                val id = o.getString("name").removePrefix("models/")
                if (ok && id.startsWith("gemini") && EXCLUDE.none { id.contains(it) }) {
                    out.add(GeminiModel(id, o.optString("displayName", id)))
                }
            }
            out
        }
    }

    /** Fast conversational default: newest non-lite "flash" model, stable builds preferred. */
    fun pickDefault(models: List<GeminiModel>): String? {
        fun version(id: String) = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(id)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        fun stable(id: String) = !(id.contains("preview") || id.contains("exp"))
        val flash = models.filter { it.id.contains("flash") && !it.id.contains("lite") }
        val pool = flash.ifEmpty { models }
        return pool.sortedWith(
            compareByDescending<GeminiModel> { version(it.id) }
                .thenByDescending { stable(it.id) }
                .thenBy { it.id.length }
        ).firstOrNull()?.id
    }

    fun stream(key: String, model: String, system: String, history: List<Turn>): Flow<String> = flow {
        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject().put("role", it.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7))
        val req = Request.Builder()
            .url("$base/models/$model:streamGenerateContent?alt=sse")
            .header("x-goog-api-key", key)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        var attempt = 0
        while (true) {
            val call = http.newCall(req)
            val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) {
                        throw GeminiException(r.code, errorMessage(r.body?.string().orEmpty(), r.code))
                    }
                    val src = r.body!!.source()
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data.isEmpty()) continue
                        val text = extract(data)
                        if (text.isNotEmpty()) emit(text)
                    }
                }
                return@flow
            } catch (e: GeminiException) {
                // Retry only on HTTP status errors (before any text was emitted), with a hard limit.
                if ((e.code == 429 || e.code >= 500) && attempt < 2) {
                    attempt++
                    delay(1500L * attempt)
                    continue
                }
                throw e
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                throw e
            } finally {
                handle?.dispose()
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun extract(data: String): String {
        return try {
            val parts = JSONObject(data).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            sb.toString()
        } catch (e: JSONException) {
            ""
        }
    }

    private fun errorMessage(body: String, code: Int): String = try {
        JSONObject(body).getJSONObject("error").getString("message")
    } catch (e: Exception) {
        "HTTP $code"
    }

    companion object {
        private val EXCLUDE = listOf("embedding", "tts", "image", "live", "audio", "robotics", "computer-use", "aqa")
    }
}
