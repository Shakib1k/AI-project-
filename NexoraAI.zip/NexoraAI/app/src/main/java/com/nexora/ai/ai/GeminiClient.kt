package com.nexora.ai.ai

import com.nexora.ai.data.SecureKeyStore
import com.nexora.ai.data.SettingsStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed interface GeminiEvent {
    data class Text(val text: String) : GeminiEvent
    data class Call(val name: String, val args: JsonObject) : GeminiEvent
    /** Raw model parts, kept verbatim so function-calling turns can be echoed back to the API. */
    data class Raw(val parts: List<JsonElement>) : GeminiEvent
}

class GeminiException(message: String, val code: Int = 0) : Exception(message)

object Gj {
    fun msg(role: String, text: String): JsonObject = buildJsonObject {
        put("role", role)
        put("parts", buildJsonArray { add(buildJsonObject { put("text", text) }) })
    }
}

class GeminiClient(private val settings: SettingsStore, private val keys: SecureKeyStore) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true }
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /** Streams a generateContent call (SSE). Retries 429/5xx/network errors with exponential backoff before any data arrives. */
    fun stream(
        contents: JsonArray,
        system: String,
        tools: JsonArray? = null,
        responseSchema: JsonObject? = null,
        temperature: Double = 0.7
    ): Flow<GeminiEvent> = flow {
        val s = settings.flow.first()
        val key = keys.get()
        if (key.isBlank()) throw GeminiException("Gemini API key সেট করা নেই — Settings থেকে key দিন।")
        val body = buildJsonObject {
            put("systemInstruction", buildJsonObject {
                put("parts", buildJsonArray { add(buildJsonObject { put("text", system) }) })
            })
            put("contents", contents)
            if (tools != null) put("tools", tools)
            put("generationConfig", buildJsonObject {
                put("temperature", temperature)
                if (responseSchema != null) {
                    put("responseMimeType", "application/json")
                    put("responseSchema", responseSchema)
                }
            })
        }.toString()
        val model = s.model.ifBlank { "gemini-2.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"

        val resp = open(url, key, body)
        var prompt = 0L
        var out = 0L
        var any = false
        var finish = ""
        resp.use { r ->
            val src = r.body?.source() ?: throw GeminiException("Empty response body")
            while (true) {
                val line = src.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty() || data == "[DONE]") continue
                val obj = json.parseToJsonElement(data).jsonObject
                obj["usageMetadata"]?.jsonObject?.let { u ->
                    prompt = u["promptTokenCount"]?.jsonPrimitive?.longOrNull ?: prompt
                    out = u["candidatesTokenCount"]?.jsonPrimitive?.longOrNull ?: out
                }
                obj["promptFeedback"]?.jsonObject?.get("blockReason")?.jsonPrimitive?.contentOrNull?.let {
                    throw GeminiException("অনুরোধটি ব্লক হয়েছে ($it)")
                }
                val cand = obj["candidates"]?.jsonArray?.firstOrNull()?.jsonObject ?: continue
                cand["finishReason"]?.jsonPrimitive?.contentOrNull?.let { finish = it }
                val parts = cand["content"]?.jsonObject?.get("parts")?.jsonArray ?: continue
                if (parts.isNotEmpty()) emit(GeminiEvent.Raw(parts.toList()))
                for (p in parts) {
                    val po = p.jsonObject
                    val text = po["text"]?.jsonPrimitive?.contentOrNull
                    if (!text.isNullOrEmpty()) {
                        any = true
                        emit(GeminiEvent.Text(text))
                    }
                    val fc = po["functionCall"]?.jsonObject
                    if (fc != null) {
                        any = true
                        emit(GeminiEvent.Call(fc["name"]!!.jsonPrimitive.content, fc["args"]?.jsonObject ?: JsonObject(emptyMap())))
                    }
                }
            }
        }
        settings.recordUsage(true, prompt, out, "")
        if (!any) {
            val msg = if (finish.isNotEmpty()) "AI কোনো উত্তর দেয়নি (finishReason=$finish)" else "AI কোনো উত্তর দেয়নি"
            settings.recordUsage(false, 0, 0, msg)
            throw GeminiException(msg)
        }
    }.flowOn(Dispatchers.IO)

    suspend fun generateOnce(system: String, user: String, schema: JsonObject? = null): String {
        val sb = StringBuilder()
        stream(JsonArray(listOf(Gj.msg("user", user))), system, null, schema, 0.4).collect {
            if (it is GeminiEvent.Text) sb.append(it.text)
        }
        return sb.toString()
    }

    private suspend fun open(url: String, key: String, body: String): Response {
        var attempt = 0
        while (true) {
            val call = http.newCall(
                Request.Builder().url(url).header("x-goog-api-key", key).post(body.toRequestBody(jsonMedia)).build()
            )
            val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { call.cancel() }
            var resp: Response? = null
            var failure: Throwable? = null
            try {
                resp = withContext(Dispatchers.IO) { call.execute() }
            } catch (e: CancellationException) {
                call.cancel()
                throw e
            } catch (e: Throwable) {
                failure = e
            }
            if (resp != null && resp.isSuccessful) return resp
            val code = resp?.code ?: 0
            val err = resp?.use { it.body?.string().orEmpty() }.orEmpty()
            handle?.dispose()
            val retryable = (resp == null && failure is IOException) || code == 429 || code >= 500
            if (retryable && attempt < 3) {
                attempt++
                delay(1000L shl (attempt - 1))
                continue
            }
            val msg = friendly(code, err, failure)
            settings.recordUsage(false, 0, 0, msg)
            throw GeminiException(msg, code)
        }
    }

    private fun friendly(code: Int, body: String, failure: Throwable?): String {
        val apiMsg = runCatching {
            json.parseToJsonElement(body).jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
        }.getOrNull()
        return when {
            failure != null -> "নেটওয়ার্ক সমস্যা: ${failure.message ?: failure.javaClass.simpleName}. ইন্টারনেট চেক করুন।"
            code == 400 && apiMsg?.contains("API key", true) == true -> "API key সঠিক নয়। Settings-এ নতুন key দিন।"
            code == 401 || code == 403 -> "অনুমতি নেই (HTTP $code): ${apiMsg ?: ""}"
            code == 404 -> "মডেল পাওয়া যায়নি। Settings-এ মডেলের নাম দেখুন।"
            code == 429 -> "কোটা/রেট লিমিট শেষ (HTTP 429)। একটু পরে চেষ্টা করুন।"
            else -> "Gemini error HTTP $code: ${apiMsg ?: body.take(200)}"
        }
    }
}
