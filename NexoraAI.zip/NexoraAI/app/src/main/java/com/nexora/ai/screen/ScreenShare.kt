package com.nexora.ai.screen

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.nexora.ai.MainActivity
import com.nexora.ai.util.Notifier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayOutputStream

/** Holds sharing state + the latest captured frame (in memory only, never written to disk). */
object ScreenShare {
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active
    @Volatile private var latest: Bitmap? = null

    internal fun setActive(v: Boolean) { _active.value = v; if (!v) latest = null }
    internal fun update(b: Bitmap) { latest = b }

    /** Latest frame as base64 JPEG (max ~1280px), or null when not sharing / no frame yet. */
    fun jpegBase64(): String? {
        val b = latest ?: return null
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 75, bos)
        return android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
    }
}

class ScreenCaptureService : Service() {
    companion object {
        private const val ACTION_STOP = "nexora.STOP_SHARE"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val NOTIF_ID = 7

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, ScreenCaptureService::class.java).putExtra(EXTRA_CODE, resultCode).putExtra(EXTRA_DATA, data)
            )
        }
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(ACTION_STOP))
        }
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastFrame = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); return START_NOT_STICKY }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        // Must be a foreground service (type mediaProjection) BEFORE obtaining the projection on Android 14+.
        ServiceCompat.startForeground(this, NOTIF_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val ht = HandlerThread("nexora-capture").also { it.start() }
        thread = ht
        val handler = Handler(ht.looper)
        val proj = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("No projection")
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, handler)

        val dm = resources.displayMetrics
        val scale = (1280f / maxOf(dm.widthPixels, dm.heightPixels)).coerceAtMost(1f)
        val w = (dm.widthPixels * scale).toInt().coerceAtLeast(2)
        val h = (dm.heightPixels * scale).toInt().coerceAtLeast(2)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastFrame >= 600) {
                    lastFrame = now
                    val plane = img.planes[0]
                    val rowPadding = plane.rowStride - plane.pixelStride * img.width
                    val full = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(plane.buffer)
                    val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                    if (cropped !== full) full.recycle()
                    ScreenShare.update(cropped)
                }
            } finally {
                img.close()
            }
        }, handler)
        display = proj.createVirtualDisplay("nexora-share", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        ScreenShare.setActive(true)
    }

    private fun stopCapture() {
        ScreenShare.setActive(false)
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        display = null; reader = null; projection = null
        thread?.quitSafely(); thread = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (ScreenShare.active.value) stopCapture()
        super.onDestroy()
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Notifier.CH_SHARE)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("NEXORA is sharing your screen")
            .setContentText("Frames go to Gemini only when you send a message.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop sharing", stop)
            .build()
    }
}
