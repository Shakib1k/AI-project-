package com.nexora.ai.screen

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.nexora.ai.container
import com.nexora.ai.data.AppSettings
import com.nexora.ai.data.SK
import kotlinx.coroutines.launch

class ScreenShareControl(val active: Boolean, val toggle: () -> Unit)

/**
 * Handles consent dialog -> notification permission -> official MediaProjection permission dialog -> service start.
 * Nothing is captured unless the user approves the system dialog.
 */
@Composable
fun rememberScreenShareToggle(): ScreenShareControl {
    val ctx: Context = LocalContext.current
    val c = ctx.container
    val scope = rememberCoroutineScope()
    val settings by c.settings.flow.collectAsState(initial = AppSettings())
    val active by ScreenShare.active.collectAsState()
    var askConsent by remember { mutableStateOf(false) }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) ScreenCaptureService.start(ctx, r.resultCode, data)
        else Toast.makeText(ctx, "Screen sharing permission denied", Toast.LENGTH_SHORT).show()
    }
    fun launchProjection() {
        val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { launchProjection() }

    fun begin() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else launchProjection()
    }

    if (askConsent) {
        AlertDialog(
            onDismissRequest = { askConsent = false },
            title = { Text("Share your screen with NEXORA AI?") },
            text = {
                Text(
                    "While sharing is ON, the latest screenshot is sent to Google's Gemini API together with each message you send, " +
                        "so the AI can answer questions about your screen. Passwords, banking or private content on screen would be included. " +
                        "A notification and an in-app banner show while sharing is active, and you can stop at any time. " +
                        "Android will now ask for its own permission."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    askConsent = false
                    scope.launch { c.settings.set(SK.screenConsent, true) }
                    begin()
                }) { Text("I understand, continue") }
            },
            dismissButton = { TextButton(onClick = { askConsent = false }) { Text("Cancel") } }
        )
    }

    return ScreenShareControl(active) {
        when {
            active -> ScreenCaptureService.stop(ctx)
            !settings.screenConsent -> askConsent = true
            else -> begin()
        }
    }
}
