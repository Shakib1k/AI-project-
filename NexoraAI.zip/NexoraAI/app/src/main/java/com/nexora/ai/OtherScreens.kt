package com.nexora.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun HistoryScreen(model: NexoraViewModel, back: () -> Unit, open: (Chat) -> Unit) {
    var chats by remember { mutableStateOf(model.store.chats()) }
    var doomed by remember { mutableStateOf<Chat?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Header("Chat history", back)
        if (chats.isEmpty()) Text("No chats yet.", color = Color.White)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats, key = { it.id }) { chat ->
                Card(onClick = { open(chat) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp)) {
                        Text(chat.title, Modifier.weight(1f))
                        TextButton(onClick = { doomed = chat }) { Text("Delete") }
                    }
                }
            }
        }
    }
    doomed?.let { chat ->
        Confirm("Delete this chat?", chat.title,
            yes = { model.store.deleteChat(chat.id); chats = model.store.chats(); doomed = null }, no = { doomed = null })
    }
}

@Composable
fun SettingsScreen(model: NexoraViewModel, back: () -> Unit) {
    val context = LocalContext.current
    val store = model.store
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var models by remember { mutableStateOf(emptyList<String>()) }
    var selected by remember { mutableStateOf(store.string("model")) }
    var note by remember { mutableStateOf("") }
    var voices by remember { mutableStateOf(emptyList<android.speech.tts.Voice>()) }
    var stt by remember { mutableStateOf(store.string("stt", "bn-BD")) }
    var speak by remember { mutableStateOf(store.flag("speak", true)) }
    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        note = result.entries.joinToString { "${it.key.substringAfterLast('.')}: ${if (it.value) "granted" else "denied"}" }
    }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Header("Settings", back)
        Section("Gemini API")
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation(),
            label = { Text(if (store.apiKey.isBlank()) "API key" else "API key saved (enter to replace)") }, singleLine = true)
        Button(onClick = {
            if (key.isNotBlank()) { store.apiKey = key; key = "" }
            note = "Loading models…"
            scope.launch {
                runCatching { model.gemini.models() }
                    .onSuccess { models = it; note = "${it.size} models available to this key." }
                    .onFailure { note = it.message ?: "Could not load models" }
            }
        }) { Text("Save and load models") }
        Text("Selected: ${selected.ifBlank { "none" }}", color = Cyan)
        Text("Pick a stronger model for coding or a faster one to save cost. Some listed models are for audio or images only.", color = Color.White, fontSize = 12.sp)
        models.forEach { name ->
            FilterChip(name == selected, { selected = name; store.put("model", name) }, { Text(name) })
        }
        Text(note, color = Color.White)

        Section("Voice")
        Row {
            listOf("bn-BD" to "Listen: বাংলা", "en-US" to "Listen: English").forEach { (code, label) ->
                FilterChip(stt == code, { stt = code; store.put("stt", code) }, { Text(label) }, Modifier.padding(end = 8.dp))
            }
        }
        FilterChip(speak, { speak = !speak; store.put("speak", speak) }, { Text("Speak replies automatically") })
        Setting(store, "rate", "Speed", 1.0f, 0.5f..2f)
        Setting(store, "pitch", "Pitch", 1.1f, 0.5f..2f)
        Setting(store, "volume", "Volume", 1f, 0f..1f)
        Setting(store, "barge", "Interrupt threshold (raise if Nexora interrupts herself)", 1800f, 600f..6000f)
        Row {
            TextButton(onClick = { model.voice.speak("জি বস, আমি নেক্সোরা। কীভাবে সাহায্য করতে পারি?") }) { Text("Preview বাংলা") }
            TextButton(onClick = { model.voice.speak("Hi, I am Nexora. How can I help?") }) { Text("Preview English") }
            TextButton(onClick = { model.voice.stopSpeaking() }) { Text("Stop") }
        }
        TextButton(onClick = { voices = model.voice.voices() }) { Text("Show installed voices") }
        if (voices.isNotEmpty()) Text("Android does not label voice gender. Preview and choose the one you like.", color = Color.White, fontSize = 12.sp)
        voices.forEach { v ->
            TextButton(onClick = {
                val lang = v.locale.language
                store.put("voice_$lang", v.name)
                model.voice.speak(if (lang == "bn") "জি বস, এই কণ্ঠটা কেমন লাগছে?" else "How does this voice sound?")
            }) { Text("${v.locale} · ${v.name}${if (v.isNetworkConnectionRequired) " (online)" else ""}") }
        }

        Section("Permissions")
        Button(onClick = {
            permissions.launch(if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.RECORD_AUDIO))
        }) { Text("Microphone and notifications") }
        Button(onClick = {
            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        }) { Text("Display over other apps (orb)") }
        Button(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility (automation)") }
        Text("Automation: ${if (AgentService.instance != null) "enabled" else "not enabled"}", color = Color.White)

        Section("Last task")
        val task = TaskRunner.state.value
        Text(if (task.goal.isBlank()) "No task in this session."
            else "${task.goal}\n${task.status}\n${task.steps.joinToString("\n")}\n${task.message}", color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun Section(title: String) = Text(title, color = Cyan, fontSize = 18.sp, modifier = Modifier.padding(top = 12.dp))

@Composable
private fun Setting(store: Store, name: String, label: String, default: Float, range: ClosedFloatingPointRange<Float>) {
    var value by remember { mutableFloatStateOf(store.float(name, default)) }
    Text("$label: ${"%.1f".format(value)}", color = Color.White, fontSize = 13.sp)
    Slider(value, { value = it }, valueRange = range, onValueChangeFinished = { store.put(name, value) })
}
