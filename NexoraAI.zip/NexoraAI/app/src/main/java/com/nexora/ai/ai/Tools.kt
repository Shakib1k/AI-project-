package com.nexora.ai.ai

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import com.nexora.ai.AppContainer
import com.nexora.ai.UiEvent
import com.nexora.ai.automation.NexoraAccessibilityService
import com.nexora.ai.workspace.PreviewBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*

/** ok = the call ran. verified = the outcome was independently confirmed (read-back, foreground check...). */
data class ToolResult(val ok: Boolean, val message: String, val verified: Boolean = ok)

object Tools {
    private fun p(type: String, desc: String) = buildJsonObject { put("type", type); put("description", desc) }

    private fun decl(
        name: String, desc: String,
        props: Map<String, JsonObject> = emptyMap(),
        required: List<String> = props.keys.toList()
    ) = buildJsonObject {
        put("name", name)
        put("description", desc)
        if (props.isNotEmpty()) put("parameters", buildJsonObject {
            put("type", "OBJECT")
            put("properties", buildJsonObject { props.forEach { (k, v) -> put(k, v) } })
            put("required", JsonArray(required.map { JsonPrimitive(it) }))
        })
    }

    private val filesParam = buildJsonObject {
        put("type", "ARRAY")
        put("description", "All files of the project with complete content")
        put("items", buildJsonObject {
            put("type", "OBJECT")
            put("properties", buildJsonObject {
                put("path", p("STRING", "Relative path inside the project, e.g. index.html"))
                put("content", p("STRING", "Full file content"))
            })
            put("required", JsonArray(listOf(JsonPrimitive("path"), JsonPrimitive("content"))))
        })
    }

    val declarations: JsonArray = buildJsonArray {
        add(buildJsonObject {
            put("functionDeclarations", JsonArray(listOf(
                decl("open_app", "Launch an installed Android app by its visible name (e.g. 'MT Manager').", mapOf("app_name" to p("STRING", "App name"))),
                decl("read_screen_ui", "Read visible text/buttons of the foreground app (needs Accessibility service). Use before tapping."),
                decl("tap", "Tap a visible UI element by its text or content description.", mapOf("text" to p("STRING", "Visible label"))),
                decl("type_text", "Type text into the focused (or first) editable field. Replaces its content.", mapOf("text" to p("STRING", "Text to enter"))),
                decl("scroll", "Scroll the foreground app's scrollable view.", mapOf("direction" to p("STRING", "up, down, left or right"))),
                decl("swipe", "Swipe gesture across the screen.", mapOf("direction" to p("STRING", "up, down, left or right"))),
                decl("go_back", "Press the Android Back button."),
                decl("go_home", "Press the Android Home button."),
                decl("create_file", "Create or overwrite a text file in the user's workspace. Path may include folders.",
                    mapOf("path" to p("STRING", "e.g. BD.txt or site/index.html"), "content" to p("STRING", "File content (may be empty)")), listOf("path")),
                decl("read_file", "Read a text file from the workspace.", mapOf("path" to p("STRING", "File path"))),
                decl("list_files", "List files/folders in a workspace folder ('' = root).", mapOf("path" to p("STRING", "Folder path")), emptyList()),
                decl("create_folder", "Create a folder in the workspace.", mapOf("path" to p("STRING", "Folder path"))),
                decl("rename_file", "Rename a file or folder.", mapOf("path" to p("STRING", "Current path"), "new_name" to p("STRING", "New name only"))),
                decl("delete_file", "Delete a file or folder (user confirmation is required).", mapOf("path" to p("STRING", "Path"))),
                decl("create_project", "Create a multi-file project (HTML/CSS/JS, Python, ...) inside a new workspace folder.",
                    mapOf("project_name" to p("STRING", "Folder name, no spaces"), "files" to filesParam)),
                decl("preview_html", "Open the live WebView preview of an HTML file (CSS/JS files next to it are inlined).", mapOf("path" to p("STRING", "HTML file path"))),
                decl("open_in_studio", "Open a workspace file in the Coding Studio editor.", mapOf("path" to p("STRING", "File path"))),
                decl("open_file_external", "Open a workspace file with another installed app.", mapOf("path" to p("STRING", "File path")))
            )))
        })
    }
}

class ToolExecutor(private val c: AppContainer) {
    private val sensitive = Regex(
        "delete|remove|uninstall|erase|format|reset|pay|purchase|buy|send|transfer|confirm|submit|sign out|logout|ডিলিট|মুছ|পেমেন্ট|পাঠান|কিনুন",
        RegexOption.IGNORE_CASE
    )

    suspend fun execute(name: String, a: JsonObject): ToolResult = try {
        run(name, a)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        ToolResult(false, "${e.javaClass.simpleName}: ${e.message}")
    }

    private fun JsonObject.str(k: String): String = this[k]?.jsonPrimitive?.contentOrNull?.trim().orEmpty()

    private suspend fun a11y(block: suspend (NexoraAccessibilityService) -> ToolResult): ToolResult {
        val svc = NexoraAccessibilityService.instance
            ?: return ToolResult(false, "Accessibility service is OFF. Ask the user to enable NEXORA in Android Accessibility settings (Automation screen).")
        return block(svc)
    }

    private suspend fun run(name: String, a: JsonObject): ToolResult {
        val ws = c.workspace
        return when (name) {
            "open_app" -> openApp(a.str("app_name"))
            "read_screen_ui" -> a11y { ToolResult(true, it.snapshot()) }
            "tap" -> a11y { svc ->
                val t = a.str("text")
                if (t.isBlank()) ToolResult(false, "text required")
                else if (sensitive.containsMatchIn(t) &&
                    !c.confirmations.ask("Tap \"$t\"?", "NEXORA wants to tap a possibly sensitive control in ${svc.currentPackage()}.")
                ) ToolResult(false, "User declined this tap.")
                else svc.tapText(t)
            }
            "type_text" -> a11y { it.typeText(a["text"]?.jsonPrimitive?.contentOrNull.orEmpty()) }
            "scroll" -> a11y { it.scroll(a.str("direction")) }
            "swipe" -> a11y { it.swipe(a.str("direction")) }
            "go_back" -> a11y { it.back() }
            "go_home" -> a11y { it.home() }
            "create_file" -> {
                val path = a.str("path")
                val content = a["content"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (path.isBlank()) return ToolResult(false, "path required")
                if (ws.exists(path) && !c.confirmations.ask("Overwrite file?", path)) return ToolResult(false, "User declined overwrite.")
                ws.write(path, content)
                ToolResult(true, "Saved $path (${content.length} chars). Verified by reading it back.")
            }
            "read_file" -> ToolResult(true, ws.read(a.str("path")).take(20_000))
            "list_files" -> {
                val items = ws.list(a.str("path"))
                ToolResult(true, if (items.isEmpty()) "(empty)" else items.joinToString("\n") { (if (it.isDir) "[dir] " else "") + it.path })
            }
            "create_folder" -> { ws.ensureDir(a.str("path")); ToolResult(true, "Folder ready: ${a.str("path")}") }
            "rename_file" -> ToolResult(true, "Renamed to ${ws.rename(a.str("path"), a.str("new_name"))}")
            "delete_file" -> {
                val path = a.str("path")
                if (!c.confirmations.ask("Delete?", path)) ToolResult(false, "User declined deletion.")
                else { ws.delete(path); ToolResult(true, "Deleted $path", true) }
            }
            "create_project" -> {
                val folder = a.str("project_name").replace(Regex("[^A-Za-z0-9_.-]"), "_").ifBlank { "project" }
                val files = a["files"]?.jsonArray ?: return ToolResult(false, "files required")
                if (files.size > 30) return ToolResult(false, "Too many files (max 30)")
                val written = mutableListOf<String>()
                for (f in files) {
                    val o = f.jsonObject
                    val rel = o.str("path").trimStart('/')
                    if (rel.isBlank()) continue
                    ws.write("$folder/$rel", o["content"]?.jsonPrimitive?.contentOrNull.orEmpty())
                    written += "$folder/$rel"
                }
                ToolResult(true, "Created ${written.size} files (verified): ${written.joinToString(", ")}")
            }
            "preview_html" -> {
                val path = a.str("path")
                c.preview.value = PreviewBuilder.build(ws, path, c.preview.value.version + 1)
                c.uiEvents.tryEmit(UiEvent.OpenPreview)
                ToolResult(true, "Preview opened for $path (user can inspect it on screen).", false)
            }
            "open_in_studio" -> {
                val path = a.str("path")
                if (!ws.exists(path)) return ToolResult(false, "File not found: $path")
                c.uiEvents.tryEmit(UiEvent.OpenStudio(path))
                ToolResult(true, "Opened $path in Coding Studio.", false)
            }
            "open_file_external" -> openExternal(a.str("path"))
            else -> ToolResult(false, "Unknown tool: $name")
        }
    }

    private suspend fun openApp(query: String): ToolResult {
        if (query.isBlank()) return ToolResult(false, "app_name required")
        val pm = c.ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val q = norm(query)
        val match = apps.firstOrNull { norm(it.first) == q }
            ?: apps.firstOrNull { norm(it.first).startsWith(q) }
            ?: apps.firstOrNull { norm(it.first).contains(q) || q.contains(norm(it.first)) && norm(it.first).length > 2 }
            ?: return ToolResult(false, "No installed app matches \"$query\".")
        val launch = pm.getLaunchIntentForPackage(match.second)
            ?: return ToolResult(false, "${match.first} has no launchable activity.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.ctx.startActivity(launch)
        delay(1500)
        val svc = NexoraAccessibilityService.instance
        val fg = svc?.currentPackage()
        return when {
            fg == match.second -> ToolResult(true, "Opened ${match.first}; it is now in the foreground (confirmed).", true)
            svc == null -> ToolResult(true, "Launch request sent for ${match.first}, but I cannot verify it because the Accessibility service is off.", false)
            else -> ToolResult(false, "Launch requested for ${match.first} but foreground app is $fg (Android may block launches from the background).")
        }
    }

    private suspend fun openExternal(path: String): ToolResult {
        val doc = c.workspace.find(path) ?: return ToolResult(false, "File not found: $path")
        val uri: Uri = c.workspace.shareableUri(doc)
        val ext = path.substringAfterLast('.', "")
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "text/plain"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            c.ctx.startActivity(i)
            ToolResult(true, "Open-with request sent for $path.", false)
        } catch (e: ActivityNotFoundException) {
            ToolResult(false, "No installed app can open this file type.")
        }
    }
}
