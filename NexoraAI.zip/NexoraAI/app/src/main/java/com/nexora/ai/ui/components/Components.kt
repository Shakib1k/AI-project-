package com.nexora.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.ai.ui.theme.NX
import com.nexora.ai.voice.Phase
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun NexoraBackground(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NX.Black, cs.background, NX.Black)))
            .drawBehind {
                val c1 = Offset(size.width * .15f, size.height * .1f)
                val c2 = Offset(size.width * .9f, size.height * .85f)
                drawCircle(Brush.radialGradient(listOf(cs.primary.copy(.18f), Color.Transparent), c1, size.width * .8f), size.width * .8f, c1)
                drawCircle(Brush.radialGradient(listOf(cs.secondary.copy(.16f), Color.Transparent), c2, size.width * .9f), size.width * .9f, c2)
            }
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    glow: Color = MaterialTheme.colorScheme.primary,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    val base = modifier
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(.09f), Color.White.copy(.03f))))
        .border(1.dp, Brush.linearGradient(listOf(glow.copy(.55f), MaterialTheme.colorScheme.secondary.copy(.25f))), shape)
    Column(if (onClick != null) base.clickable(onClick = onClick) else base, content = content)
}

@Composable
fun AiOrb(phase: Phase, level: Float, modifier: Modifier = Modifier, orbSize: Dp = 160.dp) {
    val inf = rememberInfiniteTransition(label = "orb")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "t")
    val pulse by inf.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val amp by animateFloatAsState(
        when (phase) {
            Phase.Listening -> .08f + level * .18f
            Phase.Speaking -> .12f
            Phase.Thinking -> .06f
            Phase.Idle -> .03f
        }, label = "amp"
    )
    val c1 = MaterialTheme.colorScheme.primary
    val c2 = MaterialTheme.colorScheme.secondary
    Canvas(modifier.size(orbSize)) {
        val half = this.size.minDimension / 2
        val ctr = this.center
        val r = half * .62f * (1f + (pulse - 1f) * (if (phase == Phase.Idle) .5f else 1f) + amp)
        drawCircle(Brush.radialGradient(listOf(c1.copy(.35f), c2.copy(.15f), Color.Transparent), ctr, half), half, ctr)
        rotate(t * 360f, ctr) {
            drawCircle(c1.copy(.6f), r * 1.25f, ctr, style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 26f))))
        }
        rotate(-t * 540f, ctr) {
            drawCircle(c2.copy(.6f), r * 1.12f, ctr, style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 14f))))
        }
        val hl = Offset(ctr.x - r * .25f, ctr.y - r * .3f)
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(.9f), c1, c2, NX.Black), hl, r * 1.4f), r, ctr)
    }
}

@Composable
fun Waveform(phase: Phase, level: Float, modifier: Modifier = Modifier, bars: Int = 28) {
    val inf = rememberInfiniteTransition(label = "wave")
    val t by inf.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "wt")
    val lvl by animateFloatAsState(level, label = "lvl")
    val c1 = MaterialTheme.colorScheme.primary
    val c2 = MaterialTheme.colorScheme.secondary
    Canvas(modifier.fillMaxWidth().height(56.dp)) {
        val gap = size.width / bars
        val maxH = size.height
        for (i in 0 until bars) {
            val base = when (phase) {
                Phase.Listening -> .12f + lvl * .88f * (.5f + .5f * sin(t * 2 + i * .5f))
                Phase.Speaking -> .25f + .5f * abs(sin(t + i * .4f))
                Phase.Thinking -> .15f + .2f * abs(sin(t * 3 - i * .3f))
                Phase.Idle -> .08f
            }
            val h = maxH * base.coerceIn(.05f, 1f)
            val x = gap * i + gap / 2
            drawLine(lerp(c1, c2, i / bars.toFloat()), Offset(x, (maxH - h) / 2), Offset(x, (maxH + h) / 2), strokeWidth = gap * .5f, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun RichText(text: String) {
    val parts = text.split("```")
    Column {
        parts.forEachIndexed { i, p ->
            if (i % 2 == 1) {
                val code = p.substringAfter('\n', p).trimEnd()
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(Color.Black.copy(.45f), RoundedCornerShape(10.dp)).padding(8.dp)
                        .horizontalScroll(rememberScrollState())
                ) { Text(code, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = NX.Cyan) }
            } else if (p.isNotBlank()) {
                Text(p.trim(), color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
fun Bubble(text: String, mine: Boolean, error: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        GlassCard(
            Modifier.widthIn(max = 330.dp),
            glow = if (error) NX.Danger else if (mine) cs.primary else cs.secondary
        ) {
            Box(Modifier.padding(12.dp)) {
                if (error) Text(text, color = NX.Danger) else RichText(text)
            }
        }
    }
}

@Composable
fun TypingDots() {
    val inf = rememberInfiniteTransition(label = "dots")
    val t by inf.animateFloat(0f, 3f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "d")
    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until 3) {
            Box(
                Modifier.padding(2.dp).size(8.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = if (t.toInt() == i) 1f else .3f), RoundedCornerShape(50))
            )
        }
    }
}
