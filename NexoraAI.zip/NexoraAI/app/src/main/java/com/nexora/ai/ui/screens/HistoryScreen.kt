@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nexora.ai.container
import com.nexora.ai.ui.components.GlassCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(onBack: () -> Unit, open: (Long) -> Unit) {
    val ctx = LocalContext.current
    val c = ctx.container
    val dao = c.db.dao()
    val chats by dao.chats().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var exportId by remember { mutableStateOf<Long?>(null) }
    var deleteId by remember { mutableStateOf<Long?>(null) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri ->
        val id = exportId
        if (uri != null && id != null) scope.launch {
            try {
                val title = chats.firstOrNull { it.id == id }?.title ?: "Chat"
                val md = StringBuilder("# $title\n\n")
                dao.messagesOnce(id).forEach { md.append(if (it.role == "user") "**Boss:** " else "**NEXORA:** ").append(it.text).append("\n\n") }
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(md.toString().toByteArray()) } }
                Toast.makeText(ctx, "Exported", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Chat History") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        if (chats.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("কোনো চ্যাট নেই, বস।") }
        } else LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats, key = { it.id }) { ch ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { open(ch.id) }) {
                    Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ch.title, maxLines = 1)
                            Text(DateFormat.getDateTimeInstance().format(Date(ch.updatedAt)), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { exportId = ch.id; saver.launch("nexora-chat-${ch.id}.md") }) { Icon(Icons.Default.Share, "Export") }
                        IconButton(onClick = { deleteId = ch.id }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            title = { Text("Delete conversation?") },
            text = { Text("This removes the chat and its messages permanently.") },
            confirmButton = { TextButton(onClick = { scope.launch { dao.deleteChat(id) }; deleteId = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancel") } }
        )
    }
}
