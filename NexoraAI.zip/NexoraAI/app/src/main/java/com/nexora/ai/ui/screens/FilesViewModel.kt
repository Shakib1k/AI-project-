package com.nexora.ai.ui.screens

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.ai.NexoraApp
import com.nexora.ai.workspace.FileItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class FilesViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as NexoraApp).container
    val path = MutableStateFlow("")
    val items = MutableStateFlow<List<FileItem>>(emptyList())
    val loading = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val custom = MutableStateFlow(false)

    private fun launchSafe(block: suspend () -> Unit) {
        viewModelScope.launch {
            loading.value = true
            try { block() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { message.value = e.message ?: e.toString() }
            finally { loading.value = false }
        }
    }

    fun refresh() = launchSafe {
        custom.value = c.workspace.isCustomLocation()
        items.value = c.workspace.list(path.value)
    }

    fun openDir(p: String) { path.value = p; refresh() }
    fun up() { path.value = path.value.substringBeforeLast('/', ""); refresh() }

    fun create(name: String, isDir: Boolean) = launchSafe {
        val rel = listOf(path.value, name.trim()).filter { it.isNotEmpty() }.joinToString("/")
        if (c.workspace.exists(rel)) error("\"$name\" already exists")
        if (isDir) c.workspace.ensureDir(rel)
        else c.workspace.write(rel, template(name))
        items.value = c.workspace.list(path.value)
        message.value = "Created $rel (verified)"
    }

    private fun template(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "html" -> "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>New Page</title>\n</head>\n<body>\n  <h1>Hello, Boss</h1>\n</body>\n</html>\n"
        "py" -> "def main():\n    print(\"Hello, Boss\")\n\n\nif __name__ == \"__main__\":\n    main()\n"
        "java" -> "public class ${name.substringBeforeLast('.')} {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, Boss\");\n    }\n}\n"
        else -> ""
    }

    fun rename(p: String, newName: String) = launchSafe {
        c.workspace.rename(p, newName)
        items.value = c.workspace.list(path.value)
    }

    fun delete(p: String) = launchSafe {
        c.workspace.delete(p)
        items.value = c.workspace.list(path.value)
        message.value = "Deleted $p"
    }

    fun exportZip(p: String, out: Uri) = launchSafe {
        val n = c.workspace.zipTo(p, out)
        message.value = "Exported $n files as ZIP"
    }

    fun clearMessage() { message.value = null }
}
