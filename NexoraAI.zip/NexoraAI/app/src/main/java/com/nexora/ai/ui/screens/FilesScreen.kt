@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nexora.ai.UiEvent
import com.nexora.ai.container
import com.nexora.ai.data.SK
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.workspace.FileItem
import com.nexora.ai.workspace.PreviewBuilder
import kotlinx.coroutines.launch

@Composable
fun FilesScreen(vm: FilesViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val c = ctx.container
    val scope = rememberCoroutineScope()
    val path by vm.path.collectAsState()
    val items by vm.items.collectAsState()
    val loading by vm.loading.collectAsState()
    val message by vm.message.collectAsState()
    val custom by vm.custom.collectAsState()
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileItem?>(null) }
    var deleteTarget by remember { mutableStateOf<FileItem?>(null) }
    var zipTarget by remember { mutableStateOf<FileItem?>(null) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.refresh() }
    LaunchedEffect(message) { message?.let { snack.showSnackbar(it); vm.clearMessage() } }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            scope.launch { c.settings.set(SK.workspaceUri, uri.toString()); vm.openDir("") }
        }
    }
    val zipSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val t = zipTarget
        if (uri != null && t != null) vm.exportZip(t.path, uri)
    }

    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("File Manager") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = { folderPicker.launch(null) }) { Icon(Icons.Default.FolderOpen, "Choose workspace folder") }
                    IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.NoteAdd, "New") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            Text(
                "Workspace: " + if (custom) "your chosen folder" else "app storage (tap the folder icon to choose a location)",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (path.isNotEmpty()) IconButton(onClick = { vm.up() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Up") }
                Text("/" + path, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            }
            if (items.isEmpty() && !loading) Text("ফোল্ডারটি খালি, বস।", Modifier.padding(16.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(items, key = { it.path }) { f ->
                    GlassCard(Modifier.fillMaxWidth(), onClick = {
                        if (f.isDir) vm.openDir(f.path) else c.uiEvents.tryEmit(UiEvent.OpenStudio(f.path))
                    }) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (f.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.weight(1f).padding(12.dp)) {
                                Text(f.name, maxLines = 1)
                                if (!f.isDir) Text("${f.size} bytes", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box {
                                IconButton(onClick = { menuFor = f.path }) { Icon(Icons.Default.MoreVert, "Menu") }
                                DropdownMenu(expanded = menuFor == f.path, onDismissRequest = { menuFor = null }) {
                                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menuFor = null; renameTarget = f })
                                    if (!f.isDir) {
                                        DropdownMenuItem(text = { Text("Open with…") }, onClick = {
                                            menuFor = null
                                            scope.launch {
                                                val r = c.tools.execute("open_file_external", kotlinx.serialization.json.buildJsonObject {
                                                    put("path", kotlinx.serialization.json.JsonPrimitive(f.path))
                                                })
                                                if (!r.ok) snack.showSnackbar(r.message)
                                            }
                                        })
                                        if (f.name.endsWith(".html", true) || f.name.endsWith(".htm", true)) {
                                            DropdownMenuItem(text = { Text("Live preview") }, onClick = {
                                                menuFor = null
                                                scope.launch {
                                                    try {
                                                        c.preview.value = PreviewBuilder.build(c.workspace, f.path, c.preview.value.version + 1)
                                                        c.uiEvents.tryEmit(UiEvent.OpenPreview)
                                                    } catch (e: Exception) { snack.showSnackbar(e.message ?: "Preview failed") }
                                                }
                                            })
                                        }
                                    } else {
                                        DropdownMenuItem(text = { Text("Export as ZIP") }, onClick = {
                                            menuFor = null; zipTarget = f; zipSaver.launch("${f.name}.zip")
                                        })
                                    }
                                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menuFor = null; deleteTarget = f })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var isDir by remember { mutableStateOf(false) }
        var ext by remember { mutableStateOf("txt") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Create") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(isDir, { isDir = it }); Text("Folder")
                    }
                    if (!isDir) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("txt", "html", "py", "java").forEach { e -> FilterChip(ext == e, { ext = e }, label = { Text(e) }) }
                    }
                    Text("(extension is added if the name has none)", style = MaterialTheme.typography.labelLarge)
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    val n = name.trim().let { if (!isDir && !it.contains('.')) "$it.$ext" else it }
                    vm.create(n, isDir); showCreate = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
        )
    }
    renameTarget?.let { t ->
        var n by remember(t) { mutableStateOf(t.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(t.path, n.trim()); renameTarget = null }) { Text("Rename") } },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }
        )
    }
    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete ${t.name}?") },
            text = { Text(if (t.isDir) "The folder and everything inside will be removed." else "This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.delete(t.path); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}
