package com.nexora.ai

import android.app.Application
import android.content.Context
import com.nexora.ai.ai.Agent
import com.nexora.ai.ai.GeminiClient
import com.nexora.ai.ai.ToolExecutor
import com.nexora.ai.data.AppDatabase
import com.nexora.ai.data.SecureKeyStore
import com.nexora.ai.data.SettingsStore
import com.nexora.ai.util.ConfirmationBus
import com.nexora.ai.util.Notifier
import com.nexora.ai.workspace.PreviewContent
import com.nexora.ai.workspace.WorkspaceRepo
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

sealed interface UiEvent {
    data object OpenPreview : UiEvent
    data class OpenStudio(val path: String) : UiEvent
}

class NexoraApp : Application() {
    lateinit var container: AppContainer
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        container = AppContainer(this)
    }
}

/** Simple manual dependency container (no DI framework needed). */
class AppContainer(val ctx: Context) {
    val db = AppDatabase.build(ctx)
    val settings = SettingsStore(ctx)
    val keys = SecureKeyStore(ctx)
    val gemini = GeminiClient(settings, keys)
    val workspace = WorkspaceRepo(ctx, settings)
    val confirmations = ConfirmationBus(ctx)
    val uiEvents = MutableSharedFlow<UiEvent>(extraBufferCapacity = 8)
    val preview = MutableStateFlow(PreviewContent())
    val tools = ToolExecutor(this)
    val agent = Agent(this)
}

val Context.container: AppContainer get() = (applicationContext as NexoraApp).container
