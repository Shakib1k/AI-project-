package com.nexora.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object NX {
    val Black = Color(0xFF03040A)
    val Navy = Color(0xFF0A1128)
    val Surface = Color(0xFF111A33)
    val Cyan = Color(0xFF00E5FF)
    val Purple = Color(0xFF8B5CFF)
    val Text = Color(0xFFE8F1FF)
    val Muted = Color(0xFF8FA3C7)
    val Danger = Color(0xFFFF5370)
    val Ok = Color(0xFF3DDC97)
}

@Composable
fun NexoraTheme(accent: String, amoled: Boolean, content: @Composable () -> Unit) {
    val primary = if (accent == "purple") NX.Purple else NX.Cyan
    val secondary = if (accent == "purple") NX.Cyan else NX.Purple
    val scheme = darkColorScheme(
        primary = primary, secondary = secondary, tertiary = secondary,
        background = if (amoled) NX.Black else NX.Navy,
        surface = NX.Surface, surfaceVariant = NX.Surface,
        onPrimary = Color.Black, onSecondary = Color.Black,
        onBackground = NX.Text, onSurface = NX.Text, onSurfaceVariant = NX.Muted,
        error = NX.Danger, outline = primary.copy(alpha = .35f)
    )
    val typo = Typography(
        headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 28.sp, letterSpacing = 1.sp),
        titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, letterSpacing = 1.5.sp),
        titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, letterSpacing = .4.sp),
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
        bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
        labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = .5.sp)
    )
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
