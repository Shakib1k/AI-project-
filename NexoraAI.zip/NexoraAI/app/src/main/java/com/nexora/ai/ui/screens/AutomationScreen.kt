@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.nexora.ai.automation.NexoraAccessibilityService
import com.nexora.ai.container
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.theme.NX
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject

@Composable
fun AutomationScreen(onBack: () -> Unit, openToolLog: () -> Unit) {
    val ctx = LocalContext.current
    val c = ctx.container
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(NexoraAccessibilityService.isEnabled(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { enabled = NexoraAccessibilityService.isEnabled(ctx) }
    var appName by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Phone Automation") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassCard(Modifier.fillMaxWidth(), glow = if (enabled) NX.Ok else NX.Danger) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (enabled) "● Automation service is ON" else "○ Automation service is OFF", style = MaterialTheme.typography.titleMedium, color = if (enabled) NX.Ok else NX.Danger)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "NEXORA uses Android's AccessibilityService (a legitimate, user-enabled API) to open apps, read visible text, tap, scroll, " +
                            "go back and type — only when you ask the assistant to. It cannot work until YOU enable it, can be switched off anytime, " +
                            "never types into password fields, and asks you before sensitive taps (delete, pay, send…)."
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                        Text(if (enabled) "Open Accessibility settings" else "Enable in Accessibility settings")
                    }
                    if (!enabled) Text(
                        "Tip: on Android 13+, if the toggle is greyed out for a sideloaded app, open App info → ⋮ → “Allow restricted settings”, then try again.",
                        style = MaterialTheme.typography.labelLarge, color = NX.Muted, modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Quick test (runs the same tools the AI uses)", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(appName, { appName = it }, label = { Text("App name, e.g. MT Manager") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !working && appName.isNotBlank(), onClick = {
                            scope.launch {
                                working = true
                                try {
                                    val r = c.tools.execute("open_app", buildJsonObject { put("app_name", JsonPrimitive(appName)) })
                                    output = "${if (r.ok) "ok" else "FAILED"} (verified=${r.verified}): ${r.message}"
                                } finally { working = false }
                            }
                        }) { Text("Open app") }
                        OutlinedButton(enabled = !working, onClick = {
                            scope.launch {
                                working = true
                                try {
                                    output = "Switch to another app now… reading in 4 seconds."
                                    delay(4000)
                                    val r = c.tools.execute("read_screen_ui", buildJsonObject { })
                                    output = r.message
                                } finally { working = false }
                            }
                        }) { Text("Read screen (4s)") }
                    }
                    if (working) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (output.isNotEmpty()) Text(output, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }

            GlassCard(Modifier.fillMaxWidth(), onClick = openToolLog) {
                Text("View tool execution history →", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.primary)
            }
            Text(
                "Limits: some apps (banking, DRM, secure screens) hide their content from accessibility; Android may block launching apps from the background; " +
                    "UI taps are reported as 'dispatched', not 'succeeded' — the AI re-reads the screen to confirm.",
                style = MaterialTheme.typography.labelLarge, color = NX.Muted
            )
        }
    }
}
