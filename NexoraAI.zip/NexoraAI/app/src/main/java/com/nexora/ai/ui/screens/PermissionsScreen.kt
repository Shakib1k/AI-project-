@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.nexora.ai.automation.NexoraAccessibilityService
import com.nexora.ai.container
import com.nexora.ai.screen.ScreenShare
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.theme.NX

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val sharing by ScreenShare.active.collectAsState()
    val settings by ctx.container.settings.flow.collectAsState(initial = com.nexora.ai.data.AppSettings())

    val mic = remember(tick) { ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
    val notif = remember(tick) {
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val a11y = remember(tick) { NexoraAccessibilityService.isEnabled(ctx) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Permissions") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Perm("Microphone", "Needed for voice chat (speech-to-text).", mic, "Grant") { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
            Perm("Notifications", "Shows the screen-sharing indicator and confirmation requests.", notif, "Grant") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            Perm(
                "Screen capture", if (sharing) "Sharing is ACTIVE right now." else "Asked every time via Android's official dialog; nothing is captured until you approve.",
                sharing, "Manage on Dashboard", null
            )
            Perm(
                "Screen → cloud consent", "Whether you accepted that screenshots may be sent to Gemini while sharing.",
                settings.screenConsent, "Change in Settings", null
            )
            Perm("Accessibility (automation)", "Optional. Lets the AI tap/scroll/type when you ask.", a11y, "Open settings") {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Perm(
                "Storage", if (settings.workspaceUri.isNotBlank()) "Workspace folder chosen via Storage Access Framework." else "Using private app storage. Choose a folder in File Manager to store files elsewhere.",
                settings.workspaceUri.isNotBlank(), "Open File Manager", null
            )
        }
    }
}

@Composable
private fun Perm(title: String, desc: String, ok: Boolean, action: String, onClick: (() -> Unit)?) {
    GlassCard(Modifier.fillMaxWidth(), glow = if (ok) NX.Ok else NX.Muted) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((if (ok) "✔ " else "○ ") + title, style = MaterialTheme.typography.titleMedium, color = if (ok) NX.Ok else MaterialTheme.colorScheme.onSurface)
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = NX.Muted)
            }
            if (onClick != null && !ok) TextButton(onClick = onClick) { Text(action) }
        }
    }
}
