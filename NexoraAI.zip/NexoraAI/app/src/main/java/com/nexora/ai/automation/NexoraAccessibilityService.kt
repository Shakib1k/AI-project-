package com.nexora.ai.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.nexora.ai.ai.ToolResult
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Optional automation module. Does nothing until the user enables it in Android Accessibility settings,
 * and only acts when the AI agent calls a tool in response to a user request.
 */
class NexoraAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NexoraAccessibilityService? = null

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return enabled.split(':').mapNotNull { ComponentName.unflattenFromString(it) }
                .any { it.packageName == ctx.packageName && it.className == NexoraAccessibilityService::class.java.name }
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    /** Text outline of the foreground window (password fields are never read). */
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "(no active window — screen locked or app blocks accessibility)"
        val sb = StringBuilder("package=${root.packageName}\n")
        var n = 0
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null || n >= 150 || !node.isVisibleToUser) return
            val label = if (node.isPassword) "(password field)" else (node.text ?: node.contentDescription)?.toString()
            if (!label.isNullOrBlank() || node.isClickable || node.isEditable || node.isScrollable) {
                n++
                val flags = buildList {
                    if (node.isClickable) add("click"); if (node.isEditable) add("edit")
                    if (node.isScrollable) add("scroll"); if (node.isChecked) add("checked")
                }
                sb.append("- ").append(label?.take(80) ?: "")
                if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append("]")
                sb.append('\n')
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private suspend fun dispatch(path: Path, durationMs: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val started = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!started && cont.isActive) cont.resume(false)
    }

    suspend fun tapText(q: String): ToolResult {
        val root = rootInActiveWindow ?: return ToolResult(false, "No active window")
        val target = root.findAccessibilityNodeInfosByText(q).firstOrNull { it.isVisibleToUser }
            ?: return ToolResult(false, "No visible element matching \"$q\". Call read_screen_ui to see what is on screen.")
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return ToolResult(true, "Click dispatched on \"$q\". Outcome NOT verified — call read_screen_ui to check.", false)
        }
        val r = Rect()
        target.getBoundsInScreen(r)
        val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        return if (dispatch(p, 60)) ToolResult(true, "Tap gesture completed at \"$q\". Outcome NOT verified.", false)
        else ToolResult(false, "Tap gesture failed on \"$q\".")
    }

    fun typeText(text: String): ToolResult {
        val root = rootInActiveWindow ?: return ToolResult(false, "No active window")
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: firstEditable(root)
            ?: return ToolResult(false, "No editable field found on screen.")
        if (node.isPassword) return ToolResult(false, "Refusing to type into a password field.")
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return ToolResult(false, "The field rejected the text.")
        node.refresh()
        val ok = node.text?.toString() == text
        return ToolResult(true, if (ok) "Text entered and confirmed in the field." else "Text sent; could not confirm field content.", ok)
    }

    private fun firstEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) firstEditable(n.getChild(i))?.let { return it }
        return null
    }

    private fun firstScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) firstScrollable(n.getChild(i))?.let { return it }
        return null
    }

    suspend fun scroll(dir: String): ToolResult {
        val node = firstScrollable(rootInActiveWindow)
        val forward = dir == "down" || dir == "right"
        if (node != null && node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
            return ToolResult(true, "Scroll $dir dispatched.", false)
        }
        return swipe(dir)
    }

    suspend fun swipe(dir: String): ToolResult {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val p = Path()
        // "scroll down" = content moves up = finger swipes up
        when (dir) {
            "down" -> { p.moveTo(w / 2, h * .7f); p.lineTo(w / 2, h * .3f) }
            "up" -> { p.moveTo(w / 2, h * .3f); p.lineTo(w / 2, h * .7f) }
            "right" -> { p.moveTo(w * .8f, h / 2); p.lineTo(w * .2f, h / 2) }
            "left" -> { p.moveTo(w * .2f, h / 2); p.lineTo(w * .8f, h / 2) }
            else -> return ToolResult(false, "direction must be up, down, left or right")
        }
        return if (dispatch(p, 350)) ToolResult(true, "Swipe $dir completed.", false) else ToolResult(false, "Swipe failed.")
    }

    fun back(): ToolResult = if (performGlobalAction(GLOBAL_ACTION_BACK)) ToolResult(true, "Back pressed.", false) else ToolResult(false, "Back failed.")
    fun home(): ToolResult = if (performGlobalAction(GLOBAL_ACTION_HOME)) ToolResult(true, "Home pressed.", false) else ToolResult(false, "Home failed.")
}
