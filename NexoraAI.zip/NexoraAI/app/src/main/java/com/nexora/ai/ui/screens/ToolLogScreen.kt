@file:OptIn(ExperimentalMaterial3Api::class)

package com.nexora.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nexora.ai.container
import com.nexora.ai.ui.components.GlassCard
import com.nexora.ai.ui.theme.NX
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun ToolLogScreen(onBack: () -> Unit) {
    val dao = LocalContext.current.container.db.dao()
    val logs by dao.toolLogs().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Tool execution history") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { IconButton(onClick = { scope.launch { dao.clearToolLogs() } }) { Icon(Icons.Default.Delete, "Clear") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        if (logs.isEmpty()) Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("এখনো কোনো টুল চালানো হয়নি।") }
        else LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs, key = { it.id }) { l ->
                GlassCard(Modifier.fillMaxWidth(), glow = if (l.ok) NX.Ok else NX.Danger) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${if (l.ok) "✔" else "✖"} ${l.name}", style = MaterialTheme.typography.titleMedium)
                        Text(DateFormat.getDateTimeInstance().format(Date(l.createdAt)), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("args: ${l.args}", maxLines = 3, style = MaterialTheme.typography.bodyMedium)
                        Text(l.result, maxLines = 6, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
