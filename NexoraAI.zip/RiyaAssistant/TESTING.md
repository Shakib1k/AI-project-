# টেস্ট

স্বয়ংক্রিয়: `./gradlew testDebugUnitTest` (`CoreTest.kt`: consent, confirmation gate, risk policy, gesture path, text editing, language detection, VAD, proactive rules, chunking, Gemini request/response)।

## ফোনে হাতে পরীক্ষা (কোনোটি এখনো চালানো হয়নি)
**ভয়েস:** ডিফল্ট Cute Female · বাংলা/হিন্দি/ইংরেজি/মিশ্র প্রিভিউ · ভুল TTS মডেলে ফোন TTS fallback · ইন্টারনেট বন্ধ · TTS engine নিষ্ক্রিয় · কথা বলে ও অর্ব ট্যাপে থামানো · ফোন কল এলে (audio focus) থামা · দুটি কণ্ঠ একসাথে না বাজা · রিস্টার্টের পর সেটিং থাকা

**নিশ্চিতকরণ (শুধু পরীক্ষামূলক চ্যাটে):** Send-এর আগে প্রশ্ন · "না" বললে না পাঠানো · "হ্যাঁ, কিন্তু…" বললে না পাঠানো · প্রশ্নের পর চ্যাট বদলালে আবার জিজ্ঞাসা · একই মেসেজ দুবার না যাওয়া

**অটোমেশন:** Accessibility বন্ধ · password field প্রত্যাখ্যান · ব্লকড অ্যাপ · portrait/landscape swipe · gesture ও 3-button navigation · তালিকার শেষে swipe · দুবার থাকা শব্দ ডিলিট প্রত্যাখ্যান · MT Manager-এ টাইপ ও সেভ যাচাই

**থিম:** ১০টি থিম দেখা · Apply-এর আগে সেভ না হওয়া · রিস্টার্টের পর থাকা · লেখা পড়া যায়

**মেমরি:** export → delete → import · নষ্ট ফাইল import করলে কিছু না বদলানো

**Shizuku:** ইনস্টল নেই · সার্ভিস বন্ধ · pairing বাতিল/ব্যর্থ · অনুমতি প্রত্যাখ্যান ও প্রত্যাহার · Binder সংযোগ/বিচ্ছিন্ন · অ্যাপ রিস্টার্ট · ফোন reboot · Shizuku ছাড়া অ্যাপ চলা
(UserService/privileged operation যোগ হলে task চলাকালীন বন্ধ হওয়া, unsupported operation, fallback ও result reporting টেস্ট যোগ করতে হবে।)
