# Riya Assistant (v0.1.0 — প্রথম ধাপ)

**অবস্থা:** এই প্রজেক্ট এখনো Android SDK দিয়ে বিল্ড করা বা ফোনে চালানো হয়নি। শুধু `core/` প্যাকেজের ১৬টি ইউনিট টেস্ট (সাধারণ JVM-এ) পাস করেছে এবং সব Kotlin ফাইলে সিনট্যাক্স ভুল ধরা পড়েনি। প্রথম বিল্ডে কম্পাইল এরর আসতে পারে।

## বিল্ড করার উপায়

### ক) Android Studio
1. JDK 17+, Android SDK 35 ইনস্টল করুন।
2. ফোল্ডারটি Open করুন, Gradle sync হতে দিন।
3. `./gradlew testDebugUnitTest assembleDebug`
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

### খ) শুধু ফোন থেকে (GitHub Actions)
1. GitHub-এ একটি private repository বানিয়ে ZIP-এর ভেতরের সব ফাইল আপলোড করুন (`.github` ফোল্ডারসহ; `gradlew`-এর executable বিট রাখতে git দিয়ে push করা ভালো)।
2. Actions ট্যাবে "Build APK" চালান (executable বিট হারালে ধাপটিতে `bash gradlew ...` লিখুন)।
3. `riya-debug-apk` আর্টিফ্যাক্ট ডাউনলোড করুন।

বিল্ড ব্যর্থ হলে এররের লেখাটি পাঠান।

ভার্সন: AGP 8.7.3, Gradle 8.14.3, Kotlin 2.0.21, compileSdk 35, minSdk 29। এগুলো সর্বশেষ ভার্সন নয়; পরিচিত পুরোনো সেট বেছে নেওয়া হয়েছে।

## প্রথমবার সেটআপ
1. Settings → Gemini model: Google AI Studio থেকে নেওয়া API key দিন → Save → Test connection → একটি মডেল বাছুন।
2. Voice settings: প্রিভিউ শুনে ভয়েস বাছুন। ডিফল্ট Gemini ভয়েস `Leda`। "কিউট" শোনাবে কি না তা শুনে যাচাই করতে হবে; স্টাইল নির্দেশনা ফলাফলের নিশ্চয়তা দেয় না। TTS মডেল ডিফল্ট `gemini-3.8-flash-tts` (বদলানো যায়)। ব্যর্থ হলে ফোনের TTS ব্যবহার হয়।
3. Permission Center: মাইক্রোফোন ও Accessibility চালু করুন। সাইডলোড করা অ্যাপে Android 13+ এ আগে App info → ⋮ → Allow restricted settings লাগতে পারে।
4. Live Voice Chat চাপুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- **Play Store:** accessibility tool নয় এমন অ্যাপের AccessibilityService দিয়ে স্বয়ংক্রিয়ভাবে পরিকল্পনা করে কাজ করা Google Play নীতিতে নিষিদ্ধ। শুধু ব্যক্তিগত সাইডলোডের জন্য।
- **গোপনীয়তা:** কাজের সময় স্ক্রিনের দৃশ্যমান লেখা, আপনার কথার লিখিত রূপ এবং দরকারি মেমরি Google Gemini API-তে যায়। বলা বাক্য শোনার কাজ ফোনের speech service করে।
- **নিশ্চিতকরণ:** ঝুঁকিপূর্ণ ট্যাপ চেনা হয় বাটনের লেখা/ID-র শব্দতালিকা দিয়ে; লেখাহীন বাটনেও অনুমতি চাওয়া হয়। এটি heuristic, শতভাগ সুরক্ষা নয় (অচেনা ভাষা বা অস্বাভাবিক লেবেল ফসকাতে পারে; swipe-এ অনুমতি চাওয়া হয় না)। গুরুত্বপূর্ণ অ্যাকাউন্টে নজর রেখে ব্যবহার করুন।
- ব্যাংক/পেমেন্ট/পাসওয়ার্ড অ্যাপ ও সিস্টেম সেটিংস নামের ভিত্তিতে ব্লক করা; তালিকাটি সম্পূর্ণ নয় (`core/RiskPolicy.kt`)।
- Barge-in: শুধু রিয়া কথা বলার সময় এবং hardware echo canceller থাকলে। আপনার প্রথম কয়েকটি শব্দ হারাতে পারে। ভাবার সময় থামাতে অর্বে ট্যাপ করুন।
- ভাষা: শোনার ভাষা হাতে বাছতে হয়; স্বয়ংক্রিয় ভাষা শনাক্ত নেই।
- উত্তর streaming হয় না, তাই দেরি লাগতে পারে। TTS-ও API কোটা খরচ করে।
- মেমরি export সাধারণ (অনএনক্রিপ্টেড) JSON। ১ GB সর্বোচ্চ সীমা, আগে থেকে সংরক্ষিত জায়গা নয়।
- স্ক্রিন বন্ধ বা ফোনভেদে ব্যাটারি সেভারে সেশন/স্পিচ রিকগনিশন থেমে যেতে পারে।

## ফিচারের অবস্থা
"কোড আছে" মানে লেখা হয়েছে, **ফোনে যাচাই হয়নি**।

| ফিচার (স্পেক) | অবস্থা |
|---|---|
| অর্ব, হোম UI, ১০ থিম + System, প্রিভিউ, সেভ | কোড আছে। থিম টেস্ট ও contrast যাচাই বাকি |
| দুই ভয়েস ব্যক্তিত্ব, Gemini TTS + ফোন TTS, প্রিভিউ, গতি/পিচ | কোড আছে। Pause/resume, expressiveness স্লাইডার, TTS streaming নেই |
| লাইভ ভয়েস, barge-in, proactive, quiet hours | আংশিক (উপরের সীমাবদ্ধতা) |
| কাস্টম নাম | কোড আছে। Wake word = সক্রিয় সেশনে নাম থাকা; আলাদা wake word সেটিং নেই |
| Gemini key, মডেল discovery, কাস্টম মডেল | কোড আছে |
| তিন ভাষার UI | বেশিরভাগ UI অনূদিত; থিমের নাম, মেমরি ক্যাটাগরি, কিছু টেকনিক্যাল লেবেল ইংরেজি। অ্যাপের ভেতরে ভাষা বদল Android 13+ |
| English Permission Center | বর্তমানে ব্যবহৃত পারমিশনগুলোর জন্য কোড আছে |
| অ্যাপ খোলা, স্ক্রিন পড়া, ট্যাপ, টাইপ, Back/Home | কোড আছে |
| Smart delete/replace | কোড আছে, লজিক টেস্টেড। মনে রাখে শুধু শেষ টাইপ করা অংশ (অ্যাপ চালু থাকা পর্যন্ত)। আলাদা text selection নেই |
| Swipe engine | কোড আছে, পাথ লজিক টেস্টেড |
| ওয়েব সার্চ (web/image/video) | কোড আছে |
| Telegram/WhatsApp/Messenger/Facebook, MT Manager, সোশ্যাল অ্যাপ, YouTube UI | **আলাদা adapter নেই।** সাধারণ স্ক্রিন টুল দিয়ে চেষ্টা করবে; নির্ভরযোগ্যতা অজানা। অনেক কোড এডিটর accessibility text input নেয় না। পাঠানো মেসেজ edit/delete-এ long-press লাগে, যা এখনো নেই |
| কোডিং সহায়তা | Gemini মডেলের মাধ্যমে; আলাদা coding engine নেই |
| মেমরি (সেভ, সার্চ, এডিট, ডিলিট, ব্যাকআপ, রিস্টোর) | কোড আছে। স্বয়ংক্রিয় conversation summary/task history নেই |
| Shizuku | স্ট্যাটাস, অনুমতি, Binder listener, সেটআপ গাইড। **UserService, privileged operation, task router, activity log নেই** |
| OCR, MediaProjection স্ক্রিন পর্যবেক্ষণ, ভাসমান অর্ব | **তৈরি হয়নি** |
| থাম্বনেইল (ChatGPT/AI), ভিডিও বাছাই ইঞ্জিন | **তৈরি হয়নি** |
| YouTube Data API, Google sign-in, আপলোড, pinned comment, চ্যানেল তৈরি | **তৈরি হয়নি** |
| সোশ্যাল platform adapter, প্রোফাইল ওয়ার্কফ্লো, content planning, social task log | **তৈরি হয়নি** |

## পরের ধাপের প্রস্তাবিত ক্রম
1. প্রথম বিল্ড সবুজ করা ও ফোনে ভয়েস/অটোমেশন পরীক্ষা
2. long-press + Telegram/WhatsApp ও MT Manager পরীক্ষা ও ঠিক করা
3. ভিডিও picker + YouTube আপলোড। API pinned comment pin করতে পারে কি না যাচাই করতে হবে (আমার জানা মতে পারে না, UI লাগবে)। unverified API project-এর আপলোড private-এ আটকে থাকতে পারে: এবার ডকুমেন্টেশন থেকে নিশ্চিত করা যায়নি, বানানোর আগে যাচাই করুন
4. থাম্বনেইল, MediaProjection + OCR, ভাসমান অর্ব
5. সোশ্যাল adapter, Shizuku-র দরকারি অপারেশন

টেস্ট পরিকল্পনা: [TESTING.md](TESTING.md)
