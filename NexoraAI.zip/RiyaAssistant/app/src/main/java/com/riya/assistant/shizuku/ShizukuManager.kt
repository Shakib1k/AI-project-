package com.riya.assistant.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

data class ShizukuStatus(val installed: Boolean = false, val running: Boolean = false, val authorized: Boolean = false, val mode: String = "-")

/**
 * Status, authorisation and Binder lifecycle only. No privileged operation or UserService exists yet,
 * because no current feature needs one. Everything else works without Shizuku.
 */
class ShizukuManager(private val context: Context) {
    private val _status = MutableStateFlow(ShizukuStatus())
    val status = _status.asStateFlow()

    init {
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { refresh() }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
        refresh()
    }

    /** Always read from the live service; nothing is cached across checks. */
    fun refresh() {
        val installed = runCatching { context.packageManager.getPackageInfo(PACKAGE, 0) }.isSuccess
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val authorized = running && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
        val mode = if (!running) "-" else when (runCatching { Shizuku.getUid() }.getOrNull()) {
            0 -> "Root"
            2000 -> "ADB"
            else -> "Unknown"
        }
        _status.value = ShizukuStatus(installed, running, authorized, mode)
    }

    fun requestAuthorization(): String? {
        refresh()
        if (!status.value.running) return "Shizuku service is not running."
        if (Shizuku.isPreV11()) return "This Shizuku version is too old."
        if (status.value.authorized) return "Already authorized."
        if (Shizuku.shouldShowRequestPermissionRationale()) return "Authorization was denied. Allow this app inside the Shizuku app."
        Shizuku.requestPermission(100)
        return null
    }

    fun openShizuku(): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        context.startActivity(intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private companion object { const val PACKAGE = "moe.shizuku.privileged.api" }
}
