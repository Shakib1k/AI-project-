package com.riya.assistant.core

import kotlin.math.PI
import kotlin.math.cos

enum class SwipeDirection { UP, DOWN, LEFT, RIGHT }
enum class SwipeSpeed(val durationMs: Long) { GENTLE(650), NORMAL(380), FAST(220) }
data class Area(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width get() = right - left
    val height get() = bottom - top
}
data class Insets4(val left: Int, val top: Int, val right: Int, val bottom: Int)
data class Pt(val x: Float, val y: Float)
data class SwipePlan(val points: List<Pt>, val durationMs: Long)

/** Builds eased multi-point swipe paths from live screen geometry. UP means the finger moves upward. */
object GesturePlanner {
    fun plan(
        display: Area,
        insets: Insets4,
        target: Area?,
        direction: SwipeDirection,
        speed: SwipeSpeed,
        distanceFraction: Float = 0.6f,
        steps: Int = 16,
    ): SwipePlan? {
        val edgeX = (display.width * 0.06f).toInt()
        val edgeY = (display.height * 0.04f).toInt()
        val safe = Area(
            display.left + maxOf(insets.left, edgeX),
            display.top + maxOf(insets.top, edgeY),
            display.right - maxOf(insets.right, edgeX),
            display.bottom - maxOf(insets.bottom, edgeY),
        )
        val t = target ?: safe
        val area = Area(maxOf(safe.left, t.left), maxOf(safe.top, t.top), minOf(safe.right, t.right), minOf(safe.bottom, t.bottom))
        if (area.width < 40 || area.height < 40 || steps < 2) return null

        val f = distanceFraction.coerceIn(0.2f, 0.85f)
        val cx = (area.left + area.right) / 2f
        val cy = (area.top + area.bottom) / 2f
        val dx = area.width * f / 2f
        val dy = area.height * f / 2f
        val (start, end) = when (direction) {
            SwipeDirection.UP -> Pt(cx, cy + dy) to Pt(cx, cy - dy)
            SwipeDirection.DOWN -> Pt(cx, cy - dy) to Pt(cx, cy + dy)
            SwipeDirection.LEFT -> Pt(cx + dx, cy) to Pt(cx - dx, cy)
            SwipeDirection.RIGHT -> Pt(cx - dx, cy) to Pt(cx + dx, cy)
        }
        val points = (0..steps).map { i ->
            val e = ((1 - cos(PI * i / steps)) / 2).toFloat()
            Pt(start.x + (end.x - start.x) * e, start.y + (end.y - start.y) * e)
        }
        return SwipePlan(points, speed.durationMs)
    }
}
