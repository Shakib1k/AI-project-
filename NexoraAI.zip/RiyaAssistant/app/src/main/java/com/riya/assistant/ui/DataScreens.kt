package com.riya.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as SystemSettings
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riya.assistant.AppContainer
import com.riya.assistant.R
import com.riya.assistant.automation.RiyaAccessibilityService
import com.riya.assistant.data.MemoryItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val MemoryCategories = listOf(
    "User preferences", "Important instructions", "Coding projects", "Saved files", "Task history", "Frequent apps",
    "YouTube channel", "Telegram channel", "Saved links", "Thumbnail preferences", "Description preferences", "Conversation summaries",
)

@Composable
fun MemoryScreen(app: AppContainer, back: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val all by app.memory.items.collectAsStateWithLifecycle(emptyList())
    var query by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf(emptyList<MemoryItem>()) }
    var category by remember { mutableStateOf("Saved links") }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<MemoryItem?>(null) }
    LaunchedEffect(query, all) { shown = if (query.isBlank()) all else app.memory.search(query, 100) }

    fun io(block: suspend () -> String) {
        scope.launch {
            message = try { withContext(Dispatchers.IO) { block() } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { "Error: ${e.javaClass.simpleName}" }
        }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) io {
            context.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(app.memory.exportJson().toByteArray()) }
            "OK"
        }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) io {
            val text = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
            "OK: ${app.memory.importJson(text)}"
        }
    }
    Page(stringResource(R.string.memory), back) {
        Text("%.2f MB / %.0f MB".format(app.memory.usedBytes() / 1048576.0, app.memory.limitBytes() / 1048576.0))
        Row {
            TextButton({ export.launch("riya-memory-backup.json") }) { Text(stringResource(R.string.backup)) }
            TextButton({ import.launch(arrayOf("application/json", "text/plain")) }) { Text(stringResource(R.string.restore)) }
        }
        Text(message)
        Panel {
            Dropdown(stringResource(R.string.category), category, MemoryCategories.map { it to it }) { category = it }
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.title)) })
            OutlinedTextField(content, { content = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.content)) })
            Button({ io { if (app.memory.save(category, title, content)) { title = ""; content = ""; "OK" } else "Storage full" } },
                enabled = title.isNotBlank() && content.isNotBlank()) { Text(stringResource(R.string.save)) }
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.search)) })
        shown.take(100).forEach { item ->
            key(item.id) {
                Panel {
                    Text("${item.category} · ${item.title}", style = MaterialTheme.typography.titleSmall)
                    var edited by remember(item.content) { mutableStateOf(item.content) }
                    OutlinedTextField(edited, { edited = it }, Modifier.fillMaxWidth())
                    Row {
                        TextButton({ io { app.memory.edit(item, edited); "OK" } }, enabled = edited != item.content) { Text(stringResource(R.string.save)) }
                        TextButton({ deleting = item }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }
    deleting?.let { item ->
        AlertDialog({ deleting = null }, confirmButton = { TextButton({ deleting = null; io { app.memory.delete(item); "OK" } }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton({ deleting = null }) { Text(stringResource(R.string.cancel)) } }, title = { Text(item.title) })
    }
}

private fun granted(c: Context, permission: String) = ContextCompat.checkSelfPermission(c, permission) == PackageManager.PERMISSION_GRANTED
private fun appSettings(c: Context) = Intent(SystemSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", c.packageName, null))

/** Intentionally English only, so these strings are not in the translatable resources. */
@Composable
fun PermissionScreen(app: AppContainer, back: () -> Unit) {
    val context = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val accessibility by RiyaAccessibilityService.instance.collectAsStateWithLifecycle()
    val shizuku by app.shizuku.status.collectAsStateWithLifecycle()
    fun status(ok: Boolean, otherwise: String = "Not Granted") = if (ok) "Granted" else otherwise
    fun open(intent: Intent) { runCatching { context.startActivity(intent) } }

    @Composable
    fun Entry(name: String, purpose: String, state: String, requiredFor: String, setup: () -> Unit) = Panel {
        Text("Permission Name: $name", style = MaterialTheme.typography.titleMedium)
        Text("Purpose: $purpose")
        Text("Current Status: $state", color = MaterialTheme.colorScheme.primary)
        Text("Required For: $requiredFor")
        Row {
            TextButton(setup) { Text("Setup / Open Settings") }
            TextButton({ app.shizuku.refresh(); tick++ }) { Text("Recheck Permission") }
        }
    }

    Page("Permission Center", back) {
        key(tick) {
            val mic = granted(context, Manifest.permission.RECORD_AUDIO)
            Entry("Microphone Permission", "Hear you during a voice session that you start.", status(mic), "Live Voice Chat") {
                if (mic) open(appSettings(context)) else request.launch(Manifest.permission.RECORD_AUDIO)
            }
            Entry("Speech Recognition Permission", "Android uses the microphone permission and an installed recognition service. That service may send audio to its provider.",
                if (!SpeechRecognizer.isRecognitionAvailable(context)) "Restricted by Android" else status(mic), "Voice commands") { open(Intent(SystemSettings.ACTION_VOICE_INPUT_SETTINGS)) }
            Entry("Accessibility Permission",
                "Lets the assistant read visible screen text, tap, type and swipe when you ask. During a task, visible text is sent to the Google Gemini API. Password fields are not read. Enable only if you accept this. If Android blocks it for a sideloaded app, open App info and choose Allow restricted settings.",
                status(accessibility != null), "Phone automation") { open(Intent(SystemSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
            val notificationGranted = Build.VERSION.SDK_INT < 33 || granted(context, Manifest.permission.POST_NOTIFICATIONS)
            Entry("Notification Permission", "Show the active voice session and its Stop button.", status(notificationGranted, "Optional"), "Session notification") {
                if (!notificationGranted && Build.VERSION.SDK_INT >= 33) request.launch(Manifest.permission.POST_NOTIFICATIONS) else open(appSettings(context))
            }
            Entry("Shizuku Authorization", "Optional advanced access. No current feature requires it.",
                when { !shizuku.running -> "Shizuku Not Connected"; !shizuku.authorized -> "Shizuku Authorization Required"; else -> "Granted" },
                "Optional") { app.shizuku.requestAuthorization() }
        }
    }
}

@Composable
fun ShizukuScreen(app: AppContainer, back: () -> Unit) {
    val s by app.shizuku.status.collectAsStateWithLifecycle()
    var message by remember { mutableStateOf("") }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { app.shizuku.refresh() }
    Page("Shizuku", back) {
        Panel {
            Text("Installed: ${if (s.installed) "Yes" else "No"}")
            Text("Service: ${if (s.running) "Running" else "Stopped / Not connected"}")
            Text("Authorization: ${if (s.authorized) "Authorized" else "Not authorized"}")
            Text("Mode: ${s.mode}")
            Button({ if (!app.shizuku.openShizuku()) message = "Shizuku is not installed." }) { Text("Open Shizuku") }
            OutlinedButton({ app.shizuku.refresh() }) { Text("Check Connection Again") }
            OutlinedButton({ message = app.shizuku.requestAuthorization().orEmpty() }, enabled = s.running && !s.authorized) { Text("Request Authorization") }
            Text(message)
        }
        Panel {
            Text("Wireless debugging (no root, Android 11+): install Shizuku from its official source, enable Developer options and Wireless debugging, then in Shizuku choose Pairing and enter the code shown by Android. Tap Start in Shizuku, return here and request authorization. You must complete pairing yourself. Repeat Start after a reboot.")
            Text("Android 10 and older: start Shizuku from a computer with ADB using the command shown inside Shizuku.")
            Text("Root: only if your device is already rooted, start Shizuku in root mode. This app never asks for root itself.")
            Text("Troubleshooting: pairing failed → generate a new code. Service stopped → start it again in Shizuku. Denied → allow this app inside Shizuku. To disconnect or revoke access, turn this app off in Shizuku's authorized app list.")
        }
    }
}
