package com.riya.assistant.core

import kotlinx.serialization.json.*

data class GeminiModel(val id: String, val displayName: String, val methods: List<String>) {
    val canChat get() = "generateContent" in methods && !isTts
    val isTts get() = id.contains("tts", ignoreCase = true)
}
data class FunctionCall(val name: String, val args: JsonObject, val id: String? = null)

/** [modelContent] is kept verbatim so opaque fields such as thought signatures are sent back unchanged. */
data class ModelTurn(val text: String, val calls: List<FunctionCall>, val modelContent: JsonObject?)

/** Request/response shapes for the Gemini REST API (v1beta). No networking here, so it is unit-testable. */
object GeminiProtocol {
    fun parseModels(body: String): Pair<List<GeminiModel>, String?> {
        val root = Json.parseToJsonElement(body).jsonObject
        val models = root["models"]?.jsonArray.orEmpty().map { it.jsonObject }.mapNotNull { m ->
            val name = m.string("name") ?: return@mapNotNull null
            GeminiModel(
                name.removePrefix("models/"),
                m.string("displayName") ?: name,
                m["supportedGenerationMethods"]?.jsonArray?.map { it.jsonPrimitive.content }.orEmpty(),
            )
        }
        return models to root.string("nextPageToken")
    }

    fun parseTurn(body: String): ModelTurn {
        val root = Json.parseToJsonElement(body).jsonObject
        val candidate = root["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
        val content = candidate?.get("content") as? JsonObject
        val parts = content?.get("parts")?.jsonArray?.map { it.jsonObject }.orEmpty()
        val text = parts.filter { it["thought"]?.jsonPrimitive?.booleanOrNull != true }
            .mapNotNull { it.string("text") }.joinToString("")
        val calls = parts.mapNotNull { p ->
            val c = p["functionCall"] as? JsonObject ?: return@mapNotNull null
            FunctionCall(c.string("name") ?: return@mapNotNull null, c["args"] as? JsonObject ?: JsonObject(emptyMap()), c.string("id"))
        }
        return ModelTurn(text, calls, content)
    }

    fun userText(text: String): JsonObject = buildJsonObject {
        put("role", "user")
        putJsonArray("parts") { addJsonObject { put("text", text) } }
    }

    fun functionResponses(results: List<Pair<FunctionCall, String>>): JsonObject = buildJsonObject {
        put("role", "user")
        putJsonArray("parts") {
            results.forEach { (call, result) ->
                addJsonObject {
                    putJsonObject("functionResponse") {
                        put("name", call.name)
                        call.id?.let { put("id", it) }
                        putJsonObject("response") { put("result", result) }
                    }
                }
            }
        }
    }

    fun chatRequest(system: String, contents: List<JsonObject>, tools: JsonArray, temperature: Double, maxTokens: Int): String =
        buildJsonObject {
            putJsonObject("systemInstruction") { putJsonArray("parts") { addJsonObject { put("text", system) } } }
            put("contents", JsonArray(contents))
            if (tools.isNotEmpty()) putJsonArray("tools") { addJsonObject { put("functionDeclarations", tools) } }
            putJsonObject("generationConfig") { put("temperature", temperature); put("maxOutputTokens", maxTokens) }
        }.toString()

    /** Gemini 3.8 TTS takes style as part metadata; earlier TTS models take it as a natural-language prefix. */
    fun ttsRequest(model: String, text: String, voice: String, style: String): String = buildJsonObject {
        val metadataStyle = model.startsWith("gemini-3.8")
        putJsonArray("contents") {
            addJsonObject {
                put("role", "user")
                putJsonArray("parts") {
                    addJsonObject {
                        put("text", if (metadataStyle) text else "Say in a $style voice: $text")
                        if (metadataStyle) putJsonObject("speech_metadata") { put("style", style) }
                    }
                }
            }
        }
        putJsonObject("generationConfig") {
            putJsonArray("responseModalities") { add("AUDIO") }
            putJsonObject("speechConfig") {
                putJsonObject("voiceConfig") { putJsonObject("prebuiltVoiceConfig") { put("voiceName", voice) } }
            }
        }
    }.toString()

    /** Returns base64 audio and its MIME type. */
    fun parseAudio(body: String): Pair<String, String>? {
        val parts = Json.parseToJsonElement(body).jsonObject["candidates"]?.jsonArray?.firstOrNull()
            ?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray ?: return null
        for (p in parts) {
            val data = p.jsonObject["inlineData"] as? JsonObject ?: continue
            return (data.string("data") ?: continue) to (data.string("mimeType") ?: "audio/l16")
        }
        return null
    }

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
}
