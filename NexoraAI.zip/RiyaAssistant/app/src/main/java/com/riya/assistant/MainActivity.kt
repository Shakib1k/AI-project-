package com.riya.assistant

import android.app.LocaleManager
import android.os.Build
import android.os.Bundle
import android.os.LocaleList
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.riya.assistant.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as RiyaApp).container
        setContent {
            val model: MainViewModel = viewModel()
            val loaded by model.settings.collectAsStateWithLifecycle()
            val s = loaded ?: return@setContent
            var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
            val parent = if (screen == Screen.SETTINGS) Screen.HOME else Screen.SETTINGS
            BackHandler(screen != Screen.HOME) { screen = parent }
            RiyaTheme(s.theme) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.safeDrawingPadding()) {
                        val back = { screen = parent }
                        when (screen) {
                            Screen.HOME -> HomeScreen(container, s, model::update) { screen = it }
                            Screen.SETTINGS -> SettingsScreen(s, model::update, { screen = it }, ::setAppLanguage)
                            Screen.MODELS -> ModelsScreen(container, s, model::update, back)
                            Screen.VOICE -> VoiceScreen(container, s, model::update, back)
                            Screen.MEMORY -> MemoryScreen(container, back)
                            Screen.PERMISSIONS -> PermissionScreen(container, back)
                            Screen.THEMES -> ThemesScreen(s, model::update, back)
                            Screen.SHIZUKU -> ShizukuScreen(container, back)
                        }
                    }
                }
            }
        }
    }

    /** Per-app language needs Android 13; older versions follow the system language. */
    private fun setAppLanguage(tag: String) {
        if (Build.VERSION.SDK_INT >= 33) {
            getSystemService(LocaleManager::class.java).applicationLocales = LocaleList.forLanguageTags(tag)
        } else {
            android.widget.Toast.makeText(this, R.string.language_needs_13, android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
