package com.riya.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow

/** Holds the live service instance. It does nothing on its own; it acts only when a voice session asks. */
class RiyaAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance.value = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance.value = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance.value = null; super.onDestroy() }

    companion object { val instance = MutableStateFlow<RiyaAccessibilityService?>(null) }
}
