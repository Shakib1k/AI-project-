package com.riya.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.riya.assistant.R
import com.riya.assistant.voice.OrbState

@Composable
fun Orb(state: OrbState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val duration = when (state) { OrbState.IDLE -> 3200; OrbState.LISTENING -> 1500; OrbState.SPEAKING -> 650; else -> 1000 }
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by key(duration) {
        transition.animateFloat(0f, 1f, infiniteRepeatable(tween(duration, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    }
    val spin by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin")
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val description = stringResource(R.string.orb)
    Canvas(modifier.size(260.dp).semantics { contentDescription = description }.clickable(onClick = onClick)) {
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(primary.copy(alpha = 0.45f), Color.Transparent), center, r), r)
        val core = r * (0.52f + 0.07f * pulse)
        drawCircle(Brush.radialGradient(listOf(secondary, primary, primary.copy(alpha = 0.35f)), center - Offset(core * 0.35f, core * 0.35f), core * 1.5f), core)
        listOf(0.74f to 1f, 0.86f to -1.4f).forEach { (k, dir) ->
            val ring = r * k
            drawArc(if (dir > 0) primary else secondary, spin * dir, if (state == OrbState.IDLE) 90f else 220f, false,
                center - Offset(ring, ring), Size(ring * 2, ring * 2), style = Stroke(2.dp.toPx()))
        }
    }
}

@Composable
fun Page(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", style = MaterialTheme.typography.headlineSmall) }
            Text(title, style = MaterialTheme.typography.headlineSmall)
        }
        content()
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }

@Composable
fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked, onChange)
    }

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onDone: (Float) -> Unit) {
    var local by remember(value) { mutableStateOf(value) }
    Text("$label: ${"%.2f".format(local).removeSuffix(".00")}")
    Slider(local, { local = it }, valueRange = range, onValueChangeFinished = { onDone(local) })
}

/** Text field that saves only when the button is pressed. */
@Composable
fun SavedField(label: String, value: String, onSave: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(text, { text = it }, Modifier.weight(1f), label = { Text(label) }, singleLine = true)
        TextButton({ onSave(text.trim()) }, enabled = text != value) { Text(stringResource(R.string.save)) }
    }
}

@Composable
fun Dropdown(label: String, selected: String, options: List<Pair<String, String>>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text("$label: ${options.firstOrNull { it.first == selected }?.second ?: selected}") }
        DropdownMenu(open, { open = false }) {
            options.forEach { (value, title) -> DropdownMenuItem({ Text(title) }, { open = false; onPick(value) }) }
        }
    }
}
