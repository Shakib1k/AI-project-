package com.riya.assistant.voice

import android.content.Context
import android.media.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.riya.assistant.ai.GeminiClient
import com.riya.assistant.core.GeminiProtocol
import com.riya.assistant.core.LanguageDetector
import com.riya.assistant.core.SpeechChunker
import com.riya.assistant.data.Settings
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

interface TtsProvider {
    /** Suspends until playback ends. Cancelling the coroutine stops audio at once. */
    suspend fun speak(text: String, settings: Settings)
}

class GeminiTts(private val client: GeminiClient) : TtsProvider {
    override suspend fun speak(text: String, settings: Settings) {
        val body = GeminiProtocol.ttsRequest(settings.ttsModel, text, settings.activeVoice, settings.personality.style)
        val (data, mime) = GeminiProtocol.parseAudio(client.generate(settings.ttsModel, body)) ?: error("No audio returned")
        var pcm = Base64.decode(data, Base64.DEFAULT)
        var sampleRate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toInt() ?: 24000
        if (pcm.size > 44 && String(pcm, 0, 4) == "RIFF") {
            sampleRate = int32(pcm, 24)
            var offset = 12
            while (offset + 8 < pcm.size && String(pcm, offset, 4) != "data") offset += 8 + int32(pcm, offset + 4)
            pcm = pcm.copyOfRange(minOf(offset + 8, pcm.size), pcm.size)
        }
        play(pcm, sampleRate, settings.speechRate)
    }

    private fun int32(b: ByteArray, at: Int) = (0..3).fold(0) { acc, i -> acc or ((b[at + i].toInt() and 0xff) shl (8 * i)) }

    private suspend fun play(pcm: ByteArray, sampleRate: Int, speed: Float) = withContext(Dispatchers.IO) {
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT), sampleRate / 5))
            .build()
        try {
            if (speed != 1f) runCatching { track.playbackParams = PlaybackParams().setSpeed(speed) }
            track.play()
            var written = 0
            while (written < pcm.size) {
                ensureActive()
                val n = track.write(pcm, written, minOf(2400, pcm.size - written))
                if (n <= 0) error("Audio playback failed")
                written += n
            }
            track.stop()
            val frames = pcm.size / 2
            var waited = 0L
            val limit = (frames * 1000L / sampleRate * 2) + 2000
            while (track.playbackHeadPosition < frames && waited < limit) { delay(30); waited += 30 }
        } finally {
            runCatching { track.pause(); track.flush() }
            track.release()
        }
    }
}

/** Local fallback. Voice choice and quality depend on the installed engine. */
class AndroidTts(context: Context) : TtsProvider {
    private val ready = CompletableDeferred<Boolean>()
    private val waiting = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val engine = TextToSpeech(context.applicationContext) { ready.complete(it == TextToSpeech.SUCCESS) }

    init {
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String) = Unit
            override fun onDone(id: String) { waiting.remove(id)?.complete(true) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String) { waiting.remove(id)?.complete(false) }
        })
    }

    suspend fun voices(): List<Voice> =
        if (withTimeoutOrNull(5000) { ready.await() } == true)
            engine.voices.orEmpty().filter { it.locale.language in setOf("bn", "hi", "en") }.sortedBy { it.name }
        else emptyList()

    override suspend fun speak(text: String, settings: Settings) {
        check(withTimeoutOrNull(5000) { ready.await() } == true) { "No text-to-speech engine is available" }
        val locale = Locale.forLanguageTag(LanguageDetector.localeTag(text, settings.listenLanguage))
        check(engine.setLanguage(locale) >= TextToSpeech.LANG_AVAILABLE) { "The engine has no voice for ${locale.toLanguageTag()}" }
        engine.voices.orEmpty().firstOrNull { it.name == settings.androidVoice && it.locale.language == locale.language }?.let { engine.voice = it }
        engine.setPitch(settings.personality.pitch * settings.pitch)
        engine.setSpeechRate(settings.speechRate)
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Boolean>()
        waiting[id] = done
        try {
            check(engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS) { "Speech could not start" }
            check(done.await()) { "Speech playback failed" }
        } finally {
            if (waiting.remove(id) != null || !done.isCompleted) engine.stop()
        }
    }
}

/** Single entry point for speech: a mutex prevents overlap and audio focus loss stops playback. */
class Speaker(context: Context, client: GeminiClient) {
    private val neural = GeminiTts(client)
    val local = AndroidTts(context)
    private val audio = context.getSystemService(AudioManager::class.java)
    private val mutex = Mutex()

    /** Returns a notice when the neural voice failed and the local voice was used. */
    suspend fun speak(text: String, settings: Settings): String? = mutex.withLock {
        val clean = text.replace(Regex("[*#`_]"), "").trim()
        if (clean.isEmpty()) return@withLock null
        var notice: String? = null
        coroutineScope {
            val playback = launch(start = CoroutineStart.LAZY) {
                var useNeural = settings.useNeuralVoice
                for (chunk in SpeechChunker.chunk(clean)) {
                    if (useNeural) {
                        try { neural.speak(chunk, settings); continue }
                        catch (e: CancellationException) { throw e }
                        catch (e: Exception) { useNeural = false; notice = "Neural voice unavailable, using device voice. ${e.message.orEmpty()}" }
                    }
                    local.speak(chunk, settings)
                }
            }
            val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setOnAudioFocusChangeListener { if (it < 0) playback.cancel() }.build()
            if (audio.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                playback.cancel(); return@coroutineScope
            }
            try { playback.start(); playback.join() } finally { audio.abandonAudioFocusRequest(focus) }
        }
        notice
    }
}
