package com.riya.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

sealed interface Heard {
    data class Text(val value: String) : Heard
    data object Silence : Heard
    data class Error(val message: String) : Heard
}

class SpeechInput(private val context: Context) {
    /** One utterance, with end-of-speech detection done by the platform recogniser. */
    suspend fun listen(language: String): Heard = withContext<Heard>(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return@withContext Heard.Error("No speech recognition service is installed.")
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        try {
            suspendCancellableCoroutine<Heard> { cont ->
                fun done(h: Heard) { if (cont.isActive) cont.resume(h) }
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        done(if (text.isNullOrBlank()) Heard.Silence else Heard.Text(text))
                    }
                    override fun onError(error: Int) = done(
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> Heard.Silence
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> Heard.Error("Microphone permission is not granted.")
                            else -> Heard.Error("Speech recognition error $error.")
                        },
                    )
                    override fun onReadyForSpeech(params: Bundle?) = Unit
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() = Unit
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
                recognizer.startListening(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, language),
                )
            }
        } finally {
            recognizer.destroy()
        }
    }
}
