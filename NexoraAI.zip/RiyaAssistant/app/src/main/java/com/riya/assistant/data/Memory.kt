package com.riya.assistant.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "memories", indices = [Index(value = ["category", "title"], unique = true)])
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val title: String,
    val content: String,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY updatedAt DESC LIMIT 500")
    fun observe(): Flow<List<MemoryItem>>

    @Query("SELECT * FROM memories WHERE title LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' OR category LIKE '%' || :q || '%' ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun search(q: String, limit: Int): List<MemoryItem>

    @Query("SELECT * FROM memories") suspend fun all(): List<MemoryItem>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(item: MemoryItem)
    @Update suspend fun update(item: MemoryItem)
    @Delete suspend fun delete(item: MemoryItem)
}

@Database(entities = [MemoryItem::class], version = 1, exportSchema = false)
abstract class MemoryDatabase : RoomDatabase() { abstract fun dao(): MemoryDao }

class MemoryRepository(private val context: Context) {
    private val dao = Room.databaseBuilder(context, MemoryDatabase::class.java, "memory.db").build().dao()
    val items = dao.observe()

    /** The database grows with use. 1 GB is a ceiling, not a reservation. */
    fun usedBytes(): Long = listOf("memory.db", "memory.db-wal").sumOf { context.getDatabasePath(it).length() }
    fun limitBytes(): Long =
        minOf(1L shl 30, usedBytes() + maxOf(0, context.filesDir.usableSpace - (200L shl 20)))

    suspend fun save(category: String, title: String, content: String): Boolean {
        if (usedBytes() + content.toByteArray().size >= limitBytes()) return false
        dao.put(MemoryItem(category = category.trim(), title = title.trim(), content = content))
        return true
    }

    suspend fun search(query: String, limit: Int = 10) = dao.search(query, limit)
    suspend fun edit(item: MemoryItem, content: String) = dao.update(item.copy(content = content, updatedAt = System.currentTimeMillis()))
    suspend fun delete(item: MemoryItem) = dao.delete(item)

    /** Plain JSON, not encrypted. The API key is never part of memory exports. */
    suspend fun exportJson(): String = JSONArray().apply {
        dao.all().forEach { put(JSONObject().put("category", it.category).put("title", it.title).put("content", it.content).put("updatedAt", it.updatedAt)) }
    }.toString(2)

    /** Parses the whole file before writing anything, so a damaged file changes nothing. */
    suspend fun importJson(json: String): Int {
        val array = JSONArray(json)
        val parsed = (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            MemoryItem(category = o.getString("category"), title = o.getString("title"), content = o.getString("content"), updatedAt = o.optLong("updatedAt"))
        }
        return parsed.count { save(it.category, it.title, it.content) }
    }
}
