package com.riya.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riya.assistant.AppContainer
import com.riya.assistant.R
import com.riya.assistant.automation.RiyaAccessibilityService
import com.riya.assistant.core.GeminiModel
import com.riya.assistant.core.SwipeSpeed
import com.riya.assistant.data.Personality
import com.riya.assistant.data.Settings
import com.riya.assistant.voice.OrbState
import com.riya.assistant.voice.VoiceService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, MODELS, VOICE, MEMORY, PERMISSIONS, THEMES, SHIZUKU }

private fun languages() = listOf("bn-BD" to "বাংলা", "hi-IN" to "हिन्दी", "en-IN" to "English")

@Composable
fun HomeScreen(app: AppContainer, s: Settings, update: ((Settings) -> Settings) -> Unit, go: (Screen) -> Unit) {
    val context = LocalContext.current
    val status by app.session.status.collectAsStateWithLifecycle()
    val automation by RiyaAccessibilityService.instance.collectAsStateWithLifecycle()
    val memories by app.memory.items.collectAsStateWithLifecycle(emptyList())
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) VoiceService.start(context) }
    val label = stringResource(
        when (status.state) {
            OrbState.IDLE -> R.string.ready; OrbState.LISTENING -> R.string.listening; OrbState.THINKING -> R.string.thinking
            OrbState.WORKING -> R.string.working; OrbState.SPEAKING -> R.string.speaking
        },
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(s.name, style = MaterialTheme.typography.displaySmall)
        Text(label, color = MaterialTheme.colorScheme.primary)
        Orb(status.state, { app.session.interrupt() })
        // Only the latest status line; no chat history on the home screen.
        if (status.message.isNotBlank()) Text(status.message, maxLines = 3)
        Button(
            {
                if (status.active) VoiceService.stop(context)
                else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) VoiceService.start(context)
                else mic.launch(Manifest.permission.RECORD_AUDIO)
            },
            Modifier.fillMaxWidth().height(56.dp),
        ) { Text(stringResource(if (status.active) R.string.stop else R.string.live_chat)) }
        Dropdown(stringResource(R.string.personality), s.personality.name, Personality.entries.map { it.name to it.label }) { v ->
            update { it.copy(personality = Personality.valueOf(v), geminiVoice = "") }
        }
        OutlinedButton({ go(Screen.MODELS) }, Modifier.fillMaxWidth()) {
            Text("${stringResource(R.string.model)}: ${s.model.ifBlank { stringResource(R.string.not_selected) }}")
        }
        Panel {
            Text("${stringResource(R.string.memory)}: ${memories.size}${if (memories.size == 500) "+" else ""}")
            Text("${stringResource(R.string.automation)}: ${stringResource(if (automation != null) R.string.on else R.string.off)}")
        }
        TextButton({ go(Screen.SETTINGS) }) { Text(stringResource(R.string.settings)) }
    }
}

@Composable
fun SettingsScreen(s: Settings, update: ((Settings) -> Settings) -> Unit, go: (Screen) -> Unit, onAppLanguage: (String) -> Unit) {
    Page(stringResource(R.string.settings), { go(Screen.HOME) }) {
        listOf(Screen.MODELS to stringResource(R.string.model), Screen.VOICE to stringResource(R.string.voice),
            Screen.MEMORY to stringResource(R.string.memory), Screen.THEMES to stringResource(R.string.themes),
            Screen.PERMISSIONS to "Permission Center", Screen.SHIZUKU to "Shizuku").forEach { (screen, title) ->
            OutlinedButton({ go(screen) }, Modifier.fillMaxWidth()) { Text(title) }
        }
        Panel {
            SavedField(stringResource(R.string.ai_name), s.name) { v -> if (v.isNotBlank()) update { it.copy(name = v) } }
            SavedField(stringResource(R.string.address), s.address) { v -> if (v.isNotBlank()) update { it.copy(address = v) } }
            Toggle(stringResource(R.string.require_name), s.requireName) { v -> update { it.copy(requireName = v) } }
            Dropdown(stringResource(R.string.listen_language), s.listenLanguage, languages()) { v -> update { it.copy(listenLanguage = v) } }
            Dropdown(stringResource(R.string.reply_language), s.replyLanguage,
                listOf("Same as the user", "Bengali", "Hindi", "English").map { it to it }) { v -> update { it.copy(replyLanguage = v) } }
            Dropdown(stringResource(R.string.app_language), "", listOf("bn" to "বাংলা", "hi" to "हिन्दी", "en" to "English"), onAppLanguage)
            Dropdown(stringResource(R.string.swipe_speed), s.swipeSpeed.name, SwipeSpeed.entries.map { it.name to it.name.lowercase() }) { v ->
                update { it.copy(swipeSpeed = SwipeSpeed.valueOf(v)) }
            }
        }
    }
}

@Composable
fun ModelsScreen(app: AppContainer, s: Settings, update: ((Settings) -> Settings) -> Unit, back: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(app.keys.load() != null) }
    var models by remember { mutableStateOf(emptyList<GeminiModel>()) }
    var message by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Page(stringResource(R.string.model), back) {
        Panel {
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            Text(stringResource(if (hasKey) R.string.key_saved else R.string.key_missing))
            Row {
                TextButton({ app.keys.save(key); key = ""; hasKey = app.keys.load() != null }, enabled = key.isNotBlank()) { Text(stringResource(R.string.save)) }
                TextButton({ app.keys.save(""); hasKey = false; models = emptyList() }, enabled = hasKey) { Text(stringResource(R.string.delete)) }
            }
            Button({
                scope.launch {
                    message = "…"
                    try { models = app.gemini.listModels(); message = "OK: ${models.size}" }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) { message = e.message.orEmpty() }
                }
            }, enabled = hasKey) { Text(stringResource(R.string.test_connection)) }
            Text(message)
        }
        Text("${stringResource(R.string.model)}: ${s.model.ifBlank { stringResource(R.string.not_selected) }}")
        models.filter { it.canChat }.forEach { m ->
            OutlinedButton({ update { it.copy(model = m.id) } }, Modifier.fillMaxWidth()) { Text((if (m.id == s.model) "✓ " else "") + m.id) }
        }
        val tts = models.filter { it.isTts }
        if (tts.isNotEmpty()) Dropdown("TTS", s.ttsModel, tts.map { it.id to it.id }) { v -> update { it.copy(ttsModel = v) } }
        Panel {
            OutlinedTextField(custom, { custom = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.custom_model)) }, singleLine = true)
            TextButton({
                val id = custom.trim().removePrefix("models/"); val old = editing
                update { it.copy(customModels = it.customModels - setOfNotNull(old) + id, model = if (old != null && it.model == old) id else it.model) }
                custom = ""; editing = null
            }, enabled = Regex("(models/)?[A-Za-z0-9._-]+").matches(custom.trim())) { Text(stringResource(R.string.save)) }
            s.customModels.sorted().forEach { id ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ update { it.copy(model = id) } }, Modifier.weight(1f)) { Text((if (id == s.model) "✓ " else "") + id) }
                    TextButton({ custom = id; editing = id }) { Text(stringResource(R.string.edit)) }
                    TextButton({ update { it.copy(customModels = it.customModels - id, model = if (it.model == id) "" else it.model) } }) { Text(stringResource(R.string.delete)) }
                }
            }
        }
        Panel {
            SliderRow("Temperature", s.temperature, 0f..2f) { v -> update { it.copy(temperature = v) } }
            SliderRow("Max output tokens", s.maxTokens.toFloat(), 256f..16384f) { v -> update { it.copy(maxTokens = v.toInt()) } }
        }
    }
}

@Composable
fun VoiceScreen(app: AppContainer, s: Settings, update: ((Settings) -> Settings) -> Unit, back: () -> Unit) {
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<Job?>(null) }
    var message by remember { mutableStateOf("") }
    var voices by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    LaunchedEffect(Unit) { voices = app.speaker.local.voices().map { it.name to "${it.locale.toLanguageTag()} · ${it.name}" } }
    val sessionStatus by app.session.status.collectAsStateWithLifecycle()
    val neural = "Achernar Achird Algenib Algieba Alnilam Aoede Autonoe Callirrhoe Charon Despina Enceladus Erinome Fenrir Gacrux Iapetus Kore Laomedeia Leda Orus Puck Pulcherrima Rasalgethi Sadachbia Sadaltager Schedar Sulafat Umbriel Vindemiatrix Zephyr Zubenelgenubi".split(" ")
    Page(stringResource(R.string.voice), { preview?.cancel(); back() }) {
        Panel {
            Dropdown(stringResource(R.string.personality), s.personality.name, Personality.entries.map { it.name to it.label }) { v -> update { it.copy(personality = Personality.valueOf(v), geminiVoice = "") } }
            Toggle(stringResource(R.string.spoken_replies), s.spokenReplies) { v -> update { it.copy(spokenReplies = v) } }
            Toggle(stringResource(R.string.neural_voice), s.useNeuralVoice) { v -> update { it.copy(useNeuralVoice = v) } }
            Dropdown("Gemini voice", s.activeVoice, neural.map { it to it }) { v -> update { it.copy(geminiVoice = v) } }
            SavedField("TTS model", s.ttsModel) { v -> update { it.copy(ttsModel = v) } }
            if (voices.isNotEmpty()) Dropdown("Device voice", s.androidVoice, voices) { v -> update { it.copy(androidVoice = v) } }
            else Text(stringResource(R.string.no_device_voice))
            SliderRow(stringResource(R.string.speed), s.speechRate, 0.6f..1.6f) { v -> update { it.copy(speechRate = v) } }
            SliderRow(stringResource(R.string.pitch), s.pitch, 0.8f..1.3f) { v -> update { it.copy(pitch = v) } }
            listOf("বস, আমি শুনছি।", "बॉस, मैं सुन रही हूँ।", "Boss, I'm right here.").forEach { sample ->
                OutlinedButton({
                    preview?.cancel()
                    preview = scope.launch {
                        try { message = app.speaker.speak(sample, s).orEmpty() }
                        catch (e: CancellationException) { throw e }
                        catch (e: Exception) { message = e.message.orEmpty() }
                    }
                }, enabled = !sessionStatus.active) { Text("▶ $sample") }
            }
            TextButton({ preview?.cancel() }) { Text(stringResource(R.string.stop)) }
            Text(message)
        }
        Panel {
            Toggle(stringResource(R.string.barge_in), s.bargeIn && app.bargeIn.supported) { v -> update { it.copy(bargeIn = v) } }
            if (!app.bargeIn.supported) Text(stringResource(R.string.no_echo_cancel))
            Toggle(stringResource(R.string.proactive), s.proactive.enabled) { v -> update { it.copy(proactive = it.proactive.copy(enabled = v)) } }
            Toggle(stringResource(R.string.dnd), s.doNotDisturb) { v -> update { it.copy(doNotDisturb = v) } }
            SliderRow(stringResource(R.string.silence_seconds), s.proactive.silenceSeconds.toFloat(), 15f..180f) { v -> update { it.copy(proactive = it.proactive.copy(silenceSeconds = v.toInt())) } }
            SliderRow(stringResource(R.string.max_nudges), s.proactive.maxMessages.toFloat(), 0f..5f) { v -> update { it.copy(proactive = it.proactive.copy(maxMessages = v.toInt())) } }
            SliderRow(stringResource(R.string.quiet_start), s.proactive.quietStartHour.toFloat(), 0f..23f) { v -> update { it.copy(proactive = it.proactive.copy(quietStartHour = v.toInt())) } }
            SliderRow(stringResource(R.string.quiet_end), s.proactive.quietEndHour.toFloat(), 0f..23f) { v -> update { it.copy(proactive = it.proactive.copy(quietEndHour = v.toInt())) } }
            SliderRow(stringResource(R.string.timeout_minutes), s.timeoutMinutes.toFloat(), 1f..30f) { v -> update { it.copy(timeoutMinutes = v.toInt()) } }
        }
    }
}

@Composable
fun ThemesScreen(s: Settings, update: ((Settings) -> Settings) -> Unit, back: () -> Unit) {
    var preview by remember { mutableStateOf(s.theme) }
    // The whole gallery renders in the previewed theme; nothing is saved until Apply.
    RiyaTheme(preview) {
        Surface(Modifier.fillMaxSize()) {
            Page(stringResource(R.string.themes), back) {
                Orb(OrbState.LISTENING, {}, Modifier.align(Alignment.CenterHorizontally))
                Button({ update { it.copy(theme = preview) } }, Modifier.fillMaxWidth(), enabled = preview != s.theme) { Text(stringResource(R.string.apply)) }
                (listOf(SYSTEM_THEME to "System Default") + Palettes.map { it.id to it.title }).forEach { (id, title) ->
                    RiyaTheme(id) {
                        Panel {
                            Text((if (id == s.theme) "✓ " else "") + title)
                            Button({ preview = id }) { Text(stringResource(R.string.preview)) }
                        }
                    }
                }
            }
        }
    }
}
