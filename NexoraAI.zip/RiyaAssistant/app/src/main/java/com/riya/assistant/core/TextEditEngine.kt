package com.riya.assistant.core

sealed interface EditCommand {
    data class Append(val text: String) : EditCommand
    data class ReplaceExact(val find: String, val replacement: String) : EditCommand
    data class DeleteExact(val find: String) : EditCommand
    data object DeleteLastTyped : EditCommand
    data object DeleteLastLine : EditCommand
    data object DeleteLastSentence : EditCommand
    data object DeleteLastParagraph : EditCommand
    data object Clear : EditCommand
}

sealed interface EditOutcome {
    data class Ok(val text: String) : EditOutcome
    data class Refused(val reason: String) : EditOutcome
}

/** Pure text transformations. Ambiguous or missing targets are refused so unrelated text is never removed. */
object TextEditEngine {
    fun apply(current: String, command: EditCommand, lastTyped: String? = null): EditOutcome = when (command) {
        is EditCommand.Append -> EditOutcome.Ok(current + command.text)
        is EditCommand.ReplaceExact -> replaceOne(current, command.find, command.replacement)
        is EditCommand.DeleteExact -> replaceOne(current, command.find, "")
        EditCommand.DeleteLastTyped -> when {
            lastTyped.isNullOrEmpty() -> EditOutcome.Refused("No text typed by the assistant is recorded for this field.")
            !current.endsWith(lastTyped) -> replaceOne(current, lastTyped, "")
            else -> EditOutcome.Ok(current.dropLast(lastTyped.length))
        }
        EditCommand.DeleteLastLine -> cutTail(current, Regex("\n"), keepSeparator = false)
        EditCommand.DeleteLastParagraph -> cutTail(current, Regex("\n[ \t]*\n"), keepSeparator = false)
        EditCommand.DeleteLastSentence -> cutTail(current, Regex("[.!?।॥]\\s+|\n"), keepSeparator = true)
        EditCommand.Clear -> EditOutcome.Ok("")
    }

    private fun replaceOne(current: String, find: String, replacement: String): EditOutcome {
        if (find.isEmpty()) return EditOutcome.Refused("The text to find is empty.")
        val first = current.indexOf(find)
        if (first < 0) return EditOutcome.Refused("That text is not in the field.")
        if (current.indexOf(find, first + 1) >= 0) {
            return EditOutcome.Refused("That text appears more than once. Include more surrounding words.")
        }
        return EditOutcome.Ok(current.substring(0, first) + replacement + current.substring(first + find.length))
    }

    private fun cutTail(current: String, separator: Regex, keepSeparator: Boolean): EditOutcome {
        val body = current.trimEnd()
        if (body.isEmpty()) return EditOutcome.Refused("The field is already empty.")
        val last = separator.findAll(body).lastOrNull() ?: return EditOutcome.Ok("")
        val end = if (keepSeparator) last.range.last + 1 else last.range.first
        return EditOutcome.Ok(body.substring(0, end).trimEnd())
    }
}
