package com.riya.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

data class AppPalette(val id: String, val title: String, val dark: Boolean, val bg: Long, val surface: Long, val primary: Long, val secondary: Long, val text: Long) {
    fun scheme(): ColorScheme {
        val b = Color(bg); val s = Color(surface); val p = Color(primary); val q = Color(secondary); val t = Color(text)
        fun on(c: Color) = if (c.luminance() > 0.179f) Color.Black else Color.White
        val base = if (dark) darkColorScheme() else lightColorScheme()
        return base.copy(
            primary = p, onPrimary = on(p), primaryContainer = s, onPrimaryContainer = t, inversePrimary = p,
            secondary = q, onSecondary = on(q), secondaryContainer = s, onSecondaryContainer = t,
            tertiary = q, onTertiary = on(q), background = b, onBackground = t,
            surface = b, onSurface = t, surfaceVariant = s, onSurfaceVariant = t,
            surfaceContainerLowest = b, surfaceContainerLow = s, surfaceContainer = s,
            surfaceContainerHigh = s, surfaceContainerHighest = s, outline = t.copy(alpha = 0.45f),
        )
    }
}

val Palettes = listOf(
    AppPalette("obsidian_red", "Obsidian Red", true, 0xFF050505, 0xFF151213, 0xFFE0243A, 0xFFFFFFFF, 0xFFF7F5F5),
    AppPalette("midnight_blue", "Midnight Blue", true, 0xFF060D1F, 0xFF101C38, 0xFF2F8CFF, 0xFFBFDcFF, 0xFFEEF4FF),
    AppPalette("purple_galaxy", "Purple Galaxy", true, 0xFF0F0820, 0xFF1E1238, 0xFF9D5CFF, 0xFFD9C6FF, 0xFFF3EDFF),
    AppPalette("emerald_night", "Emerald Night", true, 0xFF04140F, 0xFF0C261D, 0xFF2FD98F, 0xFFB6F2D6, 0xFFFBF7EE),
    AppPalette("rose_quartz", "Rose Quartz", false, 0xFFFFF6F7, 0xFFF8E3E8, 0xFFA8466A, 0xFF7C5964, 0xFF2D1B21),
    AppPalette("arctic_silver", "Arctic Silver", false, 0xFFEEF1F4, 0xFFDDE3EA, 0xFF2E6C91, 0xFF52626F, 0xFF16202A),
    AppPalette("ocean_teal", "Ocean Teal", true, 0xFF03191C, 0xFF0A2E33, 0xFF27D6D0, 0xFFA9F0ED, 0xFFFFFFFF),
    AppPalette("sunset_ember", "Sunset Ember", true, 0xFF151110, 0xFF261D1A, 0xFFFF6B35, 0xFFFFC09F, 0xFFFFF1DE),
    AppPalette("cyber_neon", "Cyber Neon", true, 0xFF0E0F13, 0xFF1A1C24, 0xFF00E5FF, 0xFFFF3DCB, 0xFFF2F6FF),
    AppPalette("pure_minimal", "Pure Minimal", false, 0xFFFFFFFF, 0xFFF0F0F1, 0xFF2B2B2E, 0xFF5E5E63, 0xFF000000),
)
const val SYSTEM_THEME = "system"

@Composable
fun RiyaTheme(id: String, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val palette = if (id == SYSTEM_THEME) Palettes.first { it.id == if (systemDark) "obsidian_red" else "pure_minimal" }
        else Palettes.firstOrNull { it.id == id } ?: Palettes.first()
    MaterialTheme(colorScheme = palette.scheme(), content = content)
}
