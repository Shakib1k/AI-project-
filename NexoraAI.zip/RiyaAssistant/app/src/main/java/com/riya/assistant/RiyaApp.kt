package com.riya.assistant

import android.app.Application
import android.content.Context
import com.riya.assistant.ai.Assistant
import com.riya.assistant.ai.GeminiClient
import com.riya.assistant.ai.Tools
import com.riya.assistant.automation.PhoneController
import com.riya.assistant.core.ConfirmationGate
import com.riya.assistant.data.MemoryRepository
import com.riya.assistant.data.SecureKeyStore
import com.riya.assistant.data.SettingsRepository
import com.riya.assistant.shizuku.ShizukuManager
import com.riya.assistant.voice.*

/** Manual constructor injection. */
class AppContainer(context: Context) {
    val keys = SecureKeyStore(context)
    val settings = SettingsRepository(context)
    val memory = MemoryRepository(context)
    val gemini = GeminiClient(keys)
    private val gate = ConfirmationGate()
    private val tools = Tools(context, PhoneController(context), memory, settings, gate)
    val speaker by lazy { Speaker(context, gemini) }
    val bargeIn = BargeInMonitor()
    val session by lazy { VoiceSession(Assistant(gemini, tools, settings), SpeechInput(context), speaker, bargeIn, gate, settings) }
    val shizuku = ShizukuManager(context)
}

class RiyaApp : Application() {
    lateinit var container: AppContainer
        private set
    override fun onCreate() { super.onCreate(); container = AppContainer(this) }
}
