package com.riya.assistant.voice

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.riya.assistant.R
import com.riya.assistant.RiyaApp
import kotlinx.coroutines.*

/** Keeps the microphone session alive, visibly, while the assistant works in other apps. */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val session = (application as RiyaApp).container.session
        if (intent?.action == STOP) { session.stop(); stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Voice session", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, VoiceService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_orb).setContentTitle(getString(R.string.session_active))
            .setOngoing(true).addAction(0, getString(R.string.stop), stop).build()
        try {
            ServiceCompat.startForeground(this, 1, notification,
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        session.start(scope) { stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        (application as RiyaApp).container.session.stop()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "voice"
        private const val STOP = "com.riya.assistant.STOP"
        fun start(context: Context) = ContextCompat.startForegroundService(context, Intent(context, VoiceService::class.java))
        fun stop(context: Context) { context.startService(Intent(context, VoiceService::class.java).setAction(STOP)) }
    }
}
