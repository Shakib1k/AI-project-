package com.riya.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import com.riya.assistant.core.VoiceActivityDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/**
 * Returns true when the user starts talking while the assistant is speaking.
 * Only runs with hardware echo cancellation; without it the assistant would interrupt itself.
 * Audio is analysed in memory and never stored.
 */
class BargeInMonitor {
    val supported get() = AcousticEchoCanceler.isAvailable()

    @SuppressLint("MissingPermission")
    suspend fun awaitVoice(): Boolean = withContext(Dispatchers.IO) {
        if (!supported) return@withContext false
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return@withContext false
        val record = runCatching {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
        }.getOrNull() ?: return@withContext false
        var echo: AcousticEchoCanceler? = null
        try {
            if (record.state != AudioRecord.STATE_INITIALIZED) return@withContext false
            echo = AcousticEchoCanceler.create(record.audioSessionId)?.apply { enabled = true }
            if (echo == null) return@withContext false
            record.startRecording()
            val detector = VoiceActivityDetector()
            val frame = ShortArray(320)
            while (true) {
                currentCoroutineContext().ensureActive()
                val n = record.read(frame, 0, frame.size)
                if (n < 0) return@withContext false
                if (detector.accept(frame, n)) return@withContext true
            }
            @Suppress("UNREACHABLE_CODE") false
        } finally {
            echo?.release()
            record.release()
        }
    }
}
