package com.riya.assistant.core

/** Decides which UI taps need spoken approval and which apps/fields are off limits. */
object RiskPolicy {
    private val risky = listOf(
        "send", "post", "publish", "upload", "delete", "remove", "pay", "buy", "purchase", "order",
        "submit", "share", "save changes", "block", "report", "leave", "unsubscribe", "confirm",
        "allow", "ok", "okay", "yes", "accept", "agree", "continue", "join", "follow", "subscribe", "unfriend", "install", "uninstall", "reply", "comment", "call", "pin", "done", "transfer",
        "পাঠান", "পাঠাও", "পোস্ট", "প্রকাশ", "আপলোড", "মুছ", "ডিলিট", "কিনুন", "শেয়ার",
        "ঠিক আছে", "হ্যাঁ", "ठीक", "हाँ", "भेजें", "भेजो", "पोस्ट", "प्रकाशित", "अपलोड", "हटाएं", "डिलीट", "खरीद", "शेयर",
    )

    /** Unlabelled controls (icon-only send buttons) are treated as risky because we cannot tell what they do. */
    fun tapNeedsConfirmation(label: String): Boolean {
        val l = label.trim().lowercase()
        if (l.isEmpty()) return true
        return risky.any { word ->
            if (word.all { it.code < 128 }) Regex("\\b${Regex.escape(word)}\\b").containsMatchIn(l)
            else l.contains(word)
        }
    }

    private val blockedPackageHints = listOf(
        "bkash", "nagad", "rocket", "bank", "wallet", "paytm", "phonepe", "paisa", "paypal",
        "authenticator", "com.android.settings", "packageinstaller", "permissioncontroller",
        "password", "keepass", "bitwarden", "lastpass", "moe.shizuku",
    )

    fun isBlockedPackage(pkg: String): Boolean = blockedPackageHints.any { pkg.lowercase().contains(it) }
}
