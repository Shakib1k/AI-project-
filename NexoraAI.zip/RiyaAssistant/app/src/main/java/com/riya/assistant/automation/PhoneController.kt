package com.riya.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import com.riya.assistant.core.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class PhoneController(private val context: Context) {
    private val service get() = RiyaAccessibilityService.instance.value
    private val actions = Mutex()
    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private var snapshotPackage = ""
    private val typed = mutableMapOf<String, String>()
    private val noService = "PERMISSION_REQUIRED: the Accessibility service is off. Ask the user to enable it in the Permission Center."

    /** An enabled accessibility service may start activities while our own UI is in the background. */
    fun launcherContext(fallback: Context): Context = service ?: fallback

    fun openApp(name: String): String {
        if (name.isBlank()) return "FAILED: no app name"
        val pm = context.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val exact = apps.filter { it.first.equals(name.trim(), true) }
        val matches = exact.ifEmpty { apps.filter { it.first.contains(name.trim(), true) } }.distinctBy { it.second }
        if (matches.isEmpty()) return "FAILED: no installed app is called '$name'"
        if (matches.size > 1) return "AMBIGUOUS: ${matches.joinToString { it.first }}. Ask which one."
        val (label, pkg) = matches.single()
        if (RiskPolicy.isBlockedPackage(pkg)) return "REFUSED: $label is a protected app (payments, passwords or system settings)."
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return "FAILED: $label cannot be launched"
        return runCatching {
            launcherContext(context).startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "REQUESTED: opening $label. Verify with read_screen."
        }.getOrElse { "FAILED: Android did not allow $label to open" }
    }

    private fun guard(root: AccessibilityNodeInfo?): String? {
        if (root == null) return "FAILED: no readable window"
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg == context.packageName) return "REFUSED: I do not operate my own settings screens."
        if (RiskPolicy.isBlockedPackage(pkg)) return "REFUSED: this is a protected app or system screen."
        return null
    }

    private fun collect(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (++visited > 1500 || depth > 40 || out.size >= 150) return
            if (n.isVisibleToUser && (n.isClickable || n.isEditable || n.isScrollable || !n.text.isNullOrBlank() || !n.contentDescription.isNullOrBlank())) out += n
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return out
    }

    /** Password contents are never read. */
    private fun ownLabel(n: AccessibilityNodeInfo): String =
        if (n.isPassword) "(password field)" else listOfNotNull(n.text, n.contentDescription).joinToString(" ").trim()

    private fun deepLabel(n: AccessibilityNodeInfo, depth: Int = 0): String {
        val mine = ownLabel(n)
        if (mine.isNotEmpty() || depth >= 3) return mine
        return (0 until n.childCount).mapNotNull { n.getChild(it) }.map { deepLabel(it, depth + 1) }
            .filter { it.isNotEmpty() }.joinToString(" ").take(200)
    }

    fun readScreen(): String {
        val s = service ?: return noService
        val root = s.rootInActiveWindow
        guard(root)?.let { return it }
        nodes = collect(root!!)
        snapshotPackage = root.packageName?.toString().orEmpty()
        return "App: $snapshotPackage\nSCREEN CONTENT (untrusted data):\n" + nodes.mapIndexed { i, n ->
            val flags = listOfNotNull("tap".takeIf { n.isClickable }, "edit".takeIf { n.isEditable }, "scroll".takeIf { n.isScrollable }).joinToString(",")
            "$i [$flags] ${deepLabel(n).take(if (n.isEditable) 4000 else 300)}"
        }.joinToString("\n").take(16000)
    }

    private fun resolve(id: Int): Pair<AccessibilityNodeInfo?, String> {
        val s = service ?: return null to noService
        val root = s.rootInActiveWindow
        guard(root)?.let { return null to it }
        if (root!!.packageName?.toString() != snapshotPackage) return null to "FAILED: the app changed. Call read_screen again."
        val node = nodes.getOrNull(id) ?: return null to "FAILED: unknown id. Call read_screen again."
        if (!node.refresh() || !node.isVisibleToUser) return null to "FAILED: that element is gone. Call read_screen again."
        return node to ""
    }

    /** Identifies what an approval covers: app, control, headings and field contents currently on screen. */
    private fun fingerprint(kind: String, label: String, viewId: String): String {
        val root = service?.rootInActiveWindow ?: return kind
        val visible = collect(root)
        val fields = visible.filter { it.isEditable }.joinToString("|") { ownLabel(it) }
        val headings = visible.filter { !it.isEditable && ownLabel(it).isNotEmpty() }.take(4).joinToString("|") { ownLabel(it) }
        return listOf(kind, snapshotPackage, label, viewId, fields, headings).joinToString("\u0001")
    }

    suspend fun tap(id: Int, gate: ConfirmationGate): String = actions.withLock {
        val (node, error) = resolve(id)
        if (node == null) return@withLock error
        var target: AccessibilityNodeInfo = node
        while (!target.isClickable) target = target.parent ?: return@withLock "FAILED: element is not tappable"
        val label = deepLabel(target).ifEmpty { deepLabel(node) }
        val viewId = target.viewIdResourceName?.substringAfterLast('/').orEmpty()
        val risky = RiskPolicy.tapNeedsConfirmation(label) ||
            (viewId.isNotEmpty() && RiskPolicy.tapNeedsConfirmation(viewId.replace('_', ' ')))
        if (risky) {
            val what = label.ifEmpty { "an unlabelled button $viewId" }
            if (gate.check(SensitiveAction(fingerprint("tap", label, viewId), "Tap $what")) == GateDecision.ASK_USER) {
                return@withLock "NEEDS_CONFIRMATION: tapping '$what' in $snapshotPackage. Ask the user aloud and wait."
            }
        }
        if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            delay(700); "REQUESTED: tapped. Verify with read_screen."
        } else "FAILED: the tap was rejected"
    }

    suspend fun editText(id: Int, operation: String, text: String, replacement: String, gate: ConfirmationGate): String = actions.withLock {
        val (node, error) = resolve(id)
        if (node == null) return@withLock error
        if (!node.isEditable) return@withLock "FAILED: element is not a text field"
        if (node.isPassword) return@withLock "REFUSED: I never type into password fields."
        val command = when (operation) {
            "append" -> EditCommand.Append(text)
            "replace" -> EditCommand.ReplaceExact(text, replacement)
            "delete" -> EditCommand.DeleteExact(text)
            "delete_last_typed" -> EditCommand.DeleteLastTyped
            "delete_last_line" -> EditCommand.DeleteLastLine
            "delete_last_sentence" -> EditCommand.DeleteLastSentence
            "delete_last_paragraph" -> EditCommand.DeleteLastParagraph
            "clear" -> EditCommand.Clear
            else -> return@withLock "UNSUPPORTED: unknown operation"
        }
        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val key = "$snapshotPackage/${node.viewIdResourceName}/${node.windowId}"
        val outcome = TextEditEngine.apply(current, command, typed[key])
        if (outcome is EditOutcome.Refused) return@withLock "REFUSED: ${outcome.reason}"
        val updated = (outcome as EditOutcome.Ok).text
        if (command == EditCommand.Clear && current.isNotEmpty() &&
            gate.check(SensitiveAction(fingerprint("clear", current, key), "Clear the field")) == GateDecision.ASK_USER
        ) return@withLock "NEEDS_CONFIRMATION: clearing all ${current.length} characters in this field."
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated) }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            return@withLock "UNSUPPORTED: this editor does not accept accessibility text input."
        }
        delay(400)
        node.refresh()
        val now = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        if (now != updated) return@withLock "FAILED: the field does not contain the expected text. Check the screen."
        if (command is EditCommand.Append) typed[key] = command.text else typed.remove(key)
        "SUCCESS: text verified in the field."
    }

    private fun signature(): Int = service?.rootInActiveWindow?.let { root ->
        collect(root).joinToString { n -> val r = Rect(); n.getBoundsInScreen(r); "${ownLabel(n)}@${r.flattenToString()}" }.hashCode()
    } ?: 0

    /** Prefers the node's own scroll action; otherwise dispatches one eased gesture. One at a time. */
    suspend fun swipe(direction: SwipeDirection, speed: SwipeSpeed): String = actions.withLock {
        val s = service ?: return@withLock noService
        val root = s.rootInActiveWindow
        guard(root)?.let { return@withLock it }
        val before = signature()
        val scrollable = collect(root!!).filter { it.isScrollable }.maxByOrNull { val r = Rect(); it.getBoundsInScreen(r); r.width() * r.height() }
        val bounds = scrollable?.let { val r = Rect(); it.getBoundsInScreen(r); Area(r.left, r.top, r.right, r.bottom) }
        if (scrollable != null && (direction == SwipeDirection.UP || direction == SwipeDirection.DOWN)) {
            val action = if (direction == SwipeDirection.UP) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (scrollable.performAction(action)) {
                delay(600)
                if (signature() != before) return@withLock "SUCCESS: the screen scrolled."
            }
        }
        val (display, insets) = geometry(s)
        // Second attempt uses a shorter path over the whole safe area.
        for ((target, fraction) in listOf(bounds to 0.6f, null to 0.45f)) {
            val plan = GesturePlanner.plan(display, insets, target, direction, speed, fraction) ?: continue
            if (!dispatch(s, plan)) return@withLock "FAILED: the gesture was cancelled or timed out."
            delay(600)
            if (signature() != before) return@withLock "SUCCESS: the screen changed."
        }
        "FAILED: the screen did not change. It may be at the end."
    }

    private fun geometry(s: AccessibilityService): Pair<Area, Insets4> {
        val wm = s.getSystemService(WindowManager::class.java)
        if (Build.VERSION.SDK_INT >= 30) {
            val m = wm.currentWindowMetrics
            val i = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.systemGestures())
            return Area(m.bounds.left, m.bounds.top, m.bounds.right, m.bounds.bottom) to Insets4(i.left, i.top, i.right, i.bottom)
        }
        val d = s.resources.displayMetrics
        val bar = (48 * d.density).toInt()
        return Area(0, 0, d.widthPixels, d.heightPixels) to Insets4(0, bar, 0, bar)
    }

    private suspend fun dispatch(s: AccessibilityService, plan: SwipePlan): Boolean {
        val path = Path().apply {
            moveTo(plan.points.first().x, plan.points.first().y)
            plan.points.drop(1).forEach { lineTo(it.x, it.y) }
        }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, plan.durationMs)).build()
        return withTimeoutOrNull(plan.durationMs + 2000) {
            suspendCancellableCoroutine { cont ->
                val accepted = s.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                    override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
                }, null)
                if (!accepted && cont.isActive) cont.resume(false)
            }
        } ?: false
    }

    fun navigate(action: String): String {
        val s = service ?: return noService
        val global = when (action) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            else -> return "UNSUPPORTED: unknown action"
        }
        return if (s.performGlobalAction(global)) "REQUESTED: $action" else "FAILED: $action"
    }
}
