package com.riya.assistant.core

enum class Consent { YES, NO, UNCLEAR }

/**
 * Classifies the user's spoken reply to a confirmation question.
 * Deliberately strict: the whole reply must consist of approval words.
 * "হ্যাঁ, কিন্তু আগে নামটা বদলাও" is UNCLEAR, so nothing is executed.
 */
object ConsentClassifier {
    private val negative = setOf(
        "না", "নাহ", "থাক", "বাতিল", "থামো", "পাঠিও", "করো না",
        "नहीं", "नही", "मत", "रुको", "रद्द",
        "no", "nope", "dont", "don't", "cancel", "stop", "wait", "na", "nahi", "mat",
    )
    private val affirmative = setOf(
        "হ্যাঁ", "হ্যা", "হা", "হুম", "জি", "আচ্ছা", "ঠিক",
        "हाँ", "हां", "हा", "जी", "ठीक",
        "yes", "yeah", "yep", "ok", "okay", "sure", "confirm", "confirmed", "haan", "ha", "ji",
    )
    private val actionWords = setOf(
        "পাঠাও", "পাঠান", "দাও", "দিন", "করো", "করুন", "কর", "আছে", "বস", "আপলোড", "পাবলিশ", "ডিলিট", "মুছে", "ফেলো",
        "भेजो", "भेज", "दो", "करो", "कर", "है", "अपलोड", "पब्लिश", "डिलीट",
        "send", "it", "do", "go", "ahead", "please", "upload", "publish", "delete", "post", "pathao", "koro", "karo", "bhejo",
    )
    private val strongPhrases = setOf(
        "পাঠাও", "পাঠিয়ে দাও", "করে দাও", "भेज दो", "send it", "go ahead", "do it", "confirm",
    )

    fun classify(utterance: String): Consent {
        val clean = normalize(utterance)
        if (clean.isEmpty()) return Consent.UNCLEAR
        val words = clean.split(" ")
        if (words.any { it in negative }) return Consent.NO
        if (clean in strongPhrases.map(::normalize)) return Consent.YES
        val yes = affirmative.map(::normalize).toSet()
        val allowed = yes + actionWords.map(::normalize)
        return if (words.first() in yes && words.all { it in allowed }) Consent.YES else Consent.UNCLEAR
    }

    private fun normalize(s: String): String =
        java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFC)
            .replace(Regex("[,.!?;:।\"…]"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
}
