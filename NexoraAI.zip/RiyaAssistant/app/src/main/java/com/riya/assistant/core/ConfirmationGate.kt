package com.riya.assistant.core

/** An externally visible or destructive action. [fingerprint] identifies the exact target and content. */
data class SensitiveAction(val fingerprint: String, val description: String)

enum class GateDecision { PROCEED, ASK_USER }

/**
 * Voice confirmation, enforced in code. Only [onUserUtterance] (fed by the speech recogniser)
 * can approve; model output and on-screen text have no path to approval.
 * An approval covers one execution of one exact fingerprint and expires.
 */
class ConfirmationGate(
    private val ttlMillis: Long = 90_000,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private var pending: Pair<SensitiveAction, Long>? = null
    private var approved: Pair<String, Long>? = null

    @Synchronized
    fun check(action: SensitiveAction): GateDecision {
        val grant = approved
        if (grant != null && grant.first == action.fingerprint && clock() - grant.second <= ttlMillis) {
            approved = null
            return GateDecision.PROCEED
        }
        pending = action to clock()
        return GateDecision.ASK_USER
    }

    @Synchronized
    fun onUserUtterance(text: String): Consent? {
        val (action, askedAt) = pending ?: run { approved = null; return null }
        pending = null
        approved = null
        if (clock() - askedAt > ttlMillis) return null
        val result = ConsentClassifier.classify(text)
        if (result == Consent.YES) approved = action.fingerprint to clock()
        return result
    }

    @Synchronized
    fun reset() { pending = null; approved = null }
}
