package com.riya.assistant.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.riya.assistant.automation.PhoneController
import com.riya.assistant.core.*
import com.riya.assistant.data.MemoryRepository
import com.riya.assistant.data.SettingsRepository
import kotlinx.serialization.json.*

/** The complete allowlist of things the model can do. There is no shell or arbitrary-intent tool. */
class Tools(
    private val context: Context,
    private val phone: PhoneController,
    private val memory: MemoryRepository,
    private val settings: SettingsRepository,
    private val gate: ConfirmationGate,
) {
    private fun decl(name: String, description: String, vararg params: Pair<String, String>, required: List<String> = params.map { it.first }) =
        buildJsonObject {
            put("name", name); put("description", description)
            if (params.isNotEmpty()) putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") { params.forEach { (k, d) -> putJsonObject(k) { put("type", "string"); put("description", d) } } }
                putJsonArray("required") { required.forEach { add(it) } }
            }
        }

    val declarations = JsonArray(listOf(
        decl("open_app", "Open an installed app by its visible name.", "name" to "App name, e.g. Telegram"),
        decl("web_search", "Search the web in the browser.", "query" to "Search words", "type" to "web, images or videos", required = listOf("query")),
        decl("read_screen", "List the visible UI elements with ids. Call before tapping or typing, and again afterwards to verify."),
        decl("tap", "Tap an element id from the latest read_screen.", "id" to "Element id"),
        decl("edit_text", "Edit a text field.", "id" to "Field id",
            "operation" to "append, replace, delete, delete_last_typed, delete_last_line, delete_last_sentence, delete_last_paragraph, clear",
            "text" to "Text to append, or exact text to find", "replacement" to "New text for replace", required = listOf("id", "operation")),
        decl("swipe", "Scroll or swipe. up means the finger moves up, which shows content further down.", "direction" to "up, down, left or right",
            "speed" to "gentle, normal or fast", required = listOf("direction")),
        decl("navigate", "Press a system navigation button.", "action" to "back or home"),
        decl("remember", "Save something. Use only when the user asks you to remember or save it.", "category" to "Memory category", "title" to "Short title", "content" to "Exact content"),
        decl("recall", "Search saved memory, e.g. for saved links. An empty query lists recent items.", "query" to "Search words"),
    ))

    suspend fun execute(call: FunctionCall): String {
        fun arg(key: String) = (call.args[key] as? JsonPrimitive)?.contentOrNull.orEmpty()
        return when (call.name) {
            "open_app" -> phone.openApp(arg("name"))
            "web_search" -> search(arg("query"), arg("type"))
            "read_screen" -> phone.readScreen()
            "tap" -> phone.tap(arg("id").toIntOrNull() ?: -1, gate)
            "edit_text" -> phone.editText(arg("id").toIntOrNull() ?: -1, arg("operation"), arg("text"), arg("replacement"), gate)
            "swipe" -> {
                val direction = SwipeDirection.entries.firstOrNull { it.name.equals(arg("direction"), true) }
                    ?: return "FAILED: unknown direction"
                val speed = SwipeSpeed.entries.firstOrNull { it.name.equals(arg("speed"), true) } ?: settings.current().swipeSpeed
                phone.swipe(direction, speed)
            }
            "navigate" -> phone.navigate(arg("action"))
            "remember" -> if (memory.save(arg("category"), arg("title"), arg("content"))) "SUCCESS: saved" else "FAILED: not enough storage"
            "recall" -> memory.search(arg("query")).joinToString("\n") { "[${it.category}] ${it.title}: ${it.content.take(1000)}" }
                .ifEmpty { "Nothing saved matches. Ask the user instead of guessing." }
            else -> "UNSUPPORTED: unknown tool"
        }
    }

    private fun search(query: String, type: String): String {
        if (query.isBlank()) return "FAILED: empty query"
        val url = Uri.parse("https://www.google.com/search").buildUpon().appendQueryParameter("q", query).apply {
            if (type == "images") appendQueryParameter("tbm", "isch")
            if (type == "videos") appendQueryParameter("tbm", "vid")
        }.build()
        return runCatching {
            phone.launcherContext(context).startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "REQUESTED: search opened. Use read_screen to verify and read results."
        }.getOrElse { "FAILED: no browser could be opened" }
    }
}
