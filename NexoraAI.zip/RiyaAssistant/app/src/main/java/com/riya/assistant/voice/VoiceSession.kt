package com.riya.assistant.voice

import android.os.SystemClock
import com.riya.assistant.ai.Assistant
import com.riya.assistant.core.ConfirmationGate
import com.riya.assistant.core.ProactivePolicy
import com.riya.assistant.data.Settings
import com.riya.assistant.data.SettingsRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

enum class OrbState { IDLE, LISTENING, THINKING, WORKING, SPEAKING }
data class SessionStatus(val state: OrbState = OrbState.IDLE, val active: Boolean = false, val message: String = "")

class VoiceSession(
    private val assistant: Assistant,
    private val input: SpeechInput,
    private val speaker: Speaker,
    private val bargeIn: BargeInMonitor,
    private val gate: ConfirmationGate,
    private val settings: SettingsRepository,
) {
    private val _status = MutableStateFlow(SessionStatus())
    val status = _status.asStateFlow()
    private var job: Job? = null
    private var current: Job? = null

    fun start(scope: CoroutineScope, onEnded: () -> Unit) {
        if (job?.isActive == true) return
        assistant.reset(); gate.reset()
        _status.value = SessionStatus(OrbState.LISTENING, true)
        job = scope.launch(Dispatchers.Main) {
            var note = ""
            try { note = loop() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { note = e.message ?: "The voice session failed." }
            finally {
                gate.reset()
                _status.value = SessionStatus(message = note)
                onEnded()
            }
        }
    }

    fun stop() { job?.cancel() }

    /** Tap on the orb: stop the current speech or request and listen again. */
    fun interrupt() { current?.cancel() }

    private suspend fun loop(): String {
        var lastHeard = SystemClock.elapsedRealtime()
        var proactiveSent = 0
        var errors = 0
        while (true) {
            val s = settings.current()
            show(OrbState.LISTENING)
            when (val heard = input.listen(s.listenLanguage)) {
                is Heard.Error -> {
                    if (++errors >= 3) return heard.message
                    show(OrbState.LISTENING, heard.message); delay(1500)
                }
                Heard.Silence -> {
                    val silent = SystemClock.elapsedRealtime() - lastHeard
                    if (silent > s.timeoutMinutes * 60_000L) return "Session ended after silence."
                    // Nudges are spaced: silence is measured per message already sent.
                    val required = silent / (proactiveSent + 1)
                    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    if (ProactivePolicy.shouldSpeak(s.proactive, required, proactiveSent, hour, s.doNotDisturb)) {
                        proactiveSent++
                        say(nudge(s), s)
                    }
                    delay(400)
                }
                is Heard.Text -> {
                    errors = 0
                    val consent = gate.onUserUtterance(heard.value)
                    if (s.requireName && consent == null && !heard.value.contains(s.name, true)) continue
                    lastHeard = SystemClock.elapsedRealtime(); proactiveSent = 0
                    coroutineScope {
                        val turn = launch {
                            show(OrbState.THINKING)
                            val answer = try { assistant.reply(heard.value, consent) { show(OrbState.WORKING) } }
                                catch (e: CancellationException) { throw e }
                                catch (e: Exception) { show(OrbState.IDLE, e.message.orEmpty()); delay(1500); return@launch }
                            say(answer, s)
                        }
                        current = turn
                        turn.join()
                    }
                }
            }
        }
    }

    private suspend fun say(text: String, s: Settings) {
        show(OrbState.SPEAKING, text)
        if (!s.spokenReplies) { delay(1500); return }
        coroutineScope {
            // A playback failure is reported as a notice; it must not end the whole session.
            val speech = async {
                try { speaker.speak(text, s) }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { e.message ?: "Speech playback failed." }
            }
            val monitor = if (s.bargeIn && bargeIn.supported) launch {
                delay(300)
                if (bargeIn.awaitVoice()) speech.cancel()
            } else null
            speech.join()
            monitor?.cancelAndJoin()
            if (!speech.isCancelled) speech.await()?.let { show(OrbState.SPEAKING, it) }
        }
    }

    private fun show(state: OrbState, message: String = "") { _status.value = SessionStatus(state, true, message) }

    private fun nudge(s: Settings) = when (s.listenLanguage.take(2)) {
        "bn" -> "বস, কী হলো? কথা বলছেন না কেন? 😊"
        "hi" -> "बॉस, क्या हुआ? आप बात क्यों नहीं कर रहे? 😊"
        else -> "${s.address}, are you still there? I'm listening."
    }
}
