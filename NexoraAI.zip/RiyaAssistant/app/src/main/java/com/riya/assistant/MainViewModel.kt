package com.riya.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.riya.assistant.data.Settings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = (app as RiyaApp).container.settings
    /** Null until DataStore has loaded, so the saved theme never flashes to the default. */
    val settings = repository.flow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null as Settings?)
    fun update(change: (Settings) -> Settings) { viewModelScope.launch { repository.update(change) } }
}
