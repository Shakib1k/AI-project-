package com.riya.assistant.ai

import com.riya.assistant.core.GeminiModel
import com.riya.assistant.core.GeminiProtocol
import com.riya.assistant.data.SecureKeyStore
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class GeminiException(message: String) : IOException(message)

/** REST client. The key travels only in a header; no request logging is installed. */
class GeminiClient(private val keys: SecureKeyStore) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS).callTimeout(120, TimeUnit.SECONDS).build()
    private val base = "https://generativelanguage.googleapis.com/v1beta"

    suspend fun listModels(): List<GeminiModel> {
        val all = mutableListOf<GeminiModel>()
        var token: String? = null
        var pages = 0
        do {
            val url = "$base/models".toHttpUrl().newBuilder().addQueryParameter("pageSize", "1000")
            token?.let { url.addQueryParameter("pageToken", it) }
            val (models, next) = GeminiProtocol.parseModels(execute(Request.Builder().url(url.build())))
            all += models; token = next
        } while (token != null && ++pages < 10)
        return all
    }

    suspend fun generate(model: String, body: String): String {
        require(Regex("[A-Za-z0-9._-]+").matches(model)) { "Invalid model ID" }
        return execute(Request.Builder().url("$base/models/$model:generateContent").post(body.toRequestBody("application/json".toMediaType())))
    }

    private suspend fun execute(builder: Request.Builder): String {
        val key = keys.load() ?: throw GeminiException("No Gemini API key is saved.")
        val call = http.newCall(builder.header("x-goog-api-key", key).build())
        return suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(GeminiException("Network error: ${e.javaClass.simpleName}"))
                }
                override fun onResponse(call: Call, response: Response) {
                    val result = runCatching {
                        response.use {
                            val text = it.body?.string().orEmpty()
                            if (!it.isSuccessful) throw GeminiException(
                                when (it.code) {
                                    400 -> "Request rejected (400). Check the model ID and API key."
                                    401, 403 -> "API key not accepted (${it.code})."
                                    404 -> "Model not found (404)."
                                    429 -> "Quota or rate limit reached (429)."
                                    else -> "Gemini error ${it.code}."
                                },
                            )
                            text
                        }
                    }
                    if (cont.isActive) result.fold({ cont.resume(it) }, { cont.resumeWithException(it) })
                }
            })
        }
    }
}
