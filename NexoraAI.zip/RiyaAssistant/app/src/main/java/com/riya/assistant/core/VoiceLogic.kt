package com.riya.assistant.core

/** Script-based language hint used to choose a TTS locale. Romanised Banglish/Hinglish maps to English. */
object LanguageDetector {
    fun localeTag(text: String, fallback: String = "en-IN"): String {
        var bn = 0; var hi = 0; var en = 0
        for (c in text) when (c) {
            in 'ঀ'..'৿' -> bn++
            in 'ऀ'..'ॿ' -> hi++
            in 'a'..'z', in 'A'..'Z' -> en++
        }
        val max = maxOf(bn, hi, en)
        return when {
            max == 0 -> fallback
            bn == max -> "bn-BD"
            hi == max -> "hi-IN"
            else -> "en-IN"
        }
    }
}

/**
 * Adaptive energy detector for barge-in. Requires several consecutive loud frames so that a click
 * does not cut the assistant off. Device echo cancellation does the main work of removing our own voice.
 */
class VoiceActivityDetector(
    private val minRms: Double = 900.0,
    private val ratio: Double = 3.0,
    private val framesNeeded: Int = 8,
) {
    private var noise = 200.0
    private var run = 0

    fun accept(frame: ShortArray, length: Int = frame.size): Boolean {
        if (length <= 0) return false
        var sum = 0.0
        for (i in 0 until length) sum += frame[i].toDouble() * frame[i]
        val rms = kotlin.math.sqrt(sum / length)
        if (rms > maxOf(minRms, noise * ratio)) run++ else { run = 0; noise = noise * 0.95 + rms * 0.05 }
        return run >= framesNeeded
    }
}

data class ProactiveConfig(
    val enabled: Boolean = false,
    val silenceSeconds: Int = 45,
    val maxMessages: Int = 2,
    val quietStartHour: Int = 22,
    val quietEndHour: Int = 7,
)

object ProactivePolicy {
    fun isQuietHour(hour: Int, start: Int, end: Int): Boolean = when {
        start == end -> false
        start < end -> hour in start until end
        else -> hour >= start || hour < end
    }

    fun shouldSpeak(c: ProactiveConfig, silentMs: Long, sentSoFar: Int, hour: Int, doNotDisturb: Boolean): Boolean =
        c.enabled && !doNotDisturb && sentSoFar < c.maxMessages &&
            silentMs >= c.silenceSeconds * 1000L && !isQuietHour(hour, c.quietStartHour, c.quietEndHour)
}

/** Splits long replies so speech can start early and be paused between chunks. */
object SpeechChunker {
    fun chunk(text: String, max: Int = 400): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        for (sentence in text.split(Regex("(?<=[.!?।\n])\\s*")).filter { it.isNotBlank() }) {
            if (current.isNotEmpty() && current.length + sentence.length + 1 > max) {
                out += current.toString(); current.clear()
            }
            var rest = sentence.trim()
            while (rest.length > max) {
                var cut = rest.lastIndexOf(' ', max).takeIf { it > 0 } ?: max
                if (cut < rest.length && Character.isLowSurrogate(rest[cut])) cut--
                out += rest.substring(0, cut); rest = rest.substring(cut).trim()
            }
            if (current.isNotEmpty()) current.append(' ')
            current.append(rest)
        }
        if (current.isNotBlank()) out += current.toString()
        return out
    }
}
