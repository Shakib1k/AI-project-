package com.riya.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.riya.assistant.core.ProactiveConfig
import com.riya.assistant.core.SwipeSpeed
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

enum class Personality(val label: String, val geminiVoice: String, val style: String, val pitch: Float) {
    CUTE("Cute Female", "Leda", "very cute, sweet, soft, warm, gentle, friendly young adult woman", 1.2f),
    CALM("Normal Cute Female", "Aoede", "calm, soft, friendly and professional adult woman", 1.05f),
}

data class Settings(
    val name: String = "Riya",
    val address: String = "Boss",
    val requireName: Boolean = false,
    val model: String = "",
    val customModels: Set<String> = emptySet(),
    val temperature: Float = 0.7f,
    val maxTokens: Int = 4096,
    val listenLanguage: String = "bn-BD",
    val replyLanguage: String = "Same as the user",
    val personality: Personality = Personality.CUTE,
    val useNeuralVoice: Boolean = true,
    val ttsModel: String = "gemini-3.8-flash-tts",
    val geminiVoice: String = "",
    val androidVoice: String = "",
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val spokenReplies: Boolean = true,
    val bargeIn: Boolean = true,
    val doNotDisturb: Boolean = false,
    val timeoutMinutes: Int = 5,
    val proactive: ProactiveConfig = ProactiveConfig(),
    val swipeSpeed: SwipeSpeed = SwipeSpeed.NORMAL,
    val theme: String = "obsidian_red",
) {
    val activeVoice get() = geminiVoice.ifBlank { personality.geminiVoice }
}

class SettingsRepository(private val context: Context) {
    private object K {
        val name = stringPreferencesKey("name"); val address = stringPreferencesKey("address")
        val requireName = booleanPreferencesKey("require_name"); val model = stringPreferencesKey("model")
        val custom = stringSetPreferencesKey("custom_models"); val temperature = floatPreferencesKey("temperature")
        val maxTokens = intPreferencesKey("max_tokens"); val listen = stringPreferencesKey("listen_lang")
        val reply = stringPreferencesKey("reply_lang"); val personality = stringPreferencesKey("personality")
        val neural = booleanPreferencesKey("neural"); val ttsModel = stringPreferencesKey("tts_model")
        val gVoice = stringPreferencesKey("gemini_voice"); val aVoice = stringPreferencesKey("android_voice")
        val rate = floatPreferencesKey("rate"); val pitch = floatPreferencesKey("pitch")
        val spoken = booleanPreferencesKey("spoken"); val bargeIn = booleanPreferencesKey("barge_in")
        val dnd = booleanPreferencesKey("dnd"); val timeout = intPreferencesKey("timeout")
        val pOn = booleanPreferencesKey("p_on"); val pSilence = intPreferencesKey("p_silence")
        val pMax = intPreferencesKey("p_max"); val qStart = intPreferencesKey("q_start"); val qEnd = intPreferencesKey("q_end")
        val swipe = stringPreferencesKey("swipe"); val theme = stringPreferencesKey("theme")
    }

    val flow = context.dataStore.data.map(::read)
    suspend fun current() = flow.first()

    private fun read(p: Preferences): Settings {
        val d = Settings(); val pd = d.proactive
        return Settings(
            p[K.name] ?: d.name, p[K.address] ?: d.address, p[K.requireName] ?: d.requireName,
            p[K.model] ?: d.model, p[K.custom] ?: d.customModels, p[K.temperature] ?: d.temperature,
            p[K.maxTokens] ?: d.maxTokens, p[K.listen] ?: d.listenLanguage, p[K.reply] ?: d.replyLanguage,
            Personality.entries.firstOrNull { it.name == p[K.personality] } ?: d.personality,
            p[K.neural] ?: d.useNeuralVoice, p[K.ttsModel] ?: d.ttsModel, p[K.gVoice] ?: d.geminiVoice,
            p[K.aVoice] ?: d.androidVoice, p[K.rate] ?: d.speechRate, p[K.pitch] ?: d.pitch,
            p[K.spoken] ?: d.spokenReplies, p[K.bargeIn] ?: d.bargeIn, p[K.dnd] ?: d.doNotDisturb,
            p[K.timeout] ?: d.timeoutMinutes,
            ProactiveConfig(p[K.pOn] ?: pd.enabled, p[K.pSilence] ?: pd.silenceSeconds, p[K.pMax] ?: pd.maxMessages,
                p[K.qStart] ?: pd.quietStartHour, p[K.qEnd] ?: pd.quietEndHour),
            SwipeSpeed.entries.firstOrNull { it.name == p[K.swipe] } ?: d.swipeSpeed,
            p[K.theme] ?: d.theme,
        )
    }

    suspend fun update(change: (Settings) -> Settings) {
        context.dataStore.edit { p ->
            val s = change(read(p))
            p[K.name] = s.name; p[K.address] = s.address; p[K.requireName] = s.requireName; p[K.model] = s.model
            p[K.custom] = s.customModels; p[K.temperature] = s.temperature; p[K.maxTokens] = s.maxTokens
            p[K.listen] = s.listenLanguage; p[K.reply] = s.replyLanguage; p[K.personality] = s.personality.name
            p[K.neural] = s.useNeuralVoice; p[K.ttsModel] = s.ttsModel; p[K.gVoice] = s.geminiVoice
            p[K.aVoice] = s.androidVoice; p[K.rate] = s.speechRate; p[K.pitch] = s.pitch
            p[K.spoken] = s.spokenReplies; p[K.bargeIn] = s.bargeIn; p[K.dnd] = s.doNotDisturb; p[K.timeout] = s.timeoutMinutes
            p[K.pOn] = s.proactive.enabled; p[K.pSilence] = s.proactive.silenceSeconds; p[K.pMax] = s.proactive.maxMessages
            p[K.qStart] = s.proactive.quietStartHour; p[K.qEnd] = s.proactive.quietEndHour
            p[K.swipe] = s.swipeSpeed.name; p[K.theme] = s.theme
        }
    }
}
