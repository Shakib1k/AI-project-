package com.riya.assistant

import com.riya.assistant.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test fun clearApprovalIsAccepted() {
        listOf("হ্যাঁ, পাঠাও।", "হ্যাঁ, আপলোড করো", "yes send it", "हाँ भेज दो", "ঠিক আছে", "go ahead")
            .forEach { assertEquals(it, Consent.YES, ConsentClassifier.classify(it)) }
    }
    @Test fun refusalAndConditionalRepliesNeverApprove() {
        assertEquals(Consent.NO, ConsentClassifier.classify("না, পাঠিও না"))
        assertEquals(Consent.NO, ConsentClassifier.classify("yes... no wait"))
        assertEquals(Consent.UNCLEAR, ConsentClassifier.classify("হ্যাঁ কিন্তু আগে নামটা বদলাও"))
        assertEquals(Consent.UNCLEAR, ConsentClassifier.classify("ওটা করো"))
        assertEquals(Consent.UNCLEAR, ConsentClassifier.classify(""))
    }

    private val send = SensitiveAction("telegram|send|hello", "send hello")

    @Test fun gateIsSingleUseAndBoundToExactAction() {
        val gate = ConfirmationGate()
        assertEquals(GateDecision.ASK_USER, gate.check(send))
        gate.onUserUtterance("yes")
        assertEquals(GateDecision.ASK_USER, gate.check(send.copy(fingerprint = "telegram|send|other")))
        gate.reset(); gate.check(send); gate.onUserUtterance("yes")
        assertEquals(GateDecision.PROCEED, gate.check(send))
        assertEquals(GateDecision.ASK_USER, gate.check(send))
    }
    @Test fun gateIgnoresYesGivenBeforeTheQuestion() {
        val gate = ConfirmationGate()
        gate.onUserUtterance("yes")
        assertEquals(GateDecision.ASK_USER, gate.check(send))
        assertEquals(GateDecision.ASK_USER, gate.check(send))
    }
    @Test fun gateApprovalExpiresAndDropsOnNewTopic() {
        var now = 0L
        val gate = ConfirmationGate(1000) { now }
        gate.check(send); gate.onUserUtterance("yes"); now = 2000
        assertEquals(GateDecision.ASK_USER, gate.check(send))
        gate.onUserUtterance("yes"); gate.onUserUtterance("what is the weather")
        assertEquals(GateDecision.ASK_USER, gate.check(send))
    }

    @Test fun riskPolicy() {
        listOf("Send", "Delete for everyone", "Publish", "পাঠান", "", "Post", "OK", "Join channel").forEach { assertTrue(it, RiskPolicy.tapNeedsConfirmation(it)) }
        listOf("Search", "Chats", "Postal code", "Back").forEach { assertFalse(it, RiskPolicy.tapNeedsConfirmation(it)) }
        assertTrue(RiskPolicy.isBlockedPackage("com.bKash.customerapp"))
        assertFalse(RiskPolicy.isBlockedPackage("org.telegram.messenger"))
    }

    @Test fun swipesStayInsideSafeAreaOnSeveralScreens() {
        for ((w, h) in listOf(720 to 1600, 1080 to 2400, 2400 to 1080)) for (d in SwipeDirection.entries) {
            val plan = GesturePlanner.plan(Area(0, 0, w, h), Insets4(0, 80, 0, 120), null, d, SwipeSpeed.NORMAL)!!
            assertTrue(plan.points.all { it.x > 0 && it.x < w && it.y > 80 && it.y < h - 120 })
            val a = plan.points.first(); val b = plan.points.last()
            when (d) {
                SwipeDirection.UP -> assertTrue(b.y < a.y)
                SwipeDirection.DOWN -> assertTrue(b.y > a.y)
                SwipeDirection.LEFT -> assertTrue(b.x < a.x)
                SwipeDirection.RIGHT -> assertTrue(b.x > a.x)
            }
        }
    }
    @Test fun offscreenTargetIsRejected() {
        assertNull(GesturePlanner.plan(Area(0, 0, 1080, 2400), Insets4(0, 0, 0, 0), Area(0, 3000, 1080, 3200), SwipeDirection.UP, SwipeSpeed.FAST))
    }

    private fun ok(o: EditOutcome) = (o as EditOutcome.Ok).text

    @Test fun smartDelete() {
        assertEquals("one\ntwo", ok(TextEditEngine.apply("one\ntwo\nthree\n", EditCommand.DeleteLastLine)))
        assertEquals("আমি ভালো।", ok(TextEditEngine.apply("আমি ভালো। তুমি কেমন?", EditCommand.DeleteLastSentence)))
        assertEquals("a\nb", ok(TextEditEngine.apply("a\nb\n\nc\nd", EditCommand.DeleteLastParagraph)))
        assertEquals("keep ", ok(TextEditEngine.apply("keep typed", EditCommand.DeleteLastTyped, "typed")))
    }
    @Test fun smartDeleteRefusesAmbiguity() {
        assertTrue(TextEditEngine.apply("hi hi", EditCommand.DeleteExact("hi")) is EditOutcome.Refused)
        assertTrue(TextEditEngine.apply("hello", EditCommand.DeleteExact("bye")) is EditOutcome.Refused)
        assertTrue(TextEditEngine.apply("user text", EditCommand.DeleteLastTyped) is EditOutcome.Refused)
    }

    @Test fun languageDetection() {
        assertEquals("bn-BD", LanguageDetector.localeTag("জি বস, আমি শুনছি।"))
        assertEquals("hi-IN", LanguageDetector.localeTag("बॉस, क्या हुआ?"))
        assertEquals("en-IN", LanguageDetector.localeTag("Tell me what you need"))
    }
    @Test fun vadNeedsSustainedSound() {
        val vad = VoiceActivityDetector()
        val loud = ShortArray(320) { 5000 }; val quiet = ShortArray(320) { 50 }
        repeat(7) { assertFalse(vad.accept(loud)) }
        assertFalse(vad.accept(quiet))
        repeat(7) { assertFalse(vad.accept(loud)) }
        assertTrue(vad.accept(loud))
    }
    @Test fun proactiveRules() {
        val c = ProactiveConfig(enabled = true, silenceSeconds = 30, maxMessages = 2)
        assertTrue(ProactivePolicy.shouldSpeak(c, 31_000, 0, 12, false))
        assertFalse(ProactivePolicy.shouldSpeak(c, 31_000, 2, 12, false))
        assertFalse(ProactivePolicy.shouldSpeak(c, 31_000, 0, 23, false))
        assertFalse(ProactivePolicy.shouldSpeak(c, 31_000, 0, 12, true))
        assertFalse(ProactivePolicy.shouldSpeak(ProactiveConfig(), 999_000, 0, 12, false))
    }
    @Test fun chunkerRespectsLimit() {
        val chunks = SpeechChunker.chunk("This is a sentence. ".repeat(100) + "x".repeat(900), 200)
        assertTrue(chunks.size > 1 && chunks.all { it.length <= 200 })
        assertTrue(SpeechChunker.chunk("   ").isEmpty())
    }

    @Test fun geminiParsing() {
        val (models, next) = GeminiProtocol.parseModels("""{"models":[{"name":"models/a","displayName":"A","supportedGenerationMethods":["generateContent"]},{"name":"models/a-tts","supportedGenerationMethods":["generateContent"]}],"nextPageToken":"n"}""")
        assertEquals("n", next); assertTrue(models[0].canChat); assertTrue(models[1].isTts && !models[1].canChat)
        val turn = GeminiProtocol.parseTurn("""{"candidates":[{"content":{"role":"model","parts":[{"text":"hidden","thought":true},{"text":"ok"},{"functionCall":{"name":"back","args":{}},"thoughtSignature":"s"}]}}]}""")
        assertEquals("ok", turn.text); assertEquals("back", turn.calls.single().name)
        assertTrue(turn.modelContent.toString().contains("thoughtSignature"))
        assertEquals("", GeminiProtocol.parseTurn("{}").text)
    }
    @Test fun ttsRequestShape() {
        val new = Json.parseToJsonElement(GeminiProtocol.ttsRequest("gemini-3.8-flash-tts", "hi", "Leda", "sweet")).toString()
        assertTrue(new.contains("speech_metadata") && new.contains("Leda"))
        assertTrue(GeminiProtocol.ttsRequest("older-tts", "hi", "Leda", "sweet").contains("Say in a sweet voice: hi"))
        assertEquals("QUJD" to "audio/wav", GeminiProtocol.parseAudio("""{"candidates":[{"content":{"parts":[{"inlineData":{"data":"QUJD","mimeType":"audio/wav"}}]}}]}"""))
    }
}
